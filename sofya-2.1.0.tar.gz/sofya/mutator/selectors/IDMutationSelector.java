/*
 * Copyright 2003-2006, Regents of the University of Nebraska
 *
 *  Licensed under the University of Nebraska Open Academic License,
 *  Version 1.0 (the "License"); you may not use this file except in
 *  compliance with the License. The License must be provided with
 *  the distribution of this software; if the license is absent from
 *  the distribution, please report immediately to galileo@cse.unl.edu
 *  and indicate where you obtained this software.
 *
 *  You may also obtain a copy of the License at:
 *
 *      http://sofya.unl.edu/LICENSE-1.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package sofya.mutator.selectors;

import sofya.mutator.MutationSelector;
import sofya.mutator.Mutation;
import sofya.mutator.Mutation.Variant;

import gnu.trove.TIntIntHashMap;

/**
 * Mutation selector that selects by ID.
 *
 * @author Alex Kinneer
 * @version 05/23/2006
 */
public class IDMutationSelector implements MutationSelector {
    /** Set of selected IDs. */
    private TIntIntHashMap ids;

    private IDMutationSelector() {
        throw new AssertionError("Illegal constructor");
    }

    /**
     * Creates a new mutation selector.
     *
     * @param ids Array of selected IDs.
     */
    public IDMutationSelector(ID[] ids) {
        int length = ids.length;
        for (int i = length - 1; i-- >= 0; ) {
            this.ids.put(ids[i].mId, ids[i].variant);
        }
    }

    /**
     * Creates a new mutation selector.
     *
     * @param ids Set of selected IDs, where each selected mutant
     * is mapped to a selected variant, if applicable.
     */
    public IDMutationSelector(TIntIntHashMap ids) {
        this.ids = ids;
    }

    public boolean isSelected(Mutation mutation) {
        return ids.containsKey(mutation.getID().asInt());
    }

    public Variant getVariant(Mutation mutation) {
        int variant = ids.get(mutation.getID().asInt());
        Variant[] vs = mutation.getVariants();
        if ((variant < 1) || (variant > vs.length)) {
            return mutation.getDefaultVariant();
        }
        else {
            return vs[variant - 1];
        }
    }

    public void setMutationCount(int count) {
        // This selector doesn't care
    }

    /**
     * Utility class to correlate mutants with selected variants.
     *
     * <p>Once created, an ID is immutable.</p>
     */
    public static final class ID {
        /** ID of the selected mutant. */
        public final int mId;
        /** Selected variant of the mutant, if applicable. */
        public final int variant;

        private ID() {
            throw new AssertionError("Illegal constructor");
        }

        /**
         * Creates a new mutant selection ID.
         *
         * @param mId Id of the selected mutant; the default variant
         * will be used if applicable.
         */
        public ID(int mId) {
            this.mId = mId;
            this.variant = 0;
        }

        /**
         * Creates a new mutant selection ID.
         *
         * @param mId Id of the selected mutant.
         * @param variant Selected variant of the mutant, if applicable.
         */
        public ID(int mId, int variant) {
            this.mId = mId;
            this.variant = variant;
        }

        public String toString() {
            return "[" + mId + ":" + variant + "]";
        }
    }
}
