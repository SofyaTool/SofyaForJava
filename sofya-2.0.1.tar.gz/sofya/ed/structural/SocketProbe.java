/*
 * Copyright 2003-Present, Regents of the University of Nebraska
 *
 *  Licensed under the University of Nebraska Open Academic License,
 *  Version 1.0 (the "License"); you may not use this file except in
 *  compliance with the License. The License must be provided with
 *  the distribution of this software; if the license is absent from
 *  the distribution, please report immediately to galileo@cse.unl.edu
 *  and indicate where you obtained this software.
 *
 *  You may also obtain a copy of the License at:
 *
 *      http://sofya.unl.edu/LICENSE-1.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package sofya.ed.structural;

import java.io.*;
import java.net.*;
import java.util.*;

import static sofya.base.SConstants.*;

import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.collections.MapIterator;

/**
 * The SocketProbe class is responsible for transmitting instrumentation trace
 * statements from the subject to the event dispatcher. It is calls to methods
 * implemented by this class which are actually inserted into subjects by the
 * instrumentor.
 *
 * <p>This class establishes a persistent socket connection to the event
 * dispatcher on a specified port and implements the instrumentation methods
 * which send trace messages to the dispatcher over that socket. The
 * instrumentor is responsible for inserting a call to the <code>start</code>
 * method of this class as the first executable instruction of a subject class.
 * This will create an instance of this class which has connected a socket to
 * the dispatcher and is kept alive as a daemon thread.
 *
 * <p>To enable this mechanism to work with the greatest possible genericity,
 * and to avoid naming and dynamic linking conflicts when an instrumented
 * dispatcher is being run as a subject, this class is handled in a special
 * fashion. When a dispatcher runs, it constructs a jar file which contains
 * this class (among others) and prepends the jar file to the bootstrap
 * classpath for the subject. Thus when a subject seeks to resolve a call to
 * the static methods implemented by this class, the first definition of the
 * class to be located by the class loader is the one provided on the bootstrap
 * classpath, including when the subject is an instrumented dispatcher. However,
 * since the bootstrap classpath contains no other Sofya related classes
 * (except SConstants, which as an* interface contains no code, and is
 * universally backwards compatible), all other subject classes will be found
 * by the class loader in their expected locations on the subject's own
 * classpath. Note that this also means that the SocketProbe runs inside the
 * same JVM that is running the subject, so the fact that an instrumented
 * dispatcher locates the shared SocketProbe before it locates its own is
 * not problematic (it will however copy its own SocketProbe
 * when constructing its own jar file for its subject).</p>
 *
 * <p>When the SocketProbe itself is instrumented, the instrumentor inserts
 * special calls to methods of the same name in a class named SocketProbeAlt.
 * That class is created dynamically by the invoking dispatcher at runtime, as a
 * clone of its SocketProbe, and shared in the same manner. This permits the
 * instrumented SocketProbe to call instrumentation methods that do not resolve
 * to itself and cause infinite recursion.</p>
 *
 * <p>With this mechanism it is possible to create a chain of dispatchers
 * executing other dispatchers as subjects, although intervention to set the
 * ports correctly is required beyond the first subject dispatcher. This is
 * likely only useful up to the second level of self analysis, as data
 * obtained from further chaining is redundant. (The first level of sel
 * analysis will provide trace information for the
 * {@link SocketProcessingStrategy#processProbesSynchronized} method
 * and the second level of self analysis will provide trace information for
 * {@link SocketProcessingStrategy#processProbes}).</p>
 *
 * @see sofya.ed.structural.ProgramEventDispatcher
 * @see sofya.ed.cfInstrumentor
 *
 * @author Alex Kinneer
 * @version 08/04/2006
 */
public final class SocketProbe implements Runnable {
    // TODO: Implement adaptive instrumentation features (structural)
    
    /** Conditional compilation debug flag. */
    private static final boolean DEBUG = false;

    /** Maximum number of methods for which byte arrays can be cached
        when handling optimized normal instrumentation. */
    private static final int BLOCK_ARRAY_CACHE_SIZE = 1000;

    /** Size of the array which records object sequence information
        when handling optimized sequence instrumentation. */
    private static final int SEQUENCE_ARRAY_SIZE = 16384;
    /** Constant which marks that the next element in the object
        sequence array contains the index to a new method signature. */
    protected static final int NEW_METHOD_MARKER = 0xFC000000;
    /** Constant which marks in the sequence array that the current
        method is exiting. */
    protected static final int BRANCH_EXIT_MARKER = 0xF8000000;
    // The markers above are safely distinct because they encode invalid
    // block/branch types and a block/branch ID of 0, which is also not
    // legal (numbering starts at 1)

    /** Default instrumentation is only incompatible with the JUnit
        event dispatcher. */
    private static int instMode = INST_COMPATIBLE;
    /** Indicates the type of program entity traced by the instrumentation
        in the subject. */
    private static int objType = TraceObjectType.IBASIC_BLOCK;

    /** Socket connection used to send trace messages. */
    private static Socket socket;
    /** Output stream obtained from the socket. */
    private static DataOutputStream socketOut;
    /** Lock used to synchronize output to the socket. */
    private static Object lock = new Object();

    /** Socket for receiving/exchanging synchronization signals with the
        event dispatcher, used only when the subject is an event dispatcher. */
    private static Socket signalSocket;
    /** Input stream attached to signal socket. */
    private static DataInputStream signalIn = null;
    /** Output stream attached to signal socket. */
    private static DataOutputStream signalOut = null;
    /** Flag specifying whether signal socket is in use. It is set by
        the <code>start</code> method. */
    private static boolean useSignalSocket = false;
    /** Flag indicating whether trace messages are to be timestamped. */
    private static boolean doTimestamps = false;

    /** Reference to running thread, if any. If a thread has already been
        started for this SocketProbe, the SocketProbe start method will
        return immediately without taking any action. */
    private static Thread ref = null;

    private static boolean isSocketProbeAlt = false;

    /** Set of threads which are ignored when <code>finish()</code>
        waits for all subject threads to exit (no subject threads
        should be placed in this set). */
    private static Set<Object> ignoreThreads = null;
    /** Number of threads placed in <code>ignoreThreads</code>. */
    private static int ignoreThreadCount = -1;

    /** Flag indicating whether the SocketProbe was constructed
        successfully. This acts as a guard in <code>finish()</code>,
        since the constructor calls <code>System.exit</code> on
        failure. */
    private static boolean created = false;

    private static boolean finishing = false;

    /** The cache of object arrays for methods when using optimized
        instrumentation for normal traces. When maximum capacity is
        reached, a least-recently-used algorithm is applied to
        choose a cached array to commit to the trace to make room. */
    private static Map<Object, Object> objectArrays;

    /** Array which stores the hit object IDs sequentially, using
        special marker/index pairs to indicate entry into new methods.
        It is public so that the instrumentation is not required
        to make a method call to retrieve a reference to it. */
    public static int[] sequenceArray;
    /** Index pointing to the next open entry in the sequence array.
        Instrumentation is responsible for updating this pointer when
        recording an object ID, and calling
        <code>writeSequenceData</code> when the array is filled. */
    public static int sequenceIndex = 0;
    /** Stores the signature string of the method for which objects
        are currently being recorded. This is required when object
        IDs for a method bridge an array transmit-and-reset event. */
    private static String currentMethodSig = null;
    /** Maps indices following new method markers to the signature
        string for that method. */
    private static HashMap<Object, String> indexToNameMap;
    /** Maps signature strings for a method to an already assigned
        index, if any. */
    private static HashMap<String, Object> nameToIndexMap;
    /** Holds the next value available for use as an index to a
        method signature string. */
    private static int nextMethodIndex = 0;
    /** Stack which holds the signatures of methods on the call stack.
        Used in basic block sequence tracing to ensure that blocks are
        associated with the correct method after returning from a called
        method. */
    private static ArrayList<String> methodSigStack;
    /** Offset value used during sequence array processing to decide whether
        a method exit marker element in the array should be included in the
        transmission; this is true for block sequence tracing where the exit
        blocks (which may be observed in the trace) need to be processed,
        but false for branch sequence tracing where the exit markers are
        purely internal. */
    private static int exitMarkerOffset;

    /*************************************************************************
     * Direct instantiation is not permitted, use
     * {@link start(int, int, boolean, boolean, int)} instead.
     */
    private SocketProbe() {
        throw new AssertionError("Illegal constructor");
    }

    /*************************************************************************
     * Standard constructor.
     *
     * <p>Attempts to open the static socket used to send trace messages to the
     * event dispatcher. This constructor should be called by
     * {@link SocketProbe#start}, which will be invoked by the subject with the
     * port number embedded by the {@link sofya.ed.Instrumentor}. Naturally, if
     * the subject is instrumented on a different port than the event dispatcher
     * is listening on, this action will fail. If the connection cannot be made,
     * the system exits (an action which will occur before any subject code
     * is executed).</p>
     *
     * @param port Port number to be used to connect the socket. This should
     * be set by the instrumentor and supplied by the subject via a call to
     * {@link SocketProbe#start}.
     */
    @SuppressWarnings("unchecked")
    protected SocketProbe(int port) {
        try {
            socket = new Socket("localhost", port);
            socketOut = new DataOutputStream(new BufferedOutputStream(
                                             socket.getOutputStream()));
            // Check if filter is prepared to handle declared type of
            // instrumentation
            if (DEBUG) System.out.println("SocketProbe: initiate handshake");
            try {
                socketOut.writeInt(objType);
                socketOut.flush();
                if (DEBUG) {
                    System.out.println("SocketProbe: wrote entity type");
                }
                socketOut.writeInt(instMode);
                socketOut.flush();
                if (DEBUG) {
                    System.out.println("SocketProbe: wrote instrumentation " +
                        "type");
                }
                signalIn = new DataInputStream(socket.getInputStream());
                if (DEBUG) {
                    System.out.println("SocketProbe: reading entity type " +
                        "response");
                }
                int response = signalIn.readInt();
                if (response == 1) {
                    if (DEBUG) {
                        System.out.println("SocketProbe: entity type rejected");
                    }
                    // Negative response, so die. The filter will print the
                    // error message.
                    System.exit(response);
                }
                if (DEBUG) {
                    System.out.println("SocketProbe: entity type accepted");
                }

                if (DEBUG) {
                    System.out.println("SocketProbe: reading instrumentation " +
                        "type response");
                }
                response = signalIn.readInt();
                if (response == 1) {
                    if (DEBUG) {
                        System.out.println("SocketProbe: instrumentation " +
                            "type rejected");
                    }
                    // Negative response, so die. The filter will print the
                    // error message.
                    System.exit(response);
                }
                if (DEBUG) {
                    System.out.println("SocketProbe: instrumentation " +
                        "type accepted");
                }
            }
            catch (Exception e) {
                System.err.println("Could not complete handshake with filter!");
                throw e;
            }
            if (DEBUG) System.out.println("SocketProbe: handshake completed");
            if (useSignalSocket) {
                try {
                    // The Filter will put the port for the signal socket on
                    // the main socket. Read it and connect the signal socket.
                    int signalPort = signalIn.readInt();
                    signalSocket = new Socket("localhost", signalPort);
                    signalIn =
                        new DataInputStream(signalSocket.getInputStream());
                    signalOut =
                        new DataOutputStream(signalSocket.getOutputStream());
                }
                catch (Exception e) {
                    System.err.println("Error opening signal socket!");
                    throw e;
                }
            }
            // Set up data structures depending on instrumentation type
            switch (instMode) {
                case INST_COMPATIBLE:
                    break;
                case INST_OPT_NORMAL:
                    objectArrays = new LRUTraceMap(BLOCK_ARRAY_CACHE_SIZE);
                    break;
                case INST_OPT_SEQUENCE:
                    sequenceArray = new int[SEQUENCE_ARRAY_SIZE];
                    Arrays.fill(sequenceArray, 0);
                    indexToNameMap = new HashMap();
                    nameToIndexMap = new HashMap();
                    methodSigStack = new ArrayList<String>();
                    break;
            }

            if (objType == TraceObjectType.IBASIC_BLOCK) {
                exitMarkerOffset = 1;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error opening socket for instrumentation! " +
                "(Port " + port + ")");
            System.exit(1);
        }
        created = true;
    }

    /*************************************************************************
     * Creates SocketProbe and starts daemon thread to keep it memory resident.
     *
     * <p>Creates an instance of the SocketProbe connected to the specified
     * port. Once the SocketProbe is created it is executed in a daemon thread.
     * This guarantees that the same SocketProbe object will handle all
     * instrumentation and ensures that the underlying socket remains
     * persistent. It is run as a daemon thread to ensure that it is terminated
     * automatically when the subject is finished. The thread itself does not
     * take any action (See {@link SocketProbe#run}). If this method has
     * already been called by the current subject, it returns immediately
     * without taking any action.</p>
     *
     * <p>The {@link sofya.ed.Instrumentor} should guarantee that a call
     * to this method is inserted into the subject class as the first possible
     * executable statement in the class, either in the static initializer
     * (<i>&lt;clinit&gt;</i>) or in <i>main</i>. This will ensure that all
     * instrumentation is sent correctly. If SocketProbe itself is instrumented,
     * a call to this method on SocketProbeAlt (the clone of the invoking
     * filter's SocketProbe, see {@link ProgramEventDispatcher}) will be
     * inserted in its static initializer, which allows the SocketProbe to be
     * traced without introducing infinite recursion scenarios.</p>
     *
     * <p>If the subject being run is an event dispacher, the subject
     * dispatcher's SocketProbe will be running in its own subject's JVM. As a
     * result, to trace the SocketProbe (logically considered a component of the
     * subject event dispatcher), the main invoking dispatcher will need to
     * accept two instrumentation connections, one from the subject event
     * dispatcher and one from the SocketProbe. This requires it to synchronize
     * the trace messages it receives. To make this possible, the
     * <code>doTimestamping</code> flag should be set by the instrumentor, which
     * will cause the SocketProbe to insert timestamps at the front of each
     * trace message, which can then be used by the event dispatcher to
     * order the trace messages. Under no other circumstance should this flag
     * be set. (See {@link ProgramEventDispatcher}).</p>
     *
     * <p>All parameters should be set by the instrumentor.</p>
     *
     * @param port Port number to be used to connect the socket.
     * @param _instMode Integer flag specifying the type of instrumentation
     * present in the subject.
     * @param _doTimestamps Flag indicating whether trace messages are to be
     * timestamped. This is only used with the subject is an event dispatcher.
     * @param _useSignalSocket Flag indicating whether a signal socket
     * connection should be made to the event dispatcher. This is only used
     * when the subject is an event dispatcher.
     * @param _objType Integer flag specifying the type of program entity
     * traced by the instrumentation present in the subject.
     */
    public static void start(int port, int _instMode, boolean _doTimestamps,
                             boolean _useSignalSocket, int _objType) {
        if (ref == null) {
            if ((_instMode < 1 || _instMode > 4)
                    && !(_instMode == INST_OLD_UNSUPPORTED)) {
                System.err.println("Unrecognized type of instrumentation: " +
                    _instMode);
                System.exit(1);
            }
            instMode = _instMode;
            System.setErr(System.out);
            doTimestamps = _doTimestamps;
            useSignalSocket = _useSignalSocket;
            objType = _objType;
            SocketProbe sp = new SocketProbe(port);
            String probeName = sp.getClass().getName();
            isSocketProbeAlt = probeName.endsWith("SocketProbeAlt");
            ref = new Thread(sp, "SocketProbe");
            ref.setDaemon(true);
            ref.start();

            registerInitThreads();

            // We do not want to wait on this thread during shutdown
            // (hello deadlock), so we add it to the ignored
            // threads set
            isSocketProbeAlt = true;
            if (isSocketProbeAlt) {
                if (DEBUG) System.out.println("Adding shutdown hook");
                Thread shutdownThread = new ProbeShutdownHook(probeName);
                ignoreThreads.add(shutdownThread);
                ignoreThreadCount += 1;
                Runtime.getRuntime().addShutdownHook(shutdownThread);
            }

        }
    }

    public static void finish() {
        finish(null);
    }

    /*************************************************************************
     * Notifies the socket probe that subject execution has completed.
     *
     * <p>The method ensures that any data currently cached but not
     * transmitted is sent to the event dispatcher, guaranteeing that the trace
     * will be complete. Any open sockets are then closed.</p>
     */
    @SuppressWarnings("unchecked")
    static void finish(Thread parentThread) {
        // The patched Runtime calls this method from exit(int) and halt(int).
        // The constructor calls System.exit on failure. So if the constructor
        // failed, we end up here, but we need to not try to clean up
        // resources that never got allocated/created in the first place.
        if (!created) return;

        if (isSocketProbeAlt) {
            if (DEBUG) System.out.println("Checking finish flag");
            // A shutdown hook is added to handle the case where the
            // instrumented socket probe may not call the finish
            // method on SocketProbeAlt (esp. older Galileo versions)
            synchronized(lock) {
                if (finishing) {
                    if (DEBUG) System.out.println("Already finished, exiting");
                    return;
                }
                finishing = true;
            }
        }
        if (DEBUG) System.out.println("Finishing...");

        if (parentThread != null) {
            ignoreThreads.add(parentThread);
            ignoreThreadCount += 1;
        }

        waitOnThreads(parentThread != null);

        if (DEBUG) System.out.println("Transmitting remaining trace data...");

        // Send any cached data
        switch (instMode) {
            case INST_COMPATIBLE:
                break;
            case INST_OPT_NORMAL:
                // Capture a reference to the map and then replace it with a
                // new empty map. From this point on, no new trace data will
                // be recorded. This is intended only to avoid concurrent
                // modification exceptions during iteration caused by daemon
                // threads which continue to run.
                LRUTraceMap locCopy = (LRUTraceMap) objectArrays;
                objectArrays = new HashMap();
                MapIterator it = locCopy.orderedMapIterator();
                while (it.hasNext()) {
                    String mSig = (String) it.next();
                    writeTraceData(it.getValue(), mSig, -1, -1);
                }
                break;
            case INST_OPT_SEQUENCE:
                writeSequenceData();
                break;
            default:
                System.err.println("WARNING: finish() called but the " +
                    "instrumentation type is unknown!");
                break;
        }

        if (DEBUG) System.out.println("Closing sockets...");

        // Close the sockets
        if (signalSocket != null) {
            if (signalIn != null) {
                try {
                    signalIn.close();
                }
                catch (Exception e) { }
            }
            if (signalOut != null) {
                try {
                    signalOut.close();
                }
                catch (Exception e) { }
            }
            try {
                signalSocket.close();
            }
            catch (Exception e) { }
        }
        try {
            socketOut.close();
        }
        catch (Exception e) { }
        try {
            socket.close();
        }
        catch (Exception e) { }

        if (DEBUG) System.out.println("Shutdown complete");
    }

    /*************************************************************************
     * Registers any initial threads in the JVM in the thread ignore set, so we
     * won't try to wait for those threads when all the subject threads have
     * exited. Note that the socket probe thread itself will also be included
     * in the ignore set, assuming that this method is called at appropriate
     * location in the <code>start</code> method.
     */
    @SuppressWarnings("unchecked")
    private static void registerInitThreads() {
        ThreadGroup baseTG = ref.getThreadGroup();
        ignoreThreadCount = baseTG.activeCount();
        ignoreThreads = new HashSet();
        Thread[] curThreads = new Thread[ignoreThreadCount];
        int copied = baseTG.enumerate(curThreads);
        for (int i = 0; i < copied; i++) {
            ignoreThreads.add(curThreads[i]);
        }
    }

    /*************************************************************************
     * Waits for all subject threads to terminate.
     *
     * <p>This method successively joins to all the threads found in the
     * main thread group except for those threads placed in the thread
     * ignore set by {@link #registerInitThreads}. The application thread
     * group is the top ancestor thread group for all threads created by
     * the subject and thus will always recursively contain all of the
     * subject threads. This process is repeated until no such subject
     * threads remain in the main thread group (which prevents us from
     * failing to account for additional threads created during the
     * run of the subject).</p>
     *
     * <p><strong>Note:</strong> The main thread group is not to be
     * confused with the system thread group, which contains special
     * JVM managed threads.</p>
     *
     * <p><em><strong>WARNING:</strong> Threads allocated but not started
     * by the subject program may be included in the count of active threads,
     * but not returned in the enumeration of active threads. As a consequence,
     * this method will be unable to complete and the subject will hang.
     * <strong>This is a bug in the Sun JVM!</strong> The status
     * of this problem on other JVM implementations is unknown. To prevent
     * this problem, subjects should be modified such that no allocated
     * threads are left unstarted at program exit.</em>
     */
    private static void waitOnThreads(boolean fromShutdownHook) {
        ThreadGroup baseTG = ref.getThreadGroup();
        Thread[] activeThreads = new Thread[10];
        int threadCount;

        if (DEBUG) {
            System.out.println("Ignore threads:\n" + ignoreThreads);
            System.out.println("Waiting on threads exiting...");
        }

        // We must loop and continue to join threads, since threads that we
        // know about now may create other threads we don't know about
        while ((threadCount = baseTG.activeCount()) > ignoreThreadCount) {
            if (threadCount > activeThreads.length) {
                activeThreads = new Thread[threadCount];
            }

            int copied = baseTG.enumerate(activeThreads);
            for (int i = 0; i < copied; i++) {
                Thread curThread = activeThreads[i];

                if (ignoreThreads.contains(curThread)) {
                    continue;
                }
                else if (curThread.isDaemon()) {
                    ignoreThreads.add(curThread);
                    ignoreThreadCount += 1;
                    continue;
                }
                else if (!curThread.isAlive()) {
                    continue;
                }
                else if (curThread == Thread.currentThread()) {
                    ignoreThreads.add(curThread);
                    ignoreThreadCount += 1;
                    continue;
                }

                try {
                    if (DEBUG) {
                        System.out.println("Joining to: " + curThread);
                    }
                    curThread.join();
                }
                catch (InterruptedException e) { }
            }
        }
    }

    /*************************************************************************
     * Runs the (daemon) thread.
     *
     * <p>The run method simply sleeps indefinitely, so as to keep the same
     * instance of the SocketProbe alive. Note that the run method is
     * uninterruptable. Instead, since it is running as a daemon thread, it
     * will die automatically when the subject exits.</p>
     */
    public void run() {
        int signal;
        synchronized(this) {
            if (useSignalSocket) {
                while (true) {
                    try {
                        signal = signalIn.readInt();
                        if (signal == SIG_ECHO) {
                            signalOut.writeInt(signal);
                            signalOut.flush();
                        }
                    }
                    catch (InterruptedIOException e) { break; }
                    catch (IOException e) { }
                }
            }
            else {
                while (true) {
                    try {
                        this.wait();
                    }
                    catch (InterruptedException e) {
                        System.err.println("Interrupt received in " +
                            "SocketProbe!");
                        continue;
                    }
                    break;
                }
            }
        }
    }

    /*************************************************************************
     * Transmits a trace message to the event dispatcher via the socket.
     *
     * <p>The correct port should be set by {@link SocketProbe#start} and thus
     * will be known internally as part of the state of the SocketProbe
     * object. Since the SocketProbe object is kept resident by the daemon
     * thread, any class throughout the subject can call this method and
     * successfully transmit a message, assuming {@link SocketProbe#start}
     * has been called previously.</p>
     *
     * <p>A single threaded subject can only call this method sequentially,
     * resulting in typical in-order processing of trace statements.
     * Multithreaded subjects, however, may call this method from
     * different threads, in which case the order of processing of
     * trace statements is not guaranteed to be deterministic.
     * The actual transmission of the message through the socket is
     * synchronized, however, ensuring that the message will not
     * be corrupted.</p>
     *
     * <p>This method will not block unless the buffer of the underlying
     * socket has been filled.</p>
     *
     * @param bId The ID of the trace object marked by this instrumentation
     * probe.
     * @param mSignature Full signature of the method which contains
     * the trace object being marked.
     */
    public static void writeTraceMessage(int bId, String mSignature) {
        writeTraceData(new Integer(bId), mSignature, -1, -1);
    }

    /*************************************************************************
     * Gets the byte array recording which trace objects have been witnessed
     * in a given method.
     *
     * <p>If this is the first time the method has been traced (or the
     * method has been removed from the cache), an array of the necessary
     * size is allocated and initialized. Calls to this method are
     * inserted at the beginning of methods in the subject by the
     * instrumentor.</p>
     *
     * @param mSignature Signature of the method for which the byte array
     * is to be retrieved. The signature guarantees uniqueness.
     * @param objCount Number of trace objects in the method, used only
     * when the array must be allocated. This value should be determined
     * by the CFG builder and set by the instrumentor.
     *
     * @return The byte array recording trace objects witnessed in the
     * method.
     */
    public static byte[] getObjectArray(String mSignature, int objCount) {
        writeObjectCount(mSignature, objCount);
        if (!objectArrays.containsKey(mSignature)) {
            // Need to allocate and initialize new one
            byte[] objArray = new byte[objCount];
            Arrays.fill(objArray, (byte) 0);
            objectArrays.put(mSignature, objArray);
            return objArray;
        }
        else {
            return (byte[]) objectArrays.get(mSignature);
        }
    }

    /*************************************************************************
     * Inserts a new method marker and index into the sequence array.
     *
     * <p>A map is checked to see if an index has already been created for
     * the given signature string. If it has, the existing index is
     * retrieved, otherwise a new index is created and added. A new
     * method marker is then inserted, followed by the index to the
     * signature string. The index pointer is advanced by two so that
     * it is left pointing to the next open element in the array.
     * If advancing the pointer two elements will exceed the size of
     * the array, the array is first committed to the trace and the
     * pointer is reset to zero before proceeding.</p>
     *
     * @param mSignature Signature of the method which has been entered
     * and needs to be marked in the array.
     * @param objCount Number of trace objects in the method.
     */
    public static void markMethodInSequence(String mSignature, int objCount) {
        writeObjectCount(mSignature, objCount);
        if (sequenceIndex > sequenceArray.length - 2) {
            // The array is full, so transmit the data. This also resets the
            // index..
            writeSequenceData();
        }
        sequenceArray[sequenceIndex++] = NEW_METHOD_MARKER;
        if (nameToIndexMap.containsKey(mSignature)) {
            // We've already linked this method to an index, so use that value
            sequenceArray[sequenceIndex++] =
                ((Integer) nameToIndexMap.get(mSignature)).intValue();
        }
        else {
            // Need to create a new index to correspond to this method
            sequenceArray[sequenceIndex++] = nextMethodIndex;
            nameToIndexMap.put(mSignature, new Integer(nextMethodIndex));
            indexToNameMap.put(new Integer(nextMethodIndex), mSignature);
            // Overflow detection not necessary - see writeSequenceData()
            nextMethodIndex++;
        }
    }

    /*************************************************************************
     * Writes the given hit object IDs for a method to the socket to be relayed
     * to listeners by the event dispatcher.
     *
     * @param objects Reference to a (Java) Object or object array containing
     * trace object information to be sent to the event dispatcher. The type of
     * this argument depends on the type of instrumentation, so a generic Object
     * reference is used.
     * @param mSignature Signature of the method with which the current
     * object data is associated.
     * @param fromIndex Pointer to the element in the array from which
     * the method should start reading object information. This parameter is
     * ignored unless handling optimized sequence instrumentation.
     * @param toIndex Pointer to the element in the array at which the method
     * should stop reading object information. This parameter is ignored
     * unless handling optimized sequence instrumentation.
     */
    private static void writeTraceData(Object objects, String mSignature,
                                       int fromIndex, int toIndex) {
        try {  // Trap runtime exceptions

        try {
            synchronized(lock) {
                socketOut.writeByte((byte) 1);  // Message code: trace data
                if (doTimestamps) {
                    socketOut.writeByte((byte) 1);  // Timestamp flag on
                    socketOut.writeLong(System.currentTimeMillis());
                }
                else {
                    socketOut.writeByte((byte) 0);  // Timestamp flag off
                }
                // So filter knows how many bytes to read
                socketOut.writeInt(mSignature.length());
                socketOut.writeBytes(mSignature);
                switch (instMode) {
                    case INST_COMPATIBLE:
                        socketOut.writeInt(1);  // Just one block
                        socketOut.writeInt(((Integer) objects).intValue());
                        break;
                    case INST_OPT_NORMAL:
                        // Determine and write the number of blocks hit to the
                        // stream
                        byte[] byteArray = (byte[]) objects;
                        int hitCount = 0;
                        for (int i = 0; i < byteArray.length; i++) {
                            if (byteArray[i] != 0) {
                                hitCount++;
                            }
                        }
                        // So filter knows how many block IDs to read
                        socketOut.writeInt(hitCount);
                        // Now write the actual block IDs
                        for (int i = 0; i < byteArray.length; i++) {
                            if (byteArray[i] != 0) {
                                socketOut.writeInt((byteArray[i] << 26) +
                                    (i + 1));
                            }
                        }
                        break;
                    case INST_OPT_SEQUENCE:
                        int[] intArray = (int[]) objects;
                        socketOut.writeInt(toIndex - fromIndex);
                        for (int i = fromIndex; i < toIndex; i++) {
                            socketOut.writeInt(intArray[i]);
                        }
                        break;
                    default:
                        System.err.println("ERROR: instrumentation type not " +
                            "recognized by writeTraceData");
                        break;
                }
                socketOut.flush();
            }
        }
        catch (NullPointerException e) {
            // Socket isn't open because start() wasn't called
            e.printStackTrace();
            System.err.println("Trying to send data for: " + mSignature);
            System.err.println("Instrumentation socket is not connected");
        }
        catch (SocketException e) {
            e.printStackTrace();
            // Port number output disabled because it causes problems with
            // differencing
            System.err.println("Error attempting to write instrumented " +
                "trace statement!");
                // (Port " + socket.getLocalPort() + ")");
        }
        catch (IOException e) {
            // Don't want subject to die suddenly, so simply report error
            e.printStackTrace();
            System.err.println("Error attempting to write instrumented " +
                "trace statement!"); // (Port " + socket.getLocalPort() + ")");
        }

        // Catch all unexpected exceptions and store them
        } catch (Exception e) {
            System.err.println("Error writing trace message");
        }
    }

    /*************************************************************************
     * Writes the current contents of the object sequence array to the socket
     * to be relayed to listeners by the event dispatcher.
     *
     * <p>New-method markers are used to transmit object IDs in a series
     * of chunks associated with the correct method signature string.
     * If the array begins with a continuation of object IDs for a method
     * from the previous contents of the array, the
     * <code>currentMethodSig</code> field is used to properly associate
     * the objects with that method. When this method returns, all of the
     * object IDs currently in the array will have been transmitted to the
     * filter and the array index pointer reset to zero.</p>
     */
    public static void writeSequenceData() {
        int fromIndex = 0;
        int toIndex = 0;
        while (toIndex < sequenceIndex) {
            switch (sequenceArray[toIndex]) {
            case NEW_METHOD_MARKER: {
                if (toIndex > fromIndex) {
                    if (currentMethodSig != null) {
                        writeTraceData(sequenceArray, currentMethodSig,
                                       fromIndex, toIndex);
                    }
                    else {
                        System.err.println("ERROR: Orphaned sequence " +
                            "information detected. Trace is likely invalid!");
                    }
                }

                methodSigStack.add(currentMethodSig);
                currentMethodSig = (String) indexToNameMap.get(
                    new Integer(sequenceArray[++toIndex]));
                fromIndex = ++toIndex;
                continue;
            }
            case BRANCH_EXIT_MARKER: {
                break;
            }
            default: {
                if ((sequenceArray[toIndex] >>> 26) == BlockType.IEXIT) {
                    break;
                }
                else {
                    toIndex++;
                    continue;
                }
            }}

            // We should only reach here if we are handling method exit
            if (toIndex >= fromIndex) {
                if (currentMethodSig != null) {
                    writeTraceData(sequenceArray, currentMethodSig,
                                fromIndex, toIndex + exitMarkerOffset);
                }
                else {
                    System.err.println("ERROR: Orphaned " +
                        "sequence information detected. Trace is " +
                        "likely invalid!");
                }
            }
            try {
                currentMethodSig = methodSigStack.remove(methodSigStack.size() - 1);
            }
            catch (NoSuchElementException e) {
                System.err.println("ERROR: Number of method entries " +
                    "and exits is unbalanced.");
            }
            fromIndex = ++toIndex;
        }
        if (toIndex > fromIndex) {
            if (currentMethodSig != null) {
                writeTraceData(sequenceArray, currentMethodSig,
                               fromIndex, toIndex);
            }
            else {
                System.err.println("ERROR: Orphaned sequence " +
                    "information detected. Trace is likely invalid!");
            }
        }

        sequenceIndex = 0;
        // Now that the array is cleared, we can also clear any current
        // mappings of indices to method signatures and vice-versa. This is
        // easier than trying to attach overflow protection to the index
        // counter, and safer since overflow detection would only be able to
        // report that the trace is invalid, not recover from it.
        indexToNameMap.clear();
        nameToIndexMap.clear();
        nextMethodIndex = 0;
    }

    /*************************************************************************
     * Writes the number of objects (trace entities) in the current method to
     * the socket so that the event dispatcher can notify listeners.
     *
     * @param mSignature Signature of the method for which the object count
     * is being sent.
     * @param objCount Number of objects in the method.
     */
    public static void writeObjectCount(String mSignature, int objCount) {
        try { // Catch all runtime exceptions

        try {
            synchronized(lock) {
                // Message code: send block count
                socketOut.writeByte((byte) 2);
                // So filter knows how many bytes to read
                socketOut.writeInt(mSignature.length());
                socketOut.writeBytes(mSignature);
                socketOut.writeInt(objCount);
                socketOut.flush();
            }
        }
        catch (NullPointerException e) {
            // Socket isn't open because start() wasn't called
            e.printStackTrace();
            System.err.println("Trying to send object count for: " +
                mSignature);
            System.err.println("Instrumentation socket is not connected");
        }
        catch (SocketException e) {
            // If transmission failed because we are in shutdown and the socket
            // was already closed, suppress the error message. This only arises
            // in a very specific case when a filter is run on another filter,
            // and two exit hooks get created.
            if (!e.getMessage().toLowerCase().endsWith("socket closed")) {
                e.printStackTrace();
                // Port number output disabled because it causes problems with
                // differencing
                System.err.println("Error attempting to write object count!");
                    // (Port " + socket.getLocalPort() + ")");
            }
        }
        catch (IOException e) {
            // Don't want subject to die suddenly, so simply report error
            e.printStackTrace();
            System.err.println("Error attempting to write object count!");
                // (Port " + socket.getLocalPort() + ")");
        }

        // Catch all unexpected exceptions and store them
        } catch (Exception e) {
            System.err.println("Error writing object count");
        }
    }

    /*************************************************************************
     * Customized implementation of the LRU map to ensure that the hit
     * block data in the byte array for a least-recently-used method is
     * written to the trace before its entry is removed from the map.
     */
    @SuppressWarnings("serial")
    static class LRUTraceMap extends LRUMap {
        public LRUTraceMap(int maxSize) {
            super(maxSize);
        }

        protected boolean removeLRU(LinkEntry entry) {
            // Actually record the trace data for the block array about to
            // be kicked
            Object value = entry.getValue();
            if (value != null) {
                writeTraceData(value, (String) entry.getKey(), -1, -1);
            }
            return true;
        }
    }
}
