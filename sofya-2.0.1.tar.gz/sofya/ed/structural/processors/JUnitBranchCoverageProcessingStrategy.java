/*
 * Copyright 2003-2006, Regents of the University of Nebraska
 *
 *  Licensed under the University of Nebraska Open Academic License,
 *  Version 1.0 (the "License"); you may not use this file except in
 *  compliance with the License. The License must be provided with
 *  the distribution of this software; if the license is absent from
 *  the distribution, please report immediately to galileo@cse.unl.edu
 *  and indicate where you obtained this software.
 *
 *  You may also obtain a copy of the License at:
 *
 *      http://sofya.unl.edu/LICENSE-1.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package sofya.ed.structural.processors;

import java.util.List;

import sofya.base.SConstants;
import sofya.base.SConstants.*;
import sofya.base.exceptions.ConfigurationError;
import sofya.ed.BranchCoverageListener;
import sofya.ed.CoverageListenerManager;
import sofya.ed.structural.ActiveComponent;
import sofya.ed.structural.BranchInstrumentationStrategy;
import sofya.ed.structural.BranchInstrumentationConfiguration;
import sofya.ed.structural.EventDispatcherConfiguration;
import sofya.ed.structural.TraceHandler;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;

/**
 * <p>Processing strategy to receive JUnit branch coverage probes and
 * dispatch branch coverage events.</p>
 *
 * @author Alex Kinneer
 * @version 04/24/2006
 */
public class JUnitBranchCoverageProcessingStrategy
        extends AbstractJUnitProcessingStrategy
        implements BranchInstrumentationStrategy {
    /** Configuration specifying selected branches. */
    private BranchInstrumentationConfiguration branchConfig =
            new BranchInstrumentationConfiguration();

    // Local copies for efficiency
    private boolean ifBranchesOn;
    private boolean switchBranchesOn;
    private boolean throwsBranchesOn;
    private boolean callBranchesOn;
    private boolean entryBranchesOn;
    private boolean summaryBranchesOn;

    /** Listener manager that serves the listeners to which the coverage
        events will be dispatched. */
    private CoverageListenerManager listenerManager;

    /** Conditional compilation flag to enable debug outputs. */
    private static final boolean DEBUG = false;

    /**
     * Creates a new instance of the processing strategy with a trace
     * handler as the default coverage listener manager.
     */
    public JUnitBranchCoverageProcessingStrategy() {
        super();
        setCoverageListenerManager(new TraceHandler());
    }

    /**
     * Creates a new instance of the processing strategy.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public JUnitBranchCoverageProcessingStrategy(CoverageListenerManager clm) {
        super();
        setCoverageListenerManager(clm);
    }

    /**
     * Gets the coverage listener manager to be used.
     *
     * @return The coverage listener manager being used used to retrieve
     * coverage listeners to which events will be dispatched.
     */
    public CoverageListenerManager getCoverageListenerManager() {
        return listenerManager;
    }

    /**
     * Sets the coverage listener manager to be used.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public void setCoverageListenerManager(CoverageListenerManager clm) {
        this.listenerManager = clm;
    }

    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        branchConfig.register(edConfig);

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).register(edConfig);
        }
    }

    public List<String> configure(List<String> params) {
        params = super.configure(params);

        params = branchConfig.configure(params);

        if (listenerManager instanceof ActiveComponent) {
            return ((ActiveComponent) listenerManager).configure(params);
        }
        else {
            return params;
        }
    }

    public boolean isReady() {
        boolean ready = branchConfig.isReady();

        if (listenerManager == null) {
            return ready;
        }
        else {
            if (listenerManager instanceof ActiveComponent) {
                return ((ActiveComponent) listenerManager).isReady() && ready;
            }
            else {
                return ready;
            }
        }
    }

    public void release() {
        super.release();

        branchConfig.release();

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).release();
        }
    }

    public TraceObjectType getObjectType() {
        return TraceObjectType.BRANCH_EDGE;
    }

    public void setup() {
        ifBranchesOn = branchConfig.areIfBranchesActive();
        switchBranchesOn = branchConfig.areSwitchBranchesActive();
        throwsBranchesOn = branchConfig.areThrowsBranchesActive();
        callBranchesOn = branchConfig.areCallBranchesActive();
        entryBranchesOn = branchConfig.areEntryBranchesActive();
        summaryBranchesOn = branchConfig.areSummaryBranchesActive();

        listenerManager.initialize();
    }

    public void newTest(int testNum) {
        listenerManager.newEventStream(testNum);
    }

    public void endTest(int testNum) {
        listenerManager.commitCoverageResults(testNum);
    }

    public void setMethodObjectCount(String mSig, int objCount) {
        listenerManager.initializeBranchListener(mSig, objCount);
    }

    public void processData(Object instArray, String mSig, int fromIndex,
                            int toIndex) {
        try {  // Trap exceptions

            BranchCoverageListener listener =
                    listenerManager.getBranchCoverageListener(mSig);

            switch (instMode) {
            case SConstants.INST_OPT_NORMAL:
                byte[] byteArray = (byte[]) instArray;

                for (int bId = 0; bId < byteArray.length; bId++) {
                    int branchType = byteArray[bId];

                    switch (branchType) {
                    case 0:
                        // Branch wasn't hit
                        continue;
                    case BranchType.IIF:
                        if (ifBranchesOn) {
                            listener.branchCovered(bId + 1, branchType);
                            if (DEBUG) {
                                System.err.println("tr.setBit <if> success");
                            }
                        }
                        break;
                    case BranchType.ISWITCH:
                        if (switchBranchesOn) {
                            listener.branchCovered(bId + 1, branchType);
                            if (DEBUG) {
                                System.err.println("tr.setBit <switch> success");
                            }
                        }
                        break;
                    case BranchType.ITHROW:
                        if (throwsBranchesOn) {
                            listener.branchCovered(bId + 1, branchType);
                            if (DEBUG) {
                                System.err.println("tr.setBit <throw> success");
                            }
                        }
                        break;
                    case BranchType.ICALL:
                        if (callBranchesOn) {
                            listener.branchCovered(bId + 1, branchType);
                            if (DEBUG) {
                                System.err.println("tr.setBit <call> success");
                            }
                        }
                        break;
                    case BranchType.IENTRY:
                        if (entryBranchesOn) {
                            listener.branchCovered(bId + 1, branchType);
                            if (DEBUG) {
                                System.err.println("tr.setBit <entry> success");
                            }
                        }
                        break;
                    case BranchType.IOTHER:
                        if (summaryBranchesOn) {
                            listener.branchCovered(bId + 1, branchType);
                            if (DEBUG) {
                                System.err.println("tr.setBit <other> success");
                            }
                        }
                        break;
                    default:
                        throw new ExecException("Invalid branch type code " +
                                "received from instrumented class: " +
                                branchType);
                    }
                }
                break;
            case SConstants.INST_COMPATIBLE:
                // In compatible mode instrumentation, the block data is packed
                // in the same way as for sequence instrumentation, so it's
                // easier to simply let it masquerade as such
            case SConstants.INST_OPT_SEQUENCE:
                int[] intArray = (int[]) instArray;
                for (int i = fromIndex; i < toIndex; i++) {
                    int branchType = intArray[i] >>> 26;
                    int branchID = intArray[i] & 0x03FFFFFF;

                    switch (branchType) {
                    case BranchType.IIF:
                        if (ifBranchesOn) {
                            listener.branchCovered(branchID + 1, branchType);
                        }
                        break;
                    case BranchType.ISWITCH:
                        if (switchBranchesOn) {
                            listener.branchCovered(branchID + 1, branchType);
                        }
                        break;
                    case BranchType.ITHROW:
                        if (throwsBranchesOn) {
                            listener.branchCovered(branchID + 1, branchType);
                        }
                        break;
                    case BranchType.ICALL:
                        if (callBranchesOn) {
                            listener.branchCovered(branchID + 1, branchType);
                        }
                        break;
                    case BranchType.IENTRY:
                        if (entryBranchesOn) {
                            listener.branchCovered(branchID + 1, branchType);
                        }
                        break;
                    case BranchType.IOTHER:
                        if (summaryBranchesOn) {
                            listener.branchCovered(branchID + 1, branchType);
                        }
                        break;
                    default:
                        throw new ExecException("Invalid branch type code " +
                                "received from instrumented class");
                    }
                }
                break;
            default:
                throw new ConfigurationError("Unknown or incompatible " +
                        "instrumentation");
            }

        // Catch all unexpected exceptions and store them
        }
        catch (Exception e) {
            e.printStackTrace();
            err = e;
            System.err.println("Error writing trace message");
        }
    }

    public boolean areIfBranchesActive() {
        return branchConfig.areIfBranchesActive();
    }

    public void setIfBranchesActive(boolean enable) {
        branchConfig.setIfBranchesActive(enable);
    }

    public boolean areSwitchBranchesActive() {
        return branchConfig.areSwitchBranchesActive();
    }

    public void setSwitchBranchesActive(boolean enable) {
        branchConfig.setSwitchBranchesActive(enable);
    }

    public boolean areThrowsBranchesActive() {
        return branchConfig.areThrowsBranchesActive();
    }

    public void setThrowsBranchesActive(boolean enable) {
        branchConfig.setThrowsBranchesActive(enable);
    }

    public boolean areCallBranchesActive() {
        return branchConfig.areCallBranchesActive();
    }

    public void setCallBranchesActive(boolean enable) {
        branchConfig.setCallBranchesActive(enable);
    }

    public boolean areEntryBranchesActive() {
        return branchConfig.areEntryBranchesActive();
    }

    public void setEntryBranchesActive(boolean enable) {
        branchConfig.setEntryBranchesActive(enable);
    }

    public boolean areSummaryBranchesActive() {
        return branchConfig.areSummaryBranchesActive();
    }

    public void setSummaryBranchesActive(boolean enable) {
        branchConfig.setSummaryBranchesActive(enable);
    }

    public int getTypeFlags() {
        return branchConfig.getTypeFlags();
    }
}
