/*
 * Copyright 2003-2006, Regents of the University of Nebraska
 *
 *  Licensed under the University of Nebraska Open Academic License,
 *  Version 1.0 (the "License"); you may not use this file except in
 *  compliance with the License. The License must be provided with
 *  the distribution of this software; if the license is absent from
 *  the distribution, please report immediately to galileo@cse.unl.edu
 *  and indicate where you obtained this software.
 *
 *  You may also obtain a copy of the License at:
 *
 *      http://sofya.unl.edu/LICENSE-1.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package sofya.ed.structural.processors;

import java.net.Socket;
import java.net.ServerSocket;
import java.net.InetAddress;
import java.net.BindException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;

import sofya.ed.structural.SocketProcessingStrategy;
import sofya.ed.structural.EventDispatcherConfiguration;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;

/**
 * <p>Base class for strategies to receive and process probes for a
 * program event dispatcher.</p>
 *
 * @author Alex Kinneer
 * @version 08/04/2006
 */
public abstract class AbstractSocketProcessingStrategy
        extends AbstractProcessingStrategy
        implements SocketProcessingStrategy {

    /** Local copy of the flag indicating whether the subject is itself
        an event dispatcher. */
    protected static boolean isSbjDispatcher;
    /** Lock used to synchronize access to the listener or listeners. */
    protected static Object traceLock = new Object();

    /** Conditional compilation flag indicating whether the JVM is a
        preemptive JVM. */
    protected static final boolean PREEMPTIVE = true;
    /** Conditional compilation flag to enable debug outputs. */
    private static final boolean DEBUG = false;

    protected AbstractSocketProcessingStrategy() {
        super();
    }

    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        isSbjDispatcher = edConfig.isSubjectDispatcher();
    }

    public List<String> configure(List<String> parameters) {
        return parameters;
    }

    public void reset() {
        isSbjDispatcher = false;
    }

    public void release() {
        reset();
    }

    /*************************************************************************
     * Reads the method signature portion of a trace message from the
     * socket and parses it into its class name and fully qualified method
     * name.
     *
     * <p>All of the outputs of this method are side effects.</p>
     *
     * @param in Input stream which is connected to the trace message socket.
     * @param buffer Byte buffer used to hold the signature string when it
     * is read from the socket and from which the parsing is performed. If
     * the signature string exceeds the size of this buffer, the method will
     * still succeed, but will be considerably slower since it must process
     * the signature in chunks. A reasonably large buffer is recommended.
     *
     * @throws ExecException If the signature string is improperly encoded
     * and cannot be parsed.
     * @throws IOException If there is any other error reading from the
     * socket.
     */
    protected String parseMethodSignature(DataInputStream in, byte[] buffer)
                   throws IOException, ExecException {
        int charCount = 0;
        boolean readSuccess = false;
        String classAndSig;

        // Get the length of the method signature string
        int dataLength = in.readInt();
        // Read the method signature string
        if (dataLength < buffer.length) {
            for (int trys = 0; trys < 3; trys++) {
                charCount += in.read(buffer, charCount, dataLength - charCount);
                if (charCount == dataLength) {
                    readSuccess = true;
                    break;
                }
            }

            if (!readSuccess) {
                throw new IOException("Error reading method signature from " +
                    "trace message");
            }

            int i; for (i = 0; i < dataLength; i++) {
                if (buffer[i] == '@') {
                    buffer[i] = (byte) 46;  // '.'
                    break;
                }
            }

            if (i == dataLength) {
                throw new ExecException("Malformed trace message: could not " +
                    "parse class and method names");
            }

            classAndSig = new String(buffer, 0, dataLength);
        }
        else {
            StringBuilder sb = new StringBuilder();
            boolean parsed = false;
            int numRead;
            while (dataLength > 0) {
                numRead = (dataLength > buffer.length)
                          ? buffer.length
                          : dataLength;
                charCount = 0;
                readSuccess = false;

                for (int trys = 0; trys < 3; trys++) {
                    charCount +=
                        in.read(buffer, charCount, numRead - charCount);
                    if (charCount == numRead) {
                        readSuccess = true;
                        break;
                    }
                }

                if (!readSuccess) {
                    throw new IOException("Error reading method signature " +
                        "from trace message");
                }

                int i; for (i = 0; i < numRead; i++) {
                    if (buffer[i] == '@') {
                        buffer[i] = (byte) 46; // '.'
                        break;
                     }
                }

                if ((i < buffer.length) && !parsed) {
                    if (numRead - i > 0) {
                        sb.append(new String(buffer, i, numRead - i));
                    }
                    parsed = true;
                }
                else {
                    sb.append(new String(buffer, 0, numRead));
                }
                dataLength -= numRead;
            }
            if (parsed) {
                classAndSig = sb.toString();
            }
            else {
                throw new ExecException("Malformed trace message: could not " +
                    "parse class and method names");
            }
        }

        return classAndSig;
    }

    /*************************************************************************
     * Connects the signal socket used to allow basic communication with the
     * subject's SocketProbe.
     *
     * <p>This method attempts to find a free port and bind a server socket to
     * it. It then writes the chosen port onto the main socket connection for
     * the SocketProbe to read and waits for the incoming connection. Once the
     * connection is established, it returns the associated socket and no
     * further data is written to the main socket connection.</p>
     *
     * <p><b>Note:</b> Coverage processing strategies do not use the signal
     * socket, however we still negotiate the connection so the SocketProbe
     * doesn't get confused. The signal socket is intended for use by
     * sequence processing strategies.</p>
     *
     * @param msgSocket The main socket which will be used for trace messages,
     * which should be connected before calling this method.
     *
     * @return A socket representing the signal connection.
     *
     * @throws IOException If an open port for the signal socket cannot be
     * found, there is an error connecting the socket, or there is an error
     * attempting to transmit the port number to the SocketProbe.
     */
    protected Socket openSignalSocket(Socket msgSocket) throws IOException {
        ServerSocket connectSocket = null;

        for (int cur_port = 1025; cur_port <= 65535; cur_port++) {
            try {
                connectSocket = new ServerSocket(cur_port, 1,
                    InetAddress.getByName("localhost"));
                break;
            }
            catch (BindException e) { }
        }

        if (connectSocket == null) {
            throw new IOException("Unable to create signal socket!");
        }

        if (DEBUG) stdout.println("Filter negotiating signal socket " +
            "connection on: " + connectSocket.getLocalPort());

        DataOutputStream out =
            new DataOutputStream(msgSocket.getOutputStream());
        out.writeInt(connectSocket.getLocalPort());
        out.flush();

        try {
            return connectSocket.accept();
        }
        catch (IOException e) {
            connectSocket.close();
            throw e;
        }
    }
}
