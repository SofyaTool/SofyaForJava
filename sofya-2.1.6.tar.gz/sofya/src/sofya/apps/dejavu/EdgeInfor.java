package sofya.apps.dejavu;

public class EdgeInfor {
	String classname=null;
	String methodname=null;
	int prenode=0;
	int sucnode=0;
}
