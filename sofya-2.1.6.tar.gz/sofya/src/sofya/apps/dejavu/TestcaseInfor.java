package sofya.apps.dejavu;

import java.util.Vector;

public class TestcaseInfor {
	String[] input;
	Vector<Trace> trace=new Vector<Trace>();
	Vector<String> path=new Vector<String>();
}
