package sofya.apps.dejavu;

public class Trace {
	String methodname=null;
	int blockID=0;
	String symbol=null;
}
