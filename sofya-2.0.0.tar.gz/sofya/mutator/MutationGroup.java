/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.mutator;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;

import sofya.mutator.Mutation.Variant;
import sofya.base.exceptions.SofyaError;

import org.apache.bcel.generic.ClassGen;

/************************************************************************
 * A group of related mutations that can be applied together.
 *
 * <p>A mutation group also has an associated ID. When selecting mutations
 * by ID, mutations in a mutation group can only be selected if the
 * ID of the mutation group is also selected. However, selecting a mutation
 * group does not automatically cause all member mutations to be selected
 * (mutations in the group can be selectively applied).</p>
 *
 * @author Alex Kinneer
 * @version 05/12/2006
 */
public class MutationGroup implements Mutation {
    /** List of mutations contained in this group. */
    private List mutations = new ArrayList();
    /** Name of the class to which the contained mutants apply. */
    private String className;
    /** Name of the method to which the contained mutants may apply. */
    private String methodName;
    /** Signature of the method to which the contained mutants may apply. */
    private String signature;
    /** ID associated with this mutation group. */
    private MutationID id;
    /** Flag indicating whether a visitor has requested that the mutations in
        this group be visited. */
    private boolean visitMembers = true;

    private MutationGroup() {
        throw new SofyaError("Illegal constructor");
    }

    /**
     * Creates a new mutation group for mutations that apply to a given class.
     *
     * @param className Name of the class to which the contained mutants will
     * apply.
     */
    public MutationGroup(String className) {
        this.className = className;
    }

    /**
     * Creates a new mutation group for mutations that apply to a given method
     * in a class.
     *
     * @param className Name of the class to which the contained mutants will
     * apply.
     * @param methodName Name of the method to which the contained mutants
     * will apply.
     * @param signature Signature of the method to which the contained mutants
     * will apply.
     */
    public MutationGroup(String className, String methodName,
            String signature) {
        this(className);
        this.methodName = methodName;
        this.signature = signature;
    }

    /**
     * Adds a mutation to this mutation group.
     *
     * @param mutation Mutation to be added to this group.
     */
    public void addMutation(GroupableMutation mutation) {
        mutation.setParent(this);
        mutations.add(mutation);
    }

    /**
     * Gets the class name to which the contained mutants apply.
     *
     * @return The name of the class to which the mutations in this group
     * are applied.
     */
    public String getClassName() {
        return className;
    }

    /**
     * Gets the method name to which the contained mutants apply.
     *
     * @return The name of the method to which the mutations in this group
     * are applied.
     */
    public String getMethodName() {
        return methodName;
    }

    /**
     * Gets the signature of the method to which the contained mutants apply.
     *
     * @return The signature of the method to which the mutations in this group
     * are applied.
     */
    public String getSignature() {
        return signature;
    }

    /** 
     * Gets the number of mutations in this group.
     *
     * @return The number of mutation in this group.
     */
    public int size() {
        return mutations.size();
    }

    /**
     * Returns an iterator over the mutations in this group.
     *
     * @return An iterator over the mutations in this group.
     */
    public Iterator iterator() {
        return mutations.iterator();
    }

    /**
     * Gets the type string associated with a mutation group.
     *
     * @return The string &quot;group&quot;.
     */
    public String getType() {
        return "group";
    }

    public MutationID getID() {
        return id;
    }

    public void setID(MutationID id) {
        this.id = id;
    }

    public void visitMembers(boolean b) {
        this.visitMembers = b;
    }

    public void accept(MutationVisitor visitor) throws MutationException {
        visitor.visit(this, true);

        if (visitMembers) {
            int size = mutations.size();
            Iterator iterator = mutations.iterator();
            for (int i = size; i-- > 0; ) {
                GroupableMutation gm = (GroupableMutation) iterator.next();
                gm.accept(visitor);
            }

            visitor.visit(this, false);
        }
    }

    public Variant getDefaultVariant() {
        return null;
    }
    
    public Variant[] getVariants() {
        return new Variant[0];
    }

    /**
     * The mutations contained in this group can be selected and applied
     * individually, therefore this method does nothing.
     *
     * @param cg BCEL classfile object for the class being mutated.
     * @param variant Variant of the mutation to be applied.
     *
     * @throws MutationException Never.
     */
    public void apply(ClassGen cg, Variant variant) throws MutationException {
    }

    /**
     * The mutations contained in this group can be selected and applied
     * individually, therefore this method does nothing.
     *
     * @param cg BCEL classfile object for the class being mutated.
     */
    public void undo(ClassGen cg) {
    }

    public void serialize(DataOutput out)
            throws IOException {
        out.writeUTF(className);
        if (methodName != null) {
            out.writeByte(1);
            out.writeUTF(methodName);
        }
        else {
            out.writeByte(0);
        }
        if (signature != null) {
            out.writeByte(1);
            out.writeUTF(signature);
        }

        int count = mutations.size();
        out.writeInt(count);

        for (int i = 0; i < count; i++) {
            Mutation mutation = (Mutation) mutations.get(i);
            MutationHandler.writeMutation(out, mutation);
        }
    }

    public static MutationGroup deserialize(DataInput in) throws IOException {
        String className = in.readUTF();
        String methodName = null;
        String signature = null;
        if (in.readByte() == 1) {
            methodName = in.readUTF();
        }
        if (in.readByte() == 1) {
            signature = in.readUTF();
        }

        MutationGroup mg = new MutationGroup(className, methodName, signature);

        int count = in.readInt();
        for (int i = 0; i < count; i++) {
            mg.addMutation(
                (GroupableMutation) MutationHandler.readMutation(in));
        }

        return mg;
    }

    public String print() {
        StringBuffer sb = new StringBuffer();
        if (getID() != null) {
            sb.append(getID().asInt());
            sb.append(":");
        }
        else {
            sb.append("-:");
        }
        sb.append("group:");
        sb.append(size());
        sb.append(":");
        sb.append(className);
        sb.append(":");
        sb.append(methodName);
        sb.append(":");
        sb.append(signature);
        return sb.toString();
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Mutation group {\n");
        if (getID() != null) {
            sb.append("\tid: ");
            sb.append(getID().asInt());
        }
        else {
            sb.append("\tid not assigned");
        }
        sb.append("\n\tsize: ");
        sb.append(size());
        sb.append("\n\tclass: ");
        sb.append(className);
        sb.append("\n\tmethod: ");
        sb.append(methodName);
        sb.append("\n\tsignature: ");
        sb.append(signature);
        sb.append("\n}");
        return sb.toString();
    }
}
