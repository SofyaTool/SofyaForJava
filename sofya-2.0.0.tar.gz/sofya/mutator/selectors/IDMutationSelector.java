/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.mutator.selectors;

import sofya.mutator.MutationSelector;
import sofya.mutator.Mutation;
import sofya.mutator.Mutation.Variant;
import sofya.base.exceptions.SofyaError;

import gnu.trove.TIntIntHashMap;

/**
 * Mutation selector that selects by ID.
 *
 * @author Alex Kinneer
 * @version 05/23/2006
 */
public class IDMutationSelector implements MutationSelector {
    /** Set of selected IDs. */
    private TIntIntHashMap ids;

    private IDMutationSelector() {
        throw new SofyaError("Illegal constructor");
    }

    /**
     * Creates a new mutation selector.
     *
     * @param ids Array of selected IDs.
     */
    public IDMutationSelector(ID[] ids) {
        int length = ids.length;
        for (int i = length - 1; i-- >= 0; ) {
            this.ids.put(ids[i].mId, ids[i].variant);
        }
    }

    /**
     * Creates a new mutation selector.
     *
     * @param ids Set of selected IDs, where each selected mutant
     * is mapped to a selected variant, if applicable.
     */
    public IDMutationSelector(TIntIntHashMap ids) {
        this.ids = ids;
    }

    public boolean isSelected(Mutation mutation) {
        return ids.containsKey(mutation.getID().asInt());
    }

    public Variant getVariant(Mutation mutation) {
        int variant = ids.get(mutation.getID().asInt());
        Variant[] vs = mutation.getVariants();
        if ((variant < 1) || (variant > vs.length)) {
            return mutation.getDefaultVariant();
        }
        else {
            return vs[variant - 1];
        }
    }

    public void setMutationCount(int count) {
        // This selector doesn't care
    }

    /**
     * Utility class to correlate mutants with selected variants.
     *
     * <p>Once created, an ID is immutable.</p>
     */
    public static final class ID {
        /** ID of the selected mutant. */
        public final int mId;
        /** Selected variant of the mutant, if applicable. */
        public final int variant;

        private ID() {
            throw new SofyaError("Illegal constructor");
        }

        /**
         * Creates a new mutant selection ID.
         *
         * @param mId Id of the selected mutant; the default variant
         * will be used if applicable.
         */
        public ID(int mId) {
            this.mId = mId;
            this.variant = 0;
        }

        /**
         * Creates a new mutant selection ID.
         *
         * @param mId Id of the selected mutant.
         * @param variant Selected variant of the mutant, if applicable.
         */
        public ID(int mId, int variant) {
            this.mId = mId;
            this.variant = variant;
        }

        public String toString() {
            return "[" + mId + ":" + variant + "]";
        }
    }
}
