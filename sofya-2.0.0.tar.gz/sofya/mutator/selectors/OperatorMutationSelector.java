/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.mutator.selectors;

import java.util.Set;

import sofya.mutator.MutationSelector;
import sofya.mutator.Mutation;
import sofya.mutator.Mutation.Variant;
import sofya.base.exceptions.SofyaError;

import gnu.trove.THashSet;

/**
 * Mutation selector that selects by mutation operator.
 *
 * @author Alex Kinneer
 * @version 05/12/2006
 */
public class OperatorMutationSelector implements MutationSelector {
    /** Set of selected mutation operators. */
    private Set ops;
    
    private OperatorMutationSelector() {
        throw new SofyaError("Illegal constructor");
    }
    
    /**
     * Creates a new mutation selector.
     *
     * @param ops Array of selected mutation operators, as operator
     * abbreviation strings (e.g. &quot;AOC&quot;, &quot;AOP&quot;, etc.).
     */
    public OperatorMutationSelector(String[] ops) {
        this.ops = new THashSet();
        
        for (int i = 0; i < ops.length; i++) {
            this.ops.add(ops[i]);
        }
    }
    
    /**
     * Creates a new mutation selector.
     *
     * @param ops Set of selected mutation operators, as operator
     * abbreviation strings (e.g. &quot;AOC&quot;, &quot;AOP&quot;, etc.).
     */
    public OperatorMutationSelector(Set ops) {
        this.ops = ops;
    }
    
    public boolean isSelected(Mutation mutation) {
        String type = mutation.getType();
        if (type.equals("group")) return true;
        return ops.contains(type);
    }
    
    public Variant getVariant(Mutation mutation) {
        return mutation.getDefaultVariant();
    }
    
    public void setMutationCount(int count) {
        // This selector doesn't care
    }
}
