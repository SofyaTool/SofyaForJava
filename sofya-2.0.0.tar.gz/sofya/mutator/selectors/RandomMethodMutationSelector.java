/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.mutator.selectors;

import java.util.List;

import sofya.base.exceptions.SofyaError;

/**
 * Mutation selector that randomly selects by method name and signature.
 *
 * @author Alex Kinneer
 * @version 10/01/2005
 */
public class RandomMethodMutationSelector extends MethodMutationSelector {
    private RandomMethodMutationSelector() {
        throw new SofyaError("Illegal constructor");
    }
    
    /**
     * Creates a new mutation selector to select a given number of methods
     * randomly; mutations occurring in selected methods will be selected.
     *
     * @param methodNames {@inheritDoc}
     * @param num Number of methods to be randomly selected. 
     */
    public RandomMethodMutationSelector(String[] methodNames, int num) {
        RandomSequence sequence = new RandomSequence(num, methodNames.length);
        IntSequenceIterator iterator = sequence.iterator();
        while (iterator.hasNext()) {
            addMethod(methodNames[iterator.nextInt() - 1]);
        }
    }
    
    /**
     * Creates a new mutation selector to select a given number of methods
     * randomly; mutations occurring in selected methods will be selected.
     *
     * @param methodNames List of method descriptions supplied by the diffing
     * tool, as strings. Mutations occurring in the selected methods will be
     * selected. For best efficiency, the list should support random access.
     * @param num Number of methods to be randomly selected. 
     */
    public RandomMethodMutationSelector(List methodNames, int num) {
        RandomSequence sequence = new RandomSequence(num, methodNames.size());
        IntSequenceIterator iterator = sequence.iterator();
        while (iterator.hasNext()) {
            addMethod((String) methodNames.get(iterator.nextInt() - 1));
        }
    }
}
