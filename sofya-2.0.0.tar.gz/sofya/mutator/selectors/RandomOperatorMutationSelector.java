/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.mutator.selectors;

import java.util.List;
import java.util.Set;

import sofya.mutator.MutationSelector;
import sofya.mutator.Mutation;
import sofya.mutator.Mutation.Variant;
import sofya.base.exceptions.SofyaError;

import gnu.trove.THashSet;

/**
 * Mutation selector that randomly selects by mutation operator.
 *
 * @author Alex Kinneer
 * @version 05/12/2006
 */
public class RandomOperatorMutationSelector implements MutationSelector {
    /** Set of randomly selected mutation operators. */
    private Set ops = new THashSet();
    
    private RandomOperatorMutationSelector() {
        throw new SofyaError("Illegal constructor");
    }
    
    /**
     * Creates a new mutation selector to select a given number of mutation
     * operators randomly; mutations corresponding to selected operators
     * will be selected.
     *
     * @param opChoices Array of available mutation operators, as operator
     * abbreviation strings (e.g. &quot;AOC&quot;, &quot;AOP&quot;, etc.).
     * @param num Number of mutation operators to be randomly selected. 
     */
    public RandomOperatorMutationSelector(String[] opChoices, int num) {
        RandomSequence sequence = new RandomSequence(num, opChoices.length);
        IntSequenceIterator iterator = sequence.iterator();
        while (iterator.hasNext()) {
            this.ops.add(opChoices[iterator.nextInt() - 1]);
        }
    }
    
    /**
     * Creates a new mutation selector to select a given number of mutation
     * operators randomly; mutations corresponding to selected operators
     * will be selected.
     *
     * @param opChoices List of selected mutation operators, as operator
     * abbreviation strings (e.g. &quot;AOC&quot;, &quot;AOP&quot;, etc.).
     * For best efficiency, the list should support random access.
     * @param num Number of mutation operators to be randomly selected. 
     */
    public RandomOperatorMutationSelector(List opChoices, int num) {
        RandomSequence sequence = new RandomSequence(num, opChoices.size());
        IntSequenceIterator iterator = sequence.iterator();
        while (iterator.hasNext()) {
            this.ops.add(opChoices.get(iterator.nextInt() - 1));
        }
    }
    
    public boolean isSelected(Mutation mutation) {
        String type = mutation.getType();
        if (type.equals("group")) return true;
        return ops.contains(type);
    }
    
    public Variant getVariant(Mutation mutation) {
        return mutation.getDefaultVariant();
    }
    
    public void setMutationCount(int count) {
        // This selector doesn't care
    }
}
