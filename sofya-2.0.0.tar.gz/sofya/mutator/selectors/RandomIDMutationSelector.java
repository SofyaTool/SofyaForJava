/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.mutator.selectors;

import sofya.mutator.MutationSelector;
import sofya.mutator.Mutation;
import sofya.mutator.Mutation.Variant;
import sofya.base.exceptions.SofyaError;

import gnu.trove.TIntHashSet;

/**
 * Mutation selector that randomly selects by ID.
 *
 * @author Alex Kinneer
 * @version 05/12/2006
 */
public class RandomIDMutationSelector implements MutationSelector {
    /** Number of mutations to randomly select. */
    private int randCount = -1;
    /** Random sequence generator for generating selected IDs. */
    private RandomSequence sequence = new RandomSequence();
    
    private RandomIDMutationSelector() {
        throw new SofyaError("Illegal constructor");
    }
    
    /**
     * Creates a new mutation selector to select a given number of mutations
     * randomly by ID.
     *
     * @param randCount Number of IDs to be selected at random.
     */
    public RandomIDMutationSelector(int randCount) {
        this.randCount = randCount;
    }
    
    public boolean isSelected(Mutation mutation) {
        return sequence.contains(mutation.getID().asInt());
    }
    
    public Variant getVariant(Mutation mutation) {
        return mutation.getDefaultVariant();
    }
    
    public void setMutationCount(int mutationCount) {
        sequence.newSequence(randCount, mutationCount);
    }
}
