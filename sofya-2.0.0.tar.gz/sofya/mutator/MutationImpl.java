/*
 * Copyright (c) 2003-Present Alex Kinneer and Hyunsook Do. All rights
 * reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Created 9/16/2004
 */

package sofya.mutator;

import org.apache.bcel.generic.ClassGen;

import gnu.trove.THashMap;

/************************************************************************
 * A mutation that actually implements a classfile transformation; this
 * provides a distinction between such mutations and those that are
 * actually just containers for other mutations, such as
 * {@link MutationGroup}.
 *
 * @author Alex Kinneer
 * @version 09/28/2005
 */
public abstract class MutationImpl implements Mutation {
    /** ID assigned to this mutation. */
    private MutationID id;
    
    protected MutationImpl() {
    }
    
    /**
     * Gets the ID associated with this mutation.
     *
     * @return A unique identifer associated with this mutation by the mutation
     * framework.
     */
    public MutationID getID() {
        return id;
    }
    
    /**
     * Sets the ID associated with this mutation; this method is called
     * automatically by the framework and should never be called elsewhere.
     *
     * @param id Unique identifier to be associated with this mutation.
     */
    public void setID(MutationID id) {
        this.id = id;
    }
}
