/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.tools;

import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.NumberFormat;

import sofya.tools.th.TestHistory;
import sofya.tools.th.TestHistoryHandler;
import sofya.graphs.cfg.CFHandler;
import sofya.graphs.cfg.Block;
import sofya.graphs.cfg.CFG;
import sofya.base.exceptions.MethodNotFoundException;
import sofya.viewers.Viewer;

/**
 * Computes coverage information for Java subjects traced by Sofya.
 * Currently only basic block coverage is supported.
 *
 * @author Alex Kinneer
 * @version 12/02/2005
 */
public final class Coverage {
    private static TestHistoryHandler thHandler = new TestHistoryHandler();
    /*private static CFHandler cfHandler = new CFHandler();
    
    static {
        cfHandler.setClearOnLoad(false);
    }
    */
    public static void printCoverage(PrintWriter pw, String thFile,
                                     boolean all)
                                     throws IOException {
        printCoverage(pw, thFile, all, null);
    }
    
    public static void printCoverage(PrintWriter pw, String thFile,
                                     boolean all, String tag)
                                     throws IOException {
        thHandler.readTestHistoryFile(thFile);
        String[] methodList = thHandler.getMethodList();
        long totBlocks = 0;
        long totCovered = 0;
        
        for (int i = 0; i < methodList.length; i++) {
            TestHistory tHist = null;
            try {
                tHist = thHandler.getTestHistory(methodList[i]);
            }
            catch (MethodNotFoundException e) {
                IOException ioe =
                    new IOException("Error read test history file");
                ioe.initCause(e);
                throw ioe;
            }
            
            pw.println(methodList[i]);
            pw.println();
            pw.println(" blockID   covered");
            pw.println("-------------------");
            
            int maxId = tHist.getHighestBlockID();
            for (int blkId = 1; blkId <= maxId; blkId++) {
                boolean cvrg = tHist.isEmpty(blkId);
                
                if (cvrg) {
                    if (all) {
                        pw.println(Viewer.rightJust(blkId, 7) + "      YES");
                    }
                    totCovered += 1;
                }
                else {
                    pw.println(Viewer.rightJust(blkId, 7) + "       NO");
                }
            }
            totBlocks += maxId;
            
            pw.println();
        }
        
        NumberFormat fmt = NumberFormat.getPercentInstance();
        fmt.setMinimumFractionDigits(2);
        pw.println();
        pw.print("percent coverage: ");
        pw.println(fmt.format(((double) totCovered) / totBlocks));
        pw.println();
        
        pw.flush();
    }
    
    /*private static Block loadBlock(String methodName, int blkId)
            throws IOException {
        int ulPos = methodName.indexOf('_');
        int breakPos = methodName.lastIndexOf('.', ulPos);
        String className = methodName.substring(0, breakPos);
        
        CFG cfg = null;
        if (cfHandler.containsCFG(methodName)) {
            try {
                cfg = cfHandler.getCFG(methodName);
            }
            catch (MethodNotFoundException e) { }
        }
        else {
            cfHandler.readCFFile
        }
        return null;
    }*/

    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("  java sofya.tools.Coverage <test_history> " +
            "[-ALL]"); // [-tag <db_tag>]");
        System.exit(1);
    }
    
    public static void main(String[] argv) {
        if (argv.length < 1) {
            printUsage();
        }
        
        String thFile = null;
        String tag = null;
        boolean all = false;
        
        // Process arguments
        int index = 0; for ( ; index < argv.length; index++) {
            if (argv[index].equals("-tag")) {
                if (index + 1 < argv.length) {
                    tag = argv[++index];
                }
                else {
                    System.err.println("Tag not specified");
                    printUsage();
                }
            }
            else if (argv[index].equals("-ALL")) {
                all = true;
            }
            else if (!argv[index].startsWith("-")) {
                thFile = argv[index];
            }
            else {
                System.err.println("Unrecognized parameter: " + argv[index]);
                printUsage();
            }
        }
        
        if (thFile == null) {
            System.err.println("No test history file specified");
            printUsage();
        }
        
        try {
            printCoverage(new PrintWriter(new OutputStreamWriter(System.out)),
                thFile, all, tag);
        }
        catch (FileNotFoundException e) {
            System.err.println(thFile + " not found");
            System.exit(1);
        }
        catch (IOException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }
}
