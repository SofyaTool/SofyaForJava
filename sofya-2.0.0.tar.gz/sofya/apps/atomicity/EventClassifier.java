/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps.atomicity;

import sofya.base.exceptions.SofyaError;
import sofya.ed.semantic.EventSelectionFilter;

/**
 * Abstract base class for all classes which implement a global event
 * classification policy for atomicity checking.
 *
 * <p>The classification determined for the event is published in a public
 * field before events are demultiplexed by thread and forwarded to the
 * automata which are checking the atomicity property for individual
 * method invocations. The automata may choose to use the published
 * classification if global information permits a better classification
 * for the event than is possible based on local information available to the
 * automata.</p>
 *
 * @author Alex Kinneer
 * @version 10/25/2005
 */
public abstract class EventClassifier extends EventSelectionFilter {
    /** Published classification determined by the global classifier
        for the most recent event. */
    public EventClass eventClass = EventClass.BOTH_MOVER;
    
    /**
     * Type-safe enumeration of the possible classifications defined for
     * events by the reduction-based algorithm.
     */
    public static final class EventClass {
        /** Integer constant of the enumeration element, sometimes useful for
            switch statements. */
        public final int code;
        
        /** Integer constant for right-mover. */
        public static final int IRIGHT_MOVER = 1;
        /** Integer constant for left-mover. */
        public static final int ILEFT_MOVER  = 2;
        /** Integer constant for non-mover. */
        public static final int INON_MOVER   = 3;
        /** Integer constant for both-mover. */
        public static final int IBOTH_MOVER  = 4;
        
        /** Typed constant for a right-mover event. */
        public static final EventClass RIGHT_MOVER =
            new EventClass(IRIGHT_MOVER);
        /** Typed constant for a left-mover event. */
        public static final EventClass LEFT_MOVER =
            new EventClass(ILEFT_MOVER);
        /** Typed constant for a non-mover event. */
        public static final EventClass NON_MOVER =
            new EventClass(INON_MOVER);
        /** Typed constant for a both-mover event. */
        public static final EventClass BOTH_MOVER =
            new EventClass(IBOTH_MOVER);
            
        private EventClass() {
            throw new SofyaError("Illegal constructor");
        }
        
        private EventClass(int code) {
            this.code = code;
        }
        
        public int toInt() {
            return code;
        }
        
        public String toString() {
            switch (code) {
            case IRIGHT_MOVER: return "R";
            case ILEFT_MOVER: return "L";
            case INON_MOVER: return "N";
            case IBOTH_MOVER: return "B";
            default:
                throw new SofyaError();
            }
        }
    }
}
