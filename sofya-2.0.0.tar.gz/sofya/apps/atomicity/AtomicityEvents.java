/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps.atomicity;

import java.util.List;

import sofya.ed.semantic.AllModuleEvents;
import sofya.ed.semantic.SemanticInstrumentor;
import sofya.base.exceptions.IncompleteClasspathException;

import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.InvokeInstruction;
import org.apache.bcel.generic.MethodGen;
import org.apache.bcel.generic.ObjectType;

/**
 * Specification which instructs an
 * {@link sofya.ed.semantic.SemanticEventDispatcher} to dispatch
 * events for atomicity checking.
 *
 * @author Alex Kinneer
 * @version 06/09/2006
 */
public class AtomicityEvents extends AllModuleEvents {
    /** Constant for the <code>java.lang.Thread</code> type, used for
        determining which classes are thread classes. */
    private static final ObjectType THREAD_TYPE =
        new ObjectType("java.lang.Thread");

    /**
     * Creates a new atomicity events specification.
     *
     * <p>The resulting specification will not define any classes comprising
     * the system or module. This constructor is provided only to support
     * deserialization.</p>
     */
    public AtomicityEvents() {
        super();
    }

    /**
     * Creates a new all atomicity events specification.
     *
     * @param systemUnitList List of classes comprising the entire sytem.
     * @param moduleUnitList List of classes comprising the module
     * on which atomicity events are to be observed (this can be the same as
     * the system class list).
     * @param allSystemMonitors Flag that specifies whether all monitor
     * events in the entire system should be included. This is provided
     * since many analyses are interested in all lock related events
     * despite only being interested in module related events otherwise.
     */
    public AtomicityEvents(List systemUnitList, List moduleUnitList,
            boolean allSystemMonitors) {
        super(systemUnitList, moduleUnitList, allSystemMonitors);
    }

    public boolean witnessCall(InvokeInstruction call, ConstantPoolGen cpg,
            MethodGen inMethod) {
        ObjectType classType = call.getLoadClassType(cpg);
        String methodName = call.getMethodName(cpg);

        try {
            if (classType.subclassOf(THREAD_TYPE)) {
                if (methodName.equals("start") || methodName.equals("join")) {
                    return true;
                }
            }
        }
        catch (ClassNotFoundException e) {
            throw new IncompleteClasspathException(e);
        }

        //###############################
        // if (className.equals("java.lang.System")) {
        //     return true;
        // }
        //###############################

        return super.witnessCall(call, cpg, inMethod);
    }

    public boolean useCallInterceptor(InvokeInstruction call,
            ConstantPoolGen cpg) {
        ObjectType classType = call.getLoadClassType(cpg);
        String methodName = call.getMethodName(cpg);

        try {
            if (classType.subclassOf(THREAD_TYPE)) {
                if (methodName.equals("start") || methodName.equals("join")) {
                    return true;
                }
            }
        }
        catch (ClassNotFoundException e) {
            throw new IncompleteClasspathException(e);
        }

        //###############################
        // if (className.equals("java.lang.System")) {
        //     return true;
        // }
        //###############################

        return false;
    }
}
