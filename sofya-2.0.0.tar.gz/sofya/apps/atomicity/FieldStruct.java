/*
 * Copyright (c) 2005-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps.atomicity;

import sofya.base.exceptions.SofyaError;

/**
 * Structure used to identify instance fields uniquely. Once created,
 * this object is immutable.
 *
 * @author Alex Kinneer
 * @version 11/17/2005
 */
final class FieldStruct {
    /** Identifier for the object that owns the field. */
    public final long objectId;
    /** Name of the field. */
    public final String name;
    
    /** Precomputed hash code. */
    private final int hashCode;
    
    private FieldStruct() {
        throw new SofyaError("Illegal constructor");
    }
    
    FieldStruct(long id, String name) {
        this.objectId = id;
        this.name = name;
        
        // Compute the hash code
        int tmp = 13;
        tmp = (37 * tmp) + (int) objectId;
        tmp = (37 * tmp) + name.hashCode();
        hashCode = tmp;
    }
    
    public boolean equals(Object o) {
        // This is performance-critical, so handling the cast exception
        // is preferred over having to execute instanceof on every call
        // (We should NOT see the cast exception anyway)
        try {
            FieldStruct of = (FieldStruct) o;
            if (this.objectId != of.objectId) {
                return false;
            }
            if (!this.name.equals(of.name)) {
                return false;
            }
            
            return true;
        }
        catch (ClassCastException e) {
            return false;
        }
    }
    
    public int hashCode() {
        return hashCode;
    }
}
