/*
 * Copyright (c) 2005-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps.atomicity;

import java.util.List;
import java.util.Map;
import java.util.Iterator;
import java.lang.reflect.Field;

import sofya.ed.semantic.EventSelectionFilter;
import sofya.ed.semantic.EventListener.Arguments;
import sofya.base.MethodSignature;
import sofya.base.exceptions.SofyaError;

import com.sun.jdi.*;

import gnu.trove.TLongHashSet;
import gnu.trove.TIntIntHashMap;

/**
 * Implements the dynamic escape detection algorithm as described by
 * Stoller and Wang.
 *
 * @author Alex Kinneer
 * @version 12/13/2005
 */
public final class DynamicEscapeDetector extends EventSelectionFilter {
    /** Set recording the IDs of escaped objects. */
    private TLongHashSet escaped = new TLongHashSet();
    
    /**
     * Creates a new dynamic escape detector.
     */
    public DynamicEscapeDetector() {
    }
    
    /**
     * Reports whether an given object has escaped from its creating
     * thread.
     *
     * @param objectId ID of the object that should be checked for
     * escape.
     *
     * @return <code>true</code> if the object has escaped (may be
     * accessible by more than one thread).
     */
    public boolean isEscaped(long objectId) {
        boolean result = escaped.contains(objectId);
        //System.out.println("isEscaped: " + objectId + " (" + result + ")");
        return result;
        //return escaped.contains(objectId);
    }
    
    public void threadStartEvent(ThreadData td) {
        ObjectData target = td.getRunnableTarget();
        if (target != null) {
            markEscaped(target.getReference());
        }
        else {
            markEscaped(td.getObject().getReference());
        }
    }
    
    public void instanceFieldWriteEvent(ThreadData td, ObjectData od,
            FieldData fd) {
        Value newVal = fd.getNewValue();
        
        if (escaped.contains(od.getId())
                && (newVal instanceof ObjectReference)) {
            markEscaped((ObjectReference) newVal);
        }
    }
    
    public void staticFieldWriteEvent(ThreadData td, FieldData fd) {
        Value newVal = fd.getNewValue();
        
        if (newVal instanceof ObjectReference) {
            markEscaped((ObjectReference) newVal);
        }
    }
    
    public void staticCallEvent(ThreadData td, CallData cd) {
        if (cd.canGetArguments() && cd.isNative()) {
            markEscaped(cd.getArguments());
        }
    }
    
    public void virtualCallEvent(ThreadData td, CallData cd) {
        if (cd.canGetArguments()) {
            checkAndMarkNativeArgs(cd);
        }
    }
    
    public void interfaceCallEvent(ThreadData td, CallData cd) {
        if (cd.canGetArguments()) {
            checkAndMarkNativeArgs(cd);
        }
    }
    
    private void checkAndMarkNativeArgs(CallData cd) {
        Arguments args = cd.getArguments();
        ObjectReference thisObj = args.getThis();
        ClassType thisType = (ClassType) thisObj.referenceType();
        
        MethodSignature callSig = cd.getCalledSignature();
        String rawProbeStr = cd.getRawCalledSignature();
        String callJNISig =
            rawProbeStr.substring(rawProbeStr.lastIndexOf('#') + 1);
        
        try {
            Method callMethod = thisType.concreteMethodByName(
                callSig.getMethodName(), callJNISig);
            if (callMethod.isNative()) {
                markEscaped(args);
            }
        }
        catch (ClassNotPreparedException e) {
            // Class should be prepared by the time we attempt to call
            // a method on it
            throw new SofyaError("Could not check escaping arguments for " +
                "call", e);
        }
    }
    
    private void markEscaped(Arguments arguments) {
        Map args = arguments.getAllArguments();
        int size = args.size();
        Iterator iterator = args.values().iterator();
        for (int i = size; i-- > 0; ) {
            Value val = (Value) iterator.next();
            if (val instanceof ObjectReference) {
                markEscaped((ObjectReference) val);
            }
        }
    }
    
    private void markEscaped(ObjectReference objRef) {
        if (objRef == null) {
            return;
        }
        
        long objId = objRef.uniqueID();
        if (escaped.contains(objId)) {
            return;
        }
        escaped.add(objId);
        
        if (objRef instanceof ArrayReference) {
            ArrayReference arrRef = (ArrayReference) objRef;
            
            List arrValues = arrRef.getValues();
            int length = arrValues.size();
            Iterator iterator = arrValues.iterator();
            
            boolean refElemType = false;
            for (int i = length; i-- > 0; ) {
                if (refElemType) {
                    markEscaped((ObjectReference) iterator.next());
                }
                else {
                    Value elemValue = (Value) iterator.next();
                    if (elemValue instanceof ObjectReference) {
                        refElemType = true;
                        markEscaped((ObjectReference) elemValue);
                    }
                    else {
                        return;
                    }
                }
            }
        }
        else {
            ReferenceType objType = objRef.referenceType();
            List fields = null;
            try {
                fields = objType.allFields();
            }
            catch (ClassNotPreparedException e) {
                // Shouldn't a class always be prepared before an instance
                // can be assigned to a field?
                throw new SofyaError("Could not read fields", e);
            }
            
            Map fieldVals = objRef.getValues(fields);
            int size = fieldVals.size();
            Iterator vals = fieldVals.values().iterator();
            for (int i = size; i-- > 0; ) {
                Value fVal = (Value) vals.next();
                if (fVal instanceof ObjectReference) {
                    markEscaped((ObjectReference) fVal);
                }
            }
        }
    }
    
    ////////////////////////////////////////////////////////////////////////
    // The JDI only guarantees that the ID of a mirrored object is unique
    // if it has not been garbage collected. So whenever a new object is
    // constructed, we remove its ID from the escaped set to make sure
    // the new object doesn't erroneously "inherit" the status of the old
    // (now collected) object.
    public void constructorEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
        escaped.remove(od.getId());
    }
}
