/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps.atomicity;

import sofya.base.MethodSignature;
import sofya.base.exceptions.SofyaError;
import sofya.ed.semantic.EventListener;
import sofya.apps.atomicity.EventClassifier.EventClass;

/**
 * Atomicity checking automata implementing the simple reduction-based
 * algorithm for a single method invocation on a single thread.
 *
 * @author Alex Kinneer
 * @version 12/15/2005
 */
public class RBAutomata implements EventListener {
    /** The current state of the automata. */
    protected int state = ACCEPT_R;
    
    /** Constant indicating that the automata is in the rejecting state
        (the regular expression R*N&#63;L* has been violated). */
    protected static final int REJECT   = 0;
    /** Constant indicating the automata is in the right-mover or
        non-mover event accepting state. */
    protected static final int ACCEPT_R =  1;
    /** Constant indicating the automata is the left-mover accepting state. */
    protected static final int ACCEPT_L =  2;
    
    /** Reference to the global event classifier, so that global
        classification can be read if necessary. */
    protected final EventClassifier classifier;
    /** Signature of the method for which this automata is checking for
        atomicity. */
    public final MethodSignature method;
    
    /**
     * Use of this constructor is not permitted.
     */
    private RBAutomata() {
        throw new SofyaError("Illegal constructor");
    }
    
    /**
     * Creates a new reduction-based atomicity checking automata.
     *
     * @param classifier Reference to the global event classifier, so that the
     * published global classifications can be accessed if necessary.
     * @param method Signature of the method for which this automata is
     * to check for atomicity.
     */
    public RBAutomata(EventClassifier classifier, MethodSignature method) {
        this.classifier = classifier;
        this.method = method;
    }
    
    /**
     * Reports whether the automata accepts the current method invocation
     * as atomic.
     *
     * @return <code>true</code> if the automata found this invocation of
     * the method to be atomic, <code>false</code> otherwise.
     */
    public boolean isAccepting() {
        return !(state == REJECT);
    }
    
    /**
     * Updates the state of the automata based on the current event.
     *
     * @param eventClass Classification of the event as a left-mover,
     * right-mover, non-mover, or both-mover.
     */
    protected void update(EventClass eventClass) {
        switch (state) {
        case ACCEPT_R:
            switch (eventClass.toInt()) {
            case EventClass.IBOTH_MOVER:
            case EventClass.IRIGHT_MOVER:
                break;
            case EventClass.INON_MOVER:
            case EventClass.ILEFT_MOVER:
                state = ACCEPT_L;
                break;
            default:
                throw new SofyaError();
            }
            break;
        case ACCEPT_L:
            switch (eventClass.toInt()) {
            case EventClass.IBOTH_MOVER:
            case EventClass.ILEFT_MOVER:
                break;
            case EventClass.INON_MOVER:
            case EventClass.IRIGHT_MOVER:
                state = REJECT;
                break;
            default:
                throw new SofyaError();
            }
            break;
        case REJECT:
            break;
        default:
            throw new SofyaError();
        }
    }
    
    public void systemStarted() {
    }
    
    public void executionStarted() {
    }
    
    public void threadStartEvent(ThreadData td) {
    }
    
    public void threadDeathEvent(ThreadData td) {
    }
    
    public void classPrepareEvent(ThreadData td, String className) {
    }
    
    public void monitorContendEvent(ThreadData td, ObjectData od,
            MonitorData md) {
        update(EventClass.BOTH_MOVER);
    }
    
    public void monitorAcquireEvent(ThreadData td, ObjectData od,
            MonitorData md) {
        update(EventClass.RIGHT_MOVER);
    }
    
    public void monitorPreReleaseEvent(ThreadData td, ObjectData od,
            MonitorData md) {
       update(EventClass.BOTH_MOVER);
    }
    
    public void monitorReleaseEvent(ThreadData td, ObjectData od,
            MonitorData md) {
        update(EventClass.LEFT_MOVER);
    }
    
    public void newAllocationEvent(ThreadData td, NewAllocationData nad) {
    }

    public void constructorCallEvent(ThreadData td, CallData cd) {
    }
    
    public void constructorEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void constructorExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void staticFieldAccessEvent(ThreadData td, FieldData fd) {
        update(classifier.eventClass);
    }
    
    public void instanceFieldAccessEvent(
            ThreadData td, ObjectData od, FieldData fd) {
        update(classifier.eventClass);
    }
    
    public void staticFieldWriteEvent(ThreadData td, FieldData fd) {
        update(classifier.eventClass);
    }
    
    public void instanceFieldWriteEvent(
            ThreadData td, ObjectData od, FieldData fd) {
        update(classifier.eventClass);
    }
    
    public void staticCallEvent(ThreadData td, CallData cd) {
    }
    
    public void virtualCallEvent(ThreadData td, CallData cd) {
    }
    
    public void interfaceCallEvent(ThreadData td, CallData cd) {
    }
    
    public void callReturnEvent(ThreadData td, CallData cd,
            boolean exceptional) {
    }
    
    public void virtualMethodEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void virtualMethodExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void staticMethodEnterEvent(ThreadData td, MethodData md) {
    }
    
    public void staticMethodExitEvent(ThreadData td, MethodData md) {
    }
    
    public void exceptionThrowEvent(ThreadData td, ExceptionData ed) {
    }
    
    public void exceptionCatchEvent(ThreadData td, ExceptionData ed) {
    }
    
    public void staticInitializerEnterEvent(ThreadData td, MethodData md) {
    }
    
    public void systemExited() {
    }
}
