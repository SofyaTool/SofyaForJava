/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps.dejavu;

import java.io.IOException;

import sofya.graphs.Edge;
import sofya.viewers.TestSelectionViewer;

/**
 * Adapter class which is responsible for the display of test selection
 * results and the writing of those results to a database file.
 *
 * @author Rogan Creswick
 * @author Alex Kinneer
 * @version 09/22/2004
 */
public class OutputAdapter {
    /** Name of the output file to be written. */
    private String fileName;
    /** Database tag associated with the output file to be written. */
    private String tag;
    /** Viewer used for immediate display to the console. */
    private TestSelectionViewer tsViewer;
    /** Handler for writing the test selection file to the database. */
    private TestSelectionHandler tsHandler;
    
    private OutputAdapter() { }
    
    /**
     * Standard constructor, initializes basic information required by the
     * output adapter.
     *
     * @param fileName Name of the output file to be written.
     * @param tag Database tag to be associated with the output file (can
     * be <code>null</code>).
     * @param totalTests Total number of tests from which test selection
     * may occur.
     */
    public OutputAdapter(String fileName, String tag, int totalTests) {
        this.fileName = fileName;
        this.tag = tag;
        tsHandler = new TestSelectionHandler(totalTests);
        tsViewer = new TestSelectionViewer(tsHandler);
    }
    
    /**
     * Adds test selection information about a method.
     *
     * @param methodName Name of the method for which test selection
     * data is being recorded for output.
     * @param selected Selection data object containing the test selection
     * data being recorded.
     */
    public void addSelected(String methodName, SelectionData selected) {
        tsHandler.setSelectedTests(methodName, selected.tests);
    }
    
    /**
     * Writes the test selection information to a database file.
     *
     * @throws IOException For any IO error which prevents successful
     * creation of the test selection file.
     */
    public void writeTestSelectionFile()
                throws IOException {
        tsHandler.writeTestSelectionFile(fileName, tag);
    }

    /**
     * Prints the output to standard output.
     *
     * @param format Display format to be used for the output.
     */
    public void print(int format) throws IOException {
        tsViewer.setOutputFormat(format);
        tsViewer.print();
    }
}

