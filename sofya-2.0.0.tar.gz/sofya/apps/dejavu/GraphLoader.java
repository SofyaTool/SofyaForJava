/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps.dejavu;

import java.io.IOException;
import java.io.FileNotFoundException;

import sofya.graphs.Graph;
import sofya.base.exceptions.*;

/**
 * This interface defines the contract for classes that
 * provide the service of loading graphs built from
 * Java classes.
 *
 * <p>Classes implementing this interface should provide some
 * means of storing what class is being operated on, so that
 * object instantiations can be kept to a minimum.</p>
 *
 * @author CS562 2003 dev team.
 * @author Alex Kinneer
 * @version 09/20/2004
 */
public interface GraphLoader {
    /**
     * Gets the list of methods available in the current class.
     *
     * @return The list of available method names.
     */
    public String[] getMethodList();

    /**
     * Gets the graph for a given method.
     *
     * @param method Name of the method for which to retrieve a graph.
     *
     * @return The graph for that method.
     *
     * @throws MethodNotFoundException If no method by the given
     * name exists in the loaded class.
     */
    public Graph getGraph(String method) throws MethodNotFoundException;

    /**
     * Sets the class for which graphs are to be retrieved.
     *
     * @param className The class from which graphs will be loaded.
     * @param tag Database tag associated with the class's graph data.
     *
     * @throws FileNotFoundException If the graph data file for the specified
     * class cannot be found.
     * @throws EmptyFileException If the graph data file for the class
     * is empty.
     * @throws BadFileFormatException If the graph data file for the class
     * is corrupted.
     * @throws IOException For any other IO error that prevents the graph
     * data file from being read successfully.
     */
    public void setClass(String className, String tag)
                throws FileNotFoundException, EmptyFileException,
                       BadFileFormatException, IOException;
}
