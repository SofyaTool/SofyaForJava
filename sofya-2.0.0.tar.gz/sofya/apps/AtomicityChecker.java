/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.apps;

import java.io.*;

import sofya.apps.atomicity.*;
import sofya.base.MethodSignature;
import sofya.base.exceptions.BadFileFormatException;
import sofya.ed.semantic.SemanticEventDispatcher;
import sofya.ed.semantic.SemanticEventDispatcher.InternalException;
import sofya.ed.semantic.SemanticDataHandler;
import sofya.ed.semantic.EventListener;
import sofya.ed.semantic.ThreadFilter;

/**
 * Runs a program and checks whether its methods satisfy the property of
 * atomicity.
 *
 * @author Alex Kinneer
 * @version 12/08/2005
 */
public class AtomicityChecker {
    private static boolean objectSensitive = true;

    /**
     * Prints the usage message and exits.
     *
     * @param msg Targeted explanation of the usage error,
     * may be <code>null</code>.
     */
    private static void printUsage(String msg) {
        if (msg != null) System.err.println(msg);
        System.err.println("Usage:");
        System.err.println("java sofya.eg.atomicity.AtomicityChecker -md " +
            "<data_file> -main <main_class> [arg1 arg2 ...]");
        System.exit(1);
    }

    /**
     * Entry point for the atomicity checker.
     */
    public static void main(String[] argv) {
        if (argv.length < 4) {
            printUsage(null);
        }

        SemanticEventDispatcher ed = new SemanticEventDispatcher();
        String dataFile = null;
        long timeout = 0;

        int i = 0;
        for ( ; i < argv.length; i++) {
            String curArg = argv[i];
            if (curArg.startsWith("-")) {
                if ("-md".equals(curArg)) {
                    i += 1;
                    if (i < argv.length) {
                        dataFile = argv[i];
                    }
                    else {
                        printUsage("Data file name not provided");
                    }
                }
                else if ("-to".equals(curArg)) {
                    i += 1;
                    if (i < argv.length) {
                        try {
                            timeout = Long.parseLong(argv[i]);
                        }
                        catch (NumberFormatException e) {
                            printUsage("Timeout must be numeric value");
                        }
                    }
                }
                else if ("-main".equals(curArg)) {
                    i += 1;
                    if (i < argv.length) {
                        ed.setMainClass(argv[i]);
                    }
                    else {
                        printUsage("Main class not specified");
                    }
                    break;
                }
            }
            else {
                break;
            }
        }

        if (dataFile == null) {
            printUsage("You must supply a module data file");
        }
        if (ed.getMainClass() == null) {
            printUsage("You must specify a main class");
        }

        for (++i; i < argv.length; i++) {
            ed.addArgument(argv[i]);
        }

        SemanticDataHandler sdh = new SemanticDataHandler();
        try {
            ed.setEDData(sdh.readDataFile(dataFile));
        }
        catch (BadFileFormatException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        DynamicEscapeDetector escapeDetector = new DynamicEscapeDetector();
        HappenBeforeChecker hbChecker = new HappenBeforeChecker(escapeDetector);
        MultiLocksetRaceDetector raceDetector = new MultiLocksetRaceDetector(
            escapeDetector, hbChecker, objectSensitive);
        EventClassifier classifier = new DefaultEventClassifier(
            objectSensitive, raceDetector, hbChecker);
        ResultCollector results = new ResultCollector();

        // The order is important here...
        ed.addEventListener(escapeDetector);
        ed.addEventListener(hbChecker);
        ed.addEventListener(raceDetector);
        ed.addEventListener(classifier);
        ed.addEventListener(new ThreadFilter(
            AutomataController.getFactory(classifier, results)));

        Runtime runtime = Runtime.getRuntime();
        long startMem = runtime.totalMemory() - runtime.freeMemory();

        try {
            ed.startDispatcher(timeout);
        }
        catch (IllegalStateException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (InternalException e) {
            Throwable cause = e.getCause();
            if (cause != null) {
                cause.printStackTrace();
            }
            System.err.println(e.getMessage());
            System.exit(1);
        }

        MethodSignature[] methods = results.getMethods();
        for (int n = 0; n < methods.length; n++) {
            boolean isAtomic = results.get(methods[n]);
            if (!isAtomic) {
                System.out.println(methods[n]);
                System.out.println("    [NOT ATOMIC]");
            }
            else {
                System.out.println(methods[n]);
                System.out.println("    [ATOMIC]");
            }
        }

        long finishMem = runtime.totalMemory() - runtime.freeMemory();
        long maxMem = runtime.maxMemory();
        long usedMem = finishMem - startMem;

        System.out.println();
        System.out.println(" Available memory: " + maxMem);
        System.out.println(" Start memory use: " + startMem);
        System.out.println("Finish memory use: " + finishMem);
        System.out.println("  Memory consumed: " + usedMem +
            " (" + Math.round(((double) usedMem / maxMem) * 100) + "%)");
        System.out.println();

        //System.out.println(((ThreadFilter) mt.listeners[1]).getTraceErrors().size());
    }
}
