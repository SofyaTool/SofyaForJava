/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base.exceptions;

/**
 * Defines an exception which indicates that the classpath provided to
 * Sofya appears to be incomplete with respect to the program under
 * analysis.
 *
 * <p>If the classpath provided on Sofya invocation is unable to
 * resolve all classes in the program under analysis, introspection
 * required by Sofya to perform its analysis may fail. This is most
 * common when a program class under analysis by Sofya transitively
 * initiates introspection on another program class that cannot be
 * resolved on the given classpath.</p>
 *
 * @author Alex Kinneer
 * @version 06/09/2006
 */
public class IncompleteClasspathException extends RuntimeException  {
    /** Wrapped exception that is the original cause, if applicable. */
    private Throwable cause = null;

    /** Creates an instance with no message. */
    public IncompleteClasspathException() { super(); }

    /** Creates an instance with the given message. */
    public IncompleteClasspathException(String s) { super(s); }

    /** Creates an instance with the given cause. */
    public IncompleteClasspathException(Throwable e) {
        super();
        cause = e;
    }

    /** Creates an instance with the given message wrapping another
        exception. */
    public IncompleteClasspathException(String s, Throwable e) {
        super(s);
        cause = e;
    }

    /** Gets the exception that is the original source of the problem
        (may be <code>null</code>). */
    public Throwable getCause() {
        return cause;
    }
}
