/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base.exceptions;

/**
 * Error which indicates some inconsistency in the compile-time configuration
 * of the Sofya system.
 *
 * @author Alex Kinneer
 * @version 09/23/2004
 */
public class ConfigurationError extends SofyaError {
    /**
     * Creates a new error indicating a configuration problem.
     */
    public ConfigurationError() {
        super();
    }
    
    /**
     * Creates a new error indicating a configuration problem with
     * a message.
     *
     * @param msg Message describing the nature of the configuration
     * error.
     */
    public ConfigurationError(String msg) {
        super(msg);
    }
    
    /**
     * Creates a new error indicating a configuration problem with
     * a message and encapsulating an original cause for failure.
     *
     * @param msg Message describing the nature of the configuration
     * error.
     * @param cause Exception which indicated the configuration error.
     */
    public ConfigurationError(String msg, Throwable cause) {
        super(msg, cause);
    }
}
