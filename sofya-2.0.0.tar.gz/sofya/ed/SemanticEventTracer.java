/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed;

import java.util.*;
import java.io.*;

import sofya.base.exceptions.BadFileFormatException;
import sofya.ed.semantic.*;
import sofya.ed.semantic.SemanticEventDispatcher.InternalException;

/**
 * <p>A semantic event tracer collects binary trace files recording the events
 * specified in a module description file that were witnessed during
 * execution of a program.</p>
 *
 * @author Alex Kinneer
 * @version 06/12/2005
 */
public class SemanticEventTracer {
    private SemanticEventTracer() {
    }

    /**
     * Prints the usage message and exits.
     *
     * @param msg Targeted explanation of the usage error,
     * may be <code>null</code>.
     */
    private static void printUsage(String msg) {
        if (msg != null) System.err.println(msg);
        System.err.println("Usage:");
        System.err.println("java sofya.eg.ModuleTracer -md " +
            "<data_file> -main <main_class> [arg1 arg2 ...]");
        System.exit(1);
    }

    /**
     * Entry point for the module tracer.
     */
    public static void main(String[] argv) {
        if (argv.length < 4) {
            printUsage(null);
        }

        SemanticEventDispatcher ed = new SemanticEventDispatcher();
        String dataFile = null;
        boolean toConsole = false;

        int i = 0;
        for ( ; i < argv.length; i++) {
            String curArg = argv[i];
            if (curArg.startsWith("-")) {
                if ("-md".equals(curArg)) {
                    i += 1;
                    if (i < argv.length) {
                        dataFile = argv[i];
                    }
                    else {
                        printUsage("Data file name not provided");
                    }
                }
                else if ("-main".equals(curArg)) {
                    i += 1;
                    if (i < argv.length) {
                        ed.setMainClass(argv[i]);
                    }
                    else {
                        printUsage("Main class not specified");
                    }
                    break;
                }
                else if ("-cout".equals(curArg)) {
                    toConsole = true;
                }
            }
            else {
                break;
            }
        }

        if (dataFile == null) {
            printUsage("You must supply a module data file");
        }
        if (ed.getMainClass() == null) {
            printUsage("You must specify a main class");
        }

        for (++i; i < argv.length; i++) {
            ed.addArgument(argv[i]);
        }

        SemanticDataHandler sdh = new SemanticDataHandler();
        try {
            ed.setEDData(sdh.readDataFile(dataFile));
        }
        catch (BadFileFormatException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        if (toConsole) {
            ed.addEventListener(new ConsoleTarget());
        }

        /*ed.addEventListener(new ThreadFilter(
            ObjectFilter.getFactory(
            TraceFileTarget.getFactory(ed.getEGData()))));

        eg.addEventListener(new ThreadFilter(
            TraceFileTarget.getFactory(eg.getEGData())));

        eg.addEventListener(new ObjectFilter(
            TraceFileTarget.getFactory(eg.getEGData())));*/

        try {
            ed.addEventListener(
                new TraceFileTarget("eg.tr", ed.getEDData()));
        }
        catch (IOException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }

        try {
            ed.startDispatcher();
        }
        catch (IllegalStateException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (InternalException e) {
            Throwable cause = e.getCause();
            if (cause != null) {
                cause.printStackTrace();
            }
            System.err.println(e.getMessage());
            System.exit(1);
        }

        //System.out.println(((ThreadFilter) mt.listeners[1]).getTraceErrors().size());
    }
}
