/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

/**
 * Event filter which provides null implementations of all of the
 * {@link EventListener} methods, thus discarding the events. This
 * is intended as a convenience for subclasses, which can then
 * selectively override to respond to the events of interest.
 *
 * @author Alex Kinneer
 * @version 11/15/2005
 */
public abstract class EventSelectionFilter extends EventFilter {
    
    // Null implementation of the interface
    
    public void systemStarted() {
    }
    
    public void executionStarted() {
    }
    
    public void threadStartEvent(ThreadData td) {
    }
    
    public void threadDeathEvent(ThreadData td) {
    }
    
    public void classPrepareEvent(ThreadData td, String className) {
    }
    
    public void monitorContendEvent(ThreadData td, ObjectData od,
            MonitorData md) {
    }
    
    public void monitorAcquireEvent(ThreadData td, ObjectData od,
            MonitorData md) {
    }
    
    public void monitorPreReleaseEvent(ThreadData td, ObjectData od,
            MonitorData md) {
    }
    
    public void monitorReleaseEvent(ThreadData td, ObjectData od,
            MonitorData md) {
    }
    
    public void newAllocationEvent(ThreadData td, NewAllocationData nad) {
    }

    public void constructorCallEvent(ThreadData td, CallData cd) {
    }
    
    public void constructorEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void constructorExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void staticFieldAccessEvent(ThreadData td, FieldData fd) {
    }
    
    public void instanceFieldAccessEvent(
            ThreadData td, ObjectData od, FieldData fd) {
    }
    
    public void staticFieldWriteEvent(ThreadData td, FieldData fd) {
    }
    
    public void instanceFieldWriteEvent(
            ThreadData td, ObjectData od, FieldData fd) {
    }
    
    public void staticCallEvent(ThreadData td, CallData cd) {
    }
    
    public void virtualCallEvent(ThreadData td, CallData cd) {
    }
    
    public void interfaceCallEvent(ThreadData td, CallData cd) {
    }
    
    public void callReturnEvent(ThreadData td, CallData cd,
            boolean exceptional) {
    }
    
    public void virtualMethodEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void virtualMethodExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
    }
    
    public void staticMethodEnterEvent(ThreadData td, MethodData md) {
    }
    
    public void staticMethodExitEvent(ThreadData td, MethodData md) {
    }
    
    public void exceptionThrowEvent(ThreadData td, ExceptionData ed) {
    }
    
    public void exceptionCatchEvent(ThreadData td, ExceptionData ed) {
    }
    
    public void staticInitializerEnterEvent(ThreadData td, MethodData md) {
    }
    
    public void systemExited() {
    }
}
