/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import java.io.*;
import java.util.*;
import java.util.jar.*;
import java.util.zip.*;
import java.text.NumberFormat;

import sofya.base.*;
import sofya.base.exceptions.*;
import sofya.ed.Instrumentor;
import sofya.ed.semantic.EventSpecification.MonitorType;

import org.apache.bcel.Constants;
import org.apache.bcel.Repository;
import org.apache.bcel.generic.*;
import org.apache.bcel.classfile.*;

import gnu.trove.THashSet;
import gnu.trove.THashMap;
import gnu.trove.TObjectIntHashMap;

import org.apache.commons.collections.map.ReferenceMap;

/**
 * The instrumentor for semantic event dispatching. This class compiles an event
 * specification for the {@link SemanticEventDispatcher} and uses the
 * specification to insert probes necessary to enable the
 * {@link SemanticEventDispatcher} to produce all of those events.
 *
 * <p>This class can be used to instrument for semantic event dispatch by
 * compiling an event specification given by a module description file.
 * It is also used to instrument for atomicity checking.</p>
 *
 * <p><strong>Note that the instrumentation should only ever be applied once,
 * or the behavior of the tools is undefined.</strong> If the parameters of
 * the instrumentation need to be changed (e.g. as by a change to the
 * module description), the system should be recompiled first and then
 * instrumented again.</p>
 *
 * @author Alex Kinneer
 * @version 06/09/2006
 */
public class SemanticInstrumentor extends Instrumentor {
    /** Reference to the instrumentor, used by the main method. */
    private static SemanticInstrumentor inst = null;

    /** Name of the method currently being instrumented. */
    protected String methodName;

    /** Compiled representation of the event specification. */
    protected EventSpecification eventSpec;
    /** Data file generated for the {@link SemanticEventDispatcher}. */
    protected SemanticEventData dataFile;
    /** Set of classes comprising the entire system. */
    protected Set systemClasses;
    /** Set of classes for which observables are included by default. */
    protected Set moduleClasses;
    /** Flag which specifies whether boundary events are to be raised
        (execution entering or leaving the module through method calls). */
    protected boolean autoBoundaryEvents = true;

    /** Stores the first instruction of an un-instrumented method; used
        to ensure legal insertion of certain instrumentation. */
    protected InstructionHandle origStart;
    /** Stores the last instruction of an un-instrumented method; used
        to properly target various instrumentation instructions. */
    protected InstructionHandle origEnd;
    /** Local variable index used to hold exception objects in
        inserted exception handlers. */
    protected int excHandlerVar;
    /** Exception handlers associated with the method currently being
        instrumented. */
    protected CodeExceptionGen[] exceptionHandlers;
    /** Maps instruction handles to source code line numbers, these are
        pre-loaded from the method line number table before beginning
        instrumentation of the method. */
    protected TObjectIntHashMap lineNumbers = new TObjectIntHashMap();

    /** Caches previously created interceptor methods, so that they can be
        used by multiple calls to the same intercepted method. */
    protected Map interceptorCache = new THashMap();
    /** Next available ID for an interceptor, to avoid name collisions. */
    protected int curInterceptID = 0;

    /** Memory-sensitive cache that records the results of querying whether
        a method is <code>native</code>. */
    private static Map nativeMethodsCache =
        new ReferenceMap(ReferenceMap.SOFT, ReferenceMap.HARD);

    public static final String PROBE_CLASS = "sofya.ed.semantic.EDProbe";

    /** Name of the probe field used to record event type codes.
        A field by this name is inserted in instrumented classes, thus
        it is constructed in a way that is intended to avoid a naming
        collision with any existing fields. */
    protected static final String codeFieldName = "_inst$$zk183_$code$";
    /** Name of the probe field used to record class prepare events. */
    protected static final String loadFieldName = "_inst$$zk183_$load$";
    /** Name of the probe field used to record object types for relevant
        events, such as exception related events. */
    protected static final String typeFieldName = "_inst$$zk183_$type$";

    /** Name prefix for probe fields used to record monitor events. */
    protected static final String monFieldPrefix = "_inst$$zk183_$mon$";
    /** Name of the probe field used to record monitor contention events. */
    protected static final String moncFieldName = monFieldPrefix +
        SemanticConstants.EVENT_MONITOR_CONTEND;
    /** Name of the probe field used to record monitor acquisition events. */
    protected static final String monaFieldName = monFieldPrefix +
        SemanticConstants.EVENT_MONITOR_ACQUIRE;
    /** Name of the probe field used to record monitor-to-be-released events. */
    protected static final String monprFieldName = monFieldPrefix +
        SemanticConstants.EVENT_MONITOR_PRE_RELEASE;
    /** Name of the probe field used to record monitor released events. */
    protected static final String monrFieldName = monFieldPrefix +
        SemanticConstants.EVENT_MONITOR_RELEASE;

    /** Name prefix for probe fields used to record array element events. */
    protected static final String arrFieldPrefix = "_inst$$zk183_$arr$";
    /** Name of the probe field used to record array element read events. */
    protected static final String arrRefRdFieldName = arrFieldPrefix + "ref$rd";
    /** Name of the probe field used to record array element write events. */
    protected static final String arrRefWrFieldName = arrFieldPrefix + "ref$wr";
    /** Name of the probe field used to record array event element indices. */
    protected static final String arrIdxFieldName = arrFieldPrefix + "idx$";

    /** Special flag field that may be used to receive very limited commands
        back from the event dispatcher. */
    protected static final String flagFieldName = "_inst$$zk183_$flag$";

    // 2 bits for type code
    // 00: event
    // 01: assert
    // 10: <unused>
    // 11: <unused>
    //
    // if (event)
    //   8 bits for event code
    //   2 flag bits
    //   20 bits for index
    // else if (assert)
    //   2 bits reserved for future use
    //   28 bits for assert ID

    /**
     * Constructs the bitmask for an event probe, such that only the
     * string index needs to be added.
     *
     * @param eventCode Code for the type of observable event marked
     * by the probe.
     *
     * @return The encoded bitmask for the observable event of the
     * given type. The string index can simply be added to this result.
     */
    private static int buildEventMask(int eventCode) {
        return SemanticConstants.TYPE_EVENT + (eventCode << 22);
    }

    private SemanticInstrumentor() {
        throw new UnsupportedOperationException();
    }

    /**
     * Creates a new module instrumentor.
     *
     * @param edd Event dispatch data object to which this instrumentor
     * will store event dispatch information.
     */
    public SemanticInstrumentor(SemanticEventData edd) {
        dataFile = edd;
        eventSpec = edd.getEventSpecification();
        systemClasses = eventSpec.getSystemClasses(true);
        moduleClasses = eventSpec.getModuleClasses(true);
    }

    protected void init(int port) throws IOException {
        super.init(port);
        curInterceptID = 0;
        interceptorCache.clear();
    }

    /**
     * Gets the name of the class referenced by probes inserted by this
     * instrumentor.
     *
     * @return The name of the probe class used by this instrumentor.
     */
    protected String getProbeClassName() {
        return PROBE_CLASS;
    }

    /**
     * Reports whether the instrumentor is set to insert probes to
     * automatically observe module boundary events (calls which cause
     * execution to exit the module).
     *
     * @return <code>true</code> if calls to methods outside of the
     * module are to generate events regardless of the module
     * description, <code>false</code> otherwise.
     */
    public boolean isAutoBoundaryEventsEnabled() {
        return autoBoundaryEvents;
    }

    /**
     * Specifies whether the instrumentor is to insert probes to
     * automatically observe module boundary events (calls which cause
     * execution to exit the module).
     *
     * @param enable <code>true</code> if calls to methods outside of the
     * module are to be instrumented to generate events regardless of the
     * module description, <code>false</code> otherwise.
     */
    public void setAutoBoundaryEventsEnabled(boolean enable) {
        autoBoundaryEvents = enable;
    }

    /**
     * Instruments a method.
     *
     * <p>Performs the actual instrumentation and update of the method in the
     * class.</p>
     *
     * @param m Method to be instrumented.
     * @param methodIndex Index to the method in the class method array.
     * @param insertStarter <em>Ignored</em>.
     *
     * @return The instrumented method. If the method is <code>native</code>,
     * <code>abstract</code>, or has no body, it is returned unchanged.
     */
    protected Method instrument(Method m, int methodIndex,
            boolean insertStarter) {
        if (m.isNative() || m.isAbstract()) {
            return m;
        }

        mSignature = fullClassName + "#" + m.getName() + "#" +
            m.getSignature();

        MethodGen mg = new MethodGen(m, fullClassName, cpg);
        InstructionList il = mg.getInstructionList();
        methodName = mg.getName();

        exceptionHandlers = mg.getExceptionHandlers();
        cacheHandlerStarts(exceptionHandlers);

        // Load the line number table.
        lineNumbers.clear();
        LineNumberGen[] lnTable = mg.getLineNumbers();
        for (int i = 0; i < lnTable.length; i++) {
            lineNumbers.put(lnTable[i].getInstruction(),
                            lnTable[i].getSourceLine());
        }

        boolean isConstructor = methodName.equals("<init>");
        if (isConstructor) {
            origStart = findCallToSuper(il).getNext();
        }
        else {
            origStart = il.getStart();
        }
        origEnd = il.getEnd();

        // Create an extra local variable which will be used for the temporary
        // storage of exception objects when adding exceptional exit nodes
        excHandlerVar = mg.getMaxLocals();
        mg.setMaxLocals(mg.getMaxLocals() + 1);

        InstructionHandle syntheticHandler = null;
        if (mg.isSynchronized()) {
            syntheticHandler = transformSynchronization(mg, il);
        }

        boolean superConstructorCalled = false;
        InstructionHandle ih;
        for (ih = il.getStart(); ih != null; ih = ih.getNext()) {
            Instruction i = ih.getInstruction();

            if (handlerStarts.contains(ih)) {
                addCatchProbe(mg, il, ih);
            }

            switch (i.getOpcode()) {
            case Constants.NEW:
                addNewObjectProbe(mg, il, ih);
                break;
            case Constants.MONITORENTER:
                addMonitorEnterProbes(mg, il, ih);
                break;
            case Constants.MONITOREXIT:
                addMonitorExitProbes(mg, il, ih);
                break;
            case Constants.INVOKESTATIC:
                addCallProbe(SemanticConstants.EVENT_STATIC_CALL, mg, il, ih);
                break;
            case Constants.INVOKEVIRTUAL:
                addCallProbe(SemanticConstants.EVENT_VIRTUAL_CALL, mg, il, ih);
                break;
            case Constants.INVOKEINTERFACE:
                addCallProbe(SemanticConstants.EVENT_INTERFACE_CALL, mg, il, ih);
                break;
            case Constants.INVOKESPECIAL:
                int eventCode =
                    ((InvokeInstruction) i).getMethodName(cpg).equals("<init>")
                    ? SemanticConstants.EVENT_CONSTRUCTOR
                    : SemanticConstants.EVENT_VIRTUAL_CALL;
                if (superConstructorCalled) {
                    addCallProbe(eventCode, mg, il, ih);
                }
                else {
                    if (eventCode == SemanticConstants.EVENT_CONSTRUCTOR) {
                        superConstructorCalled = true;
                    }
                    else {
                        addCallProbe(eventCode, mg, il, ih);
                    }
                }
                break;
            case Constants.AASTORE: case Constants.BASTORE:
            case Constants.CASTORE: case Constants.DASTORE:
            case Constants.FASTORE: case Constants.IASTORE:
            case Constants.LASTORE: case Constants.SASTORE:
                insertArrayProbe(il, ih, true);
                break;
            case Constants.AALOAD: case Constants.BALOAD:
            case Constants.CALOAD: case Constants.DALOAD:
            case Constants.FALOAD: case Constants.IALOAD:
            case Constants.LALOAD: case Constants.SALOAD:
                insertArrayProbe(il, ih, false);
                break;
            default:
                break;
            }
        }

        // Remove and re-add all exception handlers previously attached
        // to the method, which causes all of the handlers which have been
        // added to raise call return events on exceptional return to bind
        // first (those handlers then transfer control back to the existing
        // handlers). If BCEL had a slightly lower suckage factor and we
        // could *insert* new exception handlers, this wouldn't be necessary...
        for (int i = 0; i < exceptionHandlers.length; i++) {
            CodeExceptionGen handler = exceptionHandlers[i];
            mg.removeExceptionHandler(handler);
            mg.addExceptionHandler(handler.getStartPC(),
                                   handler.getEndPC(),
                                   handler.getHandlerPC(),
                                   handler.getCatchType());
        }

        addEntryProbes(mg, il);
        addExitProbes(mg, il, syntheticHandler);

        // Check to see whether the start marker still needs to be inserted,
        // and if so, do it
        if ((classHasMain || classHasStaticInit) && !starterInserted) {
            if (classHasStaticInit) {
                if (methodName.equals("<clinit>")) {
                    insertStartProbe(il);
                    starterInserted = true;
                }
            }
            else if (methodName.equals("main")) {
                insertStartProbe(il);
                starterInserted = true;
            }
        }

        // Insert the new instruction list into the method
        mg.setInstructionList(il);

        // As we have added new method calls (trace prints) to the
        // method, the operand stack size needs to be recalculated.
        // This is done by BCEL using control-flow analysis.
        mg.setMaxStack();

        Method mInstrumented = mg.getMethod();
        il.dispose();

        origStart = origEnd = null;

        return mInstrumented;
    }

    /**
     * Searches a constructor for the call to its superclass constructor.
     *
     * <p>The behavior of this method is undefined if called on a method
     * that is not a constructor.</p>
     *
     * @param il Instruction list of the constructor to be searched.
     *
     * @return The handle to the invoke instruction representing the
     * call to the superclass constructor.
     */
    private InstructionHandle findCallToSuper(InstructionList il) {
        InstructionHandle ih;
        for (ih = il.getStart(); ih != null; ih = ih.getNext()) {
            Instruction i = ih.getInstruction();
            if (i instanceof INVOKESPECIAL) {
                INVOKESPECIAL is = (INVOKESPECIAL) i;
                try {
                    ObjectType t1 = new ObjectType(fullClassName);
                    ObjectType t2 =
                        new ObjectType(is.getReferenceType(cpg).toString());
                    if (t1.subclassOf(t2)) {
                        break;
                    }
                }
                catch (ClassNotFoundException e) {
                    throw new IncompleteClasspathException(e);
                }
            }
        }

        if (ih == null) {
            throw new ClassFormatError("Constructor does not call " +
                "superclass constructor");
        }

        return ih;
    }

    /**
     * Transforms a synchronized method to make it the equivalent of
     * enclosing the method body in a synchronized block and removing
     * the synchronized flag.
     *
     * <p>This enables all monitor related events to be properly raised
     * for synchronized methods.</p>
     *
     * @param mg BCEL handle to the method to be transformed.
     * @param il Instruction list for the method to be transformed.
     *
     * @return A handle to the last instruction of the synthetic exception
     * handler that is inserted to ensure release of the monitor on
     * exceptional exit. This may be used later to insert other instructions
     * that should be executed before an exceptional exit (such as method
     * exit instrumentation).
     */
    private InstructionHandle transformSynchronization(MethodGen mg,
            InstructionList il) {
        // Construct the entry and exit patches
        InstructionList enterPatch = new InstructionList();
        InstructionList exitPatch = new InstructionList();

        if (mg.isStatic()) {
            // For efficiency, we'll cache the reference to the class object
            // that is locked so that at the exit points we can just load it
            // from a local variable instead of calling getClass() again.
            // We create a new local variable for this purpose.
            int clLocalVar = mg.getMaxLocals();
            mg.setMaxLocals(mg.getMaxLocals() + 1);

            enterPatch.append(new PUSH(cpg, fullClassName));
            enterPatch.append(iFactory.createInvoke("java.lang.Class",
                "forName", Type.getType("Ljava/lang/Class;"),
                new Type[]{Type.STRING}, Constants.INVOKESTATIC));
            enterPatch.append(new DUP());
            enterPatch.append(new ASTORE(clLocalVar));
            exitPatch.append(new ALOAD(clLocalVar));
        }
        else {
            enterPatch.append(new ALOAD(0));
            exitPatch.append(new ALOAD(0));
        }
        enterPatch.append(new MONITORENTER());
        exitPatch.append(new MONITOREXIT());

        il.insert(il.getStart(), enterPatch);
        enterPatch.dispose();

        insertBeforeReturns(il, exitPatch);

        // Insert GOTO that will jump handler by default
        InstructionHandle newEnd = il.insert(origEnd, new GOTO(origEnd));
        if (origStart == origEnd) { origStart = newEnd; }

        // Insert handler instructions
        InstructionList excExitPatch = exitPatch.copy();
        InstructionHandle relHandlerEnd = excExitPatch.getEnd();
        InstructionHandle handlerEnd = excExitPatch.append(new ATHROW());
        InstructionHandle handlerStart = il.insert(origEnd, excExitPatch);

        il.setPositions();
        exitPatch.dispose();
        excExitPatch.dispose();

        // Add handler - null catches any type
        mg.addExceptionHandler(origStart, newEnd, handlerStart,
            (ObjectType) null);

        // Add failsafe handler to ensure lock is released - emulated
        // from bytecode generated by the Sun compiler
        mg.addExceptionHandler(handlerStart, relHandlerEnd,
            handlerStart, (ObjectType) null);

        // Remove synchronization flag from method
        mg.setAccessFlags(mg.getAccessFlags() & ~Constants.ACC_SYNCHRONIZED);

        //return handlerStart;
        return handlerEnd;
    }

    /**
     * Inserts a sequence of instructions before every <code>return</code>
     * in a method.
     *
     * <p>This is used to implement such things as method exit instrumentation
     * and synchronized method transformation.</p>
     *
     * @param il Instruction list of the method.
     * @param patch Sequence of instructions to be inserted before every
     * <code>return</code>.
     */
    private void insertBeforeReturns(InstructionList il,
            InstructionList patch) {
        InstructionHandle ih = il.getStart();
        for ( ; ih != null; ih = ih.getNext()) {
            if (ih.getInstruction() instanceof ReturnInstruction) {
                InstructionHandle new_ih = il.insert(ih, patch.copy());
                // Update targets of any instructions pointing to the return
                // instruction
                InstructionTargeter[] targeters = ih.getTargeters();
                if (targeters != null) {
                    for (int t = 0; t < targeters.length; t++) {
                        if (targeters[t] instanceof CodeExceptionGen) {
                            CodeExceptionGen exceptionHandler =
                                (CodeExceptionGen) targeters[t];
                            if ((exceptionHandler.getStartPC() == ih) ||
                                    (exceptionHandler.getEndPC() == ih)) {
                                continue;
                            }
                        }
                        targeters[t].updateTarget(ih, new_ih);
                    }
                }
            }
        }
    }

    /**
     * Inserts a one-time probe indicating the system is starting.
     *
     * @param il Instruction list for the method.
     */
    private void insertStartProbe(InstructionList il) {
        InstructionList patch = new InstructionList();

        int strIndex = dataFile.addString("<start>");
        patch.append(new PUSH(cpg,
            buildEventMask(SemanticConstants.EVENT_START) + strIndex));
        patch.append(iFactory.createPutStatic(instClassRef,
            codeFieldName, Type.INT));

        InstructionHandle new_ih = il.insert(il.getStart(), patch);
        patch.dispose();
    }

    /**
     * Adds method entry probes to a method; handles all types of methods
     * including static initializers.
     *
     * @param mg BCEL handle to the method for which to insert method entry
     * probes.
     * @param il Instruction list for the method to be instrumented.
     */
    private void addEntryProbes(MethodGen mg, InstructionList il) {
        InstructionList instCode;
        InstructionHandle insert_ih;
        Instruction store_instr;
        int packedEntry;

        if (mg.isStatic()) {
            if (mg.getName().equals("<clinit>")) {
                if (!eventSpec.witnessStaticInitializerEntry(fullClassName)) {
                    return;
                }

                packedEntry = buildEventMask(
                     SemanticConstants.EVENT_STATIC_INIT_ENTER);
            }
            else {
                if (!eventSpec.witnessMethodEntry(mg)) {
                    return;
                }

                packedEntry = buildEventMask(
                    SemanticConstants.EVENT_SMETHOD_ENTER);
            }

            instCode = new InstructionList();
            store_instr = iFactory.createPutStatic(instClassRef,
                codeFieldName, Type.INT);

            insert_ih = il.getStart();
        }
        else {
            if (mg.getName().equals("<init>")) {
                if (!eventSpec.witnessConstructorEntry(mg)) {
                    return;
                }

                packedEntry = buildEventMask(
                    SemanticConstants.EVENT_CONSTRUCTOR_ENTER);
                insert_ih = origStart;
            }
            else {
                if (!eventSpec.witnessMethodEntry(mg)) {
                    return;
                }

                packedEntry = buildEventMask(
                    SemanticConstants.EVENT_VMETHOD_ENTER);
                insert_ih = il.getStart();
            }

            instCode = new InstructionList();
            instCode.append(new ALOAD(0));
            store_instr = iFactory.createPutField(fullClassName,
                codeFieldName, Type.INT);
        }

        StringBuffer sb = new StringBuffer();
        sb.append(mg.getClassName());
        sb.append("#");
        sb.append(mg.getName());
        sb.append("#");
        sb.append(mg.getSignature());
        packedEntry += dataFile.addString(sb.toString());

        instCode.append(new PUSH(cpg, packedEntry));
        instCode.append(store_instr);

        il.insert(insert_ih, instCode);
        instCode.dispose();
    }

    /**
     * Adds method exit probes to a method; handles all types of methods
     * including static initializers.
     *
     * @param mg BCEL handle to the method for which to insert method exit
     * probes.
     * @param il Instruction list for the method to be instrumented.
     * @param syntheticHandler Handle to the last instruction of any
     * synthetic catch-all handler previously inserted; used to guarantee
     * an exit event even on exceptional exit. May be <code>null</code>,
     * in which case the handler will be created.
     */
    public void addExitProbes(MethodGen mg, InstructionList il,
            InstructionHandle syntheticHandler) {
        InstructionList instCode;
        Instruction store_instr;
        int packedEntry;

        if (mg.isStatic()) {
            if (mg.getName().equals("<clinit>")) {
                return;
            }
            else {
                if (!eventSpec.witnessMethodExit(mg)) {
                    return;
                }

                packedEntry = buildEventMask(
                    SemanticConstants.EVENT_SMETHOD_EXIT);
            }

            instCode = new InstructionList();
            store_instr = iFactory.createPutStatic(instClassRef,
                codeFieldName, Type.INT);
        }
        else {
            if (mg.getName().equals("<init>")) {
                if (!eventSpec.witnessConstructorExit(mg)) {
                    return;
                }

                packedEntry = buildEventMask(
                    SemanticConstants.EVENT_CONSTRUCTOR_EXIT);
            }
            else {
                if (!eventSpec.witnessMethodExit(mg)) {
                    return;
                }

                packedEntry = buildEventMask(
                    SemanticConstants.EVENT_VMETHOD_EXIT);
            }

            instCode = new InstructionList();
            instCode.append(new ALOAD(0));
            store_instr = iFactory.createPutField(fullClassName,
                codeFieldName, Type.INT);
        }

        StringBuffer sb = new StringBuffer();
        sb.append(mg.getClassName());
        sb.append("#");
        sb.append(mg.getName());
        sb.append("#");
        sb.append(mg.getSignature());
        packedEntry += dataFile.addString(sb.toString());

        instCode.append(new PUSH(cpg, packedEntry));
        instCode.append(store_instr);

        // Insert instrumentation for regular return
        insertBeforeReturns(il, instCode);

        // Insert handler instructions
        if (syntheticHandler == null) {
            InstructionHandle newEnd = il.insert(origEnd, new GOTO(origEnd));
            if (origStart == origEnd) { origStart = newEnd; }

            InstructionList handlerCode = instCode.copy();
            handlerCode.append(new ATHROW());
            InstructionHandle handlerStart = il.insert(origEnd, handlerCode);

            // Add handler - null catches any type
            mg.addExceptionHandler(origStart, newEnd, handlerStart,
                (ObjectType) null);
        }
        else {
            il.insert(syntheticHandler, instCode.copy());
        }
        il.setPositions();

        instCode.dispose();
    }

    /**
     * Inserts probes to raise monitor contention and acquisition events.
     *
     * @param il Instruction list for the method.
     * @param ih Handle to the <code>MONITORENTER</code> instruction.
     */
    private void addMonitorEnterProbes(MethodGen mg, InstructionList il,
            InstructionHandle ih) {
        InstructionList patch = new InstructionList();

        boolean witnessContend =
            eventSpec.witnessAnyMonitor(MonitorType.CONTEND, mg);
        boolean witnessAcquire =
            eventSpec.witnessAnyMonitor(MonitorType.ACQUIRE, mg);

        if (witnessContend) {
            patch.append(new DUP());

            if (witnessAcquire) {
                patch.append(new DUP());
            }

            patch.append(iFactory.createPutStatic(instClassRef,
                moncFieldName, Type.OBJECT));

            InstructionHandle new_ih = il.insert(ih, patch);

            // Update targeters, which includes all affected branches
            // and exception handlers
            InstructionTargeter[] targeters = ih.getTargeters();
            if (targeters != null) {
                for (int t = 0; t < targeters.length; t++) {
                    if (targeters[t] instanceof CodeExceptionGen) {
                        CodeExceptionGen exceptionHandler =
                            (CodeExceptionGen) targeters[t];
                        if ((exceptionHandler.getStartPC() == ih) ||
                            (exceptionHandler.getEndPC() == ih)) {
                            continue;
                        }
                    }
                    targeters[t].updateTarget(ih, new_ih);
                }
            }
            patch.dispose();
        }

        if (witnessAcquire) {
            patch.append(iFactory.createPutStatic(instClassRef,
                monaFieldName, Type.OBJECT));

            il.append(ih, patch);
            patch.dispose();
        }
    }

    /**
     * Inserts probes to raise monitor to-be-released and released events.
     *
     * @param il Instruction list for the method.
     * @param ih Handle to the <code>MONITOREXIT</code> instruction.
     */
    private void addMonitorExitProbes(MethodGen mg, InstructionList il,
            InstructionHandle ih) {
        InstructionList patch = new InstructionList();

        boolean witnessPreRelease =
            eventSpec.witnessAnyMonitor(MonitorType.PRE_RELEASE, mg);
        boolean witnessRelease =
            eventSpec.witnessAnyMonitor(MonitorType.RELEASE, mg);

        if (witnessPreRelease) {
            patch.append(new DUP());

            if (witnessRelease) {
                patch.append(new DUP());
            }

            patch.append(iFactory.createPutStatic(instClassRef,
                monprFieldName, Type.OBJECT));

            InstructionHandle new_ih = il.insert(ih, patch);

            // Update targeters, which includes all affected branches
            // and exception handlers
            InstructionTargeter[] targeters = ih.getTargeters();
            if (targeters != null) {
                for (int t = 0; t < targeters.length; t++) {
                    if (targeters[t] instanceof CodeExceptionGen) {
                        CodeExceptionGen exceptionHandler =
                            (CodeExceptionGen) targeters[t];
                        if ((exceptionHandler.getStartPC() == ih) ||
                            (exceptionHandler.getEndPC() == ih)) {
                            continue;
                        }
                    }
                    targeters[t].updateTarget(ih, new_ih);
                }
            }
            patch.dispose();
        }

        if (witnessRelease) {
            patch.append(iFactory.createPutStatic(instClassRef,
                monrFieldName, Type.OBJECT));

            il.append(ih, patch);
            patch.dispose();
        }
    }

    /**
     * Inserts a probe to observe the execution of a <code>NEW</code>
     * instruction.
     *
     * @param il Instruction list for the method.
     * @param ih Handle to the <code>NEW</code> instruction in the
     * instruction list.
     */
    private void addNewObjectProbe(MethodGen mg, InstructionList il,
            InstructionHandle ih) {
        CPInstruction cpi = (CPInstruction) ih.getInstruction();
        Constant c = (Constant) cpg.getConstant(cpi.getIndex());

        int nameIndex = ((ConstantClass) c).getNameIndex();
        String className = ((ConstantUtf8)
            cpg.getConstant(nameIndex)).getBytes().replace('/', '.');

        if (!eventSpec.witnessNewObject(className, mg)) {
            return;
        }

        int strIndex = dataFile.addString(className);
        int packedEntry = buildEventMask(SemanticConstants.EVENT_NEW_OBJ) + strIndex;

        InstructionList patch = new InstructionList();
        patch.append(new PUSH(cpg, packedEntry));
        patch.append(iFactory.createPutStatic(instClassRef,
            codeFieldName, Type.INT));
        InstructionHandle new_ih = il.insert(ih, patch);
        patch.dispose();

        updateTargeters(ih, new_ih);
    }

    /**
     * Inserts a probe to observe a call.
     *
     * @param eventCode Event code associated with the particular type of
     * invoke instruction for which a probe is being inserted.
     * @param il Instruction list for the method.
     * @param ih Handle to the call instruction in the instruction list.
     */
    private void addCallProbe(int eventCode, MethodGen mg,
            InstructionList il, InstructionHandle ih) {
        InvokeInstruction ii = (InvokeInstruction) ih.getInstruction();
        InstructionHandle next_ih = ih.getNext();

        if (!eventSpec.witnessCall(ii, cpg, mg) &&
                (!moduleClasses.contains(fullClassName)
                    || !autoBoundaryEvents)) {
            return;
        }

        StringBuffer sb =
            new StringBuffer(ii.getReferenceType(cpg).toString());
        sb.append("#");
        sb.append(ii.getName(cpg));
        sb.append("#");
        sb.append(ii.getSignature(cpg));
        int strIndex = dataFile.addString(sb.toString());
        int callProbeVal = buildEventMask(eventCode) + strIndex;
        int returnProbeVal =
            buildEventMask(SemanticConstants.EVENT_CALL_RETURN) + strIndex;

        InstructionList regReturnPatch = new InstructionList();
        regReturnPatch.append(new PUSH(cpg, returnProbeVal));
        regReturnPatch.append(iFactory.createPutStatic(instClassRef,
            codeFieldName, Type.INT));
        regReturnPatch.append(new GOTO(next_ih));

        InstructionList excReturnPatch = new InstructionList();
        InstructionHandle handler =
            excReturnPatch.append(new ASTORE(excHandlerVar));
        excReturnPatch.append(new PUSH(cpg, returnProbeVal + (1 << 20)));
        excReturnPatch.append(iFactory.createPutStatic(instClassRef,
            codeFieldName, Type.INT));
        excReturnPatch.append(new ALOAD(excHandlerVar));
        excReturnPatch.append(new ATHROW());

        if (eventSpec.useCallInterceptor(ii, cpg)) {
            insertInterceptor(il, ih, callProbeVal, regReturnPatch,
                excReturnPatch);
        }
        else {
            InstructionList callPatch = new InstructionList();
            callPatch.append(new PUSH(cpg, callProbeVal));
            callPatch.append(iFactory.createPutStatic(instClassRef,
                codeFieldName, Type.INT));
            InstructionHandle new_ih = il.insert(ih, callPatch);
            callPatch.dispose();

            updateTargeters(ih, new_ih);

            il.insert(next_ih, regReturnPatch);
            il.insert(next_ih, excReturnPatch);
            mg.addExceptionHandler(ih, ih, handler, (ObjectType) null);
        }

        regReturnPatch.dispose();
        excReturnPatch.dispose();
    }

    private void insertInterceptor(InstructionList il, InstructionHandle call,
            int callProbeVal, InstructionList regReturnPatch,
            InstructionList excReturnPatch) {
        InvokeInstruction invoke = (InvokeInstruction) call.getInstruction();
        int invokeOpcode = invoke.getOpcode();

        // Ignore calls to constructors
        if ((invokeOpcode == Constants.INVOKESPECIAL)
                && invoke.getMethodName(cpg).equals("<init>")) {
            return;
        }

        MethodSignature invokeSig = new MethodSignature(invoke, cpg);
        if (interceptorCache.containsKey(invokeSig)) {
            InvokeInstruction relayCall =
                (InvokeInstruction) interceptorCache.get(invokeSig);
            call.setInstruction(relayCall.copy());
            return;
        }

        NumberFormat fmt = NumberFormat.getIntegerInstance();
        fmt.setMinimumIntegerDigits(3);
        String interceptorName = "intercept$" + fmt.format(curInterceptID++);

        boolean isStatic = (invokeOpcode == Constants.INVOKESTATIC);
        Type returnType = invoke.getReturnType(cpg);
        Type[] argTypes = invoke.getArgumentTypes(cpg);

        boolean isNative = false;
        if (!isStatic) {
            Type[] tmpArgTypes = new Type[argTypes.length + 1];
            tmpArgTypes[0] = invoke.getLoadClassType(cpg);
            System.arraycopy(argTypes, 0, tmpArgTypes, 1, argTypes.length);
            argTypes = tmpArgTypes;
        }
        else {
            try {
                isNative = isNative(invoke, cpg);
            }
            catch (ClassNotFoundException e) {
                throw new SofyaError("Could not determine if call is " +
                    "to native method");
            }
        }

        String[] argNames = new String[argTypes.length];
        for (int i = 0; i < argNames.length; i++) {
            argNames[i] = "arg" + i;
        }

        InstructionList code = new InstructionList();

        MethodGen interceptor = new MethodGen(
            Constants.ACC_PRIVATE | Constants.ACC_STATIC | Constants.ACC_FINAL,
            returnType, argTypes, argNames,
            interceptorName, fullClassName,
            code,
            cpg);

        // Build interceptor code

        // Insert probe
        callProbeVal = callProbeVal + (1 << 20);  // The interceptor flag
        if (isNative) {
            callProbeVal = callProbeVal + (1 << 21);
        }

        code.append(new PUSH(cpg, callProbeVal));
        InstructionHandle probe = code.append(
            iFactory.createPutStatic(instClassRef, codeFieldName, Type.INT));

        // Copy the source code line number. We extract these from the line
        // number table prior to modifying the method, so it is just a
        // quick lookup on the handle to the call instruction
        int lineNum = lineNumbers.get(call);
        if (lineNum == 0) {
            // The compile sometimes associates the line number with the
            // argument loading instructions prior to the call. If we don't
            // get a valid line number at the call instruction itself, do
            // a quick heuristic search of preceding instructions
            InstructionHandle prev = call.getPrev();
            while ((prev != null)
                    && ((prev.getInstruction().produceStack(cpg) > 0)
                       || (prev.getInstruction() instanceof InvokeInstruction)
                       || (prev.getPosition() == -1))) {
                lineNum = lineNumbers.get(prev);
                if (lineNum != 0) {
                    break;
                }
                prev = prev.getPrev();
            }
        }
        if (lineNum == 0) {
            System.err.println("WARNING: Could not determine source code " +
                "line number for call in\n    " + fullClassName + "." +
                methodName + " (" + call.getPosition() + ": " +
                invoke.getMethodName(cpg) + ")");
        }
        else {
            interceptor.addLineNumber(probe, lineNum);
        }

        int argCount= argTypes.length;
        int lvOffset = 0;
        for (int i = 0; i < argCount; i++) {
            code.append(iFactory.createLoad(argTypes[i], lvOffset));
            lvOffset += argTypes[i].getSize();
        }
        InstructionHandle nc = code.append(invoke.copy());

        BranchHandle jump = (BranchHandle) regReturnPatch.getEnd();
        code.append(regReturnPatch);
        InstructionHandle handler = excReturnPatch.getStart();
        code.append(excReturnPatch);

        jump.setTarget(code.append(iFactory.createReturn(returnType)));

        il.setPositions();
        interceptor.setMaxLocals();
        interceptor.setMaxStack();

        interceptor.addExceptionHandler(nc, nc, handler, (ObjectType) null);

        javaClassFile.addMethod(interceptor.getMethod());
        dataFile.recordInterceptor(fullClassName, interceptor.getName());
        code.dispose();

        // Replace original call
        InvokeInstruction relayCall = iFactory.createInvoke(
            fullClassName, interceptorName,
            returnType, argTypes,
            Constants.INVOKESTATIC);
        call.setInstruction(relayCall.copy());

        interceptorCache.put(invokeSig, relayCall);
    }

    /**
     * Inserts a probe to observe the catching of an exception by a handler.
     *
     * @param il Instruction list for the method.
     * @param ih Handle to the first instruction of the exception handler.
     */
    private void addCatchProbe(MethodGen mg, InstructionList il,
            InstructionHandle ih) {
        if (!eventSpec.witnessCatch(fullClassName, mg)) {
            return;
        }

        InstructionList patch = new InstructionList();

        patch.append(new DUP());
        patch.append(iFactory.createInvoke("java.lang.Object", "getClass",
                Type.getType("Ljava/lang/Class;"), new Type[]{},
                Constants.INVOKEVIRTUAL));
        patch.append(iFactory.createPutStatic(instClassRef,
            typeFieldName, Type.getType("Ljava/lang/Class;")));

        InstructionHandle new_ih = il.insert(ih, patch);
        patch.dispose();

        updateTargeters(ih, new_ih);
    }

    /**
     * Updates the targets of instructions to point to a probe which has
     * been inserted in front of the instruction they target.
     */
    private void updateTargeters(InstructionHandle ih, InstructionHandle new_ih) {
        // Update targeters, which includes all affected branches
        // and exception handlers
        InstructionTargeter[] targeters = ih.getTargeters();
        if (targeters != null) {
            for (int t = 0; t < targeters.length; t++) {
                /* We only want to update the start offsets to _handler_ blocks
                   of exception handlers. The offsets to the start and end
                   instructions of the region watched for exceptions should not
                   be changed, otherwise there are circumstances where we may
                   actually shift the watched region such that the code that
                   is supposed to be protected in fact no longer is. */
                if (targeters[t] instanceof CodeExceptionGen) {
                    CodeExceptionGen exceptionHandler =
                        (CodeExceptionGen) targeters[t];
                    if ((exceptionHandler.getStartPC() == ih) ||
                        (exceptionHandler.getEndPC() == ih)) {
                        continue;
                    }
                }
                targeters[t].updateTarget(ih, new_ih);
            }
        }
    }

    /**
     * This method creates or patches a static initializer to transmit the
     * probe that raises an event indicating the preparation of a new class.
     *
     * <p>Due to (as usual) a bug in the JDI, the preparing thread may not
     * be properly suspended at the point of writing the class-prepared
     * probe. Thus in the cases where a static initializer must be created
     * (as opposed to modifying an existing one), it was found to be small
     * enough that the thread might sometimes execute the synthetic
     * initializer and additional code in the class before the class prepare
     * event could be processed, which of course caused events of interest
     * to be lost. Therefore, such synthetic initializers force the thread
     * to wait on the class lock until the event dispatcher sets a flag
     * variable permitting the thread to continue. The flag is checked
     * periodically by having the thread use timed waits. Since this only
     * happens once, during static initialization of the class, and is
     * transparent to the existing user code, the interference associated
     * with this technique is deemed negligible. Note that this is only
     * done for the synthetic static initializers, as existing initializers
     * seem to be large enough to always cause proper processing of
     * the class prepare events.</p>
     */
    private void insertClassPrepareEvent() {
        // Locate existing static initializer, if any
        int pos = 0;
        Method staticInit = null;
        Method[] methods = javaClassFile.getMethods();
        for ( ; pos < methods.length; pos++) {
            if (methods[pos].getName().equals("<clinit>")) {
                staticInit = methods[pos];
                break;
            }
        }

        InstructionList patch = new InstructionList();

        // Get the reference to the class object for the loaded class and
        // store it to the probe field
        patch.append(new PUSH(cpg, fullClassName));
        patch.append(iFactory.createInvoke("java.lang.Class", "forName",
            Type.getType("Ljava/lang/Class;"), new Type[]{Type.STRING},
            Constants.INVOKESTATIC));
        InstructionHandle ih = patch.append(iFactory.createPutStatic(
            instClassRef, loadFieldName, Type.getType("Ljava/lang/Class;")));

        if (staticInit == null) {
            // Clear the flag that the event dispatcher will use to indicate
            // that the class prepare event has been processed successfully
            patch.insert(iFactory.createPutStatic(instClassRef, flagFieldName,
                Type.BYTE));
            patch.insert(new PUSH(cpg, (byte) 0));

            // Insert instructions to store the class object obtained to a
            // local variable, and acquire its lock (the local variable
            // is used for releasing it)
            patch.insert(ih, new ASTORE(0));
            patch.insert(ih, new ALOAD(0));
            patch.append(new ALOAD(0));
            patch.append(new MONITORENTER());

            // Wait until the flag is set, checking it on 10ms intervals
            InstructionHandle loop_start = patch.append(
                iFactory.createGetStatic(instClassRef, flagFieldName, Type.BYTE));
            BranchHandle loop_cond = patch.append(new IFGT(null));
            // patch.append(iFactory.createGetStatic("java.lang.System", "out",
            //     Type.getType("Ljava/io/PrintStream;")));
            // patch.append(iFactory.createGetStatic(instClassRef, loadFieldName,
            //     Type.getType("Ljava/lang/Class;")));
            // patch.append(iFactory.createInvoke("java.io.PrintStream", "println",
            //     Type.VOID, new Type[]{Type.OBJECT}, Constants.INVOKEVIRTUAL));
            patch.append(new ALOAD(0));
            patch.append(new PUSH(cpg, 10l));
            patch.append(iFactory.createInvoke("java.lang.Object", "wait",
                Type.VOID, new Type[]{Type.LONG}, Constants.INVOKEVIRTUAL));
            patch.append(new GOTO(loop_start));

            // Build exception handler to ensure release of lock
            InstructionHandle handler_start = patch.append(new ALOAD(0));
            InstructionHandle exc_release = patch.append(new MONITOREXIT());
            patch.append(new ATHROW());

            // Release the lock and return
            loop_cond.setTarget(patch.append(new ALOAD(0)));
            InstructionHandle reg_release = patch.append(new MONITOREXIT());
            patch.append(new RETURN());

            // Create the method and commit the instruction list
            patch.setPositions();
            MethodGen mg = new MethodGen(Constants.ACC_PUBLIC |
                Constants.ACC_STATIC, Type.VOID, new Type[]{}, new String[]{},
                "<clinit>", fullClassName, patch, cpg);
            mg.setMaxStack();
            mg.setMaxLocals(1);

            // Add exception handler to ensure release of lock
            mg.addExceptionHandler(loop_start, reg_release, handler_start,
                (ObjectType) null);
            // Add failsafe handler
            mg.addExceptionHandler(handler_start, exc_release, handler_start,
                (ObjectType) null);

            javaClassFile.addMethod(mg.getMethod());
        }
        else {
            MethodGen mg = new MethodGen(staticInit, fullClassName, cpg);
            InstructionList il = mg.getInstructionList();
            il.insert(patch);
            il.setPositions();
            mg.setInstructionList(il);
            mg.setMaxStack();
            javaClassFile.setMethodAt(mg.getMethod(), pos);
        }
    }

    /**
     * Inserts a probe to witness an array element event.
     *
     * @param il Instruction list for the method being instrumented.
     * @param ih Handle to the array element instruction for which to insert
     * the probe.
     * @param isWrite Flag indicating whether the array element is being
     * written.
     */
    private void insertArrayProbe(InstructionList il, InstructionHandle ih,
            boolean isWrite) {
        if (isWrite) {
            ArrayInstruction instr = (ArrayInstruction) ih.getInstruction();
            Type elemType = instr.getType(cpg);
            String typeSig;

            if (elemType instanceof ReferenceType) {
                typeSig = "A";
                elemType = Type.OBJECT;
            }
            else {
                typeSig = elemType.getSignature();
            }

            if (elemType.getSize() == 1) {
                il.insert(ih, new DUP_X2());
                il.insert(ih, iFactory.createPutStatic(instClassRef,
                    arrFieldPrefix + "val$" + typeSig, elemType));
                il.insert(ih, new DUP2_X1());
                il.insert(ih, iFactory.createPutStatic(instClassRef,
                    arrIdxFieldName, Type.INT));
                il.insert(ih, iFactory.createPutStatic(instClassRef,
                    arrRefWrFieldName, Type.OBJECT));
            }
            else if (elemType.getSize() == 2) {
                il.insert(ih, new DUP2_X2());
                il.insert(ih, iFactory.createPutStatic(instClassRef,
                    arrFieldPrefix + "val$" + typeSig, elemType));
                il.insert(ih, new DUP2_X2());
                il.insert(ih, iFactory.createPutStatic(instClassRef,
                    arrIdxFieldName, Type.INT));
                il.insert(ih, iFactory.createPutStatic(instClassRef,
                    arrRefWrFieldName, Type.OBJECT));
            }
        }
        else {
            il.insert(ih, new DUP2());
            il.insert(ih, iFactory.createPutStatic(instClassRef,
                arrIdxFieldName, Type.INT));
            il.insert(ih, iFactory.createPutStatic(instClassRef,
                arrRefRdFieldName, Type.OBJECT));
        }
    }

    public void writeClass(OutputStream dest) throws IOException {
        FieldGen fg = new FieldGen(
            Constants.ACC_PRIVATE | Constants.ACC_TRANSIENT,
            Type.INT,
            codeFieldName,
            cpg);
        javaClassFile.addField(fg.getField());

        fg = new FieldGen(
            Constants.ACC_PRIVATE | Constants.ACC_TRANSIENT,
            Type.getType("Ljava/lang/Class;"),
            typeFieldName,
            cpg);
        javaClassFile.addField(fg.getField());

        insertClassPrepareEvent();

        super.writeClass(dest);
    }

    /**
     * Reports the type of program entity traced by this instrumentor to
     * satisfy the Instrumentor contract. Not used in any meaningful way
     * by this instrumentor.
     *
     * @return Integer code indicating that this instrumentor instruments
     * program entities related to semantic event dispatch.
     */
    public TraceObjectType getObjectType() {
        return TraceObjectType.SEMANTIC_EVENT;
    }

    /**
     * Returns <code>true</code> always, since there is no type codes argument
     * to this instrumentor.
     *
     * @param typeCodes <em>Ignored</em>.
     *
     * @return <code>true</code>, always.
     */
    public boolean parseTypeCodes(String typeCodes) {
        return true;
    }

    /**
     * Does nothing, since there is no type codes argument to this instrumentor.
     * Instrumentor control is instead defined by the module description file.
     *
     * @param flags <em>Ignored</em>.
     */
    public void setTypeFlags(int flags) {
    }

    /**
     * Reports whether a static method is implemented in native code. The
     * answer will not be reliable in the presence of runtime reflective
     * class loading.
     *
     * <p><em>The result of this method cannot be trusted if called on a
     * non-static method!</em> No static guarantee can be made that a virtual
     * method will always call a native implementation, since it may
     * depend on the receiver type of the object.</p>
     *
     * @param call Invoke instruction for the call that is to be checked
     * for native implementation.
     * @param cpg Constant pool for the class in which the call resides.
     *
     * @return <code>true</code> if the static method binds to a native
     * implementation.
     *
     * @throws ClassNotFoundException If a class needed to determine the
     * result cannot be found on the classpath.
     */
    public static final boolean isNative(InvokeInstruction call,
            ConstantPoolGen cpg) throws ClassNotFoundException {
        Boolean cached = (Boolean) nativeMethodsCache.get(call);
        if (cached != null) {
            return cached.booleanValue();
        }

        boolean isNative = isNative(call.getReferenceType(cpg).toString(),
            call.getMethodName(cpg) + call.getSignature(cpg));
        nativeMethodsCache.put(call.copy(), Boolean.valueOf(isNative));

        return isNative;
    }

    /**
     * Recursive implementation of the native method query. Searches through
     * the superclasses if necessary (pretty sure this isn't technically legal
     * in bytecode, but I think many compiler and JVM implementations may
     * allow a static method reference on a class that does not implement
     * the method itself, but rather inherits from a superclass).
     */
    private static final boolean isNative(String className, String nameAndSig)
            throws ClassNotFoundException {
        JavaClass clazz = Repository.lookupClass(className);
        if (clazz == null) {
            throw new ClassNotFoundException(className);
        }
        else {
            Method[] methods = clazz.getMethods();
            for (int i = 0; i < methods.length; i++) {
                String curNameAndSig =
                    methods[i].getName() + methods[i].getSignature();
                if (nameAndSig.equals(curNameAndSig)) {
                    return methods[i].isNative();
                }
            }

            return isNative(clazz.getSuperclassName(), nameAndSig);
        }
    }

    private static void instrumentClass(OutputStream fout) throws Exception {
        inst.instrumentAll();
        inst.writeClass(fout);
    }

    private static void instrumentClassFiles(ProgramUnit pUnit)
            throws Exception {
        int clCount = pUnit.classes.size();
        Iterator iterator = pUnit.classes.iterator();
        for (int i = clCount; i-- > 0; ) {
            String className = (String) iterator.next();

            try {
                if (pUnit.useLocation) {
                    inst.loadClass(pUnit.location +
                        className.replace('.', File.separatorChar) + ".class");
                }
                else {
                    inst.loadClass(className);
                }
            }
            catch (BadFileFormatException e) {
                System.err.println("WARNING: " + e.getMessage());
                continue;
            }
            catch (EmptyFileException e) {
                System.err.println("WARNING: " + e.getMessage());
                continue;
            }
            catch (FileNotFoundException e) {
                System.err.println(e.getMessage());
                return;
            }

            BufferedOutputStream fout = null;
            try {
                fout = new BufferedOutputStream(new FileOutputStream(
                        inst.getClassName() + ".class"));
            }
            catch (Exception e) {
                System.err.println("Unable to create output file");
                System.exit(1);
            }

            try {
                instrumentClass(fout);
            }
            finally {
                try {
                    fout.close();
                }
                catch (IOException e) {
                    System.err.println("WARNING: Failed to close file \"" +
                        inst.getClassName() + "\"");
                }
            }
        }
    }

    /**
     * Helper method which instruments all of the class files found
     * in a jar file.
     *
     * @param jarName Name of the jar file to be instrumented.
     */
    private static void instrumentJar(ProgramUnit jarUnit) throws Exception {
        JarFile sourceJar = new JarFile(jarUnit.location);
        ProtectedJarOutputStream instJar = null;
        ZipEntry clazz = null;
        Set includeClasses = new THashSet(jarUnit.classes);

        File f = new File(jarUnit.location + ".inst");
        try {
            instJar = new ProtectedJarOutputStream(new BufferedOutputStream(
                          new FileOutputStream(f)));
        }
        catch (IOException e) {
            IOException ioe = new IOException("Could not create output jar " +
                "file");
            ioe.fillInStackTrace();
            throw ioe;
        }

        BufferedInputStream entryStream = null;
        try {
            for (Enumeration e = sourceJar.entries(); e.hasMoreElements(); ) {
                boolean copyOnly = false;

                ZipEntry ze = (ZipEntry) e.nextElement();
                String entryName = ze.getName();
                if (ze.isDirectory() || !entryName.endsWith(".class")) {
                    copyOnly = true;
                }
                else {
                    entryName = entryName.substring(0,
                        entryName.lastIndexOf(".class")).replace('/', '.');
                    if (!includeClasses.contains(entryName)) {
                        copyOnly = true;
                    }
                }

                if (!copyOnly) {
                    entryStream = new BufferedInputStream(
                        sourceJar.getInputStream(ze));
                    try {
                        inst.loadClass(ze.getName(), entryStream);
                    }
                    catch (BadFileFormatException exc) {
                        System.err.println(exc.getMessage());
                        copyOnly = true;
                    }
                }

                instJar.putNextEntry(new JarEntry(ze.getName()));
                if (!copyOnly) {
                    instrumentClass(instJar);
                }
                else {
                    entryStream = new BufferedInputStream(
                        sourceJar.getInputStream(ze));
                    copyFileStream(entryStream, instJar);
                }
            }
        }
        finally {
            try {
                if (entryStream != null) entryStream.close();
                instJar.closeStream();
            }
            catch (IOException e) {
                System.err.println("Error closing stream: " + e.getMessage());
            }
        }

        if (f.exists()) {
            if (!f.renameTo(new File(jarUnit.location))) {
                System.out.println("Instrumented jar file is named " +
                    f.getName());
            }
        }
    }

    private static void copyFileStream(InputStream from, OutputStream to)
            throws IOException {
        byte[] buffer = new byte[4096];
        int bytes_read;
        while((bytes_read = from.read(buffer)) != -1) {
            to.write(buffer, 0, bytes_read);
        }
    }

    /**
     * Prints the usage message and exits.
     *
     * @param msg Targeted explanation of the usage error,
     * may be <code>null</code>.
     */
    private static void printUsage(String msg) {
        if (msg != null) System.err.println(msg);
        System.err.println("Usage:");
        System.err.println("java sofya.ed.semantic.SemanticInstrumentor " +
            "[-dabe] <module_description_file>");
        System.err.println("    -dabe : Disable automatic boundary events, " +
            "prevents insertion of");
        System.err.println("            instrumentation to report " +
            "when execution leaves the module");
        System.exit(1);
    }

    /**
     * Entry point for the instrumentor.
     */
    public static void main(String[] argv) {
        if (argv.length < 1) {
            printUsage(null);
        }

        boolean autoBoundaryEvents = true;
        boolean forAtomicity = false;

        int index;
        for (index = 0; index < argv.length; index++) {
            if (!argv[index].startsWith("-")) {
                break;
            }
            else if (argv[index].equals("-dabe")) {
                autoBoundaryEvents = false;
            }
            else if (argv[index].equals("-atom")) {
                forAtomicity = true;
            }
            else {
                printUsage("Unrecognized parameter: " + argv[index]);
            }
        }

        SemanticDataHandler egh = new SemanticDataHandler();
        SemanticEventData dataFile = null;
        String dataFileName = null;
        EventSpecification eventSpec = null;

        if (!forAtomicity) {
            if (index >= argv.length) {
                System.err.println("Must provide module description file");
                System.exit(1);
            }

            try {
                eventSpec = egh.readDescriptionFile(argv[index]);
            }
            catch (FileNotFoundException e) {
                System.err.println(e.getMessage());
                System.exit(1);
            }
            catch (IOException e) {
                //e.printStackTrace();
                System.err.println(e.getMessage());
                System.exit(1);
            }

            dataFile = new SemanticEventData(eventSpec);
            dataFileName = argv[index] + ".ed.dat";
        }
        else {
            if (index >= argv.length) {
                System.err.println("Must provide progam file");
                System.exit(1);
            }
            if (!argv[index].endsWith(".prog")) {
                System.err.println("Instrumentation for atomicity checking " +
                    "requires a program file");
                System.exit(1);
            }

            List classes = new ArrayList();
            try {
                Handler.readProgFile(argv[index], null, classes);
            }
            catch (IOException e) {
                System.err.println(e.getMessage());
                System.exit(1);
            }
            eventSpec =
                new sofya.apps.atomicity.AtomicityEvents(classes, classes, true);
            autoBoundaryEvents = false;

            dataFile = new SemanticEventData(eventSpec);
            dataFileName =
                argv[index].substring(0, argv[index].lastIndexOf(".")) +
                ".ed.dat";
        }

        try {
            inst = new SemanticInstrumentor(dataFile);
            inst.autoBoundaryEvents = autoBoundaryEvents;

            Set classes = eventSpec.getSystemClasses(false);
            Iterator iterator = classes.iterator();
            for (int i = classes.size(); i-- > 0; ) {
                ProgramUnit pUnit = (ProgramUnit) iterator.next();
                if (pUnit.isJar) {
                    instrumentJar(pUnit);
                }
                else {
                    instrumentClassFiles(pUnit);
                }
            }

            egh.writeDataFile(dataFileName, dataFile);
        }
        catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            if (!e.getMessage().startsWith("Port")) {
                System.err.println("Error specifying port");
                System.exit(1);
            }
            System.exit(1);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error reading from class or jar file");
            System.exit(1);
        }
        catch (ClassFormatError e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
