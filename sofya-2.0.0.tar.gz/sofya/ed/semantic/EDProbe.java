/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import java.lang.reflect.Method;

/**
 * This class hosts the fields that are referenced by the probes inserted
 * by the instrumentor, and which are monitored by the
 * {@link SemanticEventDispatcher}.
 *
 * @author Alex Kinneer
 * @version 12/16/2005
 */
public final class EDProbe {
    // We re-assign the error stream to the standard output stream so that
    // outputs by the system are seen in their original order. (We have to
    // use separate threads to relay the outputs in the module tracer, and
    // there is no way to force those threads to honor the original order
    // of outputs, which can lead to very strange disordered output. A
    // failing of the Jave exec model, really).
    static {
        System.setErr(System.out);
    }

    /** Field to which probes write event trace codes. */
    public static int _inst$$zk183_$code$;
    /** Field to which class prepare probes write. */
    public static Class _inst$$zk183_$load$;
    /** Field to which the class of caught exceptions are written. */
    public static Class _inst$$zk183_$type$;

    /** Field to which monitor contention events are written. */
    public static Object _inst$$zk183_$mon$10;
    /** Field to which monitor acquisition events are written. */
    public static Object _inst$$zk183_$mon$11;
    /** Field to which monitor releasing events are written. */
    public static Object _inst$$zk183_$mon$12;
    /** Field to which monitor released events are written. */
    public static Object _inst$$zk183_$mon$13;

    /** Field to which the array reference of array read events are written. */
    public static Object _inst$$zk183_$arr$ref$rd;
    /** Field to which the array reference of array write events are written. */
    public static Object _inst$$zk183_$arr$ref$wr;
    /** Field to which the element index of array events are written. */
    public static int _inst$$zk183_$arr$idx$;

    /** Field to which the value of byte array write events are written. */
    public static byte _inst$$zk183_$arr$val$B;
    /** Field to which the value of char array write events are written. */
    public static char _inst$$zk183_$arr$val$C;
    /** Field to which the value of double array write events are written. */
    public static double _inst$$zk183_$arr$val$D;
    /** Field to which the value of float array write events are written. */
    public static float _inst$$zk183_$arr$val$F;
    /** Field to which the value of int array write events are written. */
    public static int _inst$$zk183_$arr$val$I;
    /** Field to which the value of long array write events are written. */
    public static long _inst$$zk183_$arr$val$J;
    /** Field to which the value of short array write events are written. */
    public static short _inst$$zk183_$arr$val$S;
    /** Field to which the value of boolean array write events are written. */
    public static boolean _inst$$zk183_$arr$val$Z;
    /** Field to which the value of reference array write events are written. */
    public static Object _inst$$zk183_$arr$val$A;

    /** Field used to transmit very limited commands back to the subject
        instrumentation. */
    public static byte _inst$$zk183_$flag$ = 0;

    /**
     * Used to reflectively invoke the main class for the monitored
     * application, which forces the probe to be loaded before any
     * monitored code can be loaded.
     *
     * <p>This is an ugly hack to work around a bug in the JDI. Namely,
     * the JDI violates the declared contract of the ClassPrepareEvent
     * by permitting execution of code in the loaded class prior to
     * dispatching the event to the JDI event queue. This means that
     * during initialization, user code may write to fields we want
     * to monitor before we have had a chance to request monitoring
     * of those fields in the SemanticEventDispatcher, since we must have a
     * reference to a loaded class to add event requests for the
     * fields of the class.</p>
     */
    public static void main(String[] argv) throws Exception {
        Runtime rt = Runtime.getRuntime();
        System.out.println("Launching subject...");
        System.out.println("    Processors: " + rt.availableProcessors());
        System.out.println("    Max memory: " + rt.maxMemory());

        Class cl = Class.forName(argv[0]);
        Method clMain = cl.getMethod("main",
            new Class[]{ (new String[]{}).getClass() });
        String[] clArgs = new String[argv.length - 1];
        System.arraycopy(argv, 1, clArgs, 0, clArgs.length);
        clMain.invoke(null, new Object[]{clArgs});
    }
}
