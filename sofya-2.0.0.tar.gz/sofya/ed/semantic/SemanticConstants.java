/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

/**
 * Constants relevant to the semantic event dispatch classes.
 *
 * @author Alex Kinneer
 * @version 11/15/2005
 */
public final class SemanticConstants {
    private SemanticConstants() { }

    /** Probe bitmask for an observable event. */
    public static final int TYPE_EVENT  = 0x00000000;
    /** Probe bitmask for an assertion. */
    public static final int TYPE_ASSERT = 0x40000000;

    // final static int <TYPE_UNUSED_1> = 0x80000000;
    // final static int <TYPE_UNUSED_2> = 0xC0000000;

    /** User code execution started event. */
    public static final byte EVENT_START          = 1;
    /** Thread started event. */
    public static final byte EVENT_THREAD_START   = 2;
    /** Thread terminated event. */
    public static final byte EVENT_THREAD_DEATH   = 3;

    /** NEW instruction event (object is not yet initialized). */
    public static final byte EVENT_NEW_OBJ        = 4;
    /** Static field access event. */
    public static final byte EVENT_GETSTATIC      = 5;
    /** Static field write event. */
    public static final byte EVENT_PUTSTATIC      = 6;
    /** Instance field access event. */
    public static final byte EVENT_GETFIELD       = 7;
    /** Instance field write event. */
    public static final byte EVENT_PUTFIELD       = 8;

    /** Thread contending for monitor event. */
    public static final byte EVENT_MONITOR_CONTEND     = 10;
    /** Thread acquired monitor event. */
    public static final byte EVENT_MONITOR_ACQUIRE     = 11;
    /** Thread about to release monitor event. */
    public static final byte EVENT_MONITOR_PRE_RELEASE = 12;
    /** Thread released monitor event. */
    public static final byte EVENT_MONITOR_RELEASE     = 13;

    /** Constructor invocation event. */
    public static final byte EVENT_CONSTRUCTOR    = 20;
    /** Static call event. */
    public static final byte EVENT_STATIC_CALL    = 21;
    /** Virtual call event. */
    public static final byte EVENT_VIRTUAL_CALL   = 22;
    /** Interface call event. */
    public static final byte EVENT_INTERFACE_CALL = 23;
    /** Call return event. */
    public static final byte EVENT_CALL_RETURN    = 24;

    /** Virtual method entered event. */
    public static final byte EVENT_VMETHOD_ENTER     = 30;
    /** Virtual method exited event. */
    public static final byte EVENT_VMETHOD_EXIT      = 31;
    /** Object constructor entered event. */
    public static final byte EVENT_CONSTRUCTOR_ENTER = 32;
    /** Object constructor exited event. */
    public static final byte EVENT_CONSTRUCTOR_EXIT  = 33;
    /** Static initializer entered event. */
    public static final byte EVENT_STATIC_INIT_ENTER = 34;
    /** Static method entered event. */
    public static final byte EVENT_SMETHOD_ENTER     = 36;
    /** Static method exited event. */
    public static final byte EVENT_SMETHOD_EXIT      = 37;

    /** Exception thrown event. */
    public static final byte EVENT_THROW          = 40;
    /** Exception caught event. */
    public static final byte EVENT_CATCH          = 41;
}
