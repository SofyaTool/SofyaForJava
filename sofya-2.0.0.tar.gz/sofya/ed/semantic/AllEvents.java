/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import sofya.base.ProgramUnit;

import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.FieldInstruction;
import org.apache.bcel.generic.InvokeInstruction;
import org.apache.bcel.generic.MethodGen;
import org.apache.bcel.generic.ObjectType;

import gnu.trove.THashSet;

/**
 * Specification which instructs an {@link SemanticEventDispatcher} to
 * generate all possible events.
 *
 * @author Alex Kinneer
 * @version 12/07/2005
 */
public class AllEvents extends AbstractEventSpecification {
    /** The set of classes which comprise the entire system. */
    private final Set systemClasses;
    /** The set of classes which for which events are dispatched if
        no other constraints are supplied. */
    private final Set moduleClasses;

    /**
     * Creates a new all events specification.
     *
     * <p>The resulting specification will not define any classes comprising
     * the system or module. This constructor is provided only to support
     * deserialization.</p>
     */
    protected AllEvents() {
        this.systemClasses = new THashSet();
        this.moduleClasses = new THashSet();
    }

    /**
     * Creates a new all events specification.
     *
     * @param systemClassList List of classes comprising the entire sytem.
     * @param moduleClassList List of classes comprising the module
     * on which all events are to be observed (this can be the same as
     * the system class list).
     */
    public AllEvents(List systemClassList, List moduleClassList) {
        this.systemClasses = new THashSet(systemClassList);
        if (systemClassList == moduleClassList) {
            this.moduleClasses = this.systemClasses;
        }
        else {
            this.moduleClasses = new THashSet(moduleClassList);
        }
    }

    public Set getSystemClasses(boolean asStrings) {
        if (asStrings) {
            Set strSet = new THashSet();
            int size = systemClasses.size();
            Iterator iterator = systemClasses.iterator();
            for (int i = size; i-- > 0; ) {
                strSet.addAll(((ProgramUnit) iterator.next()).classes);
            }
            return strSet;
        }
        else {
            return Collections.unmodifiableSet(systemClasses);
        }
    }

    public Set getModuleClasses(boolean asStrings) {
        if (asStrings) {
            Set strSet = new THashSet();
            int size = moduleClasses.size();
            Iterator iterator = moduleClasses.iterator();
            for (int i = size; i-- > 0; ) {
                strSet.add(((ProgramUnit) iterator.next()).classes);
            }
            return strSet;
        }
        else {
            return Collections.unmodifiableSet(moduleClasses);
        }
    }

    public boolean witnessNewObject(String newClass, MethodGen inMethod) {
        return true;
    }

    public boolean witnessConstructorEntry(MethodGen mg) {
        return true;
    }

    public boolean witnessConstructorExit(MethodGen mg) {
        return true;
    }

    public boolean witnessField(FieldInstruction fi, ConstantPoolGen cpg,
            MethodGen inMethod) {
        return true;
    }

    public boolean witnessField(String fieldName, FieldType fType,
            String className, String methodName, String signature) {
        return true;
    }

    public int witnessField(String fieldName, boolean isStatic) {
        return FIELD_WITNESS_READ | FIELD_WITNESS_WRITE;
    }

    public boolean witnessCall(InvokeInstruction call, ConstantPoolGen cpg,
            MethodGen inMethod) {
        return true;
    }

    public boolean useCallInterceptor(InvokeInstruction call,
            ConstantPoolGen cpg) {
        return false;
    }

    public boolean witnessMethodEntry(MethodGen mg) {
        return true;
    }

    public boolean witnessMethodExit(MethodGen mg) {
        return true;
    }

    public boolean witnessAnyMonitor(MonitorType type, MethodGen inMethod) {
        return true;
    }

    public boolean witnessMonitor(String className, MonitorType type) {
        return true;
    }

    public boolean witnessThrow(String exceptionClass, String className,
            String methodName, String signature) {
        return true;
    }

    public boolean witnessThrow(String exceptionClass) {
        return true;
    }

    public boolean witnessCatch(String exceptionClass, MethodGen inMethod) {
        return true;
    }

    public boolean witnessCatch(String exceptionClass) {
        return true;
    }

    public boolean witnessStaticInitializerEntry(String className) {
        return true;
    }

    public void serialize(DataOutputStream stream) throws IOException {
        stream.writeInt(systemClasses.size());
        for (Iterator i = systemClasses.iterator(); i.hasNext(); ) {
            serializeProgramUnit(stream, (ProgramUnit) i.next());
        }

        stream.writeInt(moduleClasses.size());
        for (Iterator i = moduleClasses.iterator(); i.hasNext(); ) {
            serializeProgramUnit(stream, (ProgramUnit) i.next());
        }
    }

    public EventSpecification deserialize(DataInputStream stream)
             throws IOException {
        int size = stream.readInt();
        for (int i = 0; i < size; i++) {
            this.systemClasses.add(deserializeProgramUnit(stream));
        }

        size = stream.readInt();
        for (int i = 0; i < size; i++) {
            this.moduleClasses.add(deserializeProgramUnit(stream));
        }

        return this;
    }
}
