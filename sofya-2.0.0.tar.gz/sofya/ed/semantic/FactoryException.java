/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic; 

/**
 * Exception which indicates that an object factory was unable to satisfy a
 * request for a new object.
 *
 * @author Alex Kinneer
 * @version 02/04/2005
 */
public class FactoryException extends Exception {
    /** Wrapped exception which indicates the original reason for failure
        (if applicable). */
    private Throwable cause = null;
    
    /**
    * Creates an exception with no message or causing exception.
    */
    public FactoryException() {
        super();
    }
    
    /**
    * Creates an exception with the specified message and
    * no causing exception.
    * 
    * @param msg Message associated with this exception.
    */
    public FactoryException(String msg) {
        super(msg);
    }
    
    /**
    * Creates an exception with the specified message and
    * causing exception.
    */
    public FactoryException(String msg, Throwable cause) {
        super(msg);
        this.cause = cause;
    }
    
    /**
    * Gets the wrapped exception indicating the original cause for failure.
    *
    * @return The original exception which caused this
    * exception to be raised, may be <code>null</code>.
    */
    public Throwable getCause() {
        return cause;
    }
}
