/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;

import gnu.trove.TObjectIntHashMap;
import gnu.trove.TLongObjectHashMap;
import gnu.trove.TLongObjectIterator;

/**
 * Observable event filter which directs events to separate listeners for
 * each object in the monitored system. Events which are not specific
 * to individual object instances are discarded.
 *
 * @author Alex Kinneer
 * @version 11/11/2005
 */
public class ObjectFilter extends EventSelectionFilter
        implements ChainedEventListener, ErrorRecorder {
    /** Factory used to generate a new listener for the event stream associated
        with each object that gets created in the observed system. */
    private ChainedEventListenerFactory listenerFactory;

    /** Map which actually links each individual object with its associated
        event listener. */
    private TLongObjectHashMap objListeners = new TLongObjectHashMap();

    /** Parent event listener from which this filter is receiving
        events, if any. */
    private ChainedEventListener parent;
    /** ID assigned to this event stream, if any (this value should be set
        only if this filter was created by a factory). */
    private long streamId = -1;
    /** Name assigned to this event stream, if any (should be set
        only by a factory). */
    private String streamName = null;

    /** Flag which is set if an error occurs while creating a
        trace file. */
    private boolean errState = false;
    /** Stores any exception raised while creating a trace file. */
    private Exception err = null;

    /**
     * Factory class used to produce instances of this class on demand,
     * which are to be used to generate independent streams for subsets of
     * the events raised by the observed system.
     */
    private static class FilterFactory implements ChainedEventListenerFactory {
        private ChainedEventListenerFactory myFactory;

        FilterFactory(ChainedEventListenerFactory celf) {
            myFactory = celf;
        }

        public ChainedEventListener createEventListener(
                ChainedEventListener parent, long streamId,
                String streamName) throws FactoryException {
            return new ObjectFilter(myFactory, parent,
                streamId, streamName);
        }
    }

    private ObjectFilter() { }

    /**
     * Creates a new object instance filter.
     *
     * @param celf Listener factory used to create the listeners associated
     * with observed objects.
     */
    public ObjectFilter(ChainedEventListenerFactory celf) {
        listenerFactory = celf;
    }

    /**
     * Creates a new object instance filter attached to an existing
     * filter chain.
     *
     * @param celf Listener factory used to create the listeners associated
     * with observed objects.
     * @param parent Event listener from which this object filter will
     * receive events.
     * @param streamId Identifier assigned to this event stream by the
     * factory creating this filter.
     * @param streamName Informational name assigned to this event stream
     * by the factory creating this filter.
     */
    protected ObjectFilter(ChainedEventListenerFactory celf,
            ChainedEventListener parent, long streamId, String streamName) {
        this(celf);
        this.parent = parent;
        this.streamId = streamId;
        this.streamName = streamName;
    }

    /**
     * Gets a factory for producing instances of this class on demand.
     *
     * @param celf Factory which the produced filters will use to generate
     * listeners for their own filter streams.
     *
     * @return A listener factory which produces instances of this class
     * to filter by object instance subsets of the events dispatched from the
     * observed system.
     */
    public static ChainedEventListenerFactory getFactory(
            ChainedEventListenerFactory celf) {
        return new FilterFactory(celf);
    }

    public ChainedEventListener getParent() {
        return parent;
    }

    public long getStreamID() {
        return streamId;
    }

    public String getStreamName() {
        return streamName;
    }

    /**
     * Reports whether the filter is in an error state.
     *
     * <p>Note that errors raised while attempting to write to
     * individual filter streams for each object will be stored for each
     * such object if the listener associated with that object
     * implements the {@link ErrorRecorder} interface. Those errors
     * can be retrieved via {@link #getTraceErrors()}. This method
     * only reports whether the filter failed to instantiate a
     * listener for a given object.
     *
     * @return <code>true</code> if an error has occurred while trying
     * to create a listener.
     */
    public boolean inError() { return errState; }

    /**
     * Rethrows the originating exception if this filter is
     * in an error state; does nothing if in a normal state.
     *
     * @throws Exception If an error has been raised while trying to
     * create a listener for an object event stream.
     */
    public void rethrowError() throws Exception {
        if (errState) {
            throw err;
        }
    }

    /**
     * Gets the exception that put the filter in an error state.
     *
     * @return The first unrecoverable exception that put the filter
     * in an error state.
     */
    public Exception getError() {
        return err;
    }

    /**
     * Returns any exceptions that were raised by listeners associated
     * with individual objects.
     *
     * @return A map which relates objects to any exceptions raised while
     * attempting to write events to their associated listeners. Map keys will
     * be object IDs (as Longs), and values will be exception objects. No
     * mapping will exist for an object for which the listener does not
     * report any errors or does not implement the {@link ErrorRecorder}
     * interface. Thus under ideal circumstances, if all attached listeners
     * support error recording, the size of the returned map should be zero.
     */
    public Map getTraceErrors() {
        Map errs = new TreeMap();

        TLongObjectIterator iterator = objListeners.iterator();
        for (int i = objListeners.size(); i-- > 0; ) {
            iterator.advance();
            Object listener = iterator.value();

            if (!(listener instanceof ErrorRecorder)) continue;

            ErrorRecorder l = (ErrorRecorder) listener;
            if (l.inError()) {
                errs.put(new Long(iterator.key()), l.getError());
            }
        }

        return errs;
    }

    private EventListener createListener(long objectId) {
        EventListener newListener = null;
        try {
            newListener = listenerFactory.createEventListener(
                this, objectId, "object");
        }
        catch (FactoryException e) {
            errState = true;
            err = e;
            return null;
        }

        objListeners.put(objectId, newListener);

        return newListener;
    }

    public void monitorContendEvent(ThreadData td, ObjectData od, MonitorData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.monitorContendEvent(td, od, md);
    }

    public void monitorAcquireEvent(ThreadData td, ObjectData od, MonitorData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.monitorAcquireEvent(td, od, md);
    }

    public void monitorPreReleaseEvent(ThreadData td, ObjectData od, MonitorData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.monitorPreReleaseEvent(td, od, md);
    }

    public void monitorReleaseEvent(ThreadData td, ObjectData od, MonitorData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.monitorReleaseEvent(td, od, md);
    }

    public void constructorEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener newListener = createListener(objectId);
        if (errState) {
            return;
        }

        newListener.constructorEnterEvent(td, od, md);
    }

    public void constructorExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener newListener = createListener(objectId);
        if (errState) {
            return;
        }

        newListener.constructorExitEvent(td, od, md);
    }

    public void instanceFieldAccessEvent(
            ThreadData td, ObjectData od, FieldData fd) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.instanceFieldAccessEvent(td, od, fd);
    }

    public void instanceFieldWriteEvent(
            ThreadData td, ObjectData od, FieldData fd) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.instanceFieldWriteEvent(td, od, fd);
    }

    public void virtualMethodEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.virtualMethodEnterEvent(td, od, md);
    }

    public void virtualMethodExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
        if (errState) return;

        long objectId = od.getId();

        EventListener listener = (EventListener) objListeners.get(objectId);

        if (listener == null) {
            listener = createListener(objectId);
            if (errState) {
                return;
            }
        }

        listener.virtualMethodExitEvent(td, od, md);
    }

    // We dispatch this event so that the end-of-file markers will be written
    // to the trace files
    public void systemExited() {
        TLongObjectIterator iterator = objListeners.iterator();
        for (int i = objListeners.size(); i-- > 0; ) {
            iterator.advance();
            ((EventListener) iterator.value()).systemExited();
        }
    }
}
