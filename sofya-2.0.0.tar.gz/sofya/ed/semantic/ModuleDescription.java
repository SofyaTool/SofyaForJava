/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import java.io.*;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import sofya.base.Handler;
import sofya.base.ProgramUnit;
import sofya.base.exceptions.BadFileFormatException;
import sofya.base.exceptions.IncompleteClasspathException;
import sofya.base.exceptions.SofyaError;
import sofya.ed.semantic.EventSpecification.*;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;

import gnu.trove.THashSet;
import gnu.trove.THashMap;

/**
 * Encapsulates the compiled representation of a module description file
 * which was supplied to the instrumentor.
 *
 * <p>Most of the methods in this class are able to report in constant
 * time whether a particular observable is defined as part of the module
 * (an important consideration because some of these methods are used
 * online by the {@link SemanticEventDispatcher}). In order to account for
 * wildcards in the specification, this is typically accomplished via the use
 * of rule tables keyed on strings containing a partial or full package and
 * name qualification. More formally, for methods of that type, the
 * runtime order to check inclusiveness of an observable is
 * characterized by: 2 * (maximum package depth).</p>
 *
 * @author Alex Kinneer
 * @version 06/09/2006
 */
public class ModuleDescription extends AbstractEventSpecification {
    /** The set of components that comprise the entire system. */
    private Set systemUnits = null;
    /** The set of classes that comprise the entire system. */
    private Set systemClasses = null;

    /** The set of components for which observables are included if
        no other conditions are supplied. */
    private Set moduleUnits = null;
    /** The set of classes for which observables are included if
        not other conditions are supplied. */
    private Set moduleClasses = new THashSet();
    /** The subset of the module classes which are throwables. */
    private Set moduleThrowables = new THashSet();

    /** Contains the rules that determine whether a NEW instruction
        creates a class defined within the module. */
    private Map new_events = new THashMap();

    /** Contains the rules that determine whether a field is specified
        as part of the module. */
    private Map[] field_events = new THashMap[4];

    /** Contains the rules that determine whether a call is to a method
        defined within the module. */
    private Map[] call_events = new THashMap[4];

    /** Contains the rules that determine whether construction of an
        object is considered part of the module. */
    private Map[] construct_events = new THashMap[2];
    private static final int CNS_ENTER = 0;
    private static final int CNS_EXIT  = 1;

    /** Contains the rules that determine whether entry to and
        exit from a method is considered part of the module. */
    private Map[] method_events = new THashMap[4];

    /** Contains the rules that determine what monitor related events
        are included in the module. */
    private Map[] monitor_events = new THashMap[4];

    /** Contains the rules that determine whether the throwing and
        catching of a throwable is considered part of the module. */
    private Map[] throwable_events = new THashMap[2];
    /** Contains the set of throwables for which subclasses are also
        to be considered part of the module. */
    private Set[] throwable_inc_subclass = new THashSet[2];
    /** Constant for checking throw event data structures. */
    private static final int THROW = 0;
    /** Constant for checking catch event data structures. */
    private static final int CATCH = 1;

    /** Contains the rules that determine what static initializer events
        are included in the module. */
    private Map static_init_events = new THashMap();

    /** Can be used to record properties relevant to certain events, such
        as whether a call should be witnessed using an interceptor. Utilizes
        the same matching mechanism as the name rule table. */
    private Map event_properties = new THashMap();

    /**
     * Creates a new module description containing no classes or rules;
     * provided for deserialization.
     */
    protected ModuleDescription() {
        this.systemUnits = new THashSet();
        this.moduleUnits = new THashSet();
    }

    /**
     * Creates a new module description.
     *
     * @param systemClassList List of classes comprising the entire system.
     * @param moduleClassList List of classes comprising the module.
     */
    protected ModuleDescription(List systemClassList, List moduleClassList) {
        this.systemUnits = new THashSet(systemClassList);
        this.moduleUnits = new THashSet(moduleClassList);
        init();
    }

    /**
     * Does some processing on the initial class lists and creates data
     * structures.
     */
    private void init() {
        initModuleClassData();

        forAllClasses(new AddNameRuleAction(new_events,
            new EventConditions(true, 0)));

        for (int i = 0; i < 4; i++) {
            field_events[i] = new THashMap();
            call_events[i] = new THashMap();
            method_events[i] = new THashMap();
            monitor_events[i] = new THashMap();

            forAllClasses(new AddNameRuleAction(field_events[i],
                new EventConditions(true, 0)));
            forAllClasses(new AddNameRuleAction(call_events[i],
                new EventConditions(true, 0)));
            forAllClasses(new AddNameRuleAction(method_events[i],
                new EventConditions(true, 0)));
            forAllClasses(new AddNameRuleAction(monitor_events[i],
                new EventConditions(true, 0)));
        }

        forAllClasses(new AddNameRuleAction(static_init_events,
            new EventConditions(true, 0)));

        for (int i = 0; i < 2; i++) {
            construct_events[i] = new THashMap();
            forAllClasses(new AddNameRuleAction(construct_events[i],
                new EventConditions(true, 0)));

            throwable_events[i] = new THashMap();
            throwable_inc_subclass[i] = new THashSet();

            forAllThrowables(new AddNameRuleAction(throwable_events[i],
                new EventConditions(true, 0)));
        }
    }

    /**
     * Initializes the module classes set and throwable classes set since
     * they are frequently used.
     */
    private void initModuleClassData() {
        int unitCount = moduleUnits.size();
        Iterator unitIterator = moduleUnits.iterator();
        for (int i = unitCount; i-- > 0; ) {
            ProgramUnit pUnit = (ProgramUnit) unitIterator.next();

            int classCount = pUnit.classes.size();
            Iterator classIterator = pUnit.classes.iterator();
            for (int j = classCount; j-- > 0; ) {
                String className = (String) classIterator.next();

                moduleClasses.add(className);

                try {
                    if ((new ObjectType(className)).subclassOf(
                            Type.THROWABLE)) {
                        moduleThrowables.add(className);
                    }
                }
                catch (ClassNotFoundException e) {
                    throw new IncompleteClasspathException(e);
                }
            }
        }
    }

    public Set getSystemClasses(boolean asStrings) {
        if (asStrings) {
            if (systemClasses == null) {
                systemClasses = new THashSet();
                int size = systemUnits.size();
                Iterator iterator = systemUnits.iterator();
                for (int i = size; i-- > 0; ) {
                    systemClasses.addAll(
                        ((ProgramUnit) iterator.next()).classes);
                }
            }
            return Collections.unmodifiableSet(systemClasses);
        }
        else {
            return Collections.unmodifiableSet(systemUnits);
        }
    }

    public Set getModuleClasses(boolean asStrings) {
        if (asStrings) {
            return Collections.unmodifiableSet(moduleClasses);
        }
        else {
            return Collections.unmodifiableSet(moduleUnits);
        }
    }

    /**
     * Interface that defines the callback function to be used by the
     * &apos;forAll&apos;-classes methods.
     */
    private static interface ClassAction {
        /**
         * Callback function implementing the action to be performed for a
         * given class.
         *
         * @param className Name of the class for which an action will be
         * performed.
         *
         * @return <code>true</code> if the action was successfully performed.
         */
        boolean handleClass(String className);
    }

    /**
     * Automatically performs some action for all of the module classes.
     *
     * @param clAction Action to be performed for each module class.
     */
    private void forAllClasses(ClassAction clAction) {
        int size = moduleClasses.size();
        Iterator iterator = moduleClasses.iterator();
        for (int i = size; i-- > 0; ) {
            clAction.handleClass((String) iterator.next());
        }
    }

    /**
     * Automatically performs some action for all of the throwable classes
     * included in the module.
     *
     * @param clAction Action to be performed for each throwable class.
     */
    private void forAllThrowables(ClassAction clAction) {
        int size = moduleThrowables.size();
        Iterator iterator = moduleThrowables.iterator();
        for (int i = size; i-- > 0; ) {
            clAction.handleClass((String) iterator.next());
        }
    }

    /**
     * Adds supplied conditions on the observation of an event to each class.
     *
     * <p>This is used during initialization to create the implied rules
     * that include all observables in the module classes by default,
     * and when adding wildcard sets of classes to the specification.</p>
     */
    private static class AddNameRuleAction implements ClassAction {
        private Map rule_map;
        private EventConditions ecs;

        /**
         * Creates a new action performer to add conditions on the observation
         * of an event to each handled class.
         *
         * @param rule_map Rule set to which the event conditions are to be
         * added for each class.
         * @param ecs Conditions constraining the observation of the event.
         */
        AddNameRuleAction(Map rule_map, EventConditions ecs) {
            this.rule_map = rule_map;
            this.ecs = ecs;
        }

        public boolean handleClass(String className) {
            EventConditions cur_ecs = (EventConditions) rule_map.get(className);
            if (cur_ecs == null) {
                rule_map.put(className, new EventConditions(ecs));
            }
            else {
                cur_ecs.merge(ecs);
            }

            return true;
        }
    }

    /**
     * Builds a rule key for a given method signature.
     *
     * @param className Class specified in the method signature.
     * @param methodSignature Name of the method.
     * @param argTypes Types of the arguments to the method.
     *
     * @return A consistent string key which can be used in the call maps.
     */
    private static String buildKeySignature(String className, String methodName,
            Type[] argTypes) {
        StringBuffer sb = new StringBuffer(className);
        sb.append(".");
        sb.append(methodName);
        if (argTypes != null) {
            sb.append(".");
            sb.append(Type.getMethodSignature(Type.VOID, argTypes));
        }
        else if (!methodName.equals("*")) {
            sb.append(".*");
        }
        return sb.toString();
    }

    /**
     * Builds a rule key for a given method signature.
     *
     * @param className Class specified in the method signature.
     * @param methodSignature Name of the method.
     * @param signature JDI-style signature string for the method.
     *
     * @return A consistent string key which can be used in the call maps;
     * it is equivalent to that produced by
     * {@link #buildKeySignature(String,String,Type[])}.
     */
    private static String buildKeySignature(String className, String methodName,
            String signature) {
        StringBuffer sb = new StringBuffer(className);
        sb.append(".");
        sb.append(methodName);
        if (signature != null) {
            sb.append(".");
            sb.append(signature);
        }
        return sb.toString();
    }

    /**
     * Adds an inclusion or exclusion rule for a named observable, and
     * associated conditions on the locations in which the observable
     * is to be witnessed.
     *
     * @param name Name of the observable for which the rule is defined,
     * may include a trailing wildcard.
     * @param rule_map Rule set for the type of observable for which
     * a rule is being added.
     * @param ecs Conditions constraining when the observable is to
     * be witnessed.
     */
    private void addNameRule(String name, Map rule_map, EventConditions ecs) {
        if (name.endsWith(".*")) {
            name = name.substring(0, name.length() - 2);
        }

        EventConditions cur_ecs = (EventConditions) rule_map.get(name);
        if (cur_ecs == null) {
            rule_map.put(name, new EventConditions(ecs));
        }
        else {
            cur_ecs.merge(ecs);
        }
    }

    /**
     * Checks the name of an observable to determine whether it is included
     * in the specification.
     *
     * @param name Name of the observable to be tested for inclusion in
     * the module.
     * @param event_map Rule set holding the rules and associated conditions
     * for observables of the type being checked.
     * @param inLoc Fully qualified location in which the event being checked
     * occurred.
     */
    private boolean checkNameRule(String name, Map event_map,
            String inLoc) {
        EventConditions ecs = (EventConditions) event_map.get(name);

        Condition curCond;
        if (ecs != null) {
            curCond = ecs.checkConditions(inLoc);
        }
        else {
            curCond = Condition.DEFAULT_EXCLUDE;
        }

        int stopIndex = name.lastIndexOf('.');
        for (int i = 0; i <= stopIndex; i++) {
            if (name.charAt(i) == '.') {
                String s = name.substring(0, i);
                ecs = (EventConditions) event_map.get(s);

                if (ecs != null) {
                    Condition cond = (Condition) ecs.checkConditions(inLoc);
                    if (cond.rank > curCond.rank) {
                        curCond = cond;
                    }
                }
           }
        }

        return curCond.inclusion;
    }

    /**
     * Adds a property and value to be associated with an event key.
     *
     * @param key Event key with which the property is to be associated,
     * normally the name of the observable referenced by the event (the
     * same as a key that would be used in the name rule table).
     * @param property Name of the property to be set.
     * @param value Value to associate with the property.
     */
    private void addProperty(String key, String property, String value) {
        if (key.endsWith(".*")) {
            key = key.substring(0, key.length() - 2);
        }

        Map properties = (Map) event_properties.get(key);
        if (properties == null) {
            properties = new THashMap();
            event_properties.put(key, properties);
        }

        properties.put(property, value);
    }

    /**
     * Gets a property value associated with an event key.
     *
     * @param key Event key with which the property is associated,
     * normally the name of the observable referenced by the event (the
     * same as a key that would be used in the name rule table).
     * @param property Name of the property value to be retrieved.
     *
     * @return The value associated with the requested property.
     */
    private String getProperty(String key, String property) {
        int stopIndex = key.lastIndexOf('.');
        for (int i = 0; i <= stopIndex; i++) {
            if (key.charAt(i) == '.') {
                String s = key.substring(0, i);
                Map properties = (Map) event_properties.get(s);

                if (properties != null) {
                    return (String) properties.get(property);
                }
           }
        }

        return null;
    }

    /**
     * Checks the name of an exception related observable to determine whether
     * it is included in the specification.
     *
     * <p>This method checks for matching exception throw and catch observable
     * events. It check for inclusion of subclasses, and it does
     * <strong>not</strong> permit wildcard queries.</p>
     *
     * @param name Name of the exception observable to be tested for inclusion
     * in the module.
     * @param int eventType Constant specifying which type of exception
     * observable is to be checked for inclusion.
     * @param inLoc Fully qualified location in which the throwable event being
     * checked occurred.
     */
    private boolean checkThrowableRule(String name, int eventType,
            String inLoc) {
        Map event_map = throwable_events[eventType];
        EventConditions ecs = (EventConditions) event_map.get(name);

        Condition curCond;
        if (ecs != null) {
            curCond = ecs.checkConditions(inLoc);
        }
        else {
            curCond = Condition.DEFAULT_EXCLUDE;
        }

        int size = throwable_inc_subclass[eventType].size();
        if (size > 0) {
            Iterator iterator = throwable_inc_subclass[eventType].iterator();
            for (int i = size; i-- > 0; ) {
                String className = (String) iterator.next();

                Class checkClass, matchClass;
                try {
                    checkClass = Class.forName(name);
                    matchClass = Class.forName(className);
                }
                catch (ClassNotFoundException e) {
                    throw new SofyaError("Unable to determine subclass " +
                        "relationship", e);
                }

                if (matchClass.isAssignableFrom(checkClass)) {
                    ecs = (EventConditions) event_map.get(className);

                    Condition cond = (Condition) ecs.checkConditions(inLoc);
                    if (cond.rank > curCond.rank) {
                        curCond = cond;
                    }
                }
            }
        }

        return curCond.inclusion;
    }

    /**
     * Performs a heuristic check to determine whether any observable events
     * associated with a given observable name are considered included in
     * the specification.
     *
     * <p>This test should report whether the given observable <em>may</em>
     * be included in the specification. Conditions on the locations in which
     * events associated with the observable should be witnessed can prevent
     * a certainly correct answer to this query. This method should not,
     * however, report an observable as excluded if there is any possibility
     * that it is included.</p>
     *
     * <p>This method currently uses the following heuristic:
     * If there are no location conditions for the given observable,
     * it is reported as included in the specification if the highest ranked
     * rule pertaining to the observable is an inclusion rule. If there are
     * conditions on the given observable, it is always reported as
     * included on the assumption that a user would not purposefully
     * code conditions that are guaranteed to prevent the observable from
     * ever being witnessed.</p>
     *
     * @param name Fully qualified name of the observable to be checked for
     * inclusion in the specification.
     * @param event_map Rule set for the type of observable on which the
     * check is to be performed.
     *
     * @return <code>true</code> if the named observable may match an
     * inclusion condition of the specification.
     */
    private boolean anyRuleMatch(String name, Map event_map) {
        EventConditions ecs = (EventConditions) event_map.get(name);

        Condition curCond;
        if (ecs != null) {
            curCond = ecs.anyInclusions();
        }
        else {
            curCond = Condition.DEFAULT_EXCLUDE;
        }

        int stopIndex = name.lastIndexOf('.');
        for (int i = 0; i <= stopIndex; i++) {
            if (name.charAt(i) == '.') {
                String s = name.substring(0, i);
                ecs = (EventConditions) event_map.get(s);

                if (ecs != null) {
                    Condition cond = (Condition) ecs.anyInclusions();
                    if (cond.rank > curCond.rank) {
                        curCond = cond;
                    }
                }
           }
        }

        return curCond.inclusion;
    }

    /**
     * Creates a request for a new object allocation observable.
     *
     * @param className Name of a class or a package of classes for which
     * new object allocations (NEW instructions) are to be included in or
     * excluded from specification.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     *
     * @return A new object allocation request object that can be used
     * to add conditions constraining where the observable is to be
     * witnessed.
     */
    NewObjectRequest createNewObjectRequest(String className,
            boolean inclusion, int rank) {
        return new NewObjectRequest(className,
                                    new EventConditions(inclusion, rank));
    }

    /**
     * Adds a new object allocation observable to the specification.
     *
     * @param request New object allocation observable request submitted for
     * addition to the specification.
     */
    void addNewObjectRequest(NewObjectRequest request) {
        if (request.name().equals("*")) {
            forAllClasses(new AddNameRuleAction(new_events,
                request.conditions()));
        }
        else {
            addNameRule(request.name(), new_events, request.conditions());
        }
    }

    public boolean witnessNewObject(String newClass, MethodGen inMethod) {
        String inLoc = buildKeySignature(inMethod.getClassName(),
            inMethod.getName(), inMethod.getArgumentTypes());
        return checkNameRule(newClass, new_events, inLoc);
    }

    /**
     * Creates a request for a field observable.
     *
     * @param fieldName Name of a field or qualified package or class
     * name for which fields should be included or excluded.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     * @param fType Type of the observable field (read instance field,
     * write instance field, etc...).
     *
     * @return A new field request object that can be used
     * to add conditions constraining where the observable is to be
     * witnessed.
     */
    FieldRequest createFieldRequest(String fieldName, boolean inclusion,
            int rank, FieldType fType) {
        return new FieldRequest(fieldName, fType,
                                new EventConditions(inclusion, rank));
    }

    /**
     * Adds a field observable to the specification.
     *
     * @param request Field observable request submitted for addition to
     * the specification.
     */
    void addFieldRequest(FieldRequest request) {
        EventConditions ecs = request.conditions();
        int fieldType = request.fieldType();

        if (request.name().equals("*")) {
            forAllClasses(new AddNameRuleAction(field_events[fieldType], ecs));
        }
        else {
            addNameRule(request.name(), field_events[fieldType], ecs);
        }
    }

    public boolean witnessField(FieldInstruction fi, ConstantPoolGen cpg,
            MethodGen inMethod) {
        int fieldType = FieldType.mapFromOpcode(fi.getOpcode());
        String fullName = fi.getReferenceType(cpg).toString() + "." +
            fi.getFieldName(cpg);
        String inLoc = buildKeySignature(inMethod.getClassName(),
            inMethod.getName(), inMethod.getArgumentTypes());

        return checkNameRule(fullName, field_events[fieldType], inLoc);
    }

    public boolean witnessField(String fieldName, FieldType fType,
            String className, String methodName, String methodSignature) {
        int fieldType = fType.toInt();
        String inLoc =
            buildKeySignature(className, methodName, methodSignature);
        return checkNameRule(fieldName, field_events[fieldType], inLoc);
    }

    public int witnessField(String fieldName, boolean isStatic) {
        int retMask = 0;

        if (isStatic) {
            if (anyRuleMatch(fieldName, field_events[FieldType.IGETSTATIC])) {
                retMask |= FIELD_WITNESS_READ;
            }
            if (anyRuleMatch(fieldName, field_events[FieldType.IPUTSTATIC])) {
                retMask |= FIELD_WITNESS_WRITE;
            }
        }
        else {
            if (anyRuleMatch(fieldName, field_events[FieldType.IGETFIELD])) {
                retMask |= FIELD_WITNESS_READ;
            }
            if (anyRuleMatch(fieldName, field_events[FieldType.IPUTFIELD])) {
                retMask |= FIELD_WITNESS_WRITE;
            }
        }

        return retMask;
    }

    /**
     * Creates a request for a call observable.
     *
     * @param className Class on which the call is invoked.
     * @param methodName Name of the invoked method.
     * @param argTypes Arguments types to the method.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     * @param cType Type of the observable call (static, virtual, etc.).
     *
     * @return A new call request object that can be used
     * to add conditions constraining where the observable is to be
     * witnessed.
     */
    CallRequest createCallRequest(String className, String methodName,
            Type[] argTypes, boolean inclusion, int rank, CallType cType,
            boolean intercept) {
        return new CallRequest(className, methodName, argTypes, cType,
                               new EventConditions(inclusion, rank),
                               intercept);
    }

    /**
     * Adds a call observable to the specification.
     *
     * @param request Call observable request submitted for addition to
     * the specification.
     */
    void addCallRequest(CallRequest request) {
        EventConditions ecs = request.conditions();
        String className = request.name();
        String methodName = request.methodName();
        Type[] argTypes = request.argTypes();
        int callType = request.callType();

        if (className.equals("*")) {
            forAllClasses(new AddNameRuleAction(call_events[callType], ecs));

            if (request.intercept) {
                forAllClasses(new ClassAction() {
                    public boolean handleClass(String className) {
                        addProperty(className, "call:use_intercept", "T");
                        return true;
                    }});
            }
        }
        else {
            String keyString =
                buildKeySignature(className, methodName, argTypes);
            addNameRule(keyString, call_events[callType], ecs);

            if (request.intercept) {
                addProperty(keyString, "call:use_intercept", "T");
            }
        }
    }

    public boolean witnessCall(InvokeInstruction call, ConstantPoolGen cpg,
            MethodGen inMethod) {
        int callType = CallType.mapFromOpcode(call.getOpcode());

        String keyString = buildKeySignature(
            call.getReferenceType(cpg).toString(),
            call.getMethodName(cpg),
            call.getArgumentTypes(cpg));

        String inLoc = buildKeySignature(inMethod.getClassName(),
            inMethod.getName(), inMethod.getArgumentTypes());

        return checkNameRule(keyString, call_events[callType], inLoc);
    }

    public boolean useCallInterceptor(InvokeInstruction call,
            ConstantPoolGen cpg) {
        String keyString = buildKeySignature(
            call.getReferenceType(cpg).toString(),
            call.getMethodName(cpg),
            call.getArgumentTypes(cpg));

        String propVal = getProperty(keyString, "call:use_intercept");
        if (propVal == null) {
            return false;
        }
        else {
            return (propVal.equals("T"));
        }
    }

    /**
     * Creates a request for a constructor entry observable.
     *
     * <p>This method does not return a request object to which conditions
     * can be added, since events associated with this type of observable can
     * only be raised in one location (per constructor).</p>
     *
     * @param className Name of a class or qualified package for which
     * entry into the object constructor(s) should be included or excluded.
     * @param argTypes Argument types to the constructor.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     */
    void addConstructorEntryRequest(String className, Type[] argTypes,
            boolean inclusion, int rank) {
        if (className.equals("*")) {
            forAllClasses(new AddNameRuleAction(construct_events[CNS_ENTER],
                new EventConditions(inclusion, rank)));
        }
        else {
            addNameRule(buildKeySignature(className, "<init>", argTypes),
                construct_events[CNS_ENTER],
                new EventConditions(inclusion, rank));
        }
    }

    public boolean witnessConstructorEntry(MethodGen mg) {
        String keyString = buildKeySignature(
            mg.getClassName(),
            mg.getName(),
            mg.getArgumentTypes());

        return checkNameRule(keyString, construct_events[CNS_ENTER], "");
    }

    /**
     * Creates a request for a constructor exit observable.
     *
     * <p>This method does not return a request object to which conditions
     * can be added, since events associated with this type of observable can
     * only be raised in one location (per constructor).</p>
     *
     * @param className Name of a class or qualified package for which
     * exit from the object constructor(s) should be included or excluded.
     * @param argTypes Argument types to the constructor.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     */
    void addConstructorExitRequest(String className, Type[] argTypes,
            boolean inclusion, int rank) {
        if (className.equals("*")) {
            forAllClasses(new AddNameRuleAction(construct_events[CNS_EXIT],
                new EventConditions(inclusion, rank)));
        }
        else {
            addNameRule(buildKeySignature(className, "<init>", argTypes),
                construct_events[CNS_EXIT],
                new EventConditions(inclusion, rank));
        }
    }

    public boolean witnessConstructorExit(MethodGen mg) {
        String keyString = buildKeySignature(
            mg.getClassName(),
            mg.getName(),
            mg.getArgumentTypes());

        return checkNameRule(keyString, construct_events[CNS_EXIT], "");
    }

    /**
     * Creates a request for a virtual method entry observable.
     *
     * <p>This method does not return a request object to which conditions
     * can be added, since events associated with this type of observable can
     * only be raised in one location (per method).</p>
     *
     * @param className Name of a class or qualified package or class for which
     * entry into the virtual method(s) should be included or excluded.
     * @param methodName Name of the entered method.
     * @param argTypes Argument types to the method.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     */
    void addMethodChangeRequest(String className, String methodName,
            Type[] argTypes, boolean inclusion, int rank, MethodAction mAct) {
        if (className.equals("*")) {
            forAllClasses(new AddNameRuleAction(method_events[mAct.toInt()],
                new EventConditions(inclusion,rank)));
        }
        else {
            addNameRule(buildKeySignature(className, methodName, argTypes),
                method_events[mAct.toInt()],
                new EventConditions(inclusion, rank));
        }
    }

    public boolean witnessMethodEntry(MethodGen mg) {
        String keyString = buildKeySignature(
            mg.getClassName(),
            mg.getName(),
            mg.getArgumentTypes());
        int actionIndex = (mg.isStatic()) ? MethodAction.ISTATIC_ENTER
                                          : MethodAction.IVIRTUAL_ENTER;

        return checkNameRule(keyString, method_events[actionIndex], "");
    }

    public boolean witnessMethodExit(MethodGen mg) {
        String keyString = buildKeySignature(
            mg.getClassName(),
            mg.getName(),
            mg.getArgumentTypes());
        int actionIndex = (mg.isStatic()) ? MethodAction.ISTATIC_EXIT
                                          : MethodAction.IVIRTUAL_EXIT;

        return checkNameRule(keyString, method_events[actionIndex], "");
    }

    /**
     * Creates a request for a monitor observable.
     *
     * @param className Name of the class or qualified package for
     * which activities relating to the monitor(s) owned by object
     * instances should be included or excluded.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     * @param mType Type of the monitor activity (contend, acquire, etc.).
     *
     * @return A new monitor request object that can be used
     * to add conditions constraining where the observable is to be
     * witnessed.
     */
    MonitorRequest createMonitorRequest(String className, boolean inclusion,
            int rank, MonitorType mType) {
        return new MonitorRequest(className, mType,
                                  new EventConditions(inclusion, rank));
    }

    /**
     * Adds a monitor observable to the specification.
     *
     * @param request Monitor observable request submitted for addition to
     * the specification.
     */
    void addMonitorRequest(MonitorRequest request) {
        EventConditions ecs = request.conditions();
        String className = request.name();
        int monitorType = request.monitorType();

        if (className.equals("*")) {
            forAllClasses(
                new AddNameRuleAction(monitor_events[monitorType], ecs));
        }
        else {
            addNameRule(className, monitor_events[monitorType], ecs);
        }
    }

    public boolean witnessMonitor(String className, MonitorType mType) {
        int monitorType = mType.toInt();

        return checkNameRule(className, monitor_events[monitorType], "");
    }

    public boolean witnessAnyMonitor(MonitorType mType, MethodGen inMethod) {
        int monitorType = mType.toInt();

        String inLoc = buildKeySignature(inMethod.getClassName(),
            inMethod.getName(), inMethod.getArgumentTypes());

        int eventCount = monitor_events[monitorType].size();
        Iterator iterator = monitor_events[monitorType].keySet().iterator();
        for (int i = eventCount; i-- > 0; ) {
            String key = (String) iterator.next();
            if (checkNameRule(key, monitor_events[monitorType], inLoc)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Creates a request for a thrown exception observable.
     *
     * @param exceptionClass Name of the class to be considered an
     * observable when thrown.
     * @param includeSubclasses Flag specifying whether subclasses of
     * <code>exceptionClass</code> should also be included as observables.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     *
     * @return A new throw request object that can be used
     * to add conditions constraining where the observable is to be
     * witnessed.
     */
    ThrowRequest createThrowRequest(String exceptionClass,
            boolean includeSubclasses, boolean inclusion, int rank) {
        if (includeSubclasses) {
            throwable_inc_subclass[THROW].add(exceptionClass);
        }

        return new ThrowRequest(exceptionClass,
            new EventConditions(inclusion, rank));
    }

    /**
     * Adds a thrown exception observable to the specification.
     *
     * @param request Throw exception observable request submitted for addition
     * to the specification.
     */
    void addThrowRequest(ThrowRequest request) {
        if (request.name().equals("*")) {
            forAllThrowables(new AddNameRuleAction(throwable_events[THROW],
                request.conditions()));
            //addAllThrowables(throwable_events[THROW], request.conditions());
        }
        else {
            addNameRule(request.name(), throwable_events[THROW],
                request.conditions());
        }
    }

    public boolean witnessThrow(String exceptionClass, String className,
            String methodName, String methodSignature) {
        String inLoc = buildKeySignature(className, methodName,
            methodSignature);
        return checkThrowableRule(exceptionClass, THROW, inLoc);
    }

    public boolean witnessThrow(String exceptionClass) {
        return checkThrowableRule(exceptionClass, THROW, "");
    }

    /**
     * Creates a request for a caught exception observable.
     *
     * @param exceptionClass Name of the class to be considered an
     * observable when caught.
     * @param includeSubclasses Flag specifying whether subclasses of
     * <code>exceptionClass</code> should also be included as observables.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     *
     * @return A new catch request object that can be used
     * to add conditions constraining where the observable is to be
     * witnessed.
     */
    CatchRequest createCatchRequest(String exceptionClass,
            boolean includeSubclasses, boolean inclusion, int rank) {
        if (includeSubclasses) {
            throwable_inc_subclass[CATCH].add(exceptionClass);
        }

        return new CatchRequest(exceptionClass,
            new EventConditions(inclusion, rank));
    }

    /**
     * Adds a caught exception observable to the specification.
     *
     * @param request Catch exception observable request submitted for addition
     * to the specification.
     */
    void addCatchRequest(CatchRequest request) {
        if (request.name().equals("*")) {
            forAllThrowables(new AddNameRuleAction(throwable_events[CATCH],
                request.conditions()));
            //addAllThrowables(throwable_events[CATCH], request.conditions());
        }
        else {
            addNameRule(request.name(), throwable_events[CATCH],
                request.conditions());
        }
    }

    public boolean witnessCatch(String exceptionClass, MethodGen inMethod) {
        String inLoc = buildKeySignature(inMethod.getClassName(),
            inMethod.getName(), inMethod.getArgumentTypes());
        return checkThrowableRule(exceptionClass, CATCH, inLoc);
    }

    public boolean witnessCatch(String exceptionClass) {
        return checkThrowableRule(exceptionClass, CATCH, "");
    }

    /**
     * Creates a request for a static initializer entry observable.
     *
     * <p>This method does not return a request object to which conditions
     * can be added, since events associated with this type of observable can
     * only be raised in one location (per initializer).</p>
     *
     * @param className Name of a class or qualified package or class for which
     * entry into the static initializer(s) should be included or excluded.
     * @param inclusion Specifies whether the rule is an inclusion or
     * exclusion rule.
     * @param precedence The rank, or precedence, of the rule.
     */
    void addStaticInitializerEntryRequest(String className, boolean inclusion,
            int rank) {
        if (className.equals("*")) {
            forAllClasses(new AddNameRuleAction(static_init_events,
                new EventConditions(inclusion, rank)));
        }
        else {
            addNameRule(className, static_init_events,
                        new EventConditions(inclusion, rank));
        }
    }

    public boolean witnessStaticInitializerEntry(String className) {
        return checkNameRule(className, static_init_events, "");
    }

    public void serialize(DataOutputStream stream) throws IOException {
        stream.writeInt(systemUnits.size());
        for (Iterator i = systemUnits.iterator(); i.hasNext(); ) {
            serializeProgramUnit(stream, (ProgramUnit) i.next());
        }

        stream.writeInt(moduleUnits.size());
        for (Iterator i = moduleUnits.iterator(); i.hasNext(); ) {
            serializeProgramUnit(stream, (ProgramUnit) i.next());
        }

        serializeRuleMap(stream, new_events);

        for (int i = 0; i < 4; i++) {
            serializeRuleMap(stream, field_events[i]);
        }

        for (int i = 0; i < 4; i++) {
            serializeRuleMap(stream, call_events[i]);
        }

        for (int i = 0; i < 2; i++) {
            serializeRuleMap(stream, construct_events[i]);
        }

        for (int i = 0; i < 4; i++) {
            serializeRuleMap(stream, method_events[i]);
        }

        for (int i = 0; i < 4; i++) {
            serializeRuleMap(stream, monitor_events[i]);
        }

        for (int i = 0; i < 2; i++) {
            serializeRuleMap(stream, throwable_events[i]);
        }

        for (int i = 0; i < 2; i++) {
            serializeStrings(stream, throwable_inc_subclass[i]);
        }

        serializeRuleMap(stream, static_init_events);

        stream.writeInt(event_properties.size());
        for (Iterator i = event_properties.keySet().iterator(); i.hasNext(); ) {
            String key = (String) i.next();
            Map props = (Map) event_properties.get(key);

            stream.writeUTF(key);
            stream.writeInt(props.size());
            for (Iterator p = props.keySet().iterator(); p.hasNext(); ) {
                String propName = (String) p.next();
                stream.writeUTF(propName);
                stream.writeUTF((String) props.get(propName));
            }
        }
    }

    private void serializeRuleMap(DataOutputStream stream, Map map)
            throws IOException {
        stream.writeInt(map.size());
        Iterator iterator = map.keySet().iterator();
        for (int i = map.size(); i-- > 0; ) {
            String key = (String) iterator.next();
            stream.writeUTF(key);
            EventConditions ecs = (EventConditions) map.get(key);
            ecs.serialize(stream);
        }
    }

    public EventSpecification deserialize(DataInputStream stream)
            throws IOException {
        int size = stream.readInt();
        for (int i = 0; i < size; i++) {
            this.systemUnits.add(deserializeProgramUnit(stream));
        }

        size = stream.readInt();
        for (int i = 0; i < size; i++) {
            this.moduleUnits.add(deserializeProgramUnit(stream));
        }

        this.new_events = deserializeRuleMap(stream);

        for (int i = 0; i < 4; i++) {
            this.field_events[i] = deserializeRuleMap(stream);
        }

        for (int i = 0; i < 4; i++) {
            this.call_events[i] = deserializeRuleMap(stream);
        }

        for (int i = 0; i < 2; i++) {
            this.construct_events[i] = deserializeRuleMap(stream);
        }

        for (int i = 0; i < 4; i++) {
            this.method_events[i] = deserializeRuleMap(stream);
        }

        for (int i = 0; i < 4; i++) {
            this.monitor_events[i] = deserializeRuleMap(stream);
        }

        for (int i = 0; i < 2; i++) {
            this.throwable_events[i] = deserializeRuleMap(stream);
        }

        for (int i = 0; i < 2; i++) {
            this.throwable_inc_subclass[i] =
                (Set) deserializeStrings(stream, new THashSet());
        }

        this.static_init_events = deserializeRuleMap(stream);

        this.event_properties = new THashMap();
        size = stream.readInt();
        for (int i = 0; i < size; i++) {
            String key = stream.readUTF();
            Map properties = new THashMap();
            this.event_properties.put(key, properties);

            int propCount = stream.readInt();
            for (int p = 0; p < propCount; p++) {
                properties.put(stream.readUTF(), stream.readUTF());
            }
        }

        initModuleClassData();

        return this;
    }

    private Map deserializeRuleMap(DataInputStream stream) throws IOException {
        Map rule_map = new THashMap();

        int size = stream.readInt();
        for (int i = size; i-- > 0; ) {
            String key = stream.readUTF();
            EventConditions ecs = EventConditions.deserialize(stream);
            rule_map.put(key, ecs);
        }

        return rule_map;
    }

    abstract static class EGEventRequest {
        protected String name;
        protected EventConditions conditions;

        protected EGEventRequest() { }

        String name() {
            return name;
        }

        EventConditions conditions() {
            return conditions;
        }
    }

    final static class NewObjectRequest extends EGEventRequest {
        private NewObjectRequest() {
            throw new SofyaError("Illegal constructor");
        }

        NewObjectRequest(String className, EventConditions ecs) {
            this.name = className;
            this.conditions = ecs;
        }
    }

    final static class FieldRequest extends EGEventRequest {
        private final int fieldType;

        private FieldRequest() {
            throw new SofyaError("Illegal constructor");
        }

        FieldRequest(String fieldName, FieldType fieldType,
                     EventConditions ecs) {
            this.name = fieldName;
            this.conditions = ecs;
            this.fieldType = fieldType.toInt();
        }

        int fieldType() {
            return fieldType;
        }
    }

    final static class CallRequest extends EGEventRequest {
        private final String methodName;
        private final Type[] argTypes;
        private final int callType;
        private final boolean intercept;

        private CallRequest() {
            throw new SofyaError("Illegal constructor");
        }

        CallRequest(String className, String methodName, Type[] argTypes,
                CallType callType, EventConditions ecs, boolean intercept) {
            this.name = className;
            this.methodName = methodName;
            this.argTypes = argTypes;
            this.conditions = ecs;
            this.callType = callType.toInt();
            this.intercept = intercept;
        }

        String methodName() {
            return methodName;
        }

        Type[] argTypes() {
            return argTypes;
        }

        int callType() {
            return callType;
        }

        boolean intercept() {
            return intercept;
        }
    }

    final static class MonitorRequest extends EGEventRequest {
        private final int monitorType;

        private MonitorRequest() {
            throw new SofyaError("Illegal constructor");
        }

        MonitorRequest(String className, MonitorType monitorType,
                EventConditions ecs) {
            this.name = className;
            this.conditions = ecs;
            this.monitorType = monitorType.toInt();
        }

        int monitorType() {
            return monitorType;
        }
    }

    final static class ThrowRequest extends EGEventRequest {
        private ThrowRequest() {
            throw new SofyaError("Illegal constructor");
        }

        ThrowRequest(String exceptionName, EventConditions ecs) {
            this.name = exceptionName;
            this.conditions = ecs;
        }
    }

    final static class CatchRequest extends EGEventRequest {
        private CatchRequest() {
            throw new SofyaError("Illegal constructor");
        }

        CatchRequest(String exceptionName, EventConditions ecs) {
            this.name = exceptionName;
            this.conditions = ecs;
        }
    }

    final static class Condition {
        public final boolean inclusion;
        public final int rank;

        public static final Condition DEFAULT_INCLUDE =
            new Condition(true, -1);
        public static final Condition DEFAULT_EXCLUDE =
            new Condition(false, -1);

        private Condition() {
            throw new SofyaError("Illegal constructor");
        }

        Condition(boolean inclusion, int rank) {
            this.inclusion = inclusion;
            this.rank = rank;
        }
    }

    final static class EventConditions {
        private final ConditionTree conditions;

        EventConditions(boolean inclusion, int rank) {
            this.conditions = new ConditionTree(inclusion, rank);
        }

        private EventConditions(EventConditions ecs) {
            this.conditions = ecs.conditions.copy();
        }

        private EventConditions(ConditionTree conditions) {
            this.conditions = conditions;
        }

        void addInCondition(String className, String methodName,
                Type[] argTypes, boolean inclusion, int rank) {
            conditions.addNode(
                buildKeySignature(className, methodName, argTypes),
                new InNode(inclusion, rank));
        }

        void addNotCondition(String className, String methodName,
                Type[] argTypes, boolean inclusion, int rank) {
            conditions.addNode(
                buildKeySignature(className, methodName, argTypes),
                new NotNode(inclusion, rank));
        }

        Condition checkConditions(String key) {
            return conditions.checkConditions(key);
        }

        Condition anyInclusions() {
            return conditions.anyInclusions();
        }

        void merge(EventConditions ecs) {
            conditions.merge(ecs.conditions);
        }

        void serialize(DataOutputStream stream) throws IOException {
            conditions.serialize(stream);
        }

        static EventConditions deserialize(DataInputStream stream)
                throws IOException {
            return new EventConditions(ConditionTree.deserialize(stream));
        }
    }

    final static class ConditionTree {
        private final RootNode root;

        private int size = 0;

        private ConditionTree(RootNode node) {
            root = node;
        }

        ConditionTree(boolean inclusion, int rank) {
            root = new RootNode(inclusion, rank);
        }

        int size() {
            return size;
        }

        void addNode(String key, ConditionNode node) {
            if ((key == null) || (key.length() == 0)) {
                throw new IllegalArgumentException("Condition key cannot " +
                    "be null or empty string");
            }

            if (key.endsWith(".*")) {
                key = key.substring(0, key.length() - 2);
            }

            ConditionNode currentNode = root;
            ConditionNode prevNode = null;
            ConditionNode nextNode = null;

            StringTokenizer stok = new StringTokenizer(key, ".");
            String nodeKey = null;
            while (stok.hasMoreTokens()) {
                nodeKey = stok.nextToken();

                nextNode = (ConditionNode) currentNode.children.get(nodeKey);
                if (nextNode == null) {
                    ConditionNode insertNode;
                    if (!key.endsWith(nodeKey)) {
                        insertNode = new ImpliedNode(node);
                    }
                    else {
                        insertNode = node.copy();
                    }

                    currentNode.children.put(nodeKey, insertNode);
                    size += 1;

                    if (currentNode instanceof ImpliedNode) {
                        ImpliedNode impNode = (ImpliedNode) currentNode;
                        if ((impNode.rankingChild == null) ||
                                (impNode.rankingChild.rank <= node.rank)) {
                            impNode.rankingChildKey = nodeKey;
                            impNode.rankingChild = insertNode;
                        }
                    }

                    prevNode = currentNode;
                    currentNode = insertNode;
                }
                else {
                    prevNode = currentNode;
                    currentNode = nextNode;
                }
            }

            if (nextNode != null) {
                if (currentNode.rank <= node.rank) {
                    // Do not replace an explicit node with an implied node
                    if ((currentNode.type() != ImpliedNode.TYPE_ID) &&
                            (node.type() == ImpliedNode.TYPE_ID)) {
                        return;
                    }

                    ConditionNode insertNode = node.copy();
                    insertNode.children.putAll(currentNode.children);
                    prevNode.children.put(nodeKey, insertNode);

                    if (prevNode instanceof ImpliedNode) {
                        ImpliedNode impNode = (ImpliedNode) prevNode;
                        if ((impNode.rankingChild == null) ||
                                (impNode.rankingChild.rank <= node.rank)) {
                            impNode.rankingChildKey = nodeKey;
                            impNode.rankingChild = insertNode;
                        }
                    }
                }
            }

            //System.out.println(toString());
        }

        Condition checkConditions(String inLoc) {
            ConditionNode rankingNode = root;
            ConditionNode currentNode = root;

            StringTokenizer stok = new StringTokenizer(inLoc, ".");
            while (stok.hasMoreTokens()) {
                String s = stok.nextToken();

                ConditionNode nextNode =
                    (ConditionNode) currentNode.children.get(s);
                if (nextNode == null) {
                    break;
                }
                else {
                    currentNode = nextNode;

                    if (currentNode.rank >= rankingNode.rank) {
                        rankingNode = currentNode;
                    }
                }
            }

            return rankingNode.condition();
        }

        Condition anyInclusions() {
            if (size == 0) {
                return new Condition(root.inclusion, root.rank);
            }

            return new Condition(true, root.rank);
        }

        /**
         * Creates a deep copy of this condition tree.
         *
         * @return A deep copy of the condition tree.
         */
        ConditionTree copy() {
            ConditionTree copy = new ConditionTree((RootNode) root.copy());
            copyNode(this.root, copy.root);
            return copy;
        }

        /**
         * Recursive implemention of the tree copy method.
         *
         * <p>This method copies all of the children from a node in one tree
         * to the corresponding node in another tree. This is a deep copy,
         * which triggers a recursive copying of all child nodes. Thus this
         * method will create a deep copy of the entire subtree rooted at
         * the specified node (or obviously the entire tree if starting from
         * the root node).</p>
         *
         * @param origNode Node in the original tree to be copied.
         * @param newNode Node in the target tree to which we are copying.
         */
        private void copyNode(ConditionNode origNode, ConditionNode newNode) {
            String origRankingChildKey = null;
            if (origNode instanceof ImpliedNode) {
                origRankingChildKey = ((ImpliedNode) origNode).rankingChildKey;
            }

            int count = origNode.children.size();
            Iterator iterator = origNode.children.keySet().iterator();
            for (int i = count; i-- > 0; ) {
                String childKey = (String) iterator.next();
                ConditionNode child =
                    (ConditionNode) origNode.children.get(childKey);
                ConditionNode childCopy = child.copy();
                newNode.children.put(childKey, childCopy);

                if (childKey.equals(origRankingChildKey)) {
                    ((ImpliedNode) newNode).rankingChild = child;
                }

                copyNode(child, childCopy);
            }
        }

        /**
         * Merges another condition tree into this tree.
         *
         * <p>Each node in the tree to be merged is added to this tree.
         * Only nodes of higher rank can replace nodes in this tree.
         * Nodes which are merged are deep copies, thus the argument
         * to this method remains an independent tree.</p>
         *
         * @param tree Tree to be merged into this tree.
         */
        void merge(ConditionTree tree) {
//             System.out.println("merge");
//             System.out.println("this tree: ");
//             System.out.println(toString());
//             System.out.println("merge tree: ");
//             System.out.println(tree.toString());

            if (tree.root.rank >= this.root.rank) {
                this.root.inclusion = tree.root.inclusion;
                this.root.rank = tree.root.rank;
            }

            mergeNode("", tree.root);

//             System.out.println("merged tree: ");
//             System.out.println(toString());
        }

        /**
         * Recursive implementation of the tree merge method.
         *
         * <p>This method recursively merges all of the children of the given
         * node into this tree. Thus this method will merge the entire subtree
         * rooted at the given node into this tree.</p>
         *
         * @param key Key associated with the node to be merged.
         * @param node Node to be merged.
         */
        private void mergeNode(String key, ConditionNode node) {
            int count = node.children.size();
            Iterator iterator = node.children.keySet().iterator();
            for (int i = count; i-- > 0; ) {
                String childKey = (String) iterator.next();
                ConditionNode child =
                    (ConditionNode) node.children.get(childKey);
                String chainKey = key + "." + childKey;
                addNode(chainKey, child);
                mergeNode(chainKey, child);
            }
        }

        public String toString() {
            StringBuffer sb = new StringBuffer();
            toString("root", root, sb, 0);
            return sb.toString();
        }

        private void toString(String key, ConditionNode node,
                StringBuffer sb, int depth) {
            for (int i = depth; i-- > 0; ) {
                sb.append("  ");
            }
            sb.append(key);
            sb.append(": ");
            sb.append(node.toString());
            sb.append(Handler.LINE_SEP);

            int count = node.children.size();
            Iterator iterator = node.children.keySet().iterator();
            for (int i = count; i-- > 0; ) {
                String childKey = (String) iterator.next();
                ConditionNode child =
                    (ConditionNode) node.children.get(childKey);
                toString(childKey, child, sb, depth + 1);
            }
        }

        void serialize(DataOutputStream stream) throws IOException {
            stream.writeInt(size);
            serializeNode("", root, stream);
        }

        void serializeNode(String key, ConditionNode node,
                DataOutputStream stream) throws IOException {
            stream.writeUTF(key);
            stream.writeInt(node.type());
            stream.writeInt(node.rank);
            stream.writeBoolean(node.inclusion);
            if (node instanceof ImpliedNode) {
                ImpliedNode impNode = (ImpliedNode) node;
                if (impNode.rankingChildKey != null) {
                    stream.writeByte(1);
                    stream.writeUTF(impNode.rankingChildKey);
                }
                else {
                    stream.writeByte(0);
                }
            }

            int count = node.children.size();
            Iterator iterator = node.children.keySet().iterator();
            stream.writeInt(count);
            for (int i = count; i-- > 0; ) {
                String childKey = (String) iterator.next();
                serializeNode(childKey,
                    (ConditionNode) node.children.get(childKey), stream);
            }
        }

        static ConditionTree deserialize(DataInputStream stream)
                throws IOException {
            int size = stream.readInt();
            RootNode root = null;
            try {
                stream.readUTF(); // Read the unused root key
                root = (RootNode) deserializeNode(stream);
            }
            catch (ClassCastException e) {
                throw new BadFileFormatException("Malformed condition tree, " +
                    "could not read root node", e);
            }

            ConditionTree tree = new ConditionTree(root);
            tree.size = size;

//             System.out.println(tree.toString());

            return tree;
        }

        static ConditionNode deserializeNode(DataInputStream stream)
                throws IOException {
            ConditionNode node = null;

            int type = stream.readInt();
            switch (type) {
            case RootNode.TYPE_ID:
                node = new RootNode();
                break;
            case ImpliedNode.TYPE_ID:
                node = new ImpliedNode();
                break;
            case InNode.TYPE_ID:
                node = new InNode();
                break;
            case NotNode.TYPE_ID:
                node = new NotNode();
                break;
            default:
                throw new SofyaError("Unknown condition node type");
            }

            node.rank = stream.readInt();
            node.inclusion = stream.readBoolean();

            String rankingChildKey = null;
            if (node instanceof ImpliedNode) {
                if (stream.readByte() == 1) {
                    rankingChildKey = stream.readUTF();
                }
            }

            int count = stream.readInt();
//             System.out.println("type: " + type);
//             System.out.println("rank: " + node.rank);
//             System.out.println("inclusion: " + node.inclusion);
//             System.out.println("rankingChildKey: " + rankingChildKey);
//             System.out.println("count: " + count);
            for (int i = count; i > 0; i--) {
                String childKey = stream.readUTF();
                ConditionNode child = deserializeNode(stream);
                if (childKey.equals(rankingChildKey)) {
                    ImpliedNode impNode = (ImpliedNode) node;
                    impNode.rankingChildKey = rankingChildKey;
                    impNode.rankingChild = child;
                }
                node.children.put(childKey, child);
            }

            return node;
        }
    }

    abstract static class ConditionNode {
        protected int rank;
        protected boolean inclusion;
        final Map children = new THashMap();

        protected ConditionNode() {
        }

        protected ConditionNode(boolean inclusion, int rank) {
            this.inclusion = inclusion;
            this.rank = rank;
        }

        protected int rank() {
            return rank;
        }

        protected boolean inclusion() {
            return inclusion;
        }

        public String toString() {
            StringBuffer sb = new StringBuffer("{ ");
            sb.append(typeString());
            sb.append(", ");
            sb.append(rank);
            sb.append(", ");
            sb.append(inclusion);
            sb.append(" }");
            return sb.toString();
        }

        protected abstract Condition condition();

        protected abstract int type();

        protected abstract String typeString();

        protected abstract ConditionNode copy();
    }

    static class ImpliedNode extends ConditionNode {
        public static final int TYPE_ID = 1;

        public String rankingChildKey = null;
        public ConditionNode rankingChild = null;

        ImpliedNode() {
        }

        ImpliedNode(boolean inclusion, int rank) {
            super(inclusion, rank);
        }

        ImpliedNode(ConditionNode node) {
            super(node.inclusion, node.rank);
        }

        protected Condition condition() {
            switch (rankingChild.type()) {
            case ImpliedNode.TYPE_ID:
                return rankingChild.condition();
            case InNode.TYPE_ID:
                return new Condition(!rankingChild.inclusion,
                    rankingChild.rank);
            case NotNode.TYPE_ID:
                return new Condition(rankingChild.inclusion,
                    rankingChild.rank);
            default:
                throw new SofyaError("Unknown condition node type: " +
                    rankingChild.type());
            }
        }

        protected int type() {
            return TYPE_ID;
        }

        protected String typeString() {
            return "IMPLIED";
        }

        protected ConditionNode copy() {
            ImpliedNode copy = new ImpliedNode(inclusion, rank);
            copy.rankingChildKey = rankingChildKey;
            return copy;
        }

        public String toString() {
            return super.toString() + ", ( " + rankingChildKey + ": " + rankingChild + " )";
        }
    }

    final static class RootNode extends ImpliedNode {
        public static final int TYPE_ID = 0;

        RootNode() {
        }

        RootNode(RootNode node) {
            super(node.inclusion, node.rank);
        }

        RootNode(boolean inclusion, int rank) {
            super(inclusion, rank);
        }

        protected Condition condition() {
            if (children.size() == 0) {
                return new Condition(inclusion, rank);
            }
            return super.condition();
        }

        protected int type() {
            return TYPE_ID;
        }

        protected String typeString() {
            return "ROOT";
        }

        protected ConditionNode copy() {
            RootNode copy = new RootNode(inclusion, rank);
            copy.rankingChildKey = rankingChildKey;
            return copy;
        }
    }

    final static class InNode extends ConditionNode {
        public static final int TYPE_ID = 2;

        InNode() {
        }

        InNode(boolean inclusion, int rank) {
            super(inclusion, rank);
        }

        protected Condition condition() {
            return new Condition(inclusion, rank);
        }

        protected int type() {
            return TYPE_ID;
        }

        protected String typeString() {
            return "IN";
        }

        protected ConditionNode copy() {
            return new InNode(inclusion, rank);
        }
    }

    final static class NotNode extends ConditionNode {
        public static final int TYPE_ID = 3;

        NotNode() {
        }

        NotNode(boolean inclusion, int rank) {
            super(inclusion, rank);
        }

        protected Condition condition() {
            return new Condition(!inclusion, rank);
        }

        protected int type() {
            return TYPE_ID;
        }

        protected String typeString() {
            return "NOT";
        }

        protected ConditionNode copy() {
            return new NotNode(inclusion, rank);
        }
    }
}

