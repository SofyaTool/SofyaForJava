/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import sofya.base.ProgramUnit;

import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.FieldInstruction;
import org.apache.bcel.generic.InvokeInstruction;
import org.apache.bcel.generic.MethodGen;
import org.apache.bcel.generic.ObjectType;

import gnu.trove.THashSet;

/**
 * Specification which instructs an {@link SemanticEventDispatcher} to
 * generate all possible module events.
 *
 * @author Alex Kinneer
 * @version 10/25/2005
 */
public class AllModuleEvents extends AbstractEventSpecification {
    /** The set of classes which comprise the entire system. */
    private final Set systemUnits;
    /** The set of classes for which events are dispatched if
        no other constraints are supplied. */
    private final Set moduleUnits;
    /** The set of classes for which events are dispatched if
        no other constraints are supplied, as strings. */
    private final Set moduleClasses;
    /** Flag specifying whether all monitor events in the entire system
        should be witnessed. */
    private boolean allSystemMonitors;

    /**
     * Creates a new all module events specification.
     *
     * <p>The resulting specification will not define any classes comprising
     * the system or module. This constructor is provided only to support
     * deserialization.</p>
     */
    protected AllModuleEvents() {
        this.systemUnits = new THashSet();
        this.moduleUnits = new THashSet();
        this.moduleClasses = new THashSet();
        this.allSystemMonitors = false;
    }

    /**
     * Creates a new all module events specification.
     *
     * @param systemUnitList List of classes comprising the entire sytem.
     * @param moduleUnitList List of classes comprising the module
     * on which all events are to be observed (this can be the same as
     * the system class list).
     * @param allSystemMonitors Flag that specifies whether all monitor
     * events in the entire system should be included. This is provided
     * since many analyses are interested in all lock related events
     * despite only being interested in module related events otherwise.
     */
    public AllModuleEvents(List systemUnitList, List moduleUnitList,
            boolean allSystemMonitors) {
        this.systemUnits = new THashSet(systemUnitList);
        if (systemUnitList == moduleUnitList) {
            this.moduleUnits = this.systemUnits;
        }
        else {
            this.moduleUnits = new THashSet(moduleUnitList);
        }
        this.moduleClasses = unitsToStrings(moduleUnits, new THashSet());
        this.allSystemMonitors = allSystemMonitors;
    }

    public Set getSystemClasses(boolean asStrings) {
        if (asStrings) {
            return unitsToStrings(systemUnits, new THashSet());
        }
        else {
            return Collections.unmodifiableSet(systemUnits);
        }
    }

    public Set getModuleClasses(boolean asStrings) {
        if (asStrings) {
            return Collections.unmodifiableSet(moduleClasses);
        }
        else {
            return Collections.unmodifiableSet(moduleUnits);
        }
    }

    private Set unitsToStrings(Set classUnits, Set strSet) {
        int size = classUnits.size();
        Iterator iterator = classUnits.iterator();
        for (int i = size; i-- > 0; ) {
            strSet.addAll(((ProgramUnit) iterator.next()).classes);
        }
        return strSet;
    }

    public boolean witnessNewObject(String newClass, MethodGen inMethod) {
        return moduleClasses.contains(newClass);
    }

    public boolean witnessConstructorEntry(MethodGen mg) {
        return moduleClasses.contains(mg.getClassName());
    }

    public boolean witnessConstructorExit(MethodGen mg) {
        return moduleClasses.contains(mg.getClassName());
    }

    public boolean witnessField(FieldInstruction fi, ConstantPoolGen cpg,
            MethodGen inMethod) {
        return moduleClasses.contains(fi.getReferenceType(cpg).toString());
    }

    public boolean witnessField(String fieldName, FieldType fType,
            String className, String methodName, String signature) {
        return moduleClasses.contains(className);
    }

    public int witnessField(String fieldName, boolean isStatic) {
        if (moduleClasses.contains(
                fieldName.substring(0, fieldName.lastIndexOf('.')))) {
            return FIELD_WITNESS_READ | FIELD_WITNESS_WRITE;
        }
        return 0;
    }

    public boolean witnessCall(InvokeInstruction call, ConstantPoolGen cpg,
            MethodGen inMethod) {
        return moduleClasses.contains(call.getReferenceType(cpg).toString());
    }

    public boolean useCallInterceptor(InvokeInstruction call,
            ConstantPoolGen cpg) {
        return false;
    }

    public boolean witnessMethodEntry(MethodGen mg) {
        //System.out.println(mg.getClassName() + "." + mg + ": " + moduleClasses.contains(mg.getClassName()));
        return moduleClasses.contains(mg.getClassName());
    }

    public boolean witnessMethodExit(MethodGen mg) {
        return moduleClasses.contains(mg.getClassName());
    }

    public boolean witnessAnyMonitor(MonitorType type, MethodGen inMethod) {
        return true;
    }

    public boolean witnessMonitor(String className, MonitorType type) {
        if (allSystemMonitors) {
            return true;
        }
        return moduleClasses.contains(className);
    }

    public boolean witnessThrow(String exceptionClass, String className,
            String methodName, String signature) {
        return moduleClasses.contains(exceptionClass);
    }

    public boolean witnessThrow(String exceptionClass) {
        return moduleClasses.contains(exceptionClass);
    }

    public boolean witnessCatch(String exceptionClass, MethodGen inMethod) {
        return moduleClasses.contains(exceptionClass);
    }

    public boolean witnessCatch(String exceptionClass) {
        return moduleClasses.contains(exceptionClass);
    }

    public boolean witnessStaticInitializerEntry(String className) {
        return moduleClasses.contains(className);
    }

    public void serialize(DataOutputStream stream) throws IOException {
        stream.writeInt(systemUnits.size());
        for (Iterator i = systemUnits.iterator(); i.hasNext(); ) {
            serializeProgramUnit(stream, (ProgramUnit) i.next());
        }

        stream.writeInt(moduleUnits.size());
        for (Iterator i = moduleUnits.iterator(); i.hasNext(); ) {
            serializeProgramUnit(stream, (ProgramUnit) i.next());
        }

        stream.writeBoolean(allSystemMonitors);
    }

    public EventSpecification deserialize(DataInputStream stream)
             throws IOException {
        int size = stream.readInt();
        for (int i = 0; i < size; i++) {
            this.systemUnits.add(deserializeProgramUnit(stream));
        }

        size = stream.readInt();
        for (int i = 0; i < size; i++) {
            this.moduleUnits.add(deserializeProgramUnit(stream));
        }

        this.allSystemMonitors = stream.readBoolean();

        unitsToStrings(this.moduleUnits, this.moduleClasses);

        return this;
    }
}
