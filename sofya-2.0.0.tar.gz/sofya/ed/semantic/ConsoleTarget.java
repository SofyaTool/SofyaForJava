/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import sofya.base.MethodSignature;

/**
 * Pretty-prints observable trace events to the console
 * (<code>System.out</code>).
 *
 * @author Alex Kinneer
 * @version 11/15/2005
 */
public class ConsoleTarget implements EventListener {
    private StringBuffer sb = new StringBuffer();

    public void systemStarted() {
    }

    public void executionStarted() {
    }

    public void threadStartEvent(ThreadData td) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : started");
        System.out.println(sb.toString());
    }

    public void threadDeathEvent(ThreadData td) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : terminated");
        System.out.println(sb.toString());
    }

    public void classPrepareEvent(ThreadData td, String className) {
    }

    public void monitorContendEvent(ThreadData td, ObjectData od,
            MonitorData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : contending for monitor : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        System.out.println(sb.toString());
    }

    public void monitorAcquireEvent(ThreadData td, ObjectData od,
            MonitorData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : acquired monitor : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        System.out.println(sb.toString());
    }

    public void monitorPreReleaseEvent(ThreadData td, ObjectData od,
            MonitorData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : preparing to release monitor : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        System.out.println(sb.toString());
    }

    public void monitorReleaseEvent(ThreadData td, ObjectData od,
            MonitorData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : released monitor : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        System.out.println(sb.toString());
    }

    public void newAllocationEvent(ThreadData td, NewAllocationData nad) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : new ");
        sb.append(nad.getNewAllocationClass());
        System.out.println(sb.toString());
    }

    public void constructorCallEvent(ThreadData td, CallData cd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : constructor call : ");
        sb.append(cd.getCalledSignature().toString());
        System.out.println(sb.toString());
    }

    public void constructorEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : construct object : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        sb.append(md.getSignature().toString());
        System.out.println(sb.toString());
    }

    public void constructorExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : object constructed : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        sb.append(md.getSignature().toString());
        System.out.println(sb.toString());
    }

    public void staticFieldAccessEvent(ThreadData td, FieldData fd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : access static field : ");
        sb.append(fd.getFullName());
        System.out.println(sb.toString());
    }

    public void instanceFieldAccessEvent(
            ThreadData td, ObjectData od, FieldData fd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : access instance field : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        sb.append(fd.getFullName());
        System.out.println(sb.toString());
    }

    public void staticFieldWriteEvent(ThreadData td, FieldData fd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : write static field : ");
        sb.append(fd.getFullName());
        System.out.println(sb.toString());
    }

    public void instanceFieldWriteEvent(
            ThreadData td, ObjectData od, FieldData fd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : write instance field : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        sb.append(fd.getFullName());
        System.out.println(sb.toString());
    }

    public void staticCallEvent(ThreadData td, CallData cd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : static call : ");
        sb.append(cd.getCalledSignature().toString());
        System.out.println(sb.toString());
    }

    public void virtualCallEvent(ThreadData td, CallData cd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : virtual call : ");
        sb.append(cd.getCalledSignature().toString());
        System.out.println(sb.toString());
    }

    public void interfaceCallEvent(ThreadData td, CallData cd) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : interface call : ");
        sb.append(cd.getCalledSignature().toString());
        System.out.println(sb.toString());
    }

    public void callReturnEvent(ThreadData td, CallData cd,
            boolean exceptional) {
       sb.setLength(0);
       sb.append("[");
       sb.append(td.getId());
       sb.append("] \"");
       sb.append(td.getName());
       sb.append("\" : call return ");
       if (exceptional) sb.append("<exceptional> ");
       sb.append(": ");
       sb.append(cd.getCalledSignature().toString());
       System.out.println(sb.toString());
    }

    public void virtualMethodEnterEvent(ThreadData td, ObjectData od,
            MethodData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : enter virtual method : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        sb.append(md.getSignature().toString());
        System.out.println(sb.toString());
    }

    public void virtualMethodExitEvent(ThreadData td, ObjectData od,
            MethodData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : exit virtual method : ");
        sb.append("[oid=");
        sb.append(od.getId());
        sb.append("] ");
        sb.append(md.getSignature().toString());
        System.out.println(sb.toString());
    }

    public void staticMethodEnterEvent(ThreadData td, MethodData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : enter static method : ");
        sb.append(md.getSignature().toString());
        System.out.println(sb.toString());
    }

    public void staticMethodExitEvent(ThreadData td, MethodData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : exit static method : ");
        sb.append(md.getSignature().toString());
        System.out.println(sb.toString());
    }

    public void exceptionThrowEvent(ThreadData td, ExceptionData ed) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : throw : ");
        sb.append(ed.getType());
        System.out.println(sb.toString());
    }

    public void exceptionCatchEvent(ThreadData td, ExceptionData ed) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : catch : ");
        sb.append(ed.getType());
        System.out.println(sb.toString());
    }

    public void staticInitializerEnterEvent(ThreadData td, MethodData md) {
        sb.setLength(0);
        sb.append("[");
        sb.append(td.getId());
        sb.append("] \"" );
        sb.append(td.getName());
        sb.append("\" : static initializer : ");
        sb.append(md.getSignature().getClassName());
        System.out.println(sb.toString());
    }

    public void systemExited() {
    }
}
