/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

import java.io.*;
import java.util.List;
import java.util.ArrayList;

import sofya.base.Handler;
import sofya.base.exceptions.BadFileFormatException;
import sofya.base.exceptions.LocatableFileException;
import sofya.base.exceptions.IncompleteClasspathException;
import sofya.ed.semantic.EventSpecification.CallType;
import sofya.ed.semantic.EventSpecification.FieldType;
import sofya.ed.semantic.EventSpecification.MethodAction;
import sofya.ed.semantic.EventSpecification.MonitorType;
import sofya.ed.semantic.ModuleDescription.*;

import org.apache.bcel.generic.Type;
import org.apache.bcel.generic.ReferenceType;
import org.apache.bcel.generic.ObjectType;

/**
 * Handler for module description and event dispatch data files used by
 * the semantic event dispatcher.
 *
 * @author Alex Kinneer
 * @version 06/09/2006
 */
public class SemanticDataHandler extends Handler {
    /**
     * Simple data structure used to store method signature information
     * parsed from an event record.
     */
    private static class MethodInfo {
        public String className;
        public String name;
        public Type[] argTypes;
        public boolean intercept;
    }

    /** Singleton instance of the structure for storing parsed method
        signature information. Since records are parsed one at a time,
        a singleton suffices to avoid inefficient allocations of
        temporary objects. Instantiated on demand. */
    private MethodInfo methodInfo = null;
    /** Maintains the current rank (or precedence) for observable rules
        read from module description files. */
    private int eventRank = 1;

    /**
     * Reads a module description file.
     *
     * @param fileName Path to the description file.
     *
     * @return An ADT representing the module description contained in the
     * specified file.
     *
     * @throws BadFileFormatException If the specified module description
     * file is malformed or not a module description file.
     * @throws IOException For any other error that prevents successful
     * reading of the specified module description file.
     */
    public ModuleDescription readDescriptionFile(String fileName)
            throws BadFileFormatException, IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(
                openInputFile(fileName)));
        StreamTokenizer stok = new StreamTokenizer(br);
        ModuleDescription md = null;

        try {
            prepareTokenizer(stok);

            List systemClassList = new ArrayList();
            List moduleClassList = new ArrayList();

            String systemProgFile = readString(stok);
            String sysTag = null;
            if (isStringAvailable(stok)) {
                sysTag = readString(stok);
            }
            if (!readToEOL(stok)) {
                throw new BadFileFormatException("Module description file " +
                    "is incomplete: module classes not specified");
            }

            String moduleProgFile = readString(stok);
            String moduleTag = null;
            if (isStringAvailable(stok)) {
                moduleTag = readString(stok);
            }

            // Hitting EOF is fine here
            readToEOL(stok);

            Handler.readProgFile(systemProgFile, sysTag, systemClassList);
            Handler.readProgFile(moduleProgFile, moduleTag, moduleClassList);

            md = new ModuleDescription(systemClassList, moduleClassList);

            eventRank = 1;

            int ttype;
            while ((ttype = stok.nextToken()) != StreamTokenizer.TT_EOF) {
                 if (ttype == StreamTokenizer.TT_EOL) continue;

                 if (ttype != StreamTokenizer.TT_WORD) {
                     throw new LocatableFileException("Record type missing " +
                         "(non-character token found)", stok.lineno());
                 }

                 String strToken = stok.sval;
                 if (strToken.length() > 1) {
                     throw new LocatableFileException("Unknown record type " +
                         "(token contains more than one character)",
                         stok.lineno());
                 }

                 char lineCode = strToken.charAt(0);
                 switch (lineCode) {
                 case 'E':
                     parseEvent(stok, md);
                     break;
                 case 'A':
                     parseAssert(stok, md);
                     break;
                 default:
                     throw new LocatableFileException("Unknown record type: '" +
                         lineCode + "'", stok.lineno());
                 }
            }
        }
        finally {
            br.close();
        }

        return md;
    }

    /**
     * Stub method in case it should eventually be useful to provide support
     * for generating these files, either automatically or with the
     * assistance of a GUI.
     */
    void writeDescriptionFile(ModuleDescription md) {
        throw new UnsupportedOperationException();
    }

    /**
     * Parses an event record from a module description file.
     *
     * @param stok Tokenizer attached to module description file stream.
     * @param md Module description object which is being constructed
     * from the description file.
     */
    private void parseEvent(StreamTokenizer stok, ModuleDescription md)
                 throws BadFileFormatException, IOException {
        boolean inclusion;

        String includeStr = readString(stok);
        if (includeStr.length() > 1) {
            throw new LocatableFileException("Record inclusion code " +
                "missing (must be '+' or '-')", stok.lineno());
        }

        switch (includeStr.charAt(0)) {
        case '+':
            inclusion = true;
            break;
        case '-':
            inclusion = false;
            break;
        default:
            throw new LocatableFileException("Illegal record inclusion code '" +
                includeStr.charAt(0) + "'", stok.lineno());
        }

        String eventName = readString(stok).toLowerCase();
        if ("new_object".equals(eventName)) {
            String className = readString(stok);
            NewObjectRequest request =
                md.createNewObjectRequest(className, inclusion, eventRank++);
            parseConditions(stok, request, inclusion);
            md.addNewObjectRequest(request);
        }
        else if ("construct_object".equals(eventName)) {
            String className = readString(stok);
            Type[] argTypes = parseArgumentTypes(stok, "{");
            md.addConstructorEntryRequest(className, argTypes,
                inclusion, eventRank++);
        }
        else if ("construct_finish".equals(eventName)) {
            String className = readString(stok);
            Type[] argTypes = parseArgumentTypes(stok, "{");
            md.addConstructorExitRequest(className, argTypes,
                inclusion, eventRank++);
        }
        else if ("get_static".equals(eventName)) {
            String fieldName = readString(stok);
            FieldRequest request = md.createFieldRequest(fieldName,
                inclusion, eventRank++, FieldType.GETSTATIC);
            parseConditions(stok, request, inclusion);
            md.addFieldRequest(request);
        }
        else if ("put_static".equals(eventName)) {
            String fieldName = readString(stok);
            FieldRequest request = md.createFieldRequest(fieldName,
                inclusion, eventRank++, FieldType.PUTSTATIC);
            parseConditions(stok, request, inclusion);
            md.addFieldRequest(request);
        }
        else if ("get_field".equals(eventName)) {
            String fieldName = readString(stok);
            FieldRequest request = md.createFieldRequest(fieldName,
                inclusion, eventRank++, FieldType.GETFIELD);
            parseConditions(stok, request, inclusion);
            md.addFieldRequest(request);
        }
        else if ("put_field".equals(eventName)) {
            String fieldName = readString(stok);
            FieldRequest request = md.createFieldRequest(fieldName,
                inclusion, eventRank++, FieldType.PUTFIELD);
            parseConditions(stok, request, inclusion);
            md.addFieldRequest(request);
        }
        else if ("constructor_call".equals(eventName)) {
            String className = readString(stok);
            Type[] argTypes = parseArgumentTypes(stok, "{");
            CallRequest request = md.createCallRequest(className, "<init>",
                argTypes, inclusion, eventRank++, CallType.CONSTRUCTOR, false);
            parseConditions(stok, request, inclusion);
            md.addCallRequest(request);
        }
        else if ("static_call".equals(eventName)) {
            MethodInfo mi = parseMethodInfo(stok);
            CallRequest request = md.createCallRequest(mi.className, mi.name,
                mi.argTypes, inclusion, eventRank++, CallType.STATIC,
                mi.intercept);
            parseConditions(stok, request, inclusion);
            md.addCallRequest(request);
        }
        else if ("virtual_call".equals(eventName)) {
            MethodInfo mi = parseMethodInfo(stok);
            CallRequest request = md.createCallRequest(mi.className, mi.name,
                mi.argTypes, inclusion, eventRank++, CallType.VIRTUAL,
                mi.intercept);
            parseConditions(stok, request, inclusion);
            md.addCallRequest(request);
        }
        else if ("interface_call".equals(eventName)) {
            MethodInfo mi = parseMethodInfo(stok);
            CallRequest request = md.createCallRequest(mi.className, mi.name,
                mi.argTypes, inclusion, eventRank++, CallType.INTERFACE,
                mi.intercept);
            parseConditions(stok, request, inclusion);
            md.addCallRequest(request);
        }
        else if ("vmethod_enter".equals(eventName)) {
            System.err.println("NOTE: \"vmethod_enter\" has been " +
                "deprecated, please use \"virtual_method_enter\" " +
                "\n      instead.");
            MethodInfo mi = parseMethodInfo(stok);
            md.addMethodChangeRequest(mi.className, mi.name, mi.argTypes,
                inclusion, eventRank++, MethodAction.VIRTUAL_ENTER);
        }
        else if ("virtual_method_enter".equals(eventName)) {
            MethodInfo mi = parseMethodInfo(stok);
            md.addMethodChangeRequest(mi.className, mi.name, mi.argTypes,
                inclusion, eventRank++, MethodAction.VIRTUAL_ENTER);
        }
        else if ("virtual_method_exit".equals(eventName)) {
            MethodInfo mi = parseMethodInfo(stok);
            md.addMethodChangeRequest(mi.className, mi.name, mi.argTypes,
                inclusion, eventRank++, MethodAction.VIRTUAL_EXIT);
        }
        else if ("static_method_enter".equals(eventName)) {
            MethodInfo mi = parseMethodInfo(stok);
            md.addMethodChangeRequest(mi.className, mi.name, mi.argTypes,
                inclusion, eventRank++, MethodAction.STATIC_ENTER);
        }
        else if ("static_method_exit".equals(eventName)) {
            MethodInfo mi = parseMethodInfo(stok);
            md.addMethodChangeRequest(mi.className, mi.name, mi.argTypes,
                inclusion, eventRank++, MethodAction.STATIC_EXIT);
        }
        else if ("monitor_contend".equals(eventName)) {
            String className = readString(stok);
            MonitorRequest request = md.createMonitorRequest(className,
                inclusion, eventRank++, MonitorType.CONTEND);
            parseConditions(stok, request, inclusion);
            md.addMonitorRequest(request);
        }
        else if ("monitor_acquire".equals(eventName)) {
            String className = readString(stok);
            MonitorRequest request = md.createMonitorRequest(className,
                inclusion, eventRank++, MonitorType.ACQUIRE);
            parseConditions(stok, request, inclusion);
            md.addMonitorRequest(request);
        }
        else if ("monitor_pre_release".equals(eventName)) {
            String className = readString(stok);
            MonitorRequest request = md.createMonitorRequest(className,
                inclusion, eventRank++, MonitorType.PRE_RELEASE);
            parseConditions(stok, request, inclusion);
            md.addMonitorRequest(request);
        }
        else if ("monitor_release".equals(eventName)) {
            String className = readString(stok);
            MonitorRequest request = md.createMonitorRequest(className,
                inclusion, eventRank++, MonitorType.RELEASE);
            parseConditions(stok, request, inclusion);
            md.addMonitorRequest(request);
        }
        else if ("throw".equals(eventName)) {
            String exceptionClass = readString(stok);
            boolean andSubclasses = false;
            if (isStringAvailable(stok)) {
                String token = readString(stok).toLowerCase();
                if (token.equals("+s")) {
                    andSubclasses = true;
                }
                else {
                    stok.pushBack();
                }
            }

            ThrowRequest request = md.createThrowRequest(exceptionClass,
                andSubclasses, inclusion, eventRank++);
            parseConditions(stok, request, inclusion);
            md.addThrowRequest(request);
        }
        else if ("catch".equals(eventName)) {
            String exceptionClass = readString(stok);
            boolean andSubclasses = false;
            if (isStringAvailable(stok)) {
                String token = readString(stok).toLowerCase();
                if (token.equals("+s")) {
                    andSubclasses = true;
                }
                else {
                    stok.pushBack();
                }
            }

            CatchRequest request = md.createCatchRequest(exceptionClass,
                andSubclasses, inclusion, eventRank++);
            parseConditions(stok, request, inclusion);
            md.addCatchRequest(request);
        }
        else if ("static_init_enter".equals(eventName)) {
            String className = readString(stok);
            md.addStaticInitializerEntryRequest(className, inclusion,
                eventRank++);
        }
        else {
            throw new LocatableFileException("Unknown event \"" + eventName +
                "\"", stok.lineno());
        }

        if (!(stok.nextToken() == StreamTokenizer.TT_EOL)) {
            if (stok.ttype != StreamTokenizer.TT_EOF) {
                throw new LocatableFileException("Failed to reach end of " +
                    "record", stok.lineno());
            }
        }
    }

    /**
     * Parses event condition information from a record.
     *
     * @param stok Tokenizer attached to module description file stream.
     * @param request Observable event request to which the conditions
     * will be added.
     * @param inclusion Flag indicating whether the record for which
     * conditions are being parsed is an inclusion or exclusion record.
     *
     * @throws BadFileFormatException If the condition information
     * in the event record is malformed.
     * @throws IOException On any I/O error that prevents successful
     * reading from the tokenizer.
     */
    private void parseConditions(StreamTokenizer stok, EGEventRequest request,
            boolean inclusion) throws BadFileFormatException, IOException {
        if (!readStringIgnoreEOL(stok).equals("{")) {
            throw new LocatableFileException("Expected \"{\"", stok.lineno());
        }

        EventConditions ecs = request.conditions();

        String token;
        while (!(token = readStringIgnoreEOL(stok)).equals("}")) {
            if (token.equals("in")) {
                MethodInfo mi = parseMethodInfo(stok);
                ecs.addInCondition(mi.className, mi.name, mi.argTypes,
                    inclusion, eventRank++);
            }
            else if (token.equals("not")) {
                MethodInfo mi = parseMethodInfo(stok);
                ecs.addNotCondition(mi.className, mi.name, mi.argTypes,
                    inclusion, eventRank++);
            }
            else {
                throw new LocatableFileException("Unexpected token \"" +
                    token + "\"", stok.lineno());
            }
        }
    }

    /**
     * Parses method signature information from a record. Extracts the class
     * name, method name, and argument types.
     *
     * @param stok Tokenizer attached to module description file stream.
     *
     * @return A data structure with appropriate fields set to their
     * corresponding values. Only the argument types field is permitted
     * to be <code>null</code> (representing a wildcard on the signature).
     *
     * @throws BadFileFormatException If the method signature information
     * in the event record is malformed.
     */
    private MethodInfo parseMethodInfo(StreamTokenizer stok)
            throws BadFileFormatException, IOException {
        if (methodInfo == null) {
            methodInfo = new MethodInfo();
        }

        methodInfo.intercept = false;
        if (isStringAvailable(stok)) {
            String buffer = readString(stok);
            if ("#INT".equals(buffer.toUpperCase())) {
                methodInfo.intercept = true;

                if (isStringAvailable(stok)) {
                    buffer = readString(stok);
                }
                else {
                    throw new LocatableFileException("Method identification " +
                        "information must be provided", stok.lineno());
                }
            }

            int length = buffer.length();
            int lastDot = buffer.lastIndexOf('.');

            if (lastDot > 0) {
                if (lastDot == (length - 1)) {
                    throw new LocatableFileException("Method class name " +
                        "missing", stok.lineno());
                }

                methodInfo.className = buffer.substring(0, lastDot);
                methodInfo.name = buffer.substring(lastDot + 1, length);
            }
            else {
                if ((length > 0) && (buffer.charAt(0) == '*')) {
                    methodInfo.className = "*";
                    methodInfo.name = "*";
                }
                else {
                    throw new LocatableFileException("Method name missing",
                        stok.lineno());
                }
            }
        }
        else {
            throw new LocatableFileException("Method identification " +
                "information must be provided", stok.lineno());
        }

        methodInfo.argTypes = null;
        if (!methodInfo.name.equals("*")) {
            methodInfo.argTypes = parseArgumentTypes(stok, "{");
        }

        return methodInfo;
    }

    /**
     * Parses the argument types from a call record.
     *
     * <p>Argument types must always be comma delimited. This method will
     * attempt to recognize the following:
     * <ul>
     * <li>JNI style single-character codes for primitive types</li>
     * <li>Simple names for primitive types, including the string type</li>
     * <li>JNI style class signatures</li>
     * <li>Regular, fully qualified names of classes</li>
     * </ul>
     * Arrays <strong>must</strong> be specified in the JNI style.</p>
     *
     * @param Tokenizer attached to module description file stream.
     *
     * @return The types of the arguments to the call.
     *
     * @throws BadFileFormatException If the tokenizer does not point
     * to a parsable set of argument types.
     * @throws IOException If any other I/O error prevents successful
     * parsing of the argument types.
     */
    private Type[] parseArgumentTypes(StreamTokenizer stok, String stopToken)
                   throws BadFileFormatException, IOException {
        stok.whitespaceChars(',', ',');

        try {
            if (!isStringAvailable(stok)) {
                return null;
            }

            String argString = readString(stok);
            if (argString.equals("*")) {
                return null;
            }
            else {
                stok.pushBack();
                if (argString.equals(stopToken)) {
                    return null;
                }
            }

            List argTypes = new ArrayList();
            while (isStringAvailable(stok)) {
                argString = readString(stok);

                if (argString.equals(stopToken)) {
                    stok.pushBack();
                    break;
                }

                char firstChar = argString.charAt(0);

                // Check for signature-style primitive type codes
                if (argString.length() == 1) {
                    switch (firstChar) {
                    case 'B':
                        argTypes.add(Type.BYTE);
                        continue;
                    case 'C':
                        argTypes.add(Type.CHAR);
                        continue;
                    case 'D':
                        argTypes.add(Type.DOUBLE);
                        continue;
                    case 'F':
                        argTypes.add(Type.FLOAT);
                        continue;
                    case 'I':
                        argTypes.add(Type.INT);
                        continue;
                    case 'J':
                        argTypes.add(Type.LONG);
                        continue;
                    case 'Z':
                        argTypes.add(Type.BOOLEAN);
                        continue;
                    case 'S':
                        argTypes.add(Type.SHORT);
                        continue;
                    default:
                        // Well... it's *theoretically* possible for it to be a
                        // single character class name with no package
                        break;
                    }
                }

                // Check for convenience string identifiers
                String lcString = argString.toLowerCase();
                if ("int".equals(lcString)) {
                    argTypes.add(Type.INT);
                }
                else if ("string".equals(lcString)) {
                    argTypes.add(Type.STRING);
                }
                else if ("boolean".equals(lcString)) {
                    argTypes.add(Type.BOOLEAN);
                }
                else if ("float".equals(lcString)) {
                    argTypes.add(Type.FLOAT);
                }
                else if ("double".equals(lcString)) {
                    argTypes.add(Type.DOUBLE);
                }
                else if ("char".equals(lcString)) {
                    argTypes.add(Type.CHAR);
                }
                else if ("byte".equals(lcString)) {
                    argTypes.add(Type.BYTE);
                }
                else if ("short".equals(lcString)) {
                    argTypes.add(Type.SHORT);
                }
                else if ("long".equals(lcString)) {
                    argTypes.add(Type.LONG);
                }
                else {
                    // Try to parse as a signature or literal class name
                    ReferenceType rt = null;

                    if (((firstChar == 'L') || (firstChar == '[')) &&
                            (argString.endsWith(";"))) {
                        try {
                            rt = (ReferenceType) Type.getType(argString);
                            // Sanity check
                            if (!rt.isCastableTo(Type.OBJECT)) {
                                rt = null;
                            }
                        }
                        catch (ClassFormatError e) { }
                        catch (ClassNotFoundException e) { }
                    }

                    if (rt == null) {
                        rt = new ObjectType(argString);
                    }

                    try {
                        if (!rt.isCastableTo(Type.OBJECT)) {
                            throw new LocatableFileException("Argument type " +
                                "is not valid", stok.lineno());
                        }
                    }
                    catch (ClassNotFoundException e) {
                        throw new LocatableFileException("Argument type " +
                            "is not on classpath", stok.lineno());
                    }

                    argTypes.add(rt);
                }
            }

            return (Type[]) argTypes.toArray(new Type[argTypes.size()]);
        }
        finally {
            stok.wordChars(',', ',');
        }
    }

    /**
     * For future implementation.
     */
    private void parseAssert(StreamTokenizer stok, ModuleDescription md)
                 throws BadFileFormatException, IOException {
        int precedence = stok.lineno();
    }

    /**
     * Reads an event dispatch data file.
     *
     * @param fileName Path to the data file.
     *
     * @return An object which provides access to the event dispatch data.
     *
     * @throws BadFileFormatException If the specified event dispatch data
     * file is corrupted, invalid, or not an event dispatcn data file.
     * @throws IOException For any other I/O error that prevents reading
     * of the file.
     */
    public SemanticEventData readDataFile(String fileName)
            throws BadFileFormatException, IOException {
        DataInputStream in = new DataInputStream(
            new BufferedInputStream(openInputFile(fileName)));
        SemanticEventData data = null;

        try {
            String specClassName = in.readUTF();
            EventSpecification eventSpec = null;

            try {
                Class specClass = Class.forName(specClassName);
                eventSpec = (EventSpecification) specClass.newInstance();
            }
            catch (ClassNotFoundException e) {
                IOException ioe = new IOException();
                ioe.initCause(e);
                throw ioe;
            }
            catch (InstantiationException e) {
                IOException ioe = new IOException();
                ioe.initCause(e);
                throw ioe;
            }
            catch (IllegalAccessException e) {
                IOException ioe = new IOException();
                ioe.initCause(e);
                throw ioe;
            }

            eventSpec.deserialize(in);
            data = new SemanticEventData(eventSpec);

            int strTableLength = in.readInt();
            for (int i = 0; i < strTableLength; i++) {
                data.addString(in.readUTF());
            }

            data.deserializeInterceptors(in);
        }
        finally {
            in.close();
        }

        return data;
    }

    /**
     * Writes an event dispatch data file.
     *
     * @param fileName Path and name of the data file to be written.
     * @param egd Event dispatch data to be written to file.
     *
     * @throws IOException For any error that prevents the data file
     * from being successfully written.
     */
    void writeDataFile(String fileName, SemanticEventData egd) throws IOException {
        DataOutputStream out = new DataOutputStream(
            new BufferedOutputStream(openOutputFile(fileName, false)));

        try {
            EventSpecification eventSpec = egd.getEventSpecification();

            String specClassName = eventSpec.getClass().getName();
            out.writeUTF(specClassName);

            eventSpec.serialize(out);

            String[] strTable = egd.getStringTable();
            int tableSize = strTable.length;

            out.writeInt(tableSize);
            for (int i = 0; i < tableSize; i++) {
                out.writeUTF(strTable[i]);
            }

            egd.serializeInterceptors(out);
        }
        finally {
            out.close();
        }
    }

    /**
     * Sets the initial configuration of the stream tokenizer used to read
     * the module description file.
     *
     * @param stok Tokenizer attached to the module description file stream.
     */
    protected static void prepareTokenizer(StreamTokenizer stok) {
        stok.resetSyntax();
        stok.eolIsSignificant(true);
        stok.whitespaceChars(0, ' ');
        stok.wordChars(33, 255);
        stok.slashSlashComments(true);
        stok.slashStarComments(true);
    }
}
