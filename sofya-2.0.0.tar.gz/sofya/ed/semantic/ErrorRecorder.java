/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

/**
 * Interface which marks an object as having error recording and reporting
 * capabilities.
 *
 * <p>Objects which need to report error conditions to a controlling
 * object, and to defer error handling by capturing and storing exceptions in
 * lieu of handling them immediately, should implement this interface. It is
 * intended primarily for use by event listeners which interact with a stateful
 * and potentially unreliable underlying object, such as a file stream.</p>
 *
 * @author Alex Kinneer
 * @version 02/04/2005
 */
public interface ErrorRecorder {
    /**
     * Reports whether the object is in an error state.
     *
     * @return <code>true</code> if an error was raised at some point
     * during the processing performed by the object.
     */
    public boolean inError();
    
    /**
     * Rethrows the originating exception if this object
     * in an error state; does nothing if in a normal state.
     *
     * @throws Exception If an error was raised at some point during the
     * processing performed by the object.
     */
    public void rethrowError() throws Exception;
    
    /**
     * Gets the exception that put the object in an error state.
     *
     * @return The first unrecoverable exception that put the object
     * in an error state.
     */
    public Exception getError();
}
