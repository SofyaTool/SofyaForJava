/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

/**
 * Interface which indicates that an object is capable of acting as a factory
 * for producing event listeners which are aware of an association with
 * a filtered event stream produced by an {@link EventFilter}.
 *
 * <p>Classes which implement this factory interface are intended to be used
 * with event filters which split a single event stream into multiple event
 * streams based on some correlation of events with particular program
 * entities, such as threads or object instances. Such filters may need to be
 * able to create new listeners on demand, since it is often the case that
 * it is not possible to know a priori how many entities will be created
 * by the program.</p>
 *
 * @author Alex Kinneer
 * @version 06/10/2005
 */
public interface ChainedEventListenerFactory {
    /**
     * Creates a new event listener to be associated with a particular
     * program entity.
     *
     * @param parent Event listener from which the newly created chained
     * listener will receive events. It is left to implementors' discretion
     * whether to permit the passing of <code>null</code>, though it is
     * generally not recommended.
     * @param streamId Unique identifier associated with the program entity,
     * or in the more generic sense, the event stream, to which this listener
     * will be attached.
     * @param streamName Name of the entity or entity type associated with
     * the stream.
     */
    public ChainedEventListener createEventListener(ChainedEventListener parent,
            long streamId, String streamName)
            throws FactoryException;
}
