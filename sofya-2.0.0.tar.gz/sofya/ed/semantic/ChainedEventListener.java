/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.semantic;

/**
 * Interface which indicates than an event listener can be made aware that
 * it is associated with a subset of the stream of events being produced
 * by the system under observation.
 *
 * <p>This interface facilitates the chaining of filters and targets
 * (listeners which are terminal points in the event processing stream).
 * In particular, it enables a listener to query recursively for information
 * about filters which precede it in the processing chain so that it
 * can report the nature of the filter chain in some meaningful way.</p>
 *
 * @author Alex Kinneer
 * @version 02/07/2005
 */
public interface ChainedEventListener extends EventListener {
    /**
     * Gets the parent of this listener in the listener chain.
     *
     * @return The event listener from which this listener receives events.
     */
    public ChainedEventListener getParent();
    
    /**
     * Gets the unique identifier associated with this event stream.
     *
     * @return An value which should uniquely identify this event stream,
     * typically derived from some characteristic of the filtering
     * criteria being applied by the parent listener.
     */
    public long getStreamID();
    
    /**
     * Gets an informational name associated with this event stream.
     *
     * @return A string which provides some description of the nature of the
     * events handled by this string.
     */
    public String getStreamName();
}
