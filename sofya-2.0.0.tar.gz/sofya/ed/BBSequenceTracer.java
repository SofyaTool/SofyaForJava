/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed;

import sofya.ed.structural.ProgramEventDispatcher;

/**
 * <p>A basic block sequence tracer records the sequence of basic blocks
 * executed by a subject program to a trace file.</p>
 *
 * @author Alex Kinneer
 * @version 03/16/2006
 */
public class BBSequenceTracer {
    private BBSequenceTracer() {
    }

    public static void main(String[] argv) {
        try {
            ProgramEventDispatcher ed =
                ProgramEventDispatcher.createBlockSequenceTracer(argv,
                    System.out, System.err, System.out);
            ed.startDispatcher();
            ed.release();
        }
        catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            printUsage();
            System.exit(1);
        }
        catch (BadParameterValueException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (ParameterValueAbsentException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (ProgramEventDispatcher.CreateException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error creating filter: " + e.getMessage());
            System.exit(1);
        }
        catch (ProgramEventDispatcher.SetupException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error during initialization: " +
                e.getMessage());
            System.exit(1);
        }
        catch (ProgramEventDispatcher.ExecException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error executing subject: " + e.getMessage());
            System.exit(1);
        }
        catch (ProgramEventDispatcher.TraceFileException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error writing trace file: " + e.getMessage());
            System.exit(1);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.err.println("Unrecoverable exception was thrown!");
            System.exit(1);
        }
    }

    /*************************************************************************
     * Prints the basic block sequence tracer usage message and exits.
     */
    private static void printUsage() {
        System.err.println("Usage:\njava sofya.ed.BBSequenceTracer [-port N] " +
            "[-cp PATH] [-i] [-tl N] [-at]\n [-trname <TraceName>] " +
            "[-o OutputFile] -<B|E|X|C> <classfileName> <arguments>");
        System.err.println("   -port <N> : Listen for subject trace " +
            "statements on port number N");
        System.err.println("   -cp <PATH> : Set CLASSPATH for subject to " +
            "PATH");
        System.err.println("   -i : Enable piping of stdin to the subject");
        System.err.println("   -tl <N> : Kill subject after N seconds");
        System.err.println("   -at : Append current trace to any existing " +
            "trace file");
        System.err.println("   -trname <TraceName> : Set trace file name " +
            "to <TraceName> (no extension)");
        System.err.println("   -o <OutputFile> : Redirect subject's " +
            "output to <OutputFile>");
        System.err.println("   -relay : Relay processed trace data to " +
            "socket (DAG builder)");
        System.err.println("   -pre <data> : Prepend <data> to trace");
        System.err.println("   -post <data> : Append <data> to trace");
        System.err.println("   -<B|E|X|C> : Any permutation of the " +
            "following : B-Basic,E-Entry,X-Exit,C-Call");
        System.exit(1);
    }
}
