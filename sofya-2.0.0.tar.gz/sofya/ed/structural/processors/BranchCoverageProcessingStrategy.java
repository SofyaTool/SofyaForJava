/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.net.Socket;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.List;

import sofya.base.SConstants;
import sofya.base.SConstants.*;
import sofya.ed.BranchCoverageListener;
import sofya.ed.CoverageListenerManager;
import sofya.ed.structural.ActiveComponent;
import sofya.ed.structural.BranchInstrumentationStrategy;
import sofya.ed.structural.BranchInstrumentationConfiguration;
import sofya.ed.structural.CoverageTrace;
import sofya.ed.structural.ControlData;
import sofya.ed.structural.TraceHandler;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;
import sofya.ed.structural.EventDispatcherConfiguration;

/**
 * <p>Processing strategy to receive branch coverage probes and
 * dispatch branch coverage events.</p>
 *
 * @author Alex Kinneer
 * @version 03/15/2006
 */
public class BranchCoverageProcessingStrategy
        extends AbstractSocketProcessingStrategy
        implements BranchInstrumentationStrategy {
    /** Configuration specifying selected branches. */
    private BranchInstrumentationConfiguration branchConfig =
            new BranchInstrumentationConfiguration();

    /** Listener manager that serves the listeners to which the coverage
        events will be dispatched. */
    private CoverageListenerManager listenerManager;

    /** Conditional compilation flag to enable debug outputs. */
    private static final boolean DEBUG = false;

    /**
     * Creates a new instance of the processing strategy with a trace
     * handler as the default coverage listener manager.
     */
    public BranchCoverageProcessingStrategy() {
        super();
        this.listenerManager = new TraceHandler();
    }

    /**
     * Creates a new instance of the processing strategy.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public BranchCoverageProcessingStrategy(CoverageListenerManager clm) {
        super();
        setCoverageListenerManager(clm);
    }

    /**
     * Gets the coverage listener manager to be used.
     *
     * @return The coverage listener manager being used used to retrieve
     * coverage listeners to which events will be dispatched.
     */
    public CoverageListenerManager getCoverageListenerManager() {
        return listenerManager;
    }

    /**
     * Sets the coverage listener manager to be used.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public void setCoverageListenerManager(CoverageListenerManager clm) {
        this.listenerManager = clm;
    }

    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        branchConfig.register(edConfig);

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).register(edConfig);
        }
    }

    public List configure(List params) {
        params = super.configure(params);

        params = branchConfig.configure(params);

        if (listenerManager instanceof ActiveComponent) {
            return ((ActiveComponent) listenerManager).configure(params);
        }
        else {
            return params;
        }
    }

    public void reset() {
        super.reset();

        branchConfig.reset();

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).reset();
        }
    }

    public boolean isReady() {
        boolean ready = branchConfig.isReady();

        if (listenerManager == null) {
            return ready;
        }
        else {
            if (listenerManager instanceof ActiveComponent) {
                return ((ActiveComponent) listenerManager).isReady() && ready;
            }
            else {
                return ready;
            }
        }
    }

    public void release() {
        super.release();

        branchConfig.release();

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).release();
        }
    }

    public void dispatcherStarting() {
        listenerManager.newEventStream(0);
    }

    public void dispatcherStopped() {
        listenerManager.commitCoverageResults(0);
    }

    public void doHandshake(Socket sbjSocket)
            throws IOException, ExecException {
        DataInputStream in = new DataInputStream(sbjSocket.getInputStream());
        DataOutputStream out =
            new DataOutputStream(sbjSocket.getOutputStream());

        // Check if the trace objects are branch edges
        TraceObjectType objType = TraceObjectType.fromInt(in.readInt());
        if (objType != TraceObjectType.BRANCH_EDGE) {
            out.writeInt(1);  // Error code
            out.flush();
            throw new ExecException("Subject is not instrumented for branch " +
                "tracing");
        }
        // Success code
        out.writeInt(0);
        out.flush();

        // Check if the declared type of instrumentation is one we can handle.
        // Coverage filters can handle all types except JUnit - some will just
        // be slower than others.
        instMode = in.readInt();
        if ((instMode < 1) || (instMode == 3) || (instMode > 4)) {
            out.writeInt(1);  // Error code
            out.flush();
            if (instMode == SConstants.INST_OLD_UNSUPPORTED) {
                throw new ExecException("Subject instrumentation is of old " +
                    "form that is no longer supported");
            }
            else {
                throw new ExecException("Cannot process type of " +
                    "instrumentation present in subject!");
            }
        }
        // Success code
        out.writeInt(0);
        out.flush();

        // Nonetheless, print a warning for optimized sequence filter
        // instrumentation
        if (instMode == SConstants.INST_OPT_SEQUENCE) {
            stdout.println("INFO: Subject is instrumented for sequence " +
                           "tracing. Running it through");
            stdout.println("this filter will be inefficient (and will not " +
                 "provide sequence");
            stdout.println("information)");
        }
    }

    public void processProbes(Socket sbjSocket, ControlData cntrl) {
        // Local copies for efficiency
        boolean ifBranchesOn = branchConfig.areIfBranchesActive();
        boolean switchBranchesOn = branchConfig.areSwitchBranchesActive();
        boolean throwsBranchesOn = branchConfig.areThrowsBranchesActive();
        boolean callBranchesOn = branchConfig.areCallBranchesActive();
        boolean entryBranchesOn = branchConfig.areEntryBranchesActive();
        boolean summaryBranchesOn = branchConfig.areSummaryBranchesActive();

        DataInputStream connectionIn = null;
        int maxBranchId, branchID;

        int threadID = cntrl.getThreadID();
        boolean[] threadConnected = cntrl.getConnectionFlags();
        boolean[] forceStop = cntrl.getStopFlags();

        try {
            connectionIn = new DataInputStream(
                new BufferedInputStream(sbjSocket.getInputStream()));
            threadConnected[threadID] = true;
        }
        catch (IOException e) {
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            throw new ExecException("Error accepting instrumentation " +
                                    "connection!", e);
        }

        byte[] buffer = new byte[1024];
        try {
            while (!forceStop[threadID]) {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message
                    parseMethodSignature(connectionIn, buffer);
                    maxBranchId = connectionIn.readInt();

                    listenerManager.initializeBranchListener(classAndSig,
                            maxBranchId);

                    continue;
                }

                // Check timestamp flag
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }

                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);

                // Now read and mark each block
                int dataLength = connectionIn.readInt();  // Number of edges
                for (int i = 0; i < dataLength; i++) {
                    branchID = connectionIn.readInt();
                    int edgeType = branchID >>> 26;
                    branchID &= 0x03FFFFFF;

                    BranchCoverageListener listener =
                        listenerManager.getBranchCoverageListener(classAndSig);

                    switch (edgeType) {
                    case BranchType.IIF:
                        if (ifBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.ISWITCH:
                        if (switchBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.ITHROW:
                        if (throwsBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.ICALL:
                        if (callBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.IENTRY:
                        if (entryBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.IOTHER:
                        if (summaryBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    default:
                        stderr.println("Invalid branch type code received " +
                            "from instrumented\nclass: " + edgeType);
                        break;
                    }
                }
            }

            // For non-preemptive JVMs
            if (!PREEMPTIVE) {
                Thread.currentThread().yield();
            }
        }
        catch (EOFException e) {
            // Intentionally ignored
        }
        catch (Exception e) {
            throw new ExecException("Processing exception", e);
        }
        finally {
            if (DEBUG) stdout.println("Filter loop exited");

            try {
                connectionIn.close();
            }
            catch (IOException e) {}

            threadConnected[threadID] = false;
        }
    }

    public void processProbesSynchronized(Socket sbjSocket, ControlData cntrl) {
        // Local copies for efficiency
        boolean ifBranchesOn = branchConfig.areIfBranchesActive();
        boolean switchBranchesOn = branchConfig.areSwitchBranchesActive();
        boolean throwsBranchesOn = branchConfig.areThrowsBranchesActive();
        boolean callBranchesOn = branchConfig.areCallBranchesActive();
        boolean entryBranchesOn = branchConfig.areEntryBranchesActive();
        boolean summaryBranchesOn = branchConfig.areSummaryBranchesActive();

        Socket signalSocket = null;
        DataInputStream connectionIn = null;
        CoverageTrace trace = null;
        int maxBranchId, branchID;

        int threadID = cntrl.getThreadID();
        boolean[] threadConnected = cntrl.getConnectionFlags();
        boolean[] forceStop = cntrl.getStopFlags();
        Throwable[] err = cntrl.getExceptionStorage();

        try {
            connectionIn = new DataInputStream(
                new BufferedInputStream(sbjSocket.getInputStream()));
            // Connect the signal socket. We won't do anything with it, but the
            // alternative is to require the user to instrument dispatchers as
            // subjects differently when they intend to run them with
            // sequential dispatchers as opposed to the coverage dispatchers
            if (instMode == SConstants.INST_COMPATIBLE) {
                signalSocket = openSignalSocket(sbjSocket);
            }
            if (DEBUG) stdout.println(threadID + ": connected signal socket");

            // Indicate that this thread is now connected and processing.
            synchronized(ControlData.stateLock) {
                threadConnected[threadID] = true;
            }
            if (DEBUG) stdout.println(threadID + ": is connected");
        }
        catch (IOException e) {
            // This may happen if either subject dispatcher or SocketProbe was
            // instrumented but not the other. Thus it is considered part of
            // orderly shutdown.
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            throw new ExecException("Error accepting instrumentation " +
                                    "connection!", e);
        }

        byte[] buffer = new byte[1024];
        try {
            while (!forceStop[threadID] && (err[(threadID + 1) % 2] == null)) {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message
                    parseMethodSignature(connectionIn, buffer);
                    maxBranchId = connectionIn.readInt();

                    synchronized(traceLock) {
                        listenerManager.initializeBranchListener(
                            classAndSig, maxBranchId);
                    }

                    continue;
                }

                // Strip timestamp
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }

                // Read the method signature information and use it to
                // load the CFG
                parseMethodSignature(connectionIn, buffer);

                // Now read and mark each block
                int dataLength = connectionIn.readInt();  // Number of edges
                for (int i = 0; i < dataLength; i++) {
                    branchID = connectionIn.readInt();
                    int edgeType = branchID >>> 26;
                    branchID &= 0x03FFFFFF;

                    BranchCoverageListener listener =
                        listenerManager.getBranchCoverageListener(
                            classAndSig);

                    switch (edgeType) {
                    case BranchType.IIF:
                        if (ifBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.ISWITCH:
                        if (switchBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.ITHROW:
                        if (throwsBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.ICALL:
                        if (callBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.IENTRY:
                        if (entryBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    case BranchType.IOTHER:
                        if (summaryBranchesOn) {
                            listener.branchCovered(branchID, edgeType);
                        }
                        break;
                    default:
                        stderr.println("Invalid branch type code received " +
                            "from instrumented\nclass: " + edgeType);
                        break;
                    }
                }
            }

            // For non-preemptive JVMs
            if (!PREEMPTIVE) {
                Thread.currentThread().yield();
            }
        }
        catch (EOFException e) {
            if (DEBUG) System.out.println(threadID + ": end of stream");
        }
        catch (Exception e) {
            throw new ExecException("Processing exception", e);
        }
        finally {
            if (DEBUG) stdout.println(threadID + ": Filter loop exited");

            try {
                connectionIn.close();
                if (signalSocket != null) signalSocket.close();
            }
            catch (IOException e) {}

            // Set this thread's flag to indicate that it has finished
            // processing
            synchronized (ControlData.stateLock) {
                threadConnected[threadID] = false;
            }
        }
    }

    public boolean areIfBranchesActive() {
        return branchConfig.areIfBranchesActive();
    }

    public void setIfBranchesActive(boolean enable) {
        branchConfig.setIfBranchesActive(enable);
    }

    public boolean areSwitchBranchesActive() {
        return branchConfig.areSwitchBranchesActive();
    }

    public void setSwitchBranchesActive(boolean enable) {
        branchConfig.setSwitchBranchesActive(enable);
    }

    public boolean areThrowsBranchesActive() {
        return branchConfig.areThrowsBranchesActive();
    }

    public void setThrowsBranchesActive(boolean enable) {
        branchConfig.setThrowsBranchesActive(enable);
    }

    public boolean areCallBranchesActive() {
        return branchConfig.areCallBranchesActive();
    }

    public void setCallBranchesActive(boolean enable) {
        branchConfig.setCallBranchesActive(enable);
    }

    public boolean areEntryBranchesActive() {
        return branchConfig.areEntryBranchesActive();
    }

    public void setEntryBranchesActive(boolean enable) {
        branchConfig.setEntryBranchesActive(enable);
    }

    public boolean areSummaryBranchesActive() {
        return branchConfig.areSummaryBranchesActive();
    }

    public void setSummaryBranchesActive(boolean enable) {
        branchConfig.setSummaryBranchesActive(enable);
    }

    public int getTypeFlags() {
        return branchConfig.getTypeFlags();
    }
}
