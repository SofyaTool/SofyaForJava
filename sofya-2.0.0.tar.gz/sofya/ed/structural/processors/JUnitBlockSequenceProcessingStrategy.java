/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.util.List;

import sofya.base.SConstants;
import sofya.base.SConstants.*;
import sofya.base.exceptions.ConfigurationError;
import sofya.ed.BlockEventListener;
import sofya.ed.structural.ActiveComponent;
import sofya.ed.structural.EventDispatcherConfiguration;
import sofya.ed.structural.BlockInstrumentationStrategy;
import sofya.ed.structural.BlockInstrumentationConfiguration;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;

/**
 * <p>Processing strategy to receive JUnit basic block sequence probes and
 * dispatch basic block sequence events.</p>
 *
 * @author Alex Kinneer
 * @version 04/24/2006
 */
public class JUnitBlockSequenceProcessingStrategy
        extends AbstractJUnitProcessingStrategy
        implements BlockInstrumentationStrategy {
    /** Configuration specifying selected basic blocks. */
    private BlockInstrumentationConfiguration blockConfig =
            new BlockInstrumentationConfiguration();

    // Local copies for efficiency
    private boolean codeBlocksOn;
    private boolean entryBlocksOn;
    private boolean exitBlocksOn;
    private boolean callBlocksOn;
    private boolean returnBlocksOn;

    /** Registered event listeners. An array is used because events are
        dispatched to all listeners, and this tool will normally observe
        a **lot** of events. In any case, we don't expect listeners to
        be added or removed mid-run in normal use, so the overhead associated
        with managing the array manually is considered to be mitigated. */
    private BlockEventListener[] listeners = new BlockEventListener[4];
    /** Number of listeners currently registered. */
    private int listenerCount = 0;

    /**
     * Creates a new instance of the processing strategy.
     */
    public JUnitBlockSequenceProcessingStrategy() {
        super();
    }

    /**
     * Registers a listener for observable events.
     *
     * @param listener Observer that wishes to receive basic block events from
     * the event dispatcher.
     */
    public void addEventListener(BlockEventListener listener) {
        if (listenerCount == listeners.length) {
            BlockEventListener[] temp =
                    new BlockEventListener[listeners.length + 4];
            System.arraycopy(listeners, 0, temp, 0, listeners.length);
            listeners = temp;
        }
        listeners[listenerCount++] = listener;
    }

    /**
     * Unregisters a listener for observable events.
     *
     * @param listener Object that no longer wishes to receive basic block
     * events from the event dispatcher.
     */
    public void removeEventListener(BlockEventListener listener) {
        listenerCount -= 1;
        if (listeners[listenerCount] == listener) {
            return;
        }

        for (int i = listenerCount - 1; i >= 0; i--) {
            if (listeners[listenerCount] == listener) {
                System.arraycopy(listeners, i + 1, listeners, i,
                                 listeners.length - 1 - i);
                return;
            }
        }
    }

    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        blockConfig.register(edConfig);

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                ((ActiveComponent) listeners[n]).register(edConfig);
            }
        }
    }

    public List configure(List params) {
        params = super.configure(params);

        params = blockConfig.configure(params);

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                params = ((ActiveComponent) listeners[n]).configure(params);
            }
        }

        return params;
    }

    public boolean isReady() {
        if (!blockConfig.isReady()) return false;

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                if (!((ActiveComponent) listeners[n]).isReady()) {
                    return false;
                }
            }
        }

        return true;
    }

    public void release() {
        super.release();

        blockConfig.release();

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                ((ActiveComponent) listeners[n]).release();
            }
        }
    }

    public TraceObjectType getObjectType() {
        return TraceObjectType.BASIC_BLOCK;
    }

    public void setup() {
        codeBlocksOn = blockConfig.areCodeBlocksActive();
        entryBlocksOn = blockConfig.areEntryBlocksActive();
        exitBlocksOn = blockConfig.areExitBlocksActive();
        callBlocksOn = blockConfig.areCallBlocksActive();
        returnBlocksOn = false;

        for (int n = 0; n < listenerCount; n++) {
            listeners[n].initialize();
        }
    }

    public void newTest(int testNum) {
        for (int n = 0; n < listenerCount; n++) {
            listeners[n].newEventStream(testNum);
        }
    }

    public void endTest(int testNum) {
        for (int n = 0; n < listenerCount; n++) {
            listeners[n].commitEventStream(testNum);
        }
    }

    public void setMethodObjectCount(String mSig, int objCount) {
        // Sequence listeners do not require this information
    }

    public void processData(Object instArray, String mSig, int fromIndex,
                            int toIndex) {
        try {  // Trap exceptions

        switch (instMode) {
        case SConstants.INST_OPT_NORMAL:
            throw new ConfigurationError("Cannot generate sequence " +
                    "event stream from coverage instrumentation");
        case SConstants.INST_COMPATIBLE:
        case SConstants.INST_OPT_SEQUENCE:
            int[] intArray = (int[]) instArray;
            for (int i = fromIndex; i < toIndex; i++) {
                int nodeType = intArray[i] >>> 26;
                int blockID = intArray[i] & 0x03FFFFFF;

                switch (nodeType) {
                case BlockType.IBLOCK:
                    if (codeBlocksOn) {
                        for (int n = 0; n < listenerCount; n++) {
                            listeners[n].codeBlockExecuteEvent(
                                    mSig, blockID);
                        }
                    }
                    break;
                case BlockType.IENTRY:
                    if (entryBlocksOn) {
                        for (int n = 0; n < listenerCount; n++) {
                            listeners[n].entryBlockExecuteEvent(
                                    mSig, blockID);
                        }
                    }
                    break;
                case BlockType.IEXIT:
                    if (exitBlocksOn) {
                        for (int n = 0; n < listenerCount; n++) {
                            listeners[n].exitBlockExecuteEvent(
                                    mSig, blockID);
                        }
                    }
                    break;
                case BlockType.ICALL:
                    if (callBlocksOn) {
                        for (int n = 0; n < listenerCount; n++) {
                            listeners[n].callBlockExecuteEvent(
                                    mSig, blockID);
                        }
                    }
                    break;
                case BlockType.IRETURN:
                    if (returnBlocksOn) {
                        for (int n = 0; n < listenerCount; n++) {
                            listeners[n].returnBlockExecuteEvent(
                                    mSig, blockID);
                        }
                    }
                    break;
                default:
                    throw new ExecException("Invalid block type code " +
                            "received from instrumented class: " + nodeType);
                }
            }
        }

        // Catch all unexpected exceptions and store them
        }
        catch (Exception e) {
            e.printStackTrace();
            err = e;
            System.err.println("Error writing trace message");
        }
    }

    public boolean areCodeBlocksActive() {
        return blockConfig.areCodeBlocksActive();
    }

    public void setCodeBlocksActive(boolean enable) {
        blockConfig.setCodeBlocksActive(enable);
    }

    public boolean areEntryBlocksActive() {
        return blockConfig.areEntryBlocksActive();
    }

    public void setEntryBlocksActive(boolean enable) {
        blockConfig.setEntryBlocksActive(enable);
    }

    public boolean areExitBlocksActive() {
        return blockConfig.areExitBlocksActive();
    }

    public void setExitBlocksActive(boolean enable) {
        blockConfig.setExitBlocksActive(enable);
    }

    public boolean areCallBlocksActive() {
        return blockConfig.areCallBlocksActive();
    }

    public void setCallBlocksActive(boolean enable) {
        blockConfig.setCallBlocksActive(enable);
    }

    public int getTypeFlags() {
        return blockConfig.getTypeFlags();
    }
}
