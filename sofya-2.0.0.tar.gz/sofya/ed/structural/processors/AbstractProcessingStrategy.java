/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.PrintStream;

import sofya.ed.structural.EventDispatcherConfiguration;

/**
 * <p>Base class for strategies to receive and process probes for a
 * structural event dispatcher.</p>
 *
 * @author Alex Kinneer
 * @version 03/15/2006
 */
public abstract class AbstractProcessingStrategy {
    /** The instrumentation mode detected in the subject. */
    protected int instMode = -1;

    /** Stream to which filter's normal outputs should be written. */
    protected static PrintStream stdout;
    /** Stream to which filter's error outputs should be written. */
    protected static PrintStream stderr;
    /** Stream to which subject's output should be written. */
    protected static PrintStream sbjout;

    /** Conditional compilation flag to enable debug outputs. */
    private static final boolean DEBUG = false;

    protected AbstractProcessingStrategy() {
    }

    /**
     * <p>Registers this component with the event dispatcher.</p>
     *
     * @param edConfig The current configuration of system global resources
     * and settings that the component will use as appropriate.
     */
    public void register(EventDispatcherConfiguration edConfig) {
        stdout = edConfig.getStandardOutput();
        stderr = edConfig.getStandardError();
        sbjout = edConfig.getSubjectOutput();
    }
}
