/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.EOFException;
import java.util.List;

import sofya.base.SConstants;
import sofya.base.SConstants.*;
import sofya.ed.BlockCoverageListener;
import sofya.ed.CoverageListenerManager;
import sofya.ed.structural.ActiveComponent;
import sofya.ed.structural.BlockInstrumentationStrategy;
import sofya.ed.structural.BlockInstrumentationConfiguration;
import sofya.ed.structural.ControlData;
import sofya.ed.structural.TraceHandler;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;
import sofya.ed.structural.EventDispatcherConfiguration;

/**
 * <p>Processing strategy to receive basic block coverage probes and
 * dispatch basic block coverage events.</p>
 *
 * @author Alex Kinneer
 * @version 03/15/2006
 */
public class BlockCoverageProcessingStrategy
        extends AbstractSocketProcessingStrategy
        implements BlockInstrumentationStrategy {
    /** Configuration specifying selected basic blocks. */
    private BlockInstrumentationConfiguration blockConfig =
            new BlockInstrumentationConfiguration();

    /** Listener manager that serves the listeners to which the coverage
        events will be dispatched. */
    private CoverageListenerManager listenerManager;

    /** Conditional compilation flag to enable debug outputs. */
    private static final boolean DEBUG = false;

    /**
     * Creates a new instance of the processing strategy with a trace
     * handler as the default coverage listener manager.
     */
    public BlockCoverageProcessingStrategy() {
        super();
        this.listenerManager = new TraceHandler();
    }

    /**
     * Creates a new instance of the processing strategy.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public BlockCoverageProcessingStrategy(CoverageListenerManager clm) {
        super();
        setCoverageListenerManager(clm);
    }

    /**
     * Gets the coverage listener manager to be used.
     *
     * @return The coverage listener manager being used used to retrieve
     * coverage listeners to which events will be dispatched.
     */
    public CoverageListenerManager getCoverageListenerManager() {
        return listenerManager;
    }

    /**
     * Sets the coverage listener manager to be used.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public void setCoverageListenerManager(CoverageListenerManager clm) {
        this.listenerManager = clm;
    }


    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        blockConfig.register(edConfig);

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).register(edConfig);
        }
    }

    public List configure(List params) {
        params = super.configure(params);

        params = blockConfig.configure(params);

        if (listenerManager instanceof ActiveComponent) {
            return ((ActiveComponent) listenerManager).configure(params);
        }
        else {
            return params;
        }
    }

    public void reset() {
        super.reset();

        blockConfig.reset();

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).reset();
        }
    }

    public boolean isReady() {
        boolean ready = blockConfig.isReady();

        if (listenerManager == null) {
            return ready;
        }
        else {
            if (listenerManager instanceof ActiveComponent) {
                return ((ActiveComponent) listenerManager).isReady() && ready;
            }
            else {
                return ready;
            }
        }
    }

    public void release() {
        super.release();

        blockConfig.release();

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).release();
        }
    }

    public void dispatcherStarting() {
        listenerManager.newEventStream(0);
    }

    public void dispatcherStopped() {
        listenerManager.commitCoverageResults(0);
    }

    public void doHandshake(Socket sbjSocket)
            throws IOException, ExecException {
        DataInputStream in = new DataInputStream(sbjSocket.getInputStream());
        DataOutputStream out =
            new DataOutputStream(sbjSocket.getOutputStream());

        // Check if the trace objects are basic blocks
        TraceObjectType objectType = TraceObjectType.fromInt(in.readInt());
        if (objectType != TraceObjectType.BASIC_BLOCK) {
            out.writeInt(1);  // Error code
            out.flush();
            throw new ExecException("Subject is not instrumented for basic " +
                "block tracing");
        }
        // Success code
        out.writeInt(0);
        out.flush();

        // Check if the declared type of instrumentation is one we can handle.
        // Coverage filters can handle all types except JUnit - some will just
        // be slower than others.
        instMode = in.readInt();
        if ((instMode < 1) || (instMode == 3) || (instMode > 4)) {
            out.writeInt(1);  // Error code
            out.flush();
            if (instMode == SConstants.INST_OLD_UNSUPPORTED) {
                throw new ExecException("Subject instrumentation is of old " +
                    "form that is no longer supported");
            }
            else {
                throw new ExecException("Cannot process type of " +
                    "instrumentation present in subject!");
            }
        }
        // Success code
        out.writeInt(0);
        out.flush();

        // Nonetheless, print a warning for optimized sequence filter
        // instrumentation
        if (instMode == SConstants.INST_OPT_SEQUENCE) {
            stdout.println("INFO: Subject is instrumented for sequence " +
                "tracing. Running it through");
            stdout.println("this filter will be inefficient (and " +
                "will not provide sequence");
            stdout.println("information)");
        }
    }

    public void processProbes(Socket sbjSocket, ControlData cntrl) {
        // Local copies for efficiency
        boolean codeBlocksOn = blockConfig.areCodeBlocksActive();
        boolean entryBlocksOn = blockConfig.areEntryBlocksActive();
        boolean exitBlocksOn = blockConfig.areExitBlocksActive();
        boolean callBlocksOn = blockConfig.areCallBlocksActive();
        boolean returnBlocksOn = false;

        DataInputStream connectionIn = null;
        int maxBlockId, blockID;

        int threadID = cntrl.getThreadID();
        boolean[] threadConnected = cntrl.getConnectionFlags();
        boolean[] forceStop = cntrl.getStopFlags();

        try {
            connectionIn = new DataInputStream(new BufferedInputStream(
                sbjSocket.getInputStream()));
            threadConnected[threadID] = true;
        }
        catch (IOException e) {
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            throw new ExecException("Error accepting instrumentation " +
                                    "connection!", e);
        }

        byte[] buffer = new byte[1024];
        try {
            while (!forceStop[threadID]) {
                // Check message code
                if (connectionIn.readByte() == 2) {

                    // This is the trace creation message
                    parseMethodSignature(connectionIn, buffer);
                    maxBlockId = connectionIn.readInt();

                    listenerManager.initializeBlockListener(classAndSig,
                            maxBlockId);

                    continue;
                }

                // Check timestamp flag
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }

                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);

                // Now read and mark each block

                // Number of blocks to be processed
                int dataLength = connectionIn.readInt();
                for (int i = 0; i < dataLength; i++) {
                    blockID = connectionIn.readInt();
                    int nodeType = blockID >>> 26;
                    blockID &= 0x03FFFFFF;

                    BlockCoverageListener listener =
                        listenerManager.getBlockCoverageListener(classAndSig);

                    switch (nodeType) {
                    case BlockType.IBLOCK:
                        if (codeBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.IENTRY:
                        if (entryBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.IEXIT:
                        if (exitBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.ICALL:
                        if (callBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.IRETURN:
                        if (returnBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    default:
                        stderr.println("Invalid block type code received " +
                            "from instrumented\nclass: " + nodeType);
                        break;
                    }
                }
            }

            // For non-preemptive JVMs
            if (!PREEMPTIVE) {
                Thread.currentThread().yield();
            }
        }
        catch (EOFException e) {
            // Intentionally ignored
        }
        catch (Exception e) {
            throw new ExecException("Processing exception", e);
        }
        finally {
            if (DEBUG) stdout.println("Filter loop exited");

            try {
                connectionIn.close();
            }
            catch (IOException e) {}

            threadConnected[threadID] = false;
        }
    }

    public void processProbesSynchronized(Socket sbjSocket, ControlData cntrl) {
        // Local copies for efficiency
        boolean codeBlocksOn = blockConfig.areCodeBlocksActive();
        boolean entryBlocksOn = blockConfig.areEntryBlocksActive();
        boolean exitBlocksOn = blockConfig.areExitBlocksActive();
        boolean callBlocksOn = blockConfig.areCallBlocksActive();
        boolean returnBlocksOn = false;

        Socket signalSocket = null;
        DataInputStream connectionIn = null;
        int maxBlockId, blockID;

        int threadID = cntrl.getThreadID();
        boolean[] threadConnected = cntrl.getConnectionFlags();
        boolean[] forceStop = cntrl.getStopFlags();

        try {
            connectionIn = new DataInputStream(new BufferedInputStream(
                sbjSocket.getInputStream()));
            // Connect the signal socket. We won't do anything with it, but the
            // alternative is to require the user to instrument Filter as a
            // subject differently when they intend to run it with
            // SequenceFilter as opposed to the regular Filter
            if (instMode == SConstants.INST_COMPATIBLE) signalSocket =
                openSignalSocket(sbjSocket);
            if (DEBUG) {
                stdout.println(threadID + ": connected signal socket");
            }
            // Indicate that this thread is now connected and processing.
            synchronized(ControlData.stateLock) {
                threadConnected[threadID] = true;
            }
            if (DEBUG) stdout.println(threadID + ": is connected");
        }
        catch (IOException e) {
            // This may happen if either the subject dispatcher or SocketProbe
            // was instrumented but not the other. Thus it is considered part of
            // orderly shutdown.
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            throw new ExecException("Error accepting instrumentation " +
                                    "connection!", e);
        }

        byte[] buffer = new byte[1024];
        try {
            while (!forceStop[threadID]) {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message
                    parseMethodSignature(connectionIn, buffer);
                    maxBlockId = connectionIn.readInt();

                    synchronized(traceLock) {
                      listenerManager.initializeBlockListener(classAndSig,
                            maxBlockId);
                    }

                    continue;
                }

                // Strip timestamp
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }

                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);
                if (DEBUG) {
                    stdout.println(threadID + ": " + classAndSig);
                }

                // Now read and mark each block

                // Number of blocks to be processed
                int dataLength = connectionIn.readInt();
                for (int i = 0; i < dataLength; i++) {
                    blockID = connectionIn.readInt();
                    int nodeType = blockID >>> 26;
                    blockID &= 0x03FFFFFF;

                    BlockCoverageListener listener =
                        listenerManager.getBlockCoverageListener(classAndSig);


                    switch (nodeType) {
                    case BlockType.IBLOCK:
                        if (codeBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.IENTRY:
                        if (entryBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.IEXIT:
                        if (exitBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.ICALL:
                        if (callBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    case BlockType.IRETURN:
                        if (returnBlocksOn) {
                            listener.blockCovered(blockID, nodeType);
                        }
                        break;
                    default:
                        stderr.println("Invalid block type code received " +
                            "from instrumented\nclass: " + nodeType);
                        break;
                    }
                }
            }

            // For non-preemptive JVMs
            if (!PREEMPTIVE) {
                Thread.currentThread().yield();
            }
        }
        catch (EOFException e) {
            if (DEBUG) System.out.println(threadID + ": end of stream");
        }
        catch (Exception e) {
            throw new ExecException("Processing exception", e);
        }
        finally {
            if (DEBUG) stdout.println(threadID + ": Filter loop exited");

            try {
                connectionIn.close();
                if (signalSocket != null) signalSocket.close();
            }
            catch (IOException e) {}

            // Set this thread's flag to indicate that it has finished
            // processing
            synchronized (ControlData.stateLock) {
                threadConnected[threadID] = false;
            }
        }
    }

    public boolean areCodeBlocksActive() {
        return blockConfig.areCodeBlocksActive();
    }

    public void setCodeBlocksActive(boolean enable) {
        blockConfig.setCodeBlocksActive(enable);
    }

    public boolean areEntryBlocksActive() {
        return blockConfig.areEntryBlocksActive();
    }

    public void setEntryBlocksActive(boolean enable) {
        blockConfig.setEntryBlocksActive(enable);
    }

    public boolean areExitBlocksActive() {
        return blockConfig.areExitBlocksActive();
    }

    public void setExitBlocksActive(boolean enable) {
        blockConfig.setExitBlocksActive(enable);
    }

    public boolean areCallBlocksActive() {
        return blockConfig.areCallBlocksActive();
    }

    public void setCallBlocksActive(boolean enable) {
        blockConfig.setCallBlocksActive(enable);
    }

    public int getTypeFlags() {
        return blockConfig.getTypeFlags();
    }
}
