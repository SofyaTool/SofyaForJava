/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.net.Socket;
import java.net.SocketException;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.StreamTokenizer;
import java.io.IOException;
import java.io.EOFException;
import java.util.List;

import sofya.base.SConstants;
import sofya.base.SConstants.*;
import sofya.ed.BlockEventListener;
import sofya.ed.structural.ActiveComponent;
import sofya.ed.structural.ControlData;
import sofya.ed.structural.BlockInstrumentationStrategy;
import sofya.ed.structural.BlockInstrumentationConfiguration;
import sofya.ed.structural.EventDispatcherConfiguration;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;

/**
 * <p>Processing strategy to receive basic block sequence probes and
 * dispatch basic block sequence events.</p>
 *
 * @author Alex Kinneer
 * @version 03/15/2006
 */
public class BlockSequenceProcessingStrategy
        extends AbstractSocketProcessingStrategy
        implements BlockInstrumentationStrategy {
    /** Configuration specifying selected basic blocks. */
    private BlockInstrumentationConfiguration blockConfig =
            new BlockInstrumentationConfiguration();

    /** Last timestamp that forced a synchronization, used when the subject
        is an event dispatcher. */
    protected static volatile long pendingTimeStamp = 0;
    /** Synchronizes access to <code>pendingTimeStamp</code> and controls
        notifications between threads. */
    protected static Object timeLock = new Object();

    /** Registered event listeners. An array is used because events are
        dispatched to all listeners, and this tool will normally observe
        a **lot** of events. In any case, we don't expect listeners to
        be added or removed mid-run in normal use, so the overhead associated
        with managing the array manually is considered to be mitigated. */
    private BlockEventListener[] listeners = new BlockEventListener[4];
    /** Number of listeners currently registered. */
    private int listenerCount = 0;

    /** Conditional compilation flag to enable debug outputs. */
    private static final boolean DEBUG = false;

    /**
     * Creates a new instance of the processing strategy.
     */
    public BlockSequenceProcessingStrategy() {
        super();
    }

    /**
     * Registers a listener for observable events.
     *
     * @param listener Observer that wishes to receive basic block events from
     * the event dispatcher.
     */
    public void addEventListener(BlockEventListener listener) {
        if (listenerCount == listeners.length) {
            BlockEventListener[] temp =
                    new BlockEventListener[listeners.length + 4];
            System.arraycopy(listeners, 0, temp, 0, listeners.length);
            listeners = temp;
        }
        listeners[listenerCount++] = listener;
    }

    /**
     * Unregisters a listener for observable events.
     *
     * @param listener Object that no longer wishes to receive basic block
     * events from the event dispatcher.
     */
    public void removeEventListener(BlockEventListener listener) {
        listenerCount -= 1;
        if (listeners[listenerCount] == listener) {
            return;
        }

        for (int i = listenerCount - 1; i >= 0; i--) {
            if (listeners[listenerCount] == listener) {
                System.arraycopy(listeners, i + 1, listeners, i,
                                 listeners.length - 1 - i);
                return;
            }
        }
    }

    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        blockConfig.register(edConfig);

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                ((ActiveComponent) listeners[n]).register(edConfig);
            }
        }
    }

    public List configure(List params) {
        params = super.configure(params);

        params = blockConfig.configure(params);

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                params = ((ActiveComponent) listeners[n]).configure(params);
            }
        }

        return params;
    }

    public void reset() {
        super.reset();

        this.pendingTimeStamp = 0;
        blockConfig.release();

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                ((ActiveComponent) listeners[n]).reset();
            }
        }
    }

    public boolean isReady() {
        if (!blockConfig.isReady()) return false;

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                if (!((ActiveComponent) listeners[n]).isReady()) {
                    return false;
                }
            }
        }

        return true;
    }

    public void release() {
        super.release();

        this.pendingTimeStamp = 0;
        blockConfig.release();

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                ((ActiveComponent) listeners[n]).release();
            }
        }
    }

    public void dispatcherStarting() {
        for (int n = 0; n < listenerCount; n++) {
            listeners[n].newEventStream(0);
        }
    }

    public void dispatcherStopped() {
        for (int n = 0; n < listenerCount; n++) {
            listeners[n].commitEventStream(0);
        }
    }

    public void doHandshake(Socket sbjSocket)
            throws IOException, ExecException {
        DataInputStream in = new DataInputStream(sbjSocket.getInputStream());
        DataOutputStream out =
            new DataOutputStream(sbjSocket.getOutputStream());

        // Check if the trace objects are basic blocks
        TraceObjectType objType = TraceObjectType.fromInt(in.readInt());
        if (objType != TraceObjectType.BASIC_BLOCK) {
            out.writeInt(1);  // Error code
            out.flush();
            throw new ExecException("Subject is not instrumented for basic " +
                "block tracing");
        }
        // Success code
        out.writeInt(0);
        out.flush();

        // Check if the declared type of instrumentation is one we can handle
        instMode = in.readInt();
        switch (instMode) {
        case SConstants.INST_COMPATIBLE:

            // Compatible-mode instrumentation is always okay
            out.writeInt(0);
            out.flush();
            break;
        case SConstants.INST_OPT_NORMAL:

            // Regular-mode-optimized is never okay
            out.writeInt(1); // Error code
            out.flush();
            throw new ExecException("Subject is not instrumented for " +
                                    "sequence traces!");
        case SConstants.INST_OPT_SEQUENCE:
            if (isSbjDispatcher) {
                // Optimized-sequence-mode instrumentation will not work
                // on self-as-subject
                out.writeInt(1);
                out.flush();
                throw new ExecException("Cannot use optimized sequence " +
                                        "filter instrumentation when the subject is another " +
                                        "filter!");
            }
            else {
                // Other subjects are fine
                out.writeInt(0);
                out.flush();
            }
            break;
        case SConstants.INST_OLD_UNSUPPORTED:
            out.writeInt(1); // Error code
            out.flush();
            throw new ExecException("Subject instrumentation is of old " +
                                    "form that is no longer supported");
        default:

            // Don't know what kind of instrumentation it is
            out.writeInt(1);
            out.flush();
            throw new ExecException("Subject is not instrumented for " +
                                    "sequence traces!");
        }
    }

    public void processProbes(Socket sbjSocket, ControlData cntrl) {
        // Local copies for efficiency
        boolean codeBlocksOn = blockConfig.areCodeBlocksActive();
        boolean entryBlocksOn = blockConfig.areEntryBlocksActive();
        boolean exitBlocksOn = blockConfig.areExitBlocksActive();
        boolean callBlocksOn = blockConfig.areCallBlocksActive();
        boolean returnBlocksOn = false;

        DataInputStream connectionIn = null;
        StreamTokenizer stok = null;
        int maxBlockId, blockID;

        int threadID = cntrl.getThreadID();
        boolean[] threadConnected = cntrl.getConnectionFlags();
        boolean[] forceStop = cntrl.getStopFlags();

        try {
            connectionIn = new DataInputStream(
                new BufferedInputStream(sbjSocket.getInputStream()));
            threadConnected[threadID] = true;
        }
        catch (IOException e) {
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            throw new ExecException("Error accepting instrumentation " +
                                    "connection!", e);
        }

        byte[] buffer = new byte[1024];
        try {
            while (!forceStop[threadID]) {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message. Sequence filter
                    // just consumes it since it doesn't need to know
                    // the block count for the method
                    parseMethodSignature(connectionIn, buffer);
                    maxBlockId = connectionIn.readInt();
                    if (DEBUG) {
                        stdout.println("Received create trace " +
                            "message for: " + classAndSig);
                    }
                    continue;
                }

                // Check timestamp flag
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }

                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);
                if (DEBUG) {
                    stdout.println("Received signature: " +
                        classAndSig);
                }

                // Now read and mark each block
                int dataLength = connectionIn.readInt();  // Number of blocks
                for (int i = 0; i < dataLength; i++) {
                    blockID = connectionIn.readInt();
                    int nodeType = blockID >>> 26;
                    blockID &= 0x03FFFFFF;

                    switch (nodeType) {
                    case BlockType.IBLOCK:
                        if (codeBlocksOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].codeBlockExecuteEvent(
                                        classAndSig, blockID);
                            }
                        }
                        break;
                    case BlockType.IENTRY:
                        if (entryBlocksOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].entryBlockExecuteEvent(
                                        classAndSig, blockID);
                            }
                        }
                        break;
                    case BlockType.IEXIT:
                        if (exitBlocksOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].exitBlockExecuteEvent(
                                        classAndSig, blockID);
                            }
                        }
                        break;
                    case BlockType.ICALL:
                        if (callBlocksOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].callBlockExecuteEvent(
                                        classAndSig, blockID);
                            }
                        }
                        break;
                    case BlockType.IRETURN:
                        if (returnBlocksOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].returnBlockExecuteEvent(
                                        classAndSig, blockID);
                            }
                        }
                        break;
                    default:
                        stderr.println("Invalid block type code received " +
                            "from instrumented\nclass: " + nodeType);
                        break;
                    }
                }
            }

            // For non-preemptive JVMs
            if (!PREEMPTIVE) {
                Thread.currentThread().yield();
            }
        }
        catch (EOFException e) {
            // Intentionally ignored
        }
        catch (Exception e) {
            throw new ExecException("Processing exception", e);
        }
        finally {
            if (DEBUG) stdout.println("Filter loop exited");

            try {
                connectionIn.close();
            }
            catch (IOException e) {}

            threadConnected[threadID] = false;
        }
    }

    public void processProbesSynchronized(Socket sbjSocket, ControlData cntrl) {
        // Local copies for efficiency
        boolean codeBlocksOn = blockConfig.areCodeBlocksActive();
        boolean entryBlocksOn = blockConfig.areEntryBlocksActive();
        boolean exitBlocksOn = blockConfig.areExitBlocksActive();
        boolean callBlocksOn = blockConfig.areCallBlocksActive();
        boolean returnBlocksOn = false;

        Socket signalSocket = null;
        DataInputStream connectionIn = null;
        DataInputStream signalIn = null;
        DataOutputStream signalOut = null;
        long timeStamp = 0;
        int maxBlockId, blockID;

        int threadID = cntrl.getThreadID();
        boolean[] threadConnected = cntrl.getConnectionFlags();
        boolean[] forceStop = cntrl.getStopFlags();
        Throwable[] err = cntrl.getExceptionStorage();

        try {
            connectionIn = new DataInputStream(
                new BufferedInputStream(sbjSocket.getInputStream()));
            // Connect the signal socket
            if (instMode == SConstants.INST_COMPATIBLE) {
                signalSocket = openSignalSocket(sbjSocket);
                signalIn = new DataInputStream(signalSocket.getInputStream());
                signalOut =
                    new DataOutputStream(signalSocket.getOutputStream());
            }
            // Indicate that this thread is now connected and processing.
            synchronized(ControlData.stateLock) {
                threadConnected[threadID] = true;
            }
        }
        catch (IOException e) {
            // This may happen if either the subject dispatcher or SocketProbe
            // was instrumented but not the other. Thus it is considered part of
            // orderly shutdown.
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            throw new ExecException("Error accepting instrumentation " +
                                    "connection!", e);
        }

        byte[] buffer = new byte[1024];
        try {
            runLoop:
            while (!forceStop[threadID] && (err[(threadID + 1) % 2] == null)) {
                // If we're about to block reading, notify the other thread so
                // it can continue processing (its trace message must be oldest
                // at this point).
                synchronized(timeLock) {
                    if (!(connectionIn.available() > 0)
                            && threadConnected[(threadID + 1) % 2]) {
                        try {
                            // Force a synchronization with the subject. By
                            // requiring a response, we ensure that  any old
                            // messages still waiting from being blocked when
                            // the socket buffer became full will be written
                            // before we decide whether to grant the the other
                            // thread permission to begin processing.
                            signalOut.writeInt(SConstants.SIG_ECHO);
                            signalOut.flush();
                            signalIn.readInt();
                        }
                        catch (IOException e) {
                            // If this fails, socket has been closed on other
                            // end
                            break runLoop;
                        }
                    }
                    // Continue to check for new messages until we are signaled
                    // to stop, the subject terminates (closes the socket), or
                    // the other thread finishes processing (at which point this
                    // thread continues to run as if it were a regular
                    // unsynchronized processing thread).
                    while (!(connectionIn.available() > 0)
                            && threadConnected[(threadID + 1) % 2]) {
                        if (forceStop[threadID]) break runLoop;
                        // Since ready() returns false both when there is no
                        // data to be read and when the socket is closed, the
                        // only way to determine whether the subject has
                        // terminated is to actually attempt to write something
                        // to its control socket. If the subject is still
                        // alive, its SocketProbe simply consumes this signal.
                        try {
                            signalOut.writeInt(SConstants.SIG_CHKALIVE);
                            signalOut.flush();
                        }
                        catch (IOException e) {
                            break runLoop;
                        }
                        // Everything in the other thread's queue must be older
                        // than whatever will come here next, so let it process
                        // them as a block before checking again.
                        pendingTimeStamp = System.currentTimeMillis();
                        timeLock.notify();
                        timeLock.wait();
                    }
                }

                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message. Sequence filter
                    // just consumes it since it doesn't need to know
                    // the block count for the method
                    parseMethodSignature(connectionIn, buffer);
                    maxBlockId = connectionIn.readInt();
                }

                // Read timestamp, we may block here
                if (connectionIn.readByte() == 1) {
                    timeStamp = connectionIn.readLong();
                }
                else {
                    throw new ExecException("Malformed trace " +
                        "message: timestamp was not provided");
                }

                // Now check the timestamp against the last one the other thread
                // blocked on. If ours is larger (the trace message is more
                // recent), sleep and allow the other thread to process and
                // register its message. Otherwise, continue processing trace
                // messages until we get one that is younger than the one
                // currently held by the other thread. This check is not
                // performed at all if the other thread is determined to be
                // unconnected.
                synchronized(timeLock) {
                    if ((timeStamp >= pendingTimeStamp)
                            && threadConnected[(threadID + 1) % 2]) {
                        pendingTimeStamp = timeStamp;
                        try {
                            timeLock.notify();
                            timeLock.wait();
                        }
                        catch (InterruptedException e) {
                            throw new ExecException(
                                "Sequence processing thread " + threadID +
                                "was interrupted!");
                        }
                    }
                    if (DEBUG) {
                        stdout.println("Thread " + threadID +
                            " processing message, timestamp: " + timeStamp);
                    }
                }

                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);

                // Now mark the block
                int dataLength = connectionIn.readInt();  // Number of blocks
                if (dataLength > 0) {
                    synchronized(traceLock) {
                        blockID = connectionIn.readInt();
                        int nodeType = blockID >>> 26;
                        blockID &= 0x03FFFFFF;

                        switch (nodeType) {
                        case BlockType.IBLOCK:
                            if (codeBlocksOn) {
                                for (int n = 0; n < listenerCount; n++) {
                                    listeners[n].codeBlockExecuteEvent(
                                            classAndSig, blockID);
                                }
                            }
                            break;
                        case BlockType.IENTRY:
                            if (entryBlocksOn) {
                                for (int n = 0; n < listenerCount; n++) {
                                    listeners[n].entryBlockExecuteEvent(
                                            classAndSig, blockID);
                                }
                            }
                            break;
                        case BlockType.IEXIT:
                            if (exitBlocksOn) {
                                for (int n = 0; n < listenerCount; n++) {
                                    listeners[n].exitBlockExecuteEvent(
                                            classAndSig, blockID);
                                }
                            }
                            break;
                        case BlockType.ICALL:
                            if (callBlocksOn) {
                                for (int n = 0; n < listenerCount; n++) {
                                    listeners[n].callBlockExecuteEvent(
                                            classAndSig, blockID);
                                }
                            }
                            break;
                        case BlockType.IRETURN:
                            if (returnBlocksOn) {
                                for (int n = 0; n < listenerCount; n++) {
                                    listeners[n].returnBlockExecuteEvent(
                                            classAndSig, blockID);
                                }
                            }
                            break;
                        default:
                            stderr.println("Invalid block type code received " +
                                "from instrumented\nclass: " + nodeType);
                            break;
                        }

                        if (dataLength > 1) {
                            stderr.println("WARNING: Multiple block " +
                                "IDs encoded in trace message, only the " +
                                "first will be recorded");
                            // Now eat the rest (so the input stream is still
                            // in synch)
                            for (int i = 0; i < dataLength - 1; i++) {
                                connectionIn.readInt();
                            }
                        }
                    }
                }
                else {
                    stderr.println("WARNING: No block ID encoded in " +
                        "trace message");
                }
            }

            // For non-preemptive JVMs
            if (!PREEMPTIVE) {
                Thread.currentThread().yield();
            }
        }
        catch (EOFException e) {
            // Intentionally ignored
        }
        catch (SocketException e) {
            if (!e.getMessage().toLowerCase()
                    .startsWith("connection reset")) {
                throw new ExecException(
                        "Processing exception (socket error)", e);
            }
        }
        catch (InterruptedException e) {
            throw new ExecException("Unrecoverable " +
                "interrupt received by thread " + threadID);
        }
        catch (Exception e) {
            throw new ExecException("Processing exception", e);
        }
        finally {
            if (DEBUG) stdout.println("Filter loop exited");

            try {
                signalOut.close();
                signalIn.close();
                signalSocket.close();
                connectionIn.close();
            }
            catch (IOException e) {}

            // Set this thread's flag to indicate that it has finished
            // processing and retrieve the flag containing the other thread's
            // state.
            boolean otherConnected;
            synchronized (ControlData.stateLock) {
                threadConnected[threadID] = false;
                otherConnected = threadConnected[(threadID + 1) % 2];
            }

            // If the other thread is still connected, notify it to continue
            // processing. With this thread's connected flag set to false, the
            // other thread will continue to process until completion without
            // blocking. If the other thread is not still connected, we are
            // completely finished, so stop the server socket.
            if (otherConnected) {
                if (DEBUG) stdout.println(threadID + " notifying");
                synchronized (timeLock) {
                    timeLock.notify();
                }
            }
            else {
                if (DEBUG) stdout.println(threadID + " shutting down");
            }
        }
    }

    public boolean areCodeBlocksActive() {
        return blockConfig.areCodeBlocksActive();
    }

    public void setCodeBlocksActive(boolean enable) {
        blockConfig.setCodeBlocksActive(enable);
    }

    public boolean areEntryBlocksActive() {
        return blockConfig.areEntryBlocksActive();
    }

    public void setEntryBlocksActive(boolean enable) {
        blockConfig.setEntryBlocksActive(enable);
    }

    public boolean areExitBlocksActive() {
        return blockConfig.areExitBlocksActive();
    }

    public void setExitBlocksActive(boolean enable) {
        blockConfig.setExitBlocksActive(enable);
    }

    public boolean areCallBlocksActive() {
        return blockConfig.areCallBlocksActive();
    }

    public void setCallBlocksActive(boolean enable) {
        blockConfig.setCallBlocksActive(enable);
    }

    public int getTypeFlags() {
        return blockConfig.getTypeFlags();
    }
}
