/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.util.List;

import sofya.ed.structural.JUnitProcessingStrategy;
import sofya.ed.structural.JUnitEventDispatcher.InstrumentationMode;

/**
 * <p>Base class for strategies to receive and process probes for a
 * JUnit event dispatcher.</p>
 *
 * @author Alex Kinneer
 * @version 04/24/2006
 */
public abstract class AbstractJUnitProcessingStrategy
        extends AbstractProcessingStrategy
        implements JUnitProcessingStrategy {
    /** Stores the exception that stopped probe processing, if any. */
    protected Exception err;

    protected AbstractJUnitProcessingStrategy() {
        super();
    }

    public List configure(List parameters) {
        return parameters;
    }

    public void reset() {
        throw new IllegalStateException("Once configured, a JUnit event " +
            "dispatcher cannot be reset");
    }

    public boolean isReady() {
        return true;
    }

    public void release() {
        instMode = -1;
        err = null;
    }

    public void setInstrumentationMode(InstrumentationMode instMode) {
        this.instMode = instMode.getValue();
    }

    public void checkError() throws Exception {
        if (err != null) throw err;
    }
}
