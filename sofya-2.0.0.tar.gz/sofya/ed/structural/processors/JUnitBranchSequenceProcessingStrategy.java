/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.util.List;

import sofya.base.SConstants;
import sofya.base.SConstants.*;
import sofya.base.exceptions.ConfigurationError;
import sofya.ed.BranchEventListener;
import sofya.ed.structural.ActiveComponent;
import sofya.ed.structural.BranchInstrumentationStrategy;
import sofya.ed.structural.BranchInstrumentationConfiguration;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;
import sofya.ed.structural.EventDispatcherConfiguration;
import sofya.ed.structural.AbstractEventDispatcher;

/**
 * <p>Processing strategy to receive JUnit branch sequence probes and
 * dispatch branch sequence events.</p>
 *
 * @author Alex Kinneer
 * @version 04/24/2006
 */
public class JUnitBranchSequenceProcessingStrategy
        extends AbstractJUnitProcessingStrategy
        implements BranchInstrumentationStrategy {
    /** Configuration specifying selected branches. */
    private BranchInstrumentationConfiguration branchConfig =
            new BranchInstrumentationConfiguration();

    // Local copies for efficiency
    private boolean ifBranchesOn;
    private boolean switchBranchesOn;
    private boolean throwsBranchesOn;
    private boolean callBranchesOn;
    private boolean entryBranchesOn;
    private boolean summaryBranchesOn;

    /** Registered event listeners. An array is used because events are
        dispatched to all listeners, and this tool will normally observe
        a **lot** of events. In any case, we don't expect listeners to
        be added or removed mid-run in normal use, so the overhead associated
        with managing the array manually is considered to be mitigated. */
    private BranchEventListener[] listeners = new BranchEventListener[4];
    /** Number of listeners currently registered. */
    private int listenerCount = 0;

    /** Conditional compilation debug flag. */
    private static final boolean DEBUG = false;

    /**
     * Creates a new instance of the processing strategy.
     */
    public JUnitBranchSequenceProcessingStrategy() {
        super();
    }

    /**
     * Registers a listener for observable events.
     *
     * @param listener Observer that wishes to receive branch events from
     * the event dispatcher.
     */
    public void addEventListener(BranchEventListener listener) {
        if (listenerCount == listeners.length) {
            BranchEventListener[] temp =
                    new BranchEventListener[listeners.length + 4];
            System.arraycopy(listeners, 0, temp, 0, listeners.length);
            listeners = temp;
        }
        listeners[listenerCount++] = listener;
    }

    /**
     * Unregisters a listener for observable events.
     *
     * @param listener Object that no longer wishes to receive branch
     * events from the event dispatcher.
     */
    public void removeEventListener(BranchEventListener listener) {
        listenerCount -= 1;
        if (listeners[listenerCount] == listener) {
            return;
        }

        for (int i = listenerCount - 1; i >= 0; i--) {
            if (listeners[listenerCount] == listener) {
                System.arraycopy(listeners, i + 1, listeners, i,
                                 listeners.length - 1 - i);
                return;
            }
        }
    }

    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        branchConfig.register(edConfig);

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                ((ActiveComponent) listeners[n]).register(edConfig);
            }
        }
    }

    public List configure(List params) {
        params = super.configure(params);

        params = branchConfig.configure(params);

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                params = ((ActiveComponent) listeners[n]).configure(params);
            }
        }

        return params;
    }

    public boolean isReady() {
        if (!branchConfig.isReady()) return false;

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                if (!((ActiveComponent) listeners[n]).isReady()) {
                    return false;
                }
            }
        }

        return true;
    }

    public void release() {
        super.release();

        branchConfig.release();

        for (int n = 0; n < listenerCount; n++) {
            if (listeners[n] instanceof ActiveComponent) {
                ((ActiveComponent) listeners[n]).release();
            }
        }
    }

    public TraceObjectType getObjectType() {
        return TraceObjectType.BRANCH_EDGE;
    }

    public void setup() {
        ifBranchesOn = branchConfig.areIfBranchesActive();
        switchBranchesOn = branchConfig.areSwitchBranchesActive();
        throwsBranchesOn = branchConfig.areThrowsBranchesActive();
        callBranchesOn = branchConfig.areCallBranchesActive();
        entryBranchesOn = branchConfig.areEntryBranchesActive();
        summaryBranchesOn = branchConfig.areSummaryBranchesActive();

        for (int n = 0; n < listenerCount; n++) {
            listeners[n].initialize();
        }
    }

    public void newTest(int testNum) {
        for (int n = 0; n < listenerCount; n++) {
            listeners[n].newEventStream(testNum);
        }
    }

    public void endTest(int testNum) {
        for (int n = 0; n < listenerCount; n++) {
            listeners[n].commitEventStream(testNum);
        }
    }

    public void setMethodObjectCount(String mSig, int objCount) {
            // Sequence listeners do not require this information
    }

    public void processData(Object instArray, String mSig, int fromIndex,
                            int toIndex) {
        try {  // Trap exceptions

            switch (instMode) {
            case SConstants.INST_OPT_NORMAL:
                throw new ConfigurationError("Cannot generate sequence " +
                        "event stream from coverage instrumentation");
            case SConstants.INST_COMPATIBLE:
            case SConstants.INST_OPT_SEQUENCE:
                int[] intArray = (int[]) instArray;

                for (int i = fromIndex; i < toIndex; i++) {
                    int branchType = intArray[i] >>> 26;
                    int branchID = intArray[i] & 0x03FFFFFF;

                    switch (branchType) {
                    case BranchType.IIF:
                        if (ifBranchesOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].ifBranchExecuteEvent(
                                        mSig, branchID);
                            }
                        }
                        break;
                    case BranchType.ISWITCH:
                        if (switchBranchesOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].switchBranchExecuteEvent(
                                        mSig, branchID);
                            }
                        }
                        break;
                    case BranchType.ITHROW:
                        if (throwsBranchesOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].throwBranchExecuteEvent(
                                        mSig, branchID);
                            }
                        }
                        break;
                    case BranchType.ICALL:
                        if (callBranchesOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].callBranchExecuteEvent(
                                        mSig, branchID);
                            }
                        }
                        break;
                    case BranchType.IENTRY:
                        if (entryBranchesOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].entryBranchExecuteEvent(
                                        mSig, branchID);
                            }
                        }
                        break;
                    case BranchType.IOTHER:
                        if (summaryBranchesOn) {
                            for (int n = 0; n < listenerCount; n++) {
                                listeners[n].otherBranchExecuteEvent(
                                        mSig, branchID);
                            }
                        }
                        break;
                    default:
                        throw new ExecException("Invalid branch type code " +
                                "received from instrumented class: " +
                                branchType);
                    }
                }
            }

        // Catch all unexpected exceptions and store them
        }
        catch (Exception e) {
            e.printStackTrace();
            err = e;
            System.err.println("Error writing trace message");
        }
    }

    public boolean areIfBranchesActive() {
        return branchConfig.areIfBranchesActive();
    }

    public void setIfBranchesActive(boolean enable) {
        branchConfig.setIfBranchesActive(enable);
    }

    public boolean areSwitchBranchesActive() {
        return branchConfig.areSwitchBranchesActive();
    }

    public void setSwitchBranchesActive(boolean enable) {
        branchConfig.setSwitchBranchesActive(enable);
    }

    public boolean areThrowsBranchesActive() {
        return branchConfig.areThrowsBranchesActive();
    }

    public void setThrowsBranchesActive(boolean enable) {
        branchConfig.setThrowsBranchesActive(enable);
    }

    public boolean areCallBranchesActive() {
        return branchConfig.areCallBranchesActive();
    }

    public void setCallBranchesActive(boolean enable) {
        branchConfig.setCallBranchesActive(enable);
    }

    public boolean areEntryBranchesActive() {
        return branchConfig.areEntryBranchesActive();
    }

    public void setEntryBranchesActive(boolean enable) {
        branchConfig.setEntryBranchesActive(enable);
    }

    public boolean areSummaryBranchesActive() {
        return branchConfig.areSummaryBranchesActive();
    }

    public void setSummaryBranchesActive(boolean enable) {
        branchConfig.setSummaryBranchesActive(enable);
    }

    public int getTypeFlags() {
        return branchConfig.getTypeFlags();
    }
}
