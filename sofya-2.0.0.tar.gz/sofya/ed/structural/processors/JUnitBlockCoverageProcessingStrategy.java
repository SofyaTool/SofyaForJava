/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural.processors;

import java.util.List;
import java.io.IOException;

import sofya.base.SConstants;
import sofya.base.SConstants.*;
import sofya.base.exceptions.ConfigurationError;
import sofya.ed.BlockCoverageListener;
import sofya.ed.CoverageListenerManager;
import sofya.ed.structural.ActiveComponent;
import sofya.ed.structural.BlockInstrumentationStrategy;
import sofya.ed.structural.BlockInstrumentationConfiguration;
import sofya.ed.structural.EventDispatcherConfiguration;
import sofya.ed.structural.TraceHandler;
import sofya.ed.structural.AbstractEventDispatcher;
import sofya.ed.structural.AbstractEventDispatcher.ExecException;

/**
 * <p>Processing strategy to receive JUnit basic block coverage probes and
 * dispatch basic block coverage events.</p>
 *
 * @author Alex Kinneer
 * @version 03/15/2006
 */
public class JUnitBlockCoverageProcessingStrategy
        extends AbstractJUnitProcessingStrategy
        implements BlockInstrumentationStrategy {
    /** Configuration specifying selected basic blocks. */
    private BlockInstrumentationConfiguration blockConfig =
            new BlockInstrumentationConfiguration();

    // Local copies for efficiency
    private boolean codeBlocksOn;
    private boolean entryBlocksOn;
    private boolean exitBlocksOn;
    private boolean callBlocksOn;
    private boolean returnBlocksOn;

    /** Listener manager that serves the listeners to which the coverage
        events will be dispatched. */
    private CoverageListenerManager listenerManager;

    /** Conditional compilation flag to enable debug outputs. */
    private static final boolean DEBUG = false;

    /**
     * Creates a new instance of the processing strategy with a trace
     * handler as the default coverage listener manager.
     */
    public JUnitBlockCoverageProcessingStrategy() {
        super();
        setCoverageListenerManager(new TraceHandler());
    }

    /**
     * Creates a new instance of the processing strategy.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public JUnitBlockCoverageProcessingStrategy(CoverageListenerManager clm) {
        super();
        setCoverageListenerManager(clm);
    }

    /**
     * Gets the coverage listener manager to be used.
     *
     * @return The coverage listener manager being used used to retrieve
     * coverage listeners to which events will be dispatched.
     */
    public CoverageListenerManager getCoverageListenerManager() {
        return listenerManager;
    }

    /**
     * Sets the coverage listener manager to be used.
     *
     * @param clm Coverage listener manager to be used to retrieve coverage
     * listeners to which events will be dispatched.
     */
    public void setCoverageListenerManager(CoverageListenerManager clm) {
        this.listenerManager = clm;
    }

    public void register(EventDispatcherConfiguration edConfig) {
        super.register(edConfig);

        blockConfig.register(edConfig);

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).register(edConfig);
        }
    }

    public List configure(List params) {
        params = super.configure(params);

        params = blockConfig.configure(params);

        if (listenerManager instanceof ActiveComponent) {
            return ((ActiveComponent) listenerManager).configure(params);
        }
        else {
            return params;
        }
    }

    public boolean isReady() {
        boolean ready = blockConfig.isReady();

        if (listenerManager == null) {
            return ready;
        }
        else {
            if (listenerManager instanceof ActiveComponent) {
                return ((ActiveComponent) listenerManager).isReady() && ready;
            }
            else {
                return ready;
            }
        }
    }

    public void release() {
        super.release();

        blockConfig.release();

        if (listenerManager instanceof ActiveComponent) {
            ((ActiveComponent) listenerManager).release();
        }
    }

    public TraceObjectType getObjectType() {
        return TraceObjectType.BASIC_BLOCK;
    }

    public void setup() {
        codeBlocksOn = blockConfig.areCodeBlocksActive();
        entryBlocksOn = blockConfig.areEntryBlocksActive();
        exitBlocksOn = blockConfig.areExitBlocksActive();
        callBlocksOn = blockConfig.areCallBlocksActive();
        returnBlocksOn = false;

        listenerManager.initialize();
   }

    public void newTest(int testNum) {
        listenerManager.newEventStream(testNum);
    }

    public void endTest(int testNum) {
        listenerManager.commitCoverageResults(testNum);
    }

    public void setMethodObjectCount(String mSig, int objCount) {
        listenerManager.initializeBlockListener(mSig, objCount);
    }

    public void processData(Object instArray, String mSig, int fromIndex,
                            int toIndex) {
        try {  // Trap exceptions

        BlockCoverageListener listener =
                    listenerManager.getBlockCoverageListener(mSig);

        switch (instMode) {
        case SConstants.INST_OPT_NORMAL:
            byte[] byteArray = (byte[]) instArray;
            for (int bId = 0; bId < byteArray.length; bId++) {
                int nodeType = byteArray[bId];

                switch (nodeType) {
                case 0:
                    // Block wasn't hit
                    continue;
                case BlockType.IBLOCK:
                    if (codeBlocksOn) {
                        listener.blockCovered(bId + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <basic> success");
                        }
                    }
                    break;
                case BlockType.IENTRY:
                    if (entryBlocksOn) {
                        listener.blockCovered(bId + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <entry> success");
                        }
                    }
                    break;
                case BlockType.IEXIT:
                    if (exitBlocksOn) {
                        listener.blockCovered(bId + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <exit> success");
                        }
                    }
                    break;
                case BlockType.ICALL:
                    if (callBlocksOn) {
                        listener.blockCovered(bId + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <call> success");
                        }
                    }
                    break;
                case BlockType.IRETURN:
                    if (returnBlocksOn) {
                        listener.blockCovered(bId + 1, nodeType);
                        if (DEBUG) {
                            System.out.println("tr.setBit <return> " +
                                    "success");
                        }
                    }
                    break;
                default:
                    throw new ExecException("Invalid block type code " +
                            "received from instrumented class");
                }
            }
            break;
        case SConstants.INST_COMPATIBLE:
            // In compatible mode instrumentation, the block data is packed
            // in the same way as for sequence instrumentation, so it's
            // easier to simply let it masquerade as such
        case SConstants.INST_OPT_SEQUENCE:
            int[] intArray = (int[]) instArray;
            for (int i = fromIndex; i < toIndex; i++) {
                int nodeType = intArray[i] >>> 26;
                int blockID = intArray[i] & 0x03FFFFFF;

                switch (nodeType) {
                case BlockType.IBLOCK:
                    if (codeBlocksOn) {
                        listener.blockCovered(blockID + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <basic> success");
                        }
                    }
                    break;
                case BlockType.IENTRY:
                    if (entryBlocksOn) {
                        listener.blockCovered(blockID + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <entry> success");
                        }
                    }
                    break;
                case BlockType.IEXIT:
                    if (exitBlocksOn) {
                        listener.blockCovered(blockID + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <exit> success");
                        }
                    }
                    break;
                case BlockType.ICALL:
                    if (callBlocksOn) {
                        listener.blockCovered(blockID + 1, nodeType);
                        if (DEBUG) {
                            System.out.println(
                                    "tr.setBit <call> success");
                        }
                    }
                    break;
                case BlockType.IRETURN:
                    if (returnBlocksOn) {
                        listener.blockCovered(blockID + 1, nodeType);
                        if (DEBUG) {
                            System.out.println("tr.setBit <return> " +
                                    "success");
                        }
                    }
                    break;
                default:
                    throw new ExecException("Invalid block type code " +
                            "received from instrumented class: " + nodeType);
                }
            }
            break;
        default:
            throw new ConfigurationError("Unknown or incompatible " +
                    "instrumentation");
        }

        // Catch all unexpected exceptions and store them
        }
        catch (Exception e) {
            e.printStackTrace();
            err = e;
            System.err.println("Error writing trace message");
        }
    }

    public boolean areCodeBlocksActive() {
        return blockConfig.areCodeBlocksActive();
    }

    public void setCodeBlocksActive(boolean enable) {
        blockConfig.setCodeBlocksActive(enable);
    }

    public boolean areEntryBlocksActive() {
        return blockConfig.areEntryBlocksActive();
    }

    public void setEntryBlocksActive(boolean enable) {
        blockConfig.setEntryBlocksActive(enable);
    }

    public boolean areExitBlocksActive() {
        return blockConfig.areExitBlocksActive();
    }

    public void setExitBlocksActive(boolean enable) {
        blockConfig.setExitBlocksActive(enable);
    }

    public boolean areCallBlocksActive() {
        return blockConfig.areCallBlocksActive();
    }

    public void setCallBlocksActive(boolean enable) {
        blockConfig.setCallBlocksActive(enable);
    }

    public int getTypeFlags() {
        return blockConfig.getTypeFlags();
    }
}
