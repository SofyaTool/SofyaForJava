/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

import java.util.BitSet;

import sofya.ed.BlockCoverageListener;
import sofya.base.SConstants.BlockType;

/**
 * <p>A basic block coverage trace records the coverage of basic blocks
 * in a method.</p>
 *
 * @author Alex Kinneer
 * @version 03/13/2006
 */
public class BlockCoverageTrace extends CoverageTrace
        implements BlockCoverageListener {
    /**
     * Creates a new basic block coverage trace.
     *
     * @param highestId The highest identifier associated with any basic block
     * in the method (effectively the number of basic blocks in the method.
     */
    public BlockCoverageTrace(int highestId) {
        super(highestId);
    }

    /**
     * Records a basic block as covered.
     *
     * @param id Identifier associated with the covered basic block.
     * @param blockType Numeric constant encoding the type of basic block
     * covered (see {@link sofya.base.SConstants.BlockType}).
     */
    public void blockCovered(int id, int blockType) {
        if ((id - 1 > highestId) || (id < 1)) {
            throw new IndexOutOfBoundsException("Method does not contain " +
                    "block or branch " + id);
        }
        traceVector.set(id - 1);
    }

    /**************************************************************************
     * Creates a deep clone of this trace object.
     *
     * @return A new trace object with the same number of basic blocks
     * and the same basic blocks marked as covered.
     */
    public CoverageTrace copy() {
        BlockCoverageTrace traceClone = new BlockCoverageTrace(highestId);
        traceClone.traceVector = (BitSet) this.traceVector.clone();

        return traceClone;
    }
}
