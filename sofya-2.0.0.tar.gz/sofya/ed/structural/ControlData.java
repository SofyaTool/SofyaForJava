/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

/**
 * <p>This class provides thread identity and synchronization variables that
 * are used by a {@link ProgramEventDispatcher} when it is executed with
 * another <code>ProgramEventDispatcher</code> as its subject. In such cases,
 * the invoking <code>ProgramEventDispatcher</code> must create two processing
 * threads, one to receive information from the subject event dispatcher,
 * and another to receive information from the subject {@link SocketProbe},
 * which is running in the subject of the subject event dispatcher.</p>
 *
 * <p>Much of the data in this class is static and thus is shared between
 * all instances. Separate instances are allocated only to assign independent
 * thread identifiers to each processing thread. This class cannot be used
 * to synchronize more than two threads, as there should be no need for
 * that capability.</p>
 *
 * @author Alex Kinneer
 * @version 03/13/2006
 */
public final class ControlData {
    /** Thread ID to be associated with the processing thread to which this
        control object will be passed; the only variable allocated on a
        per-instance basis. */
    private int threadID;
    /** Flags used to indicate whether processing threads are (still)
        connected and processing probes. */
    static boolean[] threadConnected = new boolean[2];
    /** Flags used to force processing threads to stop. */
    static boolean[] forceStop = new boolean[2];
    /** Holding locations for exceptions thrown during processing thread
        execution. */
    static Throwable[] err = new Throwable[2];
    /** Lock object used to synchronize access to the connection flags. */
    public final static Object stateLock = new Object();

    private ControlData() {
    }

    /**
     * Creates a new thread control object.
     *
     * @param threadID Identifier to be associated with the processing thread to
     * which this control object will be passed.
     */
    ControlData(int threadID) {
        this.threadID = threadID;
    }

    /**
     * Gets the ID associated with the processing thread that owns this
     * control object.
     *
     * @return The numeric identifier to be used by the thread using this
     * control object.
     */
    public int getThreadID() {
        return threadID;
    }

    /**
     * Gets the thread connection state flags for the threads coordinated
     * by this control object.
     *
     * @return The shared thread connection state flags used by the processing
     * threads to indicated whether they are (still) connected and processing
     * probes.
     */
    public boolean[] getConnectionFlags() {
        return threadConnected;
    }

    /**
     * Gets the thread stop flags for the threads coordinated by this control
     * object.
     *
     * @return The shared thread stop flags used to signal the processing
     * threads to halt processing.
     */
    public boolean[] getStopFlags() {
        return forceStop;
    }

    /**
     * Gets the exceptions caught by the processing threads during probe
     * processing.
     *
     * @return The last exception caught by each processing thread during
     * probe processing, if any. This method is guaranteed to return an
     * array of throwables, but the contents of any element may be
     * <code>null</code>, in which case processing completed normally.
     */
    public Throwable[] getExceptionStorage() {
        return err;
    }
}
