/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

import java.util.List;
import java.util.ListIterator;

import sofya.base.SConstants.BranchType;
import sofya.ed.BadParameterValueException;

import gnu.trove.TIntHashSet;

/**
 * <p>A branch instrumentation configuration stores the types of branches
 * that have been selected for instrumentation or observation by an
 * event dispatcher.</p>
 *
 * @author Alex Kinneer
 * @version 03/16/2006
 */
public class BranchInstrumentationConfiguration implements ActiveComponent {
    /** Flag to activate if branches. */
    private boolean ifBranchesOn;
    /** Flag to activate switch branches. */
    private boolean switchBranchesOn;
    /** Flag to activate throws branches. */
    private boolean throwsBranchesOn;
    /** Flag to activate call branches. */
    private boolean callBranchesOn;
    /** Flag to activate entry branches. */
    private boolean entryBranchesOn;
    /** Flag to activate summary branches. */
    private boolean summaryBranchesOn;

    /** Flag indicating whether the configuration is considered in a ready
        state. */
    protected boolean ready;

    /** Set of characters used to heuristically guess the command line
        parameter specifying the branch types to activate. */
    private static TIntHashSet matchChars = new TIntHashSet();

    static {
        matchChars.add('I');
        matchChars.add('S');
        matchChars.add('T');
        matchChars.add('C');
        matchChars.add('E');
        matchChars.add('O');
    }

    /**
     * Creates a new branch configuration.
     *
     * <p>No branches are activated by default.</p>
     */
    public BranchInstrumentationConfiguration() {
    }

    public void register(EventDispatcherConfiguration edConfig) {
    }

    public List configure(List params) {
        boolean typeParamFound = false;
        String bestMatch = null;
        int bestMatchCount = 0;

        paramLoop:
        for (ListIterator li = params.listIterator(); li.hasNext(); ) {
            String param = (String) li.next();
            int length = param.length();

            if (param.startsWith("-") && (length <= 7)) {
                int curMatchCount = 0;

                for (int i = 1; i < length; i++) {
                    if (!matchChars.contains(param.charAt(i))) {
                        if (curMatchCount >= bestMatchCount) {
                            bestMatch = param;
                            bestMatchCount = curMatchCount;
                        }
                        continue paramLoop;
                    }
                    curMatchCount++;
                }

                parseParameter(param);
                typeParamFound = true;

                li.remove();
                break;
            }
        }

        if (!typeParamFound) {
            if (bestMatchCount > 0) {
                parseParameter(bestMatch);
            }
            else {
                throw new IllegalArgumentException("Branch types not " +
                        "specified");
            }
        }

        this.ready = true;

        return params;
    }

    /**
     * Parses branch types from a command line parameter.
     *
     * @param param The command line parameter to attempt to parse.
     */
    private void parseParameter(String param) {
        int length = param.length();
        for (int i = 1; i < length; i++) {
            switch(param.charAt(i)) {
            case 'I':
                ifBranchesOn = true;
                break;
            case 'S':
                switchBranchesOn = true;
                break;
            case 'T':
                throwsBranchesOn = true;
                break;
            case 'C':
                callBranchesOn = true;
                break;
            case 'E':
                entryBranchesOn = true;
                break;
            case 'O':
                summaryBranchesOn = true;
                break;
            default:
                throw new BadParameterValueException(
                        "Invalid branch type: " + param.charAt(i));
            }
        }
    }
    
    public void reset() {
        this.ifBranchesOn = false;
        this.switchBranchesOn = false;
        this.throwsBranchesOn = false;
        this.callBranchesOn = false;
        this.entryBranchesOn = false;
        this.summaryBranchesOn = false;
        this.ready = false;
    }

    public boolean isReady() {
        return ready;
    }

    public void release() {
    }

    /*************************************************************************
     * Reports whether <code>if</code> branches are selected.
     *
     * @return <code>true</code> if <code>if</code> branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areIfBranchesActive() {
        return ifBranchesOn;
    }
    
    /*************************************************************************
     * Sets whether <code>if</code> branches are selected.
     *
     * @param enable <code>true</code> to select <code>if</code> branches,
     * <code>false</code> to ignore.
     */
    public void setIfBranchesActive(boolean enable) {
        this.ifBranchesOn = enable;
        ready = true;
    }

    /*************************************************************************
     * Reports whether <code>switch</code> branches are selected.
     *
     * @return <code>true</code> if <code>switch</code> branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areSwitchBranchesActive() {
        return switchBranchesOn;
    }

    /*************************************************************************
     * Sets whether <code>switch</code> branches are selected.
     *
     * @param enable <code>true</code> to select <code>switch</code> branches,
     * <code>false</code> to ignore.
     */
    public void setSwitchBranchesActive(boolean enable) {
        this.switchBranchesOn = enable;
        ready = true;
    }

    /*************************************************************************
     * Reports whether <code>throws</code> branches are selected.
     *
     * @return <code>true</code> if <code>throws</code> branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areThrowsBranchesActive() {
        return throwsBranchesOn;
    }

    /*************************************************************************
     * Sets whether <code>throws</code> branches are selected.
     *
     * @param enable <code>true</code> to select <code>throws</code> branches,
     * <code>false</code> to ignore.
     */
    public void setThrowsBranchesActive(boolean enable) {
        this.throwsBranchesOn = enable;
        ready = true;
    }

    /*************************************************************************
     * Reports whether call branches are selected.
     *
     * @return <code>true</code> if call branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areCallBranchesActive() {
        return callBranchesOn;
    }

    /*************************************************************************
     * Sets whether call branches are selected.
     *
     * @param enable <code>true</code> to select call branches,
     * <code>false</code> to ignore.
     */
    public void setCallBranchesActive(boolean enable) {
        this.callBranchesOn = enable;
        ready = true;
    }

    /*************************************************************************
     * Reports whether entry branches are selected.
     *
     * @return <code>true</code> if entry branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areEntryBranchesActive() {
        return entryBranchesOn;
    }

    /*************************************************************************
     * Sets whether entry branches are selected.
     *
     * @param enable <code>true</code> to select entry branches,
     * <code>false</code> to ignore.
     */
    public void setEntryBranchesActive(boolean enable) {
        this.entryBranchesOn = enable;
        ready = true;
    }

    /*************************************************************************
     * Reports whether summary branches are selected.
     *
     * @return <code>true</code> if summary branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areSummaryBranchesActive() {
        return summaryBranchesOn;
    }

    /*************************************************************************
     * Sets whether summary branches are selected.
     *
     * @param enable <code>true</code> to select summary branches,
     * <code>false</code> to ignore.
     */
    public void setSummaryBranchesActive(boolean enable) {
        this.summaryBranchesOn = enable;
        ready = true;
    }

    /*************************************************************************
     * Gets the bitmask corresponding to the types of branches currently
     * selected.
     *
     * <p>Used for communicating configuration information to certain other
     * components. To be phased out at a future date.</p>
     *
     * @return The bitmask indicating which branch types have been selected
     * in this configuration.
     */
    public int getTypeFlags() {
        int typeFlags = 0x00000000;
        if (ifBranchesOn) typeFlags      |= BranchType.MASK_IF;
        if (switchBranchesOn) typeFlags  |= BranchType.MASK_SWITCH;
        if (throwsBranchesOn) typeFlags  |= BranchType.MASK_THROW;
        if (callBranchesOn) typeFlags    |= BranchType.MASK_CALL;
        if (entryBranchesOn) typeFlags   |= BranchType.MASK_ENTRY;
        if (summaryBranchesOn) typeFlags |= BranchType.MASK_OTHER;
        return typeFlags;
    }
}
