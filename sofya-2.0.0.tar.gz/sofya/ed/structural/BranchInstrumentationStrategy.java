/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

/**
 * <p>Specifies that a component uses or depends on a branch instrumentation
 * strategy. Defines methods to specify which types of branches are selected
 * for instrumentation or observation.</p>
 *
 * @author Alex Kinneer
 * @version 03/16/2006
 */
public interface BranchInstrumentationStrategy {
    /*************************************************************************
     * Reports whether <code>if</code> branches are selected.
     *
     * @return <code>true</code> if <code>if</code> branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areIfBranchesActive();

    /*************************************************************************
     * Sets whether <code>if</code> branches are selected.
     *
     * @param enable <code>true</code> to select <code>if</code> branches,
     * <code>false</code> to ignore.
     */
    public void setIfBranchesActive(boolean enable);

    /*************************************************************************
     * Reports whether <code>switch</code> branches are selected.
     *
     * @return <code>true</code> if <code>switch</code> branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areSwitchBranchesActive();

    /*************************************************************************
     * Sets whether <code>switch</code> branches are selected.
     *
     * @param enable <code>true</code> to select <code>switch</code> branches,
     * <code>false</code> to ignore.
     */
    public void setSwitchBranchesActive(boolean enable);

    /*************************************************************************
     * Reports whether <code>throws</code> branches are selected.
     *
     * @return <code>true</code> if <code>throws</code> branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areThrowsBranchesActive();

    /*************************************************************************
     * Sets whether <code>throws</code> branches are selected.
     *
     * @param enable <code>true</code> to select <code>throws</code> branches,
     * <code>false</code> to ignore.
     */
    public void setThrowsBranchesActive(boolean enable);

    /*************************************************************************
     * Reports whether call branches are selected.
     *
     * @return <code>true</code> if call branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areCallBranchesActive();

    /*************************************************************************
     * Sets whether call branches are selected.
     *
     * @param enable <code>true</code> to select call branches,
     * <code>false</code> to ignore.
     */
    public void setCallBranchesActive(boolean enable);

    /*************************************************************************
     * Reports whether entry branches are selected.
     *
     * @return <code>true</code> if entry branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areEntryBranchesActive();

    /*************************************************************************
     * Sets whether entry branches are selected.
     *
     * @param enable <code>true</code> to select entry branches,
     * <code>false</code> to ignore.
     */
    public void setEntryBranchesActive(boolean enable);

    /*************************************************************************
     * Reports whether summary branches are selected.
     *
     * @return <code>true</code> if summary branches are selected,
     * <code>false</code> otherwise.
     */
    public boolean areSummaryBranchesActive();

    /*************************************************************************
     * Sets whether summary branches are selected.
     *
     * @param enable <code>true</code> to select summary branches,
     * <code>false</code> to ignore.
     */
    public void setSummaryBranchesActive(boolean enable);

    /*************************************************************************
     * Gets the bitmask corresponding to the types of branches currently
     * selected.
     *
     * <p>Used for communicating configuration information to certain other
     * components. To be phased out at a future date.</p>
     *
     * @return The bitmask indicating which branch types have been selected
     * in this configuration.
     */
    public int getTypeFlags();
}
