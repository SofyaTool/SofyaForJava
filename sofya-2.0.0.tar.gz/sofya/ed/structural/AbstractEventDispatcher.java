/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

/**
 * <p>This is the abstract base class of all event dispatchers that produce
 * structural event streams.</p>
 *
 * @author Alex Kinneer
 * @version 03/16/2006
 */
public abstract class AbstractEventDispatcher {
    /** Flag indicating whether a dispatcher's own configuration is set and
        the dispatcher is ready to invoke the subject program. */
    protected static boolean dispatcherReady = false;

    /** Flag indicating whether subject is instrumented. Set to true once a
        connection has been made from the subject. */
    protected static volatile boolean isInstrumented = false;

    protected AbstractEventDispatcher() {
    }

    /*************************************************************************
     * <p>Performs setup and runs the subject; this is the main driving
     * method of a structural event dispatcher.</p>
     *
     * @throws SetupException If there is an error attempting to set up the
     * event dispatcher to run the subject.
     * @throws ExecException If an error occurs executing the subject. This
     * does not include exceptions thrown by the subject itself, only errors
     * in the event dispatcher while attempting to interface with the subject.
     */
    public abstract void startDispatcher();

    /** Exception that indicates an error occurred during instantiation of an
        event dispatcher. */
    public static class CreateException extends RuntimeException {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;

        /** Creates an instance with the given message. */
        public CreateException(String s) { super(s); }

        /** Creates an instance with the given message wrapping another
            exception. */
        public CreateException(String s, Throwable e) {
            super(s);
            cause = e;
        }

        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }

    /** Exception that indicates an error occurred while preparing to execute
        a subject class. */
    public static class SetupException extends RuntimeException {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;

        /** Create an instance with the given message. */
        public SetupException(String s) { super(s); }

        /** Creates an instance with the given message wrapping another
            exception. */
        public SetupException(String s, Throwable e) {
            super(s);
            cause = e;
        }

        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }

    /** Exception that indicates an error occurred in an event dispatcher while
        executing a subject class. */
    public static class ExecException extends RuntimeException  {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;

        /** Create an instance with the given message. */
        public ExecException(String s) { super(s); }

        /** Creates an instance with the given message wrapping another
            exception. */
        public ExecException(String s, Throwable e) {
            super(s);
            cause = e;
        }

        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }

    /** Exception that indicates an error occurred while creating or writing
        a trace file. */
    public static class TraceFileException extends RuntimeException  {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;

        /** Create an instance with the given message. */
        public TraceFileException(String s) { super(s); }

        /** Creates an instance with the given message wrapping another
            exception. */
        public TraceFileException(String s, Throwable e) {
            super(s);
            cause = e;
        }

        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }
}
