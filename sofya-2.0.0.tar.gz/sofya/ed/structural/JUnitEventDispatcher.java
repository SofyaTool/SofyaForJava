/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

import java.util.*;

import sofya.base.SConstants;
import sofya.base.SConstants.BlockType;
import sofya.base.exceptions.*;

import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.collections.MapIterator;

import gnu.trove.TIntObjectHashMap;
import gnu.trove.TObjectIntHashMap;

/**
 * A JUnitEventDispatcher is designed to be used by a specially modified JUnit
 * test runner to dispatch an event stream from JUnit test cases run on
 * instrumented code.
 *
 * <p>The JUnitEventDispatcher does not provide any mechanism for invoking a
 * subject class in a separate virtual machine, has a restricted set of
 * configuration options, and exposes special methods for controlling the
 * dispatch of distinct event streams.  It is expected that an instance of
 * a JUnitEvent Dispatcher class will be created inside a JUnit test runner.
 * Instrumented JUnit test suites and test cases can then be run,
 * using a TestListener (part of the JUnit framework) to handle processing
 * of per-test event streams at the appropriate times (as by writing a trace
 * file, for example). It is strongly recommended that the listener regularly
 * issue calls to the {@link #checkError} method to ensure timely termination
 * in the event of a failure. This class requires that the subject classes
 * be instrumented using the '<code>junit</code>' mode of instrumentation
 * (see {@link sofya.ed.cfInstrumentor}).</p>
 *
 * <p>This class cannot be run directly from the command line.</p>
 *
 * @author Alex Kinneer
 * @version 03/15/2006
 */
public final class JUnitEventDispatcher extends AbstractEventDispatcher {
    /** The singleton instance of the dispatcher. Only one instance may exist
        because much of the class data is static (and must be to enable the
        instrumentation to work). */
    private static JUnitEventDispatcher theDispatcher = null;
    /** The probe processing strategy that this dispatcher is configured
        to use. */
    private static JUnitProcessingStrategy processingStrategy;

    /** Indicates the type of instrumentation present in the subject. Note that
        this is automatically detected, and the dispatcher will reject subjects
        with mixed instrumentation.*/
    protected static int instMode = -1;

    /** Maximum number of methods for which byte arrays can be cached
        when handling optimized normal instrumentation. */
    protected static final int OBJECT_ARRAY_CACHE_SIZE = 1000;

    /** Size of the array which records object sequence information
        when handling optimized sequence instrumentation. */
    protected static final int SEQUENCE_ARRAY_SIZE = 8192;

    /** LRU cache which holds the byte arrays recording which objects have been
        hit in each method. If the cache fills, data is written to the trace
        before the oldest array is removed from the cache. */
    protected static LRUTraceMap traceObjArrays;
      /* Using an LRU map creates a rough upper bound on memory consumption.
         Assuming an average of 100 blocks in a typical method (probably even
         a little high), allocating a cache for 1000 methods limits the
         memory usage to (1 * 100 * 1000) = 100,000 bytes, or about 100K. Do
         NOT set this value too low, or performance will suffer severely as the
         system spends too much time shifting entries in and out of the cache
         and writing redundant data to the trace. */
    /** Current trace being recorded. */
    protected static CoverageTrace methodTrace;

    /** Array which stores the executed object IDs sequentially, using
        special marker/index pairs to indicate entry into new methods.
        It is public so that the instrumentation is not required
        to make a method call to retrieve a reference to it. */
    public static int[] sequenceArray;
    /** Index pointing to the next open entry in the sequence array.
        Instrumentation is responsible for updating this pointer when
        recording an object ID, and calling
        <code>writeSequenceData</code> when the array is filled. */
    public static int sequenceIndex = 0;
    /** Stores the signature string of the method for which objects
        are currently being recorded. This is required when object
        IDs for a method bridge an array transmit-and-reset event. */
    protected static String currentMethodSig = null;
    /** Maps indices following new method markers to the signature
        string for that method. */
    protected static TIntObjectHashMap indexToNameMap;
    /** Maps signature strings for a method to an already assigned
        index, if any. */
    protected static TObjectIntHashMap nameToIndexMap;
    /** Holds the next value available for use as an index to a
        method signature string. */
    protected static int nextMethodIndex = 0;
    /** Stack which holds the signatures of methods on the call stack.
        Used in basic block sequence tracing to ensure that blocks are
        associated with the correct method after returning from a called
        method. */
    protected static LinkedList methodSigStack;

    /** Flag which indicates if an instrumentation error (wrong mode of
        instrumentation) has been detected. It is used to suppress repeat
        messages. */
    protected static boolean instError = false;

    /*************************************************************************
     * No argument constructor not allowed.
     */
    private JUnitEventDispatcher() {
        throw new SofyaError("Illegal constructor");
    }

    /**
     * Constructs a new event dispatcher using a given processing strategy;
     * private to implement the singleton pattern.
     *
     * @param procStrategy Processing strategy to be used to process probes
     * received from the instrumentation.
     */
    private JUnitEventDispatcher(JUnitProcessingStrategy procStrategy) {
        processingStrategy = procStrategy;
        dispatcherReady = true;
    }

    /**
     * Factory method that returns a singleton instance of the event
     * dispatcher.
     *
     * <p>A singleton strategy is enforced because much of the class data
     * is static, and must be to enable the instrumentation to work. If
     * a completely new instance is desired, call {@link #release} and then
     * call this method.</p>
     *
     * @param strategy Processing strategy to be used to process probes
     * received from the instrumentation.
     *
     * @return A new event dispatcher, or a reference to the existing
     * singleton instance if this method has already been called and
     * {@link #release} has not yet been called.
     */
    public static JUnitEventDispatcher createEventDispatcher(
            JUnitProcessingStrategy strategy) {
        if (theDispatcher == null) {
            theDispatcher = new JUnitEventDispatcher(strategy);
        }
        return theDispatcher;
    }

    /**
     * Gets the processing strategy currently in use by this event dispatcher
     * to receive probes from the subject.
     *
     * @return The processing strategy that this event dispatcher is configured
     * to use to receive probes from the subject.
     */
    public JUnitProcessingStrategy getProcessingStrategy() {
        return processingStrategy;
    }

    /**
     * Specifies the processing strategy to be used by this event dispatcher
     * to receive probes from the subject.
     *
     * @param procStrategy The processing strategy to be used by this event
     * dispatcher to receive probes from the subject.
     */
    public void setProcessingStrategy(JUnitProcessingStrategy procStrategy) {
        processingStrategy = procStrategy;
    }

    /**
     * Reports the instrumentation mode detected in the subject.
     *
     * @return The numeric constant for the instrumentation mode detected in
     * the subject (e.g. coverage, sequence, compatibility).
     */
    public int getInstrumentationMode() {
        return instMode;
    }

    /**
     * Registers the processing strategy and any attached components.
     *
     * @param edc The global event dispatcher configuration for this event
     * dispatcher.
     */
    public void register(EventDispatcherConfiguration edc) {
        processingStrategy.register(edc);
    }

    /**
     * Releases this event dispatcher, its processing strategy, and any
     * attached components.
     */
    public void release() {
        instMode = -1;
        processingStrategy.release();
        theDispatcher = null;
        dispatcherReady = false;
    }

    /*************************************************************************
     * Initializes the data structures necessary to process the instrumentation
     * detected in the subject. All invocations subsequent to the first must
     * specify the same form of instrumentation, or the method will fail. In
     * practice it should only be called once.
     *
     * @param _instMode Type of instrumentation detected in the subject.
     *
     * @throws IllegalStateException If this method has previously been called
     * with a different mode of instrumentation.
     */
    protected static void setup(int _instMode) {
        if ((instMode != -1) && (instMode != _instMode)) {
            throw new IllegalStateException("Subject contains inconsistent " +
                "instrumentation");
        }

        instMode = _instMode;

        processingStrategy.setInstrumentationMode(
            new InstrumentationMode(instMode));

        // Initialize data structures
        switch (instMode) {
        case SConstants.INST_COMPATIBLE:
            break;
        case SConstants.INST_OPT_NORMAL:
            traceObjArrays = new LRUTraceMap(OBJECT_ARRAY_CACHE_SIZE);
            break;
        case SConstants.INST_OPT_SEQUENCE:
            sequenceArray = new int[SEQUENCE_ARRAY_SIZE];
            Arrays.fill(sequenceArray, 0);
            indexToNameMap = new TIntObjectHashMap();
            nameToIndexMap = new TObjectIntHashMap();
            methodSigStack = new LinkedList();
            break;
        default:
            throw new IllegalArgumentException("Subject contains " +
                "unrecognized type of instrumentation");
        }
    }

    /*************************************************************************
     * Clears instrumentation data structures (for the next test case).
     */
    protected void reset() {
        if (instMode == -1) return;

        switch (instMode) {
            case SConstants.INST_COMPATIBLE:
                break;
            case SConstants.INST_OPT_NORMAL:
                traceObjArrays.clear();
                break;
            case SConstants.INST_OPT_SEQUENCE:
                sequenceIndex = 0;
                currentMethodSig = null;
                methodSigStack.clear();
                break;
            default:
                throw new IllegalStateException("Unrecognized type of " +
                    "instrumentation");
        }
    }

    /*************************************************************************
     * Initializes the event dispatcher such that it is ready to process
     * instrumentation and dispatch event streams.
     *
     * @throws SetupException If there is an error attempting to set up this
     * event dispatcher to receive instrumentation.
     */
    public void startDispatcher() {
        processingStrategy.setup();

        if (!dispatcherReady || !processingStrategy.isReady()) {
            throw new SetupException("Dispatcher is not ready, it must be " +
                "configured or a new instance should be created");
        }
    }

    /*************************************************************************
     * Signals that a new test case is executing.
     *
     * <p>Some event stream observers may need to perform setup before
     * handling a new event stream, such as opening a new trace file.</p>
     *
     * <p>This method resets the flag indicating whether a test case
     * was instrumented.</p>
     *
     * @param testNumber Number associated with the current test.
     */
    public void newTest(int testNumber) {
        isInstrumented = false;
        processingStrategy.newTest(testNumber);
    }

    /*************************************************************************
     * Signals that the current test case has finished executing.
     *
     * <p>Some event stream observers may need to take some kind of action
     * here, such as saving or storing a trace file.</p>
     *
     * <p>Data structures for handling* instrumentation will be reset for
     * the next test case.</p>
     */
    public void endTest(int testNumber) throws TraceFileException {
        try {
            if (instMode != -1) {
                finish();
            }
            // else we haven't inferred what type of instrumentation is present,
            // which is only possible if none has been encountered yet. Thus
            // we don't need to worry about any unprocessed cached data.

            processingStrategy.endTest(testNumber);
        }
        finally {
            reset();
        }
    }

    /*************************************************************************
     * Checks whether the last test case was instrumented.
     *
     * <p>If the test case executed instrumented code, this method will
     * return <code>true</code> until the next call to {@link #newTest},
     * otherwise it returns <code>false</code>.</p>
     *
     * @return <code>true</code> if the last test case executed instrumented
     * code and <code>newTraceFile</code> has not yet been called,
     * <code>false</code> otherwise.
     */
    public boolean checkInstrumented() {
        return isInstrumented;
    }

    /*************************************************************************
     * Checks whether any exceptions have been raised during processing, and
     * rethrows the exception for handling if so. This method returns without
     * action if there are no errors.
     *
     * @throws Exception For any exception that was raised and stored.
     */
    public static void checkError() throws Exception {
        processingStrategy.checkError();
    }

    /*************************************************************************
     * Checks that the type of instrumentation can be handled by the
     * a JUnit event dispatcher. This also makes the instrumentor
     * implementation easier by allowing it to simply change the name of the
     * class the instrumentation related methods are invoked on depending on
     * what type of instrumentation it has been directed to insert.
     *
     * <p><strong>Note: It is not necessary for a subject to call this method
     * for the event dispatcher to work</strong> (assuming the instrumentation
     * is appropriate). This method is merely provided to assist the
     * instrumentor.</p>
     *
     * @param port <i>Ignored.</i>
     * @param _instMode Flag indicating the type of instrumentation present in
     * the subject. All types are supported as long as the instrumentation is
     * targeted for a JUnit event dispatcher.
     * @param _doTimestamps <i>Ignored.</i>
     * @param _useSignalSocket <i>Ignored.</i>
     * @param _entityType <i>Ignored</i>
     */
    public static void start(int port, int _instMode, boolean _doTimestamps,
                             boolean _useSignalSocket, int _entityType) {
        if ((_instMode < 1) || (_instMode > 4)) {
            if (!instError) {
                System.err.println("Cannot process type of instrumentation " +
                    "present in subject!");
                instError = true;
            }
            return;
        }
    }

    /*************************************************************************
     * Ensures that all data currently in the cache is written to the
     * trace, guaranteeing that it will be complete.
     */
    public static void finish() {
        switch (instMode) {
        case SConstants.INST_COMPATIBLE:
            break;
        case SConstants.INST_OPT_NORMAL:
            MapIterator it = traceObjArrays.orderedMapIterator();
            while (it.hasNext()) {
                String mSig = (String) it.next();
                processingStrategy.processData(it.getValue(), mSig, -1, -1);
            }
            break;
        case SConstants.INST_OPT_SEQUENCE:
            writeSequenceData();
            break;
        default:
            throw new IllegalStateException("Unrecognized type of " +
                "instrumentation");
        }
    }

    /*************************************************************************
     * Notifies the event dispatcher of the number of basic blocks in
     * the current method, to be reported to the processing strategy and
     * any interested listeners.
     *
     * <p>This method is retained for compatibility with previous
     * instrumentation.</p>
     *
     * @param mSignature Signature of the method for which the basic block
     * count is being sent.
     * @param blockCount Number of basic blocks in the method.
     */
    public static void writeBlockCount(String mSignature, int blockCount) {
        writeObjectCount(mSignature, blockCount);
    }

    /*************************************************************************
     * Notifies the event dispacher of the number of structural objects in
     * the current method, to be reported to the processing strategy and
     * any interested listeners.
     *
     * @param mSignature Signature of the method for which the object count
     * is being sent.
     * @param objCount Number of objects in the method.
     */
    public static void writeObjectCount(String mSignature, int objCount) {
        mSignature = mSignature.replace('@', '.');
        processingStrategy.setMethodObjectCount(mSignature, objCount);
    }

    /*************************************************************************
     * Marks a single object in the trace; used by the compatible mode
     * instrumentation.
     *
     * @param bId The ID of the object marked by this instrumentation
     * statement.
     * @param mSignature Signature of the method owning the object.
     */
    public static void writeTraceMessage(int bId, String mSignature) {
        if (instMode != SConstants.INST_COMPATIBLE) {
            if (instMode == -1) {
                setup(SConstants.INST_COMPATIBLE);
            }
            else {
                throw new IllegalStateException("Subject contains " +
                    "inconsistent instrumentation");
            }
        }

        isInstrumented = true;
        processingStrategy.processData(new int[]{bId},
                                       mSignature.replace('@', '.'), 0, 1);
    }

    /*************************************************************************
     * Maps to an equivalent call to {@link #getObjectArray};
     * this method is retained for backwards compatibility with previous
     * instrumentation.
     *
     * @param mSignature Signature of the method for which the byte array
     * is to be retrieved. The signature guarantees uniqueness.
     * @param blockCount Number of basic blocks in the method, used only
     * when the array must be allocated. This value should be determined
     * by the CFG builder and set by the instrumentor.
     *
     * @return The byte array recording basic blocks covered in the method.
     */
    public static byte[] getBlockArray(String mSignature, int blockCount) {
        return getObjectArray(mSignature, blockCount);
    }

    /*************************************************************************
     * Gets the byte array recording which objects have been covered in a
     * given method.
     *
     * <p>If this is the first time the method has been traced (or the
     * method has been removed from the cache), an array of the necessary
     * size is allocated and initialized. Calls to this method are
     * inserted at the beginning of methods in the subject by the
     * instrumentor.</p>
     *
     * @param mSignature Signature of the method for which the byte array
     * is to be retrieved. The signature guarantees uniqueness.
     * @param objCount Number of objects in the method, used only
     * when the array must be allocated. This value should be determined
     * by the CFG builder and set by the instrumentor.
     *
     * @return The byte array recording objects covered in the method.
     */
    public static byte[] getObjectArray(String mSignature, int objCount) {
        if (instMode != SConstants.INST_OPT_NORMAL) {
            if (instMode == -1) {
                setup(SConstants.INST_OPT_NORMAL);
            }
            else {
                throw new IllegalStateException("Subject contains " +
                    "inconsistent instrumentation");
            }
        }

        isInstrumented = true;
        writeObjectCount(mSignature, objCount);

        mSignature = mSignature.replace('@', '.');
        if (!traceObjArrays.containsKey(mSignature)) {
            // Need to allocate and initialize new one
            byte[] traceObjArray = new byte[objCount];
            Arrays.fill(traceObjArray, (byte) 0);
            traceObjArrays.put(mSignature, traceObjArray);
            return traceObjArray;
        }
        else {
            return (byte[]) traceObjArrays.get(mSignature);
        }
    }

    /*************************************************************************
     * Inserts a new method marker and index into the sequence array.
     * (See {@link sofya.ed.structural.SocketProbe#markMethodInSequence}).
     *
     * @param mSignature Signature of the method which has been entered
     * and needs to be marked in the array.
     * @param objCount Number of objects in the method.
     */
    public static void markMethodInSequence(String mSignature, int objCount) {
        if (instMode != SConstants.INST_OPT_SEQUENCE) {
            if (instMode == -1) {
                setup(SConstants.INST_OPT_SEQUENCE);
            }
            else {
                throw new IllegalStateException("Subject contains " +
                    "inconsistent instrumentation");
            }
        }

        isInstrumented = true;
        writeObjectCount(mSignature, objCount);

        mSignature = mSignature.replace('@', '.');
        if (sequenceIndex > sequenceArray.length - 2) {
            // The array is full, so transmit the data. This also resets the
            // index
            writeSequenceData();
        }
        sequenceArray[sequenceIndex++] = SocketProbe.NEW_METHOD_MARKER;
        if (nameToIndexMap.containsKey(mSignature)) {
            // We've already linked this method to an index, so use that value
            sequenceArray[sequenceIndex++] = nameToIndexMap.get(mSignature);
        }
        else {
            // Need to create a new index to correspond to this method
            sequenceArray[sequenceIndex++] = nextMethodIndex;
            nameToIndexMap.put(mSignature, nextMethodIndex);
            indexToNameMap.put(nextMethodIndex, mSignature);
            // Overflow detection not necessary - see writeSequenceData()
            nextMethodIndex++;
        }
    }

    /*************************************************************************
     * Writes the current contents of the object sequence array to the trace.
     * (See {@link sofya.ed.structural.SocketProbe#writeSequenceData}).
     */
    public static void writeSequenceData() {
        int fromIndex = 0;
        int toIndex = 0;
        while (toIndex < sequenceIndex) {
            if (sequenceArray[toIndex] == SocketProbe.NEW_METHOD_MARKER) {
                if (toIndex > fromIndex) {
                    if (currentMethodSig != null) {
                        processingStrategy.processData(sequenceArray,
                            currentMethodSig, fromIndex, toIndex);
                    }
                    else {
                        System.err.println("ERROR: Orphaned block sequence " +
                            "information detected. Trace is likely invalid!");
                    }
                }
                if (processingStrategy.getObjectType()
                        == SConstants.TraceObjectType.BASIC_BLOCK) {
                    methodSigStack.addLast(currentMethodSig);
                }
                currentMethodSig =
                    (String) indexToNameMap.get(sequenceArray[++toIndex]);
                fromIndex = ++toIndex;
            }
            else if (sequenceArray[toIndex] >>> 26 == BlockType.EXIT.toInt()) {
                if (toIndex >= fromIndex) {
                    if (currentMethodSig != null) {
                        processingStrategy.processData(sequenceArray,
                            currentMethodSig, fromIndex, toIndex + 1);
                    }
                    else {
                        System.err.println("ERROR: Orphaned block sequence " +
                            "information detected. Trace is likely invalid!");
                    }
                }
                try {
                    currentMethodSig = (String) methodSigStack.removeLast();
                }
                catch (NoSuchElementException e) {
                    System.err.println("ERROR: Number of method entries and " +
                        "exits is unbalanced.");
                }
                fromIndex = ++toIndex;
            }
            else {
                toIndex++;
            }
        }
        if (toIndex > fromIndex) {
            if (currentMethodSig != null) {
                processingStrategy.processData(sequenceArray, currentMethodSig,
                                         fromIndex, toIndex);
            }
            else {
                System.err.println("ERROR: Orphaned block sequence " +
                    "information detected. Trace is likely invalid!");
            }
        }

        sequenceIndex = 0;
        // Now that the array is cleared, we can also clear any current
        // mappings of indices to method signatures and vice-versa. This is
        // easier than trying to attach overflow protection to the index
        // counter, and safer since overflow detection would only be able to
        // report that the trace is invalid, not recover from it.
        indexToNameMap.clear();
        nameToIndexMap.clear();
        nextMethodIndex = 0;
    }

    /*************************************************************************
     * Customized implementation of the LRU map to ensure that the hit
     * object data in the byte array for a least-recently-used method is
     * written to the trace before its entry is removed from the map.
     */
    private static class LRUTraceMap extends LRUMap {
        public LRUTraceMap(int maxSize) {
            super(maxSize);
        }

        protected boolean removeLRU(LinkEntry entry) {
            // Actually record the trace data for the block array about to be
            // kicked
            Object value = entry.getValue();
            if (value != null) {
                processingStrategy.processData(value,
                        (String) entry.getKey(), -1 ,-1);
            }
            return true;
        }
    }

    /**
     * Callback class used to safely transfer the instrumentation mode
     * constant to the processing strategy.
     */
    public static class InstrumentationMode {
        private int instMode;

        private InstrumentationMode() {
        }

        InstrumentationMode(int instMode) {
            this.instMode = instMode;
        }

        public int getValue() {
            return instMode;
        }
    }
}
