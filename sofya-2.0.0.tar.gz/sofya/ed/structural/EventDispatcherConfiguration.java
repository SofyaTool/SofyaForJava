/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

import java.io.PrintStream;

/**
 * An event dispatcher configuration stores global configuration parameters
 * and resources that may be required by various components attached to an
 * event dispatcher.
 *
 * @author Alex Kinneer
 * @version 03/10/2006
 */
public class EventDispatcherConfiguration {
    /** Stream to which standard outputs will be directed. */
    private PrintStream stdout = System.out;
    /** Stream to which standard error outputs will be directed. */
    private PrintStream stderr = System.err;
    /** Stream to which subject program outputs will be directed. */
    private PrintStream sbjout = System.out;

    /** Flag indicating whether the subject program is itself a
        <code>ProgramEventDispatcher</code>. */
    private boolean isSbjDispatcher = false;

    /**
     * Creates a new event dispatcher configuration set to defaults.
     */
    public EventDispatcherConfiguration() {
    }

    /**
     * Resets this configuration to defaults.
     */
    public void clear() {
        this.stdout = System.out;
        this.stderr = System.err;
        this.sbjout = System.out;
        this.isSbjDispatcher = false;
    }

    /**
     * Gets the output stream to which standard outputs will be printed.
     *
     * @return The output stream on which standard outputs produced by the
     * event dispatcher and any registered components will be printed.
     */
    public PrintStream getStandardOutput() {
        return stdout;
    }

    /**
     * Sets the output stream to which standard outputs will be printed.
     *
     * @param stdout The output stream on which standard outputs produced
     * by the event dispatcher and any registered components should be
     * printed.
     */
    public void setStandardOutput(PrintStream stdout) {
        this.stdout = stdout;
    }

    /**
     * Gets the output stream to which standard error outputs will be printed.
     *
     * @return The output stream on which standard error outputs produced by the
     * event dispatcher and any registered components will be printed.
     */
    public PrintStream getStandardError() {
        return stderr;
    }

    /**
     * Sets the output stream to which standard error outputs will be printed.
     *
     * @param stderr The output stream on which standard error outputs produced
     * by the event dispatcher and any registered components should be
     * printed.
     */
    public void setStandardError(PrintStream stderr) {
        this.stderr = stderr;
    }

    /**
     * Gets the output stream to which subject outputs will be printed.
     *
     * @return The output stream on which outputs produced by the
     * subject program will be printed.
     */
    public PrintStream getSubjectOutput() {
        return sbjout;
    }

    /**
     * Sets the output stream to which subject outputs will be printed.
     *
     * @param sbjout The output stream on which outputs produced
     * by the subject program should be printed.
     */
    public void setSubjectOutput(PrintStream sbjout) {
        this.sbjout = sbjout;
    }

    /**
     * Reports whether the subject program is itself an event dispatcher.
     *
     * @return <code>true</code> if the subject program has been identified
     * as being an event dispatcher.
     */
    public boolean isSubjectDispatcher() {
        return isSbjDispatcher;
    }

    /**
     * Specifies whether the subject program is itself an event dispatcher.
     *
     * @param status <code>true</code> to indicate that the subject program
     * is itself an event dispatcher, <code>false</code> otherwise.
     */
    public void setSubjectIsDispatcher(boolean status) {
        this.isSbjDispatcher = status;
    }
}
