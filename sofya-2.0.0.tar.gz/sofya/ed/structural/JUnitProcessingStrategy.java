/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed.structural;

import sofya.base.SConstants.TraceObjectType;
import sofya.ed.structural.JUnitEventDispatcher.InstrumentationMode;

/**
 * <p>A JUnit processing strategy implements a strategy to be used by a
 * {@link JUnitEventDispatcher} to receive probes received from a subject
 * instrumented for execution in a JUnit test runner and dispatch them
 * as events.</p>
 *
 * @author Alex Kinneer
 * @version 03/15/2006
 */
public interface JUnitProcessingStrategy extends ActiveComponent {
    /**
     * Notifies the processor to perform any setup required to receive
     * probes from the subject.
     */
    void setup();

    /**
     * Notifies the processor that a new test case is about to execute;
     * this is normally relayed to attached listeners.
     *
     * @param testNum The number of the test case about to execute.
     */
    void newTest(int testNum);

    /**
     * Notifies the processor that a test case has finished executing;
     * this is normally relayed to attached listeners.
     *
     * @param testNum The number of the test case that finished executing.
     */
    void endTest(int testNum);

    /**
     * Notification received from the instrumentated subject indicating a
     * structural object count for a method.
     *
     * @param mSig Concatenation of the fully qualified class name, method
     * name, and JNI signature of the method for which an object count is
     * being reported.
     * @param objCount The number of structural objects in the method.
     */
    void setMethodObjectCount(String mSig, int objCount);

    /**
     * Instrumentation data received from the subject.
     *
     * <p>This is a mapping of the actual instrumentation method called from
     * the subject. The data provided varies depending on the the type of
     * instrumentation applied.</p>
     *
     * @param instArray Array of instrumentation data. The type and contents
     * depend on the type of instrumentation applied.
     * @param mSig Concatenation of the fully qualified class name, method
     * name, and JNI signature of the method for which an object count is
     * being reported.
     * @param fromIndex Start index of the segment of the array to be processed
     * on this invocation.
     * @param toIndex End index of the segment of the array to be processed on
     * this invocation.
     */
    void processData(Object instArray, String mSig, int fromIndex, int toIndex);

    /**
     * Gets the type of structural object for which this processor can receive
     * probes.
     *
     * <p>This is used by the JUnit event dispatcher for certain configuration
     * activities.</p>
     *
     * @return The type of structural object for which this processor knows how
     * to receive probes.
     */
    TraceObjectType getObjectType();

    /**
     * Notifies the processor of the instrumentation mode detected in the
     * subject.
     *
     * @param instMode A callback object to be used to retrieve the
     * instrumentation mode detected by the JUnit event dispatcher.
     */
    void setInstrumentationMode(InstrumentationMode instMode);

    /**
     * Checks whether any exceptions have been raised during processing, and
     * rethrows the exception for handling if so. This method returns without
     * action if there are no errors.
     *
     * @throws Exception For any exception that was raised and stored.
     */
    void checkError() throws Exception;
}
