/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed;

import java.io.*;
import java.util.*;

import sofya.base.Handler;
import sofya.base.SConstants;
import sofya.base.exceptions.*;
import sofya.graphs.cfg.CFG;
import sofya.graphs.cfg.Block;
import sofya.graphs.cfg.CFHandler;

import org.apache.bcel.classfile.*;
import org.apache.bcel.generic.*;
import org.apache.bcel.Repository;
import org.apache.bcel.Constants;

import gnu.trove.THashSet;

/**
 * Abstract base class for all instrumentors, which instrument Java class
 * files for execution by an event dispatcher.
 *
 * <p><i>Special note regarding instrumentation of Sofya as a subject</i>: If
 * you change the mode of instrumentation (compatible, normal optimized,
 * etc...) of the instrumentation applied to Sofya as a subject, make
 * sure to delete the 'bootstrap.jar' file in the <code>inst</code>
 * directory of the subject Sofya to force the event dispatcher to rebuild it
 * using the newly instrumented SocketProbe. Otherwise the event dispatcher may
 * refuse to run if the old mode of instrumentation that was applied to
 * SocketProbe in the jar file is not compatible with a form that
 * it accepts.</p>
 *
 * @author Alex Kinneer
 * @version 03/17/2006
 *
 * @see sofya.ed.cfInstrumentor
 * @see sofya.ed.semantic.SemanticInstrumentor
 */
public abstract class Instrumentor
        implements InstructionConstants, SConstants {
    /** BCEL data structure representing the class. */
    protected JavaClass javaClass;
    /** BCEL data structure allowing more advanced modifications to class. */
    protected ClassGen javaClassFile;
    /** BCEL data structure representing the class constant pool. */
    protected ConstantPoolGen cpg;
    /** Collection of uninstrumented methods in the class. */
    protected Method[] methods;
    /** Factory object used to generate more complex instructions. */
    protected InstructionFactory iFactory;

    /** Name of the class currently loaded by the instrumentor, as provided
        in the constructor. */
    protected String className = null;
    /** Fully qualified name of the class currently loaded by the
        instrumentor. */
    protected String fullClassName;
    /** Name of method last instrumented. */
    protected String lastInstrumented;
    /** Socket port to be used for instrumentation. */
    protected int port = -1;
    /** Flag indicating whether the port will be selected automatically. */
    protected boolean useDefaultPort = true;
    /** Bit vector representing types of blocks that will be instrumented. */
    protected int typeFlags = 0x00000000;
    /** Integer code indicating type of instrumentation to be inserted. */
    protected int instMode = INST_OPT_NORMAL;
    /** Flag indicating that the instrumentation is targeted for a
        JUnit event dispatcher. */
    protected boolean targetJUnit = false;
    /** Handler for class method CFGs. */
    protected CFHandler classGraphs = new CFHandler();
    /** Tag associated with the class database files. */
    protected String tag = null;
    /** CFG for the method currently being instrumented. */
    protected CFG methodCFG = null;
    /** Name of the class upon which instrumentation methods are to be
        invoked. */
    protected String instClassRef = null;

    /** Flag indicating whether the class is an event dispatcher. */
    protected boolean classIsDispatcher = false;
    /** Flag indicating whether the class is SocketProbe. */
    protected boolean classIsSocketProbe = false;
    /** Flag indicating whether the class has a <code>main</code> method. */
    protected boolean classHasMain = false;
    /** Flag indicating whether the class has a static initializer
        (<code>&lt;clinit&gt;</code> method). */
    protected boolean classHasStaticInit = false;
    /** Flag indicating whether the call to <code>SocketProbe.start</code> has
        been inserted. */
    protected boolean starterInserted = false;

    /** Index to <code>SocketProbe.start</code> method reference added to
        constant pool. */
    protected int startMethodref;
    /** Index to probe statement method reference added to constant pool. */
    protected int traceMethodref;
    /** Index to a method reference that should be called on entry to a new
        method, if any. */
    protected int methodEntryMethodref;
    /** Signature of the method currently referenced by instrumentation. */
    protected String mSignature;
    /** Number of blocks in the method currently referenced by
        instrumentation. */
    protected int blockCount;
    /** Index to a local variable in the instrumented method used to hold the
        hit-object array (used by optimized normal and JUnit
        instrumentation). */
    protected int arrayVarref;
    /** Flag used to control whether the summary exit node will be marked on an
        exceptional exit. If the exceptional exit is associated with a
        precisely known control flow path, this flag is set, which signals the
        summary exit node handler not to mark the summary node. */
    protected int excExitBooleanVar;

    /** Cache of instruction handles that begin exception handlers, used
        by sequence instrumentation to guarantee that exceptional returns
        from calls will properly record the change in method to the trace. */
    protected Set handlerStarts = new THashSet();

    /*************************************************************************
     * Protected default constructor, to prevent unsafe instances of
     * the instrumentor from being created.
     */
    protected Instrumentor() { }

    /*************************************************************************
     * Creates am instrumentor configured by a list of command line
     * parameters.
     *
     * @param argv Set of command line parameters, such as would be obtained
     * from {@link sofya.ed.cfInstrumentor}.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws BadFileFormatException If the class is an interface.
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If the class file cannot be parsed.
     * @throws Exception If any other error is raised attempting to parse the
     * class.
     */
    public Instrumentor(String[] argv) throws IllegalArgumentException,
                                              IOException,
                                              ClassFormatError,
                                              Exception {
        parseCommandLine(argv);
        if (className != null) {
            try {
                loadClass(className);
            }
            catch (BadFileFormatException e) {
                System.err.println(e.getMessage());
            }
            catch (FileNotFoundException e) {
                System.err.println("Cannot find class " + className);
            }
        }
    }

    /*************************************************************************
     * Creates an instrumentor for the specified class with the given object
     * types activated for instrumentation and using the default port.
     *
     * @param className Name of the class to be instrumented.
     * @param typeFlags Bit mask representing the types of objects to be
     * instrumented.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws BadFileFormatException If the class is an interface.
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If the class file cannot be parsed.
     * @throws Exception If any other error is raised attempting to parse the
     * class.
     */
    public Instrumentor(String className, int typeFlags)
           throws BadFileFormatException, IllegalArgumentException,
                  IOException, ClassFormatError, Exception {
        if ((typeFlags & BlockType.MASK_VALID) == 0) {
            throw new IllegalArgumentException("No valid block type " +
                                               "specified");
        }
        this.typeFlags = typeFlags;
        parseClass(className, null);
        init(-1);
    }

    /*************************************************************************
     * Creates an instrumentor for the specified class with the given object
     * types activated for instrumentation and using the given port.
     *
     * @param className Name of the class to be instrumented.
     * @param typeFlags Bit mask representing the types of objects to be
     * instrumented.
     * @param port Port to which instrumentation should be set. The valid
     * range is 1024 to 65535.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws BadFileFormatException If the class is an interface.
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If the class file cannot be parsed.
     * @throws Exception If any other error is raised attempting to parse the
     * class.
     */
    public Instrumentor(String className, int typeFlags, int port)
           throws BadFileFormatException, IllegalArgumentException,
                  IOException, ClassFormatError, Exception {
        if ((typeFlags & BlockType.MASK_VALID) == 0) {
            throw new IllegalArgumentException("No valid block type " +
                "specified!");
        }
        this.typeFlags = typeFlags;
        parseClass(className, null);
        if (port < 0) {
            throw new IllegalArgumentException("Port " + port + " out of " +
                "range (valid range is 1024-65535)");
        }
        useDefaultPort = false;
        init(port);
    }

    /*************************************************************************
     * Creates an instrumentor for the specified class with the given object
     * types activated for instrumentation, using the given port, and
     * activating the specified mode of instrumentation.
     *
     * @param className Name of the class to be instrumented.
     * @param typeFlags Bit mask representing the types of objects to be
     * instrumented.
     * @param port Port to which instrumentation should be set. The valid
     * range is 1024 to 65535.
     * @param instMode Integer flag indicating the form of instrumentation to
     * be inserted. Acceptable values are the following:
     * <ul>
     * <li>{@link sofya.base.SConstants#INST_COMPATIBLE}</li>
     * <li>{@link sofya.base.SConstants#INST_OPT_NORMAL}</li>
     * <li>{@link sofya.base.SConstants#INST_OPT_SEQUENCE}</li>
     * </ul>
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws BadFileFormatException If the class is an interface.
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If the class file cannot be parsed.
     * @throws Exception If any other error is raised attempting to parse the
     * class.
     */
    public Instrumentor(String className, int typeFlags,
                        int port, int instMode)
           throws BadFileFormatException, IllegalArgumentException,
                  IOException, ClassFormatError, Exception {
        if ((typeFlags & BlockType.MASK_VALID) == 0) {
            throw new IllegalArgumentException("No valid block type " +
                "specified");
        }
        this.typeFlags = typeFlags;
        parseClass(className, null);
        if (port < 0) {
            throw new IllegalArgumentException("Port " + port + " out of " +
                "range (valid range is 1024-65535)");
        }
        if ((instMode < 1) || (instMode > 4)) {
            throw new IllegalArgumentException("Instrumentation mode is " +
                "invalid");
        }
        this.instMode = instMode;
        useDefaultPort = false;
        init(port);
    }

    /*************************************************************************
     * Parses command line parameters that control aspects of the internal
     * state of the instrumentor.
     *
     * <p><b>Note:</b> Some parameters may need to be processed prior to
     * invocation of this method, such as is done by
     * {@link sofya.ed.cfInstrumentor}, to implement behaviors that should
     * not be reflected in the internal state of the instrumentor itself.</p>
     *
     * @param argv Command line parameters to be parsed.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     */
    protected void parseCommandLine(String[] argv)
                   throws IllegalArgumentException {
        boolean traceTypeSet = false;
        boolean portSet = false;

        /*if (argv.length < 1) {
            throw new IllegalArgumentException("No arguments supplied");
        }*/

        int i = 0;
        while (i < argv.length) {
            if (argv[i].startsWith("-")) {
                if (argv[i].equals("-port")) {
                    if (i + 1 < argv.length) {
                        try {
                            this.port = Integer.parseInt(argv[i + 1]);
                            useDefaultPort = false;
                        }
                        catch (NumberFormatException e) {
                            throw new IllegalArgumentException("Port " +
                                "argument must be numeric value");
                        }
                        i += 1;
                        portSet = true;
                    }
                    else {
                        throw new IllegalArgumentException("Port number not " +
                            "supplied");
                    }
                }
                else if (argv[i].equals("-t")) {
                    if (i + 1 < argv.length) {
                        String param1 = argv[i + 1], param2 = null;
                        int delimPos = -1;
                        if ((delimPos = param1.indexOf(',')) != -1) {
                            param2 = param1.substring(delimPos + 1,
                                                      param1.length());
                            param1 = param1.substring(0, delimPos);
                        }

                        if (param1.equals("comp")) {
                            this.instMode = INST_COMPATIBLE;
                        }
                        else if (param1.equals("norm")) {
                            this.instMode = INST_OPT_NORMAL;
                        }
                        else if (param1.equals("junit")) {
                            this.instMode = INST_OPT_NORMAL;
                            this.targetJUnit = true;
                        }
                        else if (param1.equals("seq")) {
                            this.instMode = INST_OPT_SEQUENCE;
                        }
                        else {
                            throw new IllegalArgumentException(
                                "Instrumentation type '" + argv[i + 1] +
                                "' not recognized");
                        }

                        if ((param2 != null) && param2.equals("junit")) {
                            this.targetJUnit = true;
                        }
                        i += 1;
                    }
                    else {
                        throw new IllegalArgumentException("Instrumentation " +
                            "type not supplied");
                    }
                }
                else if (argv[i].equals("-tag")) {
                    if (i + 1 < argv.length) {
                        tag = argv[i + 1];
                    }
                    else {
                        throw new IllegalArgumentException("Tag value not " +
                            "specified");
                    }
                    i += 1;
                }
                /*else if (argv[i].equals("-o")) {
                    if (i + 1 < argv.length) {
                        outputFile = argv[i + 1];
                        i += 1;
                    }
                    else {
                        throw new IllegalArgumentException("Output file not " +
                            "specified");
                    }
                }*/
                else if ((argv[i].length() <= 7) && (argv[i].length() > 1)
                            && Character.isUpperCase(argv[i].charAt(1))) {
                    traceTypeSet = parseTypeCodes(argv[i]);
                }
                else {
                    throw new IllegalArgumentException("Unrecognized " +
                        "parameter");
                }
            }
            else {
                break;
            }
            i += 1;
        }

        if (!traceTypeSet && (getObjectType() == TraceObjectType.BASIC_BLOCK)) {
            throw new IllegalArgumentException("No object type(s) specified");
        }

        // Check that the user didn't specify a negative port number (negative
        // values are used as an internal signal to determine the port
        // automatically).
        if (portSet && (port < 0)) {
            throw new IllegalArgumentException("Port " + port + " out of " +
                "range (valid range is 1024-65535)");
        }

        if (i < argv.length) {
            this.className = argv[i];
        }
    }

    /*************************************************************************
     * Parses the command-line parameter that specifies the types of objects
     * to be instrumented (eg &apos;-BEXC&apos;, etc.).
     *
     * @param typeCodes Parameter read from command-line, including the
     * leading dash.
     *
     * @return <code>true</code> object types were read from the parameter,
     * <code>false</code> if no types were given.
     *
     * @throws IllegalArgumentException If an unrecognized object type
     * character is encountered.
     */
    protected abstract boolean parseTypeCodes(String typeCodes)
                               throws IllegalArgumentException;

    /*************************************************************************
     * Parses the class, making it ready for instrumentation.
     *
     * <p>Uses BCEL to parse the class file and initialize the internal data
     * structures used for inserting instrumentation.</p>
     *
     * @param className Name of the class to be parsed.
     * @param source Stream from which the class should be parsed. May be
     * <code>null</code>, in which case this method will attempt to load
     * the class from the classpath or the filesystem (in that order).
     *
     * @throws BadFileFormatException If the class is an interface.
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If the class file cannot be parsed.
     * @throws Exception If any other error is raised attempting to parse the
     * class.
     */
    protected void parseClass(String className, InputStream source)
                   throws BadFileFormatException, IOException,
                          ClassFormatError {
        if (source != null) {
            javaClass = new ClassParser(source, className).parse();
        }
        else {
            javaClass = Handler.parseClass(className);
        }

        if (javaClass.isInterface()) {
            throw new BadFileFormatException("Cannot instrument an " +
                "interface (" + className + ")");
        }

        Repository.addClass(javaClass);
        this.className = className;
        this.fullClassName = javaClass.getClassName();
        javaClassFile = new ClassGen(javaClass);
        cpg = javaClassFile.getConstantPool();
        methods = javaClassFile.getMethods();
        iFactory = new InstructionFactory(cpg);
        starterInserted = false;
        lastInstrumented = null;
    }

    /*************************************************************************
     * Initializes the instrumentor, making it ready to instrument methods in
     * the class.
     *
     * <p>Analyzes the class and sets various flags used to control
     * instrumentation. Determines if the subject is a filter class
     * or {@link sofya.ed.structural.SocketProbe}. Determines the default port
     * or checks that the port number is in range if one is specified. Adds
     * the instrumentation method references to the class constant pool.
     * Determines if the class has a static initializer and/or
     * <code>main</code> method to control where to insert the call
     * to <code>SocketProbe.start</code>.
     *
     * @param port Port which is to be used for instrumentation. If a negative
     * number is supplied, the default port is selected. Otherwise, the valid
     * range for this parameter is 1024 to 65535.
     */
    protected void init(int port) throws IOException {
        // Make sure '.class' extension is not attached to class name
        if (className.endsWith(".class")) {
            className =
                className.substring(0, className.lastIndexOf(".class"));
        }

        // No special handling for event dispatchers or SocketProbe if
        // instrumenting for JUnit (there will be no infinitely recursive
        // class reference issues)
        checkForDispatcher:
        if (!targetJUnit) {
            classIsSocketProbe = fullClassName.endsWith("SocketProbe"); //&&
                //fullClassName.startsWith("sofya.inst");

            // Perform various tests to determine if the class in an event
            // dispatcher class

            // Check for known classes that are built on the event dispatchers
            if ("sofya.ed.BBTracer".equals(className)
                    || "sofya.ed.BBSequenceTracer".equals(className)
                    || "sofya.ed.BranchTracer".equals(className)
                    || "sofya.ed.BranchSequenceTracer".equals(className)) {
                classIsDispatcher = true;
                break checkForDispatcher;
            }

            ObjectType dispatcherClass;
            if (fullClassName.startsWith("galileo")) {
                try {
                    Repository.lookupClass("galileo.inst.AbstractFilter");

                    // Later versions of Galileo had AbstractFilter as the
                    // root of the hierarchy, as with Sofya.
                    dispatcherClass =
                        new ObjectType("galileo.inst.AbstractFilter");
                }
                catch (ClassNotFoundException e) {
                    // Earlier versions of Galileo had Filter as the root
                    // of the hierarchy.
                    dispatcherClass = new ObjectType("galileo.inst.Filter");
                }
            }
            else {
                // Initial versions of Sofya had AbstractFilter at the
                // base of the event dispatcher class hierarchy
                try {
                    Repository.lookupClass("sofya.inst.AbstractFilter");

                    dispatcherClass =
                            new ObjectType("sofya.inst.AbstractFilter");
                }
                catch (ClassNotFoundException e) {
                    // AbstractFilter would have to be on the classpath to
                    // run the subject if it was an older version of Sofya,
                    // so if it is not, we know the subject isn't old Sofya
                    classIsDispatcher = false;
                    break checkForDispatcher;
                }
            }

            try {
                classIsDispatcher = (new ObjectType(fullClassName)).subclassOf(
                                dispatcherClass);
            }
            catch (ClassNotFoundException e) {
                throw new IncompleteClasspathException(e);
            }
        }

        instClassRef = (targetJUnit)
                       ? "sofya.ed.structural.JUnitEventDispatcher"
                       : getProbeClassName();
        instClassRef += ((classIsSocketProbe) ||
                         (className.indexOf("SocketProbe$") != -1))
                        ? "Alt" : "";
        startMethodref = (!targetJUnit)
                         ? cpg.addMethodref(instClassRef, "start", "(IIZZI)V")
                         : -1;

        switch (instMode) {
            case INST_COMPATIBLE:
                methodEntryMethodref = cpg.addMethodref(instClassRef,
                    "writeObjectCount", "(Ljava/lang/String;I)V");
                traceMethodref = cpg.addMethodref(instClassRef,
                    "writeTraceMessage", "(ILjava/lang/String;)V");
                break;
            case INST_OPT_NORMAL:
                methodEntryMethodref = cpg.addMethodref(instClassRef,
                    "getObjectArray", "(Ljava/lang/String;I)[B");
                traceMethodref = -1;
                break;
            case INST_OPT_SEQUENCE:
                methodEntryMethodref = cpg.addMethodref(instClassRef,
                    "markMethodInSequence", "(Ljava/lang/String;I)V");
                traceMethodref = cpg.addMethodref(instClassRef,
                    "writeSequenceData", "()V");
                break;
        }

        if (useDefaultPort) {
            if (classIsDispatcher || classIsSocketProbe) {
                this.port = DEFAULT_PORT + 1;
            }
            else {
                this.port = DEFAULT_PORT;
            }
        }
        else {
            if (port < 1024 || port > 65535) {
                throw new IllegalArgumentException("Port " + port + " out " +
                    "of range (valid range is 1024-65535)");
            }
            else {
                this.port = port;
            }
        }

        // We must determine where to insert the call to the SocketProbe start
        // method. Unless the class is SocketProbe, we don't insert the call
        // at all if the class doesn't have a main method. If it has a main
        // method and a static initializer (<clinit> method), it is inserted
        // into the static initializer, since that is the first code that can
        // possibly be run. Otherwise, it is inserted into the main method.
        if (classIsSocketProbe) {
            classHasMain = true;
            classHasStaticInit = true;
        }
        else {
            classHasMain = classHasStaticInit = false;
            for (int i = 0; i < methods.length; i++) {
                if (!classHasMain) {
                    classHasMain = methods[i].getName().equals("main");
                }
                if (!classHasStaticInit) {
                    classHasStaticInit =
                        methods[i].getName().equals("<clinit>");
                }
                if (classHasMain && classHasStaticInit) break;
            }
        }
    }

    /*************************************************************************
     * Loads a new class into the instrumentor.
     *
     * <p><b>Note:</b> If {@link Instrumentor#writeClass} is not called before
     * this method, any instrumentation performed on the last loaded class
     * will be lost.</p>
     *
     * @param className Name of the class to be loaded.
     *
     * @throws BadFileFormatException If the class is an interface.
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If the class file cannot be parsed.
     * @throws Exception If any other error is raised attempting to load the
     * class.
     */
    public void loadClass(String className)
                throws BadFileFormatException, FileNotFoundException,
                       IOException, ClassFormatError, Exception {
        parseClass(className, null);
        init(port);
    }

    /*************************************************************************
     * Loads a new class into the instrumentor, from a given stream.
     *
     * <p><b>Note:</b> If {@link Instrumentor#writeClass} is not called before
     * this method, any instrumentation performed on the last loaded class
     * will be lost.</p>
     *
     * @param className Name of the class to be loaded.
     * @param source Stream from which the class should be read.
     *
     * @throws BadFileFormatException If the specified class is an interface.
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If BCEL cannot parse the class.
     * @throws Exception If any other error is raised attempting to
     * load the class.
     */
    public void loadClass(String className, InputStream source)
                throws BadFileFormatException, IOException,
                       ClassFormatError, Exception {
        if (source == null) {
            throw new NullPointerException();
        }
        parseClass(className, source);
        init(port);
    }

    /*************************************************************************
     * Reloads the current class from file, destroying any instrumentation
     * that has been performed.
     *
     * @throws IOException If there is an error reading the class file.
     * @throws ClassFormatError If the class file cannot be parsed.
     * @throws Exception If any other error is raised attempting to parse the
     * class.
     */
    public void reloadClass() throws IOException, ClassFormatError, Exception {
        loadClass(this.className);
    }

    /*************************************************************************
     * Reloads a method, destroying any instrumentation previously applied to
     * it.
     *
     * @param methodName Name of the method to be reloaded.
     * @param returnType Return type of the method.
     * @param argumentTypes The types of the arguments to the method. Together
     * with the return type, these constitute the signature which will be used
     * to identify a match.
     *
     * @throws MethodNotFoundException If no method matching the specified name
     * and signature can be found.
     */
    public void reloadMethod(String methodName, Type returnType,
                             Type[] argumentTypes)
                             throws MethodNotFoundException {
        for (int i = 0; i < methods.length; i++) {
            if (methods[i].getName().equals(methodName) &&
                Type.getMethodSignature(returnType, argumentTypes)
                    .equals(methods[i].getSignature()))
            {
                javaClassFile.setMethodAt(methods[i], i);
                return;
            }
        }
        throw new MethodNotFoundException(methodName);
    }

    /*************************************************************************
     * Gets the socket port being used for instrumentation.
     *
     * @return The port which is currently being used for instrumentation.
     */
    public int getPort() {
        return port;
    }

    /*************************************************************************
     * Sets the socket port to be used in instrumentation.
     *
     * <p><b>Warning:</b> This method should be used with caution. Only the
     * first occurrence of an invocation of <code>SocketProbe.start</code>
     * during execution will cause the port to be set. The method where the
     * call to <code>SocketProbe.start</code> has been inserted must be
     * re-instrumented for the change to take effect. The
     * {@link Instrumentor#hasMain} and {@link Instrumentor#hasStaticInit}
     * methods can be used to determine which method in the class represents
     * the first executable code that can be run by the class, if that is the
     * preferred location for the call to <code>SocketProbe.start</code>. A
     * call to {@link Instrumentor#instrumentAll} will also cause the change
     * to take effect.
     *
     * @param port Port which is to be used for instrumentation. The valid
     * range is 1024 to 65535.
     * @param auto If <code>true</code>, set to the default port.
     */
    public void setPort(int port, boolean auto) {
        if (auto) {
            useDefaultPort = true;
            if (classIsDispatcher) {
                this.port = DEFAULT_PORT + 1;
            }
            else {
                this.port = DEFAULT_PORT;
            }
        }
        else if (port < 1024 || port > 65535) {
            throw new IllegalArgumentException("Port " + port +
                " out of range (valid range is 1024-65535)");
        }
        else {
            useDefaultPort = false;
            this.port = port;
        }
    }

    /*************************************************************************
     * Gets the name of the class which is currently loaded in the
     * instrumentor.
     *
     * @return The name of the class which is being handled by this
     * instrumentor.
     */
    public String getClassName() {
        return className;
    }

    /*************************************************************************
     * Gets the fully qualified name of the class (includes package name)
     * which is currently loaded in the instrumentor.
     *
     * @return The fully qualified name of the class which is being handled
     * by this instrumentor.
     */
    public String getQualifiedName() {
        return fullClassName;
    }

    /*************************************************************************
     * Gets the form of instrumentation that the instrumentor is currently
     * set to insert, which will be one of the following:
     * <ul>
     * <li>{@link sofya.base.SConstants#INST_COMPATIBLE}</li>
     * <li>{@link sofya.base.SConstants#INST_OPT_NORMAL}</li>
     * <li>{@link sofya.base.SConstants#INST_OPT_SEQUENCE}</li>
     * </ul>
     *
     * @return The form of instrumentation which the instrumentor is set to
     * insert, indicated by one of the above constants.
     */
    public int getInstMode() {
        return instMode;
    }

    /*************************************************************************
     * Sets the form of instrumentation that the instrumentor is to
     * insert.
     *
     * @param instMode Integer flag indicating the form of instrumentation to
     * be inserted. Acceptable values are the following:
     * <ul>
     * <li>{@link sofya.base.SConstants#INST_COMPATIBLE}</li>
     * <li>{@link sofya.base.SConstants#INST_OPT_NORMAL}</li>
     * <li>{@link sofya.base.SConstants#INST_OPT_SEQUENCE}</li>
     * </ul>
     *
     * @throws IllegalStateException If methods in the class have already
     * been instrumented using a different form of instrumentation. Call
     * {@link Instrumentor#reloadClass} to begin instrumenting the current
     * class with a different form of instrumentation.
     * @throws IllegalArgumentException If the instrumentation mode is
     * invalid.
     */
    public void setInstMode(int instMode)
                throws IllegalStateException, IllegalArgumentException {
        if ((this.instMode != instMode) && (lastInstrumented != null)) {
            throw new IllegalStateException("Cannot use two modes of " +
                "instrumentation in one class");
        }
        if ((instMode < 1) || (instMode == 3) || (instMode > 4)) {
            throw new IllegalArgumentException("Instrumentation mode is " +
                "invalid");
        }
        this.instMode = instMode;
    }

    /*************************************************************************
     * Gets the bit mask controlling the object types that are currently set
     * to be instrumented by this instrumentor.
     *
     * @return Bit mask controlling what types of objects are instrumented.
     */
    public int getTypeFlags() {
        return typeFlags;
    }

    /*************************************************************************
     * Sets the bit mask controlling what object types are to be
     * instrumented by this instrumentor.
     *
     * @param typeFlags Bit mask representing the types of objects to be
     * instrumented.
     *
     * @throws IllegalArgumentException If the bit mask doesn't have a set
     * bit which corresponds to a valid object type.
     */
    public abstract void setTypeFlags(int typeFlags);

    /*************************************************************************
     * Gets the structural entity that is instrumented by this instrumentor.
     * This allows the abstract superclass to implement some general
     * functions, simply using dynamic binding to the actual current object
     * to determine proper actions and values when necessary.
     *
     * @return The structural entity (e.g. block, edge) that this instrumentor
     * knows how to instrument.
     */
    protected abstract TraceObjectType getObjectType();

    /*************************************************************************
     * Gets the name of the class referenced by probes inserted by this
     * instrumentor.
     *
     * @return The name of the probe class used by this instrumentor.
     */
    protected abstract String getProbeClassName();

    /*************************************************************************
     * Gets the number of methods in the class.
     *
     * @return The number of methods found in the class.
     */
    public int getMethodCount() {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }
        return methods.length;
    }

    /*************************************************************************
     * Gets the name of a method in the class method array.
     *
     * @param methodIndex Index of the method whose name is to be retrieved.
     *
     * @return The name of the method at the given location in the method
     * array.
     */
    public String getMethodName(int methodIndex) {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }
        if (methodIndex < 0 || methodIndex >= methods.length) {
            throw new IllegalArgumentException("Method index out of range");
        }
        return methods[methodIndex].getName();
    }

    /*************************************************************************
     * Gets the signature of a method in the class method array, as a string.
     *
     * @param methodIndex Index of the method whose name is to be retrieved.
     *
     * @return The signature of the method at the given location in the method
     * array.
     */
    public String getMethodSignature(int methodIndex) {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }
        if (methodIndex < 0 || methodIndex >= methods.length) {
            throw new IllegalArgumentException("Method index out of range");
        }
        return methods[methodIndex].getSignature();
    }

    /*************************************************************************
     * Gets the name of the last method instrumented.
     *
     * <p>This may be useful to determine when a method is actually
     * instrumented. Methods declared as <code>native</code>,
     * <code>abstract</code>, or which have no method body will not cause
     * the value returned by this method to be updated.</p>
     *
     * @return The name of the last method successfully instrumented, or
     * <code>null</code> if no method has been instrumented yet.
     */
    public String getLastInstrumented() {
        return lastInstrumented;
    }

    /*************************************************************************
     * Reports whether the class has a main method.
     *
     * @return <code>true</code> if the class has a <code>main</code> method,
     * <code>false</code> otherwise.
     */
    public boolean hasMain() {
        return classHasMain;
    }

    /*************************************************************************
     * Reports whether the class has a static initializer.
     *
     * @return <code>true</code> if the class has a
     * <code>&lt;clinit&gt;</code> method, <code>false</code> otherwise.
     */
    public boolean hasStaticInit() {
        return classHasStaticInit;
    }

    /*************************************************************************
     * Instruments every method in the class using the current instrumentation
     * settings. This will overwrite any instrumentation previously applied to
     * the methods.
     *
     * <p>This method will automatically determine the correct method into
     * which to insert the call to <code>SocketProbe.start</code>.</p>
     */
    public void instrumentAll() {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }

        starterInserted = false;

        // Iterates through each method to perform instrumentation.
        for (int i = 0; i < methods.length; i++) {
            javaClassFile.setMethodAt(instrument(methods[i], i, false), i);
        }
    }

    /*************************************************************************
     * Instruments the method with the given name and signature using the
     * current instrumentation settings. This will overwrite any
     * instrumentation previously applied to the method.
     *
     * @param methodName Name of the method to be reloaded.
     * @param returnType Return type of the method.
     * @param argumentTypes The types of the arguments to the method. Together
     * with the return type, these constitute the signature which will be used
     * to identify a match.
     * @param insertStarter Flag specifying whether call to
     * <code>SocketProbe.start</code> should be unconditionally inserted at
     * the beginning of this method. The <code>SocketProbe.start</code> method
     * is guarded against multiple invocations, such that only the first
     * occurrence during execution has any effect. Nonetheless, setting this
     * flag should be done with discretion and is generally discouraged. Note
     * also that the {@link Instrumentor#instrumentAll} method will cause the
     * call to be automatically inserted in the appropriate location.
     *
     * @throws MethodNotFoundException If no method matching the specified
     * name and signature can be found.
     */
    public void instrument(String methodName, Type returnType,
                           Type[] argumentTypes, boolean insertStarter)
                           throws MethodNotFoundException {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }

        for (int i = 0; i < methods.length; i++) {
            if (methods[i].getName().equals(methodName) &&
                Type.getMethodSignature(returnType, argumentTypes)
                    .equals(methods[i].getSignature()))
            {
                javaClassFile.setMethodAt(instrument(methods[i], i,
                    insertStarter), i);
                return;
            }
        }
        throw new MethodNotFoundException(methodName);
    }

    /**
     * Instruments a method.
     *
     * <p>Performs the actual instrumentation and update of the method in the
     * class.</p>
     *
     * @param m Method to be instrumented.
     * @param methodIndex Index to the method in the class method array.
     * @param insertStarter If <code>true</code>, force the instrumentor to
     * insert a call to <code>SocketProbe.start</code> at the beginning of
     * this method, otherwise it will be determined automatically whether it
     * should be inserted.
     *
     * @return The instrumented method. If the method is <code>native</code>,
     * <code>abstract</code>, or has no body, it is returned unchanged.
     */
    protected abstract Method instrument(Method m, int methodIndex,
                                         boolean insertStarter);

    /*************************************************************************
     * Inserts call to <code>SocketProbe.start</code> unconditionally at
     * the beginning of the specified method.
     *
     * <p>The <code>SocketProbe.start</code> method is guarded against
     * multiple invocations, such that only the first occurrence during
     * execution has any effect. Nonetheless, this method should be used with
     * discretion and such use is generally discouraged. Note also that the
     * {@link Instrumentor#instrumentAll} method will cause the call to be
     * automatically inserted in the appropriate location.
     *
     * @param methodName Name of the method into which to insert call.
     * @param returnType Return type of the method.
     * @param argumentTypes The types of the arguments to the method. Together
     * with the return type, these constitute the signature which will be used
     * to identify a match.
     *
     * @throws MethodNotFoundException If no method matching the specified
     * name and signature can be found.
     */
    public void insertStarter(String methodName, Type returnType,
                              Type[] argumentTypes)
                              throws MethodNotFoundException {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }

        Method[] instMethods = javaClassFile.getMethods();
        for (int i = 0; i < instMethods.length; i++) {
            if (instMethods[i].getName().equals(methodName) &&
                Type.getMethodSignature(returnType, argumentTypes)
                    .equals(instMethods[i].getSignature()))
            {
                MethodGen mg =
                    new MethodGen(instMethods[i], fullClassName, cpg);
                InstructionList il = mg.getInstructionList();
                insertProbeStartCall(il);
                mg.setInstructionList(il);
                mg.setMaxStack();
                javaClassFile.setMethodAt(mg.getMethod(), i);
                il.dispose();
                return;
            }
        }
        throw new MethodNotFoundException(methodName);
    }

    /*************************************************************************
     * Inserts call to <code>SocketProbe.finish</code> unconditionally at
     * the exit points of the specified method.
     *
     * <p><b>Warning:</b> <i>Use this method with extreme caution.</i> The
     * <code>SocketProbe.finish</code> method causes the SocketProbe to
     * transmit all remaining trace data and close its socket(s). Thus it
     * should be called only once, and after all possible instrumentation
     * has been executed, or errors and data loss will occur. Note also
     * that the {@link Instrumentor#instrumentAll} method will cause the
     * call to be automatically inserted in the appropriate location.</p>
     *
     * @param methodName Name of the method into which to insert call.
     * @param returnType Return type of the method.
     * @param argumentTypes The types of the arguments to the method. Together
     * with the return type, these constitute the signature which will be used
     * to identify a match.
     *
     * @throws MethodNotFoundException If no method matching the specified
     * name and signature can be found.
     */
    public void insertFinisher(String methodName, Type returnType,
                               Type[] argumentTypes)
                               throws MethodNotFoundException {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }

        Method[] instMethods = javaClassFile.getMethods();
        for (int i = 0; i < instMethods.length; i++) {
            if (instMethods[i].getName().equals(methodName) &&
                Type.getMethodSignature(returnType, argumentTypes)
                    .equals(instMethods[i].getSignature()))
            {
                MethodGen mg =
                    new MethodGen(instMethods[i], fullClassName, cpg);
                InstructionList il = mg.getInstructionList();
                addDefaultHandler(mg, il);
                insertProbeFinishCall(il);
                mg.setInstructionList(il);
                mg.setMaxStack();
                javaClassFile.setMethodAt(mg.getMethod(), i);
                il.dispose();
                return;
            }
        }
        throw new MethodNotFoundException(methodName);
    }

    /*************************************************************************
     * Writes the binary instrumented class data to a stream.
     *
     * <p>The class data written constitutes a valid Java class file. In
     * other words, if the output stream is a file, the resulting file will
     * be a valid class file containing any instrumentation that was
     * applied.</p>
     *
     * @param dest Output stream to which class is to be written.
     *
     * @throws IOException If there is an error writing to the stream.
     */
    public void writeClass(OutputStream dest) throws IOException {
        if (javaClass == null) {
            throw new IllegalStateException("No class loaded for " +
                "instrumentation");
        }

        // Commit the updated constant pool
        javaClassFile.setConstantPool(cpg);
        // Write the classfile to the given stream
        javaClassFile.getJavaClass().dump(dest);
    }

    /*************************************************************************
     * Inserts call to
     * {@link sofya.ed.structural.SocketProbe#start(int,int,boolean,boolean,int)}
     * at beginning of method.
     *
     * <p>The call to
     * {@link sofya.ed.structural.SocketProbe#start(int,int,boolean,boolean,int)}
     * will be the very first instruction in the method. It should be inserted
     * into the static initializer (<i>&lt;clinit&gt;</i>), or the main
     * method if no static initializer is present. Otherwise, instrumentation
     * calls to SocketProbe may fail.</p>
     *
     * @param il The instruction list of the method into which the call is
     * to be inserted.
     */
    protected void insertProbeStartCall(InstructionList il) {
        if (startMethodref == -1) {
            if (!targetJUnit) {
                System.err.println("WARNING: Ignoring request to insert " +
                    "start method call (It is unneccessary for the kind of " +
                    "instrumentation requested)");
            }
            return;
        }

        InstructionHandle startIh = il.getStart();
        InstructionList patch = new InstructionList();

        patch.append(new PUSH(cpg, this.port));
        patch.append(new PUSH(cpg, this.instMode));
        // If the subject is an event dispatcher or SocketProbe, and we are
        // instrumenting in compatible mode, set the flags to indicate that
        // trace messages should be timestamped, and the signal socket
        // should be opened. (Optimized sequence mode is not safe when the
        // subject is an event dispatcher).
        if ((classIsDispatcher || classIsSocketProbe)
                && (instMode == INST_COMPATIBLE)) {
            patch.append(new PUSH(cpg, 1));
            patch.append(new PUSH(cpg, 1));
        }
        else {
            patch.append(new PUSH(cpg, 0));
            patch.append(new PUSH(cpg, 0));
        }
        patch.append(new PUSH(cpg, getObjectType().toInt()));
        patch.append(new INVOKESTATIC(startMethodref));

        il.insert(startIh, patch);
        il.setPositions();
        patch.dispose();
    }

    /*************************************************************************
     * Inserts call to {@link sofya.ed.structural.SocketProbe#finish}
     * immediately prior to any <code>return</code> instruction in the method.
     *
     * @param il The instruction list of the method into which the call is to
     * be inserted.
     */
    protected void insertProbeFinishCall(InstructionList il) {
        InstructionHandle ih = il.getStart();
        for ( ; ih != null; ih = ih.getNext()) {
            if (ih.getInstruction() instanceof ReturnInstruction) {
                il.insert(ih, new INVOKESTATIC(cpg.addMethodref(instClassRef,
                                               "finish", "()V")));
                // Update targets of any instructions pointing to the return
                // instruction
                InstructionTargeter[] targeters = ih.getTargeters();
                if (targeters != null) {
                    for (int t = 0; t < targeters.length; t++) {
                        if (targeters[t] instanceof CodeExceptionGen) {
                            CodeExceptionGen exceptionHandler =
                                (CodeExceptionGen) targeters[t];
                            if ((exceptionHandler.getStartPC() == ih) ||
                                    (exceptionHandler.getEndPC() == ih)) {
                                continue;
                            }
                        }
                        targeters[t].updateTarget(ih, ih.getPrev());
                    }
                }
            }
        }
    }

    /*************************************************************************
     * Modifies the <code>main</code> method, if necessary, to prevent
     * unhandled exceptions from being thrown.
     *
     * <p>This method wraps the entire <code>main</code> method with a generic
     * handler for any <code>java.lang.Throwable</code> and eliminates the
     * <code>throws</code> declarations. The handler will emulate the behavior
     * of the <code>ThreadGroup</code> class's <code>uncaughtException</code>
     * method. This is effectively a workaround for a stream-redirection
     * related bug in the SDK or JVM implementation that results in
     * non-deterministic display of subject outputs through Filter when
     * exceptions are thrown from the <code>main</code> method.
     *
     * @param mg The BCEL mutable representation of the method, required to
     * manipulate the throws clauses and handlers associated with the method.
     * @param il The instruction list of the method, used to insert the
     * actual handler instructions.
     */
    protected void addDefaultHandler(MethodGen mg, InstructionList il) {
        /* Note: the default handler is now always added, for the following
           two reasons: 1) It imposes the same simulated determinism
           on unchecked exceptions propagating from main, and 2) It
           provides a convenient mechanism for ensuring
           SocketProbe.finish() is called on any exceptional exit
           from main. */

        // A local variable must be available to hold the exception object
        // received by the catch block. To make sure we don't have any
        // conflicts, we'll just allocate an additional local variable above
        // of any existing ones and use that.
        int maxLocals = mg.getMaxLocals();
        mg.setMaxLocals(maxLocals + 1);

        // Remove all thrown exceptions, since they'll be caught inside the
        // method now
        mg.removeExceptions();

        // If the main method ends in an ATHROW or GOTO, append a regular
        // return. The handler will then get inserted in front of the
        // return and the other instruction will be enclosed in the
        // guarded region.
        InstructionHandle origEnd;
        switch (il.getEnd().getInstruction().getOpcode()) {
        case Constants.ATHROW:
        case Constants.GOTO:
            origEnd = il.getEnd();
            il.append(new RETURN());
            break;
        default:
            origEnd = il.insert(il.getEnd(), new GOTO(il.getEnd()));
            if (origEnd.getPrev() != null) origEnd = origEnd.getPrev();
            break;
        }

        // Build handler instruction sequence
        InstructionList defaultHandler = new InstructionList();
        defaultHandler.append(new ASTORE(maxLocals));
        defaultHandler.append(iFactory.createGetStatic("java.lang.System",
            "out", new ObjectType("java.io.PrintStream")));
        defaultHandler.append(new PUSH(cpg, "Exception in thread " + "\"main" +
            "\" "));
        defaultHandler.append(iFactory.createInvoke("java.io.PrintStream",
            "print", Type.VOID, new Type[]{new ObjectType("java.lang.String")},
            Constants.INVOKEVIRTUAL));
        defaultHandler.append(new ALOAD(maxLocals));
        defaultHandler.append(iFactory.createInvoke("java.lang.Throwable",
            "printStackTrace", Type.VOID, new Type[]{},
            Constants.INVOKEVIRTUAL));

        // Insert handler instructions
        InstructionHandle handlerStart = il.insert(il.getEnd(), defaultHandler);

        il.setPositions();

        // Add handler
        mg.addExceptionHandler(il.getStart(), origEnd, handlerStart,
            (ObjectType) null); // Null catches any type
        defaultHandler.dispose();
    }

    /*************************************************************************
     * Reads the exception handlers associated with the method and caches
     * the starting instruction handle for each handler.
     *
     * <p>During the sequence instrumentation process, this cache is
     * consulted to determine whether a block is the lead block of an
     * exception handler. If it is, a call to record the possible change in
     * method (exceptional return) to the trace is inserted.</p>
     *
     * @param excHandlers Table of exception handlers attached to the method.
     */
    protected void cacheHandlerStarts(CodeExceptionGen[] excHandlers) {
        handlerStarts.clear();
        for (int i = 0; i < excHandlers.length; i++) {
            handlerStarts.add(excHandlers[i].getHandlerPC());
        }
    }

    /*************************************************************************
     * Loads the instruction handles corresponding to the bytecode offsets
     * encoded in the given blocks into the reference fields for those
     * blocks, using the supplied BCEL instruction list to find the
     * handles.
     *
     * <p><b>Warning:</b> This method must be called before any changes are
     * made to the instruction list! By ensuring this condition, this
     * method can use what is presumed to be a faster lookup method
     * to locate handles in the list.</p>
     *
     * @param blocks List of blocks for which the reference fields should
     * be assigned the instruction handles corresponding to the start
     * and end offsets of the block.
     * @param il BCEL instruction list from which instruction handles
     * are to be loaded.
     */
    protected void loadBlockRefs(Block[] blocks, InstructionList il) {
        for (int i = 0; i < blocks.length; i++) {
            blocks[i].setStartRef(il.findHandle(blocks[i].getStartOffset()));
            blocks[i].setEndRef(il.findHandle(blocks[i].getEndOffset()));
        }
    }
}

/*****************************************************************************/
