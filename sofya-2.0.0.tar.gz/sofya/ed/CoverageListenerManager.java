/*
 * Copyright (c) 2003-Present Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.ed;

import sofya.ed.BlockCoverageListener;
import sofya.ed.BranchCoverageListener;

/**
 * <p>A coverage listener manager acts as a server to attach a single
 * coverage listener to a
 * {@link sofya.ed.structural.ProgramEventDispatcher} using a coverage
 * processing strategy during dispatch of coverage events for a particular
 * method. This is a special design to provide maximum performance during
 * coverage event monitoring. If it is desired to dispatch coverage events
 * to multiple coverage listeners simultaneously, the coverage listener
 * manager can serve listeners that perform this service by relaying
 * events to listeners of their own.</p>
 *
 * @see sofya.ed.structural.processors.BlockCoverageProcessingStrategy
 * @see sofya.ed.structural.processors.BranchCoverageProcessingStrategy
 * @see sofya.ed.structural.processors.JUnitBlockCoverageProcessingStrategy
 * @see sofya.ed.structural.processors.JUnitBranchCoverageProcessingStrategy
 *
 * @author Alex Kinneer
 * @version 03/16/2006
 */
public interface CoverageListenerManager {
    /**
     * <p>Initializes the coverage listener manager. Listener managers that
     * need to perform configuration or setup of state that will persist
     * across multiple event streams should implement this method.</p>
     *
     * <p>This method is called automatically by a
     * {@link sofya.ed.structural.JUnitEventDispatcher} prior to beginning
     * execution of test cases. It is the responsibility of the applications
     * using other event dispatchers to call this method at the appropriate
     * time.</p>
     */
    void initialize();

    /**
     * <p>Notification that a new event stream is starting.</p>
     *
     * @param streamId Identifier associated with the event stream, such as
     * a test case number.
     */
    void newEventStream(int streamId);

    /**
     * <p>Notification that an event stream has completed.</p>
     *
     * @param streamId Identifier associated with the finished event stream,
     * such as a test case number.
     */
    void commitCoverageResults(int streamId);

    /**
     * <p>Notification to initialize a basic block listener for a method.</p>
     *
     * @param classAndSignature Concatenation of the fully qualified class
     * name, method name, and JNI signature of the method for which a basic
     * block listener is to be initialized.
     * @param blockCount The number of basic blocks in the method.
     */
    void initializeBlockListener(String classAndSignature, int blockCount);

    /**
     * <p>Notification to initialize a branch listener for a method.</p>
     *
     * @param classAndSignature Concatenation of the fully qualified class
     * name, method name, and JNI signature of the method for which a branch
     * listener is to be initialized.
     * @param branchCount The number of basic blocks in the method.
     */
    void initializeBranchListener(String classAndSignature, int branchCount);

    /**
     * <p>Gets the basic block listener for a particular method.</p>
     *
     * @param classAndSignature Concatenation of the fully qualified class
     * name, method name, and JNI signature of the method for which a basic
     * block listener is to be retrieved.
     */
    BlockCoverageListener getBlockCoverageListener(String classAndSignature);

    /**
     * <p>Gets the branch listener for a particular method.</p>
     *
     * @param classAndSignature Concatenation of the fully qualified class
     * name, method name, and JNI signature of the method for which a branch
     * listener is to be retrieved.
     */
    BranchCoverageListener getBranchCoverageListener(String classAndSignature);
}
