/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.graphs.irg;

import java.io.*;

/**
 * Front end for building Interclass Relation Graphs.
 *
 * <p>This class uses a &apos;<code>.prog</code>&apos; file to construct
 * an interclass relation graph for the specified classes and writes it to
 * a file in the database.</p>
 *
 * <p>Usage:<br><code>java sofya.graphs.irg.jIRG [-tag &lt;tag&gt;]
 * &lt;<i>listfile</i>&gt;</code></p>
 *
 * @author Alex Kinneer
 * @version 04/14/2004
 *
 * @see sofya.graphs.irg.IRG
 */
public final class jIRG {
    /** No reason to instantiate class. */
    private jIRG() { }
    
    /**
     * Prints the usage message and exits with an error code.
     */
    private static void printUsage() {
        System.err.println("Usage:\njava sofya.graphs.irg.jIRG " +
            "[-tag <tag>] <listfile>\n");
        System.exit(1);
    }
    
    /**
     * Entry point for the IRG front end.
     */
    public static void main(String[] argv) {
        if (argv.length < 1 || argv.length > 3) {
            printUsage();
        }
        
        int index = 0;
        
        // Check and set tag name if necessary
        String tag = null;
        if (argv[0].equals("-tag")) {
            if (argv.length < 3) {
                printUsage();
            }
            tag = argv[1];
            index = 2;
        }
        
        IRG irg = null;
        try {
            irg = new IRG(argv[index], tag);
        }
        catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        catch (ClassFormatError e) {
            System.err.println("Class format error: " + e.getMessage());
            System.exit(1);
        }
        
        try {
            IRGHandler.writeIRGFile(argv[index], tag, irg);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
