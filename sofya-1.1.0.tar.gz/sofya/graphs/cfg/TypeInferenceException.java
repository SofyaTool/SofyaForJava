/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.graphs.cfg;

/**
 * Exception thrown to indicate that a failure has occurred in the type
 * inferencing module. These exceptions frequently wrap other exceptions
 * which indicate the true cause of failure.
 *
 * @author Alex Kinneer
 * @version 09/13/2004
 */
public class TypeInferenceException extends Exception {
    /** Wrapped exception which indicates the original reason for failure
        (if applicable). */
    private Throwable cause = null;
    
    /**
     * Creates a type inference exception with no message or causing
     * exception.
     */
    public TypeInferenceException() {
        super();
    }
    
    /**
     * Creates a type inference exception with the specified message and
     * no causing exception.
     * 
     * @param msg Message associated with this exception.
     */
    public TypeInferenceException(String msg) {
        super(msg);
    }
    
    /**
     * Creates a type inference exception with the specified message and
     * causing exception.
     */
    public TypeInferenceException(String msg, Throwable cause) {
        super(msg);
        this.cause = cause;
    }
    
    /**
     * Gets the wrapped exception indicating the original cause for failure.
     *
     * @return The original exception which caused this type inference
     * exception to be raised, may be <code>null</code>.
     */
    public Throwable getCause() {
        return cause;
    }
}
