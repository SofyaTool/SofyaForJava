/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.graphs;

import java.util.*;
import java.io.Serializable;

/**
 * 
 * Class to represent a basic graph, constructed of a set of nodes
 * connected by directed edges. Any specialized graph should be built by
 * deriving from this class.
 *
 * @author Alex Kinneer
 * @version 09/16/2004
 */
public abstract class Graph {
    /** The collection of nodes in the graph. */
    protected List nodes = new ArrayList();
    /** The collection of edges in the graph. */
    protected List edges = new ArrayList();

    /** For use with {@link Graph#getEdges(Node,int,Edge[])}, specifies that
        outgoing edges from the node will be matched. */
    public static final int MATCH_OUTGOING = 0;
    /** For use with {@link Graph#getEdges(Node,int,Edge[])}, specifies that
        incoming edges to the node will be matched. */
    public static final int MATCH_INCOMING = 1;

    /*************************************************************************
     * Inserts a node into the graph.
     *
     * @param n {@link sofya.graphs.Node} to be inserted into the graph.
     */
    protected void addNode(Node n) {
        nodes.add(n);
    }
    
    /*************************************************************************
     * Gets a node by index.  Nodes should be accessed using start-from-one
     * numbering.
     *
     * @param nodeID ID of the node to be retrieved, where the first node in
     * the graph is indexed as 1 (one).
     *
     * @return The node in the graph with the given ID (index).
     */
    public Node getNode(int nodeID) {
        return (Node) nodes.get(nodeID - 1);
    }

    /*************************************************************************
     * Gets the &apos;root&apos; node of the graph, which is defined to be
     * the node with ID 1.  <strong>This is a convenience method only</strong>,
     * the semantics of the method <i>are not</i> strictly enforced and it is
     * perfectly possible for a graph to be constructed where this
     * definition of a root node is meaningless or even misleading.
     *
     * @return The &apos;root&apos; node of the graph.
     */
    public Node getRootNode() {
        return (Node) nodes.get(0);
    }

    /*************************************************************************
     * Removes a node from the graph.
     *
     * @param n {@link sofya.graphs.Node} to be removed from the graph.
     */
    protected void removeNode(Node n) {
        nodes.remove(n);
    }

    /*************************************************************************
     * Adds an edge to the graph.
     *
     * @param e {@link sofya.graphs.Edge} to be added to the graph.
     */
    protected void addEdge(Edge e) {
        edges.add(e);
    }

    /*************************************************************************
     * Removes an edge from the graph.
     *
     * @param e {@link sofya.graphs.Edge} to be removed from the graph.
     */
    protected void removeEdge(Edge e) {
        edges.remove(e);
    }

    /*************************************************************************
     * Gets an edge in the graph. This method will match only the
     * <strong>first</strong> edge which is found to have the given source
     * and sink nodes. Note that edges are searched in the order in which
     * they were added to the graph.
     *
     * @param sourceNode Source node of the edge to be matched.
     * @param sinkNode Sink node of the edge to be matched.
     *
     * @return The edge in the control flow graph with the specified source
     * node and sink node, if any.
     *
     * @throws NoSuchElementException If a matching edge cannot be found in
     * the graph.
     */
    public Edge getEdge(Node sourceNode, Node sinkNode) {
        for (int i = 0; i < edges.size(); i++) {
            Edge e = (Edge) edges.get(i);
            if ((e.predNodeID == sourceNode.nodeID)
                    && (e.succNodeID == sinkNode.nodeID)) {
                return e;
            }
        }
        throw new NoSuchElementException("No matching edge exists in graph");
    }
    
    /*************************************************************************
     * Gets all of the edges in the graph, in the order in which they
     * were added to the graph.
     *
     * @param a Array which will be used to determine the runtime type
     * of the array returned by this method.
     *
     * @return The complete set of edges in the graph, in order of addition.
     */
    public Edge[] getEdges(Edge[] a) {
        return (Edge[]) edges.toArray(a);
    }

    /*************************************************************************
     * Gets all edges which have the given source and sink nodes.
     *
     * <p><i>Special explanatory note regarding CFGs:</i> Under some
     * circumstances, it is possible for switch statements and
     * finally-block returns to have multiple edges which point to the
     * same successor node (e.g. multiple cases point to the same block or
     * multiple exceptions return to the same location after handling).
     * The {@link Graph#getEdge(Node,Node)} method will only return the first
     * matching edge, which may be insufficient.</p> 
     *
     * @param sourceNode Source node of matching edges.
     * @param sinkNode Sink node of matching edges.
     * @param a Array which will be used to determine the runtime type
     * of the array returned by this method.
     *
     * @return The set of edges in the graph with the specified source node
     * and sink node, if any.
     *
     * @throws NoSuchElementException If no matching edges can be found in
     * the graph.
     */
    public Edge[] getEdges(Node sourceNode, Node sinkNode, Edge[] a) {
        LinkedList matchingEdges = new LinkedList();
        for (int i = 0; i < edges.size(); i++) {
            Edge e = (Edge) edges.get(i);
            if ((e.predNodeID == sourceNode.nodeID)
                    && (e.succNodeID == sinkNode.nodeID)) {
                matchingEdges.add(e);
            }
        }
        if (matchingEdges.size() > 0) {
            return (Edge[]) matchingEdges.toArray(a);
        }
        else {
            throw new NoSuchElementException("No matching edges " +
                "exist in graph");
        }
    }

    /*************************************************************************
     * Gets either all the edges which originate on a given node or which are
     * incident on a node.
     *
     * @param n Node for which associated edges will be returned.
     * @param matchType Constant indicating whether edges which start on the
     * node or which end on the node are to be returned. Acceptable values
     * are {@link Graph#MATCH_OUTGOING} and {@link Graph#MATCH_INCOMING}.
     * @param a Array which will be used to determine the runtime type
     * of the array returned by this method.
     *
     * @return Either the set of edges in the graph which start on the given
     * node or the set of edges which end on the node. 
     *
     * @throws NoSuchElementException If no matching edges can be found in
     * the graph.
     */
    public Edge[] getEdges(Node n, int matchType, Edge[] a) {
        LinkedList matchingEdges = new LinkedList();
        for (int i = 0; i < edges.size(); i++) {
            Edge e = (Edge) edges.get(i);
            if ((matchType == MATCH_OUTGOING) && (e.predNodeID == n.nodeID)) {
                matchingEdges.add(e);
            }
            else if ((matchType == MATCH_INCOMING)
                    && (e.succNodeID == n.nodeID)) {
                matchingEdges.add(e);
            }
        }
        if (matchingEdges.size() > 0) {
            return (Edge[]) matchingEdges.toArray(a);
        }
        else {
            throw new NoSuchElementException("No matching edges " +
                "exist in graph");
        }
    }
    
    /*************************************************************************
     * Gets the total number of nodes contained in the graph.
     *
     * @return The number of nodes in the graph.
     */
    public int getNodeCount() {
        return nodes.size();
    }
    
    /*************************************************************************
     * Gets the total number of edges contained in the graph.
     *
     * @return The number of edges in the graph.
     */
    public int getEdgeCount() {
        return edges.size();
    }
    
    /*************************************************************************
     * Clears the graph, such that it has no nodes or edges.
     */
    protected void clear() {
        nodes.clear();
        edges.clear();
    }

    /*************************************************************************
     * Returns string representation of the graph, which is a list of the
     * edges that constitute the graph.
     *
     * @return List of edges that constitute this graph.
     *
     * @see sofya.graphs.Edge#toString()
     */
    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < edges.size(); i++) {
            sb.append(((Edge) edges.get(i)).toString() + "\n");
        }
        return sb.toString();
    }
}

/****************************************************************************/

