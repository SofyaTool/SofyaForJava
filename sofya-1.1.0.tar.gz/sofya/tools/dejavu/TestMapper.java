/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.tools.dejavu;

import java.util.*;
import java.io.FileNotFoundException;
import java.io.IOException;

import sofya.base.exceptions.*;
import sofya.graphs.Edge;
import sofya.tools.th.*;

/**
 * A concrete implementation of this class is responsible for performing
 * the mapping of dangerous edges to tests in the original test suite.
 *
 * @author CS562 2003 dev team.
 * @author Alex Kinneer
 * @version 09/23/2004
 */
public abstract class TestMapper {
    /**
     * Selects tests based on the dangerous edge list for a given
     * method.
     *
     * @param methodName Name of the method for which test selection is
     * occurring.
     * @param dangerousEdges List of dangerous edges found in the method,
     * to be mapped to corresponding tests.
     *
     * @return A selection data object containing information about
     * the selected tests, most importantly the list of selected test numbers.
     *
     * @throws MethodNotFoundException If the method test descriptor references
     * a method that cannot be found in the test history file.
     */
    public abstract SelectionData selectTests(String methodName,
                                              Edge[] dangerousEdges)
                                  throws MethodNotFoundException;
    
    /**
     * Returns the number of tests in the test history.
     *
     * @return The total number of tests.
     */
    public abstract int getTotalNumberOfTests();
}


