/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.tools.dejavu;

/**
 * Data structure which correlates a class name to its location in the
 * two versions of the program.
 *
 * @author Alex Kinneer
 * @version 05/03/2005
 */
public final class ClassPair {
    /** The name of the class. */
    public final String name;
    /** Location of the class in the old version of the program. */
    public final String oldLocation;
    /** Location of the class in the new version of the program. */
    public final String newLocation;
    
    /** Stored hashcode which is computed once for efficiency, since
        this is an immutable object. */
    private int hashCode;
    
    private ClassPair() {
        throw new UnsupportedOperationException();
    }
    
    /**
     * Constructs a new class pair object.
     *
     * @param name Name of the class.
     * @param oldLocation Location of the class in the old version.
     * @param newLocation Location of the class in the new version.
     */
    ClassPair(String name,
              String oldLocation, String newLocation) {
        this.name = name;
        this.oldLocation = oldLocation;
        this.newLocation = newLocation;
        
        computeHashCode();
    }
    
    /**
     * Computes the stored hashcode.
     */
    private void computeHashCode() {
        hashCode = 13;
        hashCode = (31 * hashCode) + name.hashCode();
        hashCode = (31 * hashCode) + oldLocation.hashCode();
        hashCode = (31 * hashCode) + newLocation.hashCode();
    }
    
    public boolean equals(Object obj) {
        if (this == obj) return true;
        
        if (!(obj instanceof ClassPair)) {
            return false;
        }
        
        ClassPair cpObj = (ClassPair) obj;
        if ((cpObj.name != this.name) ||
                (cpObj.oldLocation != this.oldLocation) ||
                (cpObj.newLocation != this.newLocation)) {
            return false;
        }
        
        return true;
    }
    
    public int hashCode() {
        return hashCode;
    }
}
