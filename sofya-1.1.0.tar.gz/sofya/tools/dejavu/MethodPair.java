/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.tools.dejavu;

import sofya.graphs.Graph;
import sofya.graphs.Edge;

/**
 * Data structure which maintains information about the class
 * and methods currently being processed by DejaVu.
 *
 * @author CS562 dev team
 * @author Alex Kinneer
 * @version 05/13/2005
 */
public class MethodPair {
    private MethodPair() {
        throw new UnsupportedOperationException();
    }
    
    public MethodPair(ClassPair clazz, String name,
            Graph oldGraph, Graph newGraph) {
        this.class_ = clazz;
        this.name = name;
        this.oldGraph = oldGraph;
        this.newGraph = newGraph;
    }
    
    /** Information about the class which implements the method in the
        respective versions of the program. */
    public final ClassPair class_;

    /** Name of the method. */
    public final String name;

    /** Graph for the old version of the method. */
    public final Graph oldGraph;

    /** Graph for the new version of the method. */
    public final Graph newGraph;
}
