/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.tools;

import java.io.*;
import java.util.*;
import java.util.jar.*;
import java.util.zip.*;

import sofya.base.*;
import sofya.base.exceptions.*;
import sofya.tools.th.*;
import sofya.graphs.cfg.CFG;
import sofya.graphs.cfg.Block;
import sofya.graphs.cfg.CFHandler;
import sofya.graphs.cfg.CFGCache;
import sofya.inst.Trace;
import sofya.inst.TraceHandler;

import org.apache.commons.collections.map.ReferenceMap;
import gnu.trove.THashMap;

/**
 * The TestHistoryBuilder gathers coverage information from trace files produced
 * by a {@link sofya.inst.ProgramFilter} and uses it to produce test history
 * files for test subjects.
 *
 * <p>Usage:<br><code>java sofya.tools.TestHistoryBuilder -&lt;B|E|X|C&gt;
 * [-tag &lt;tag&gt;] &lt;tracedir&gt; &lt;histfile&gt;
 * &lt;classname|classlist_file&gt;</code><br>
 *
 * <p><b>Note:</b> Arguments must be given in exactly the order shown,
 * including optional arguments when used.</p>
 *
 * <p>A class list file should be a simple text file ending with the extension
 * "<i>.prog</i>" which contains a list of classes, one per line, including all
 * package qualifications. If the fourth argument does not end in
 * "<i>.prog</i>", it will be treated as a single class name.</p>
 *
 * @author Alex Kinneer
 * @version 05/13/2005
 *
 * @see sofya.inst.ProgramFilter
 * @see sofya.tools.th.TestHistory
 * @see sofya.tools.th.TestHistoryHandler
 * @see sofya.viewers.TestHistoryViewer
 */
public final class TestHistoryBuilder implements SConstants {
    /** Convenience reader for the <code>System.in</code> stream. */
    private static final BufferedReader stdin = new BufferedReader(
                                                new InputStreamReader(
                                                    System.in));
    
    /** Stream to which normal builder outputs will be printed. */
    private PrintStream stdout = System.out;
    /** Stream to which error builder outputs will be printed. */
    private PrintStream stderr = System.err;
    
    /** Bit vector representing types of blocks used to build the test history. */
    private int typeFlags = 0x00000000;
    /** Database tag associated with the subject. */
    private String tag = null;
    
    /** Handler for loading CF files. May be used on demand by the memory
        sensitive cache. */
    private CFHandler cfHandler;
    
    /*************************************************************************
     * Creates a test history builder which prints its outputs to the
     * standard streams (<code>System.out</code> and <code>System.err</code>).
     *
     * @param typeFlags Bit mask representing the types of blocks to be
     * instrumented.
     */
    public TestHistoryBuilder(int typeFlags) {
        if ((typeFlags & BlockType.MASK_VALID) == 0) {
            throw new IllegalArgumentException("No valid block type specified");
        }
        this.typeFlags = typeFlags;
    }

    /*************************************************************************
     * Creates a test history builder which prints its outputs to the
     * standard streams (<code>System.out</code> and <code>System.err</code>).
     *
     * @param typeFlags Bit mask representing the types of blocks to be
     * instrumented.
     */
    public TestHistoryBuilder(int typeFlags, String tag) {
        if ((typeFlags & BlockType.MASK_VALID) == 0) {
            throw new IllegalArgumentException("No valid block type specified");
        }
        this.typeFlags = typeFlags;
        if ((tag != null) && (tag.length() == 0)) tag = null;
        this.tag = tag;
    }

    /*************************************************************************
     * Creates a test history builder which prints its outputs to the
     * specified streams.
     *
     * @param typeFlags Bit mask representing the types of blocks to be
     * instrumented.
     */
    public TestHistoryBuilder(int typeFlags, String tag,
                              PrintStream stdout, PrintStream stderr) {
        if ((typeFlags & BlockType.MASK_VALID) == 0) {
            throw new IllegalArgumentException("No valid block type specified");
        }
        this.typeFlags = typeFlags;
        if ((tag != null) && (tag.length() == 0)) tag = null;
        this.tag = tag;
        if ((stdout == null) || (stderr == null)) {
            throw new IllegalArgumentException("Required parameter is null");
        }
        this.stdout = stdout;
        this.stderr = stderr;
    }
    
    /*************************************************************************
     * Sets the stream to which standard outputs will be printed.
     *
     * @param stdout Stream to which standard outputs will be printed.
     */
    public void setStdoutStream(PrintStream stdout) {
        if (stdout == null) {
            throw new IllegalArgumentException("Stream cannot be null");
        }
        this.stdout = stdout;
    }
    
    /*************************************************************************
     * Sets the stream to which standard error outputs will be printed.
     *
     * @param stderr Stream to which error outputs will be printed.
     */
    public void setStderrStream(PrintStream stderr) {
        if (stderr == null) {
            throw new IllegalArgumentException("Stream cannot be null");
        }
        this.stderr = stderr;
    }

    /*************************************************************************
     * Builds test history information for a subject class from a set of
     * traces and writes it to a file.
     *
     * @param traceDir Path to the directory containing the traces from which
     * to gather test history information.
     * @param thFile Name of the test history file to be created.
     * @param classList List of the classes for which test history information
     * is being constructed.
     *
     * @return <code>true</code> if the test history file was successfully
     * written. If <code>false</code>, the reason for failure will be printed
     * to the error stream.
     */
    public boolean buildTestHistory(String traceDir, String thFile,
                                    List classList) {
        if ((traceDir == null) || (thFile == null) || (classList == null)) {
            throw new IllegalArgumentException("Required parameter is null");
        }
        
        // Get the list of trace files
        File tDir = new File(traceDir);
        if (!tDir.exists()) {
            stderr.println("Trace directory cannot be found");
            return false;
        }
        if (!tDir.canRead()) {
            stderr.println("Cannot read trace directory");
            return false;
        }
        
        String[] fileList = (tDir.list(new FilenameFilter() {
                                 public boolean accept(File dir, String name) {
                                     if (name.endsWith(".tr")) return true;
                                     return false;
                                 }
                             }));
        
        if (fileList.length == 0) {
            stderr.println("No .tr files found in directory");
            return false;
        }

        Arrays.sort(fileList, new NumericStringComparator());
        //for (int i = 0; i < fileList.length; i++)
        //    System.out.print(fileList[i] + " ");
        
        CFGCache procCFGs = new CFGCache();
        TraceHandler trHandler = new TraceHandler();
        TestHistoryHandler thHandler = new TestHistoryHandler(typeFlags);
        Map nameSigMap = new THashMap();
        cfHandler = new CFHandler(procCFGs);
        
        // Tell the handler to collect all the CFGs, instead of clearing
        // them out each time a new control flow file is read
        cfHandler.setClearOnLoad(false);
        
        // Iterate over the classes creating empty test histories for each
        // method and caching the CFGs for block-type screening later
        String[] procList = null;
        CFG procCFG = null;
        String className;
        int size = classList.size();
        Iterator iterator = classList.iterator();
        for (int i = size; i-- > 0; ) {
            className = (String) iterator.next();
            
            try {
                cfHandler.readCFFile(className + ".java", tag);
            }
            catch (FileNotFoundException e) {
                stderr.println("WARNING: CF file does not exist for class " +
                    className);
                continue;
            }
            catch (BadFileFormatException e) {
                stderr.println(e.getMessage());
                return false;
            }
            catch (EmptyFileException e) {
                stderr.println("WARNING: CF file for class " + className +
                    " is empty");
                continue;
            }
            catch (IOException e) {
                stderr.println("I/O error: \"" + e.getMessage() +
                               "\" while reading CF file for class " +
                               className);
                return false;
            }

            Iterator procs = procCFGs.iterator(className);
            while (procs.hasNext()) {
                procCFG = (CFG) procs.next();
                
                MethodSignature mSig = procCFG.getSignature();
                if (mSig == null) {
                    stderr.println("Cannot operate on legacy control flow " +
                        "files");
                    return false;
                }
                
                // For now, traces still don't use signatures
                String mName = procCFG.getMethodName();
                nameSigMap.put(mName, mSig);
                
                thHandler.setTestHistory(mName, new TestHistory(
                    procCFG.getHighestNodeId(), fileList.length));
            }
        }
        
        // Now iterate over all of the trace files, and for each match hit
        // blocks to test histories for all methods of interest.
        TestHistory th;
        Trace trace;
        procList = thHandler.getMethodList();
        for (int testNum = 0; testNum < fileList.length; testNum++) {
            String traceFile =
                traceDir + File.separatorChar + fileList[testNum];
            // Read the trace
            try {
                trHandler.readTraceFile(traceFile);
            }
            catch (EmptyFileException e) {
                continue;
            }
            catch (BadFileFormatException e) {
                 stderr.println("Error opening trace file " +
                     fileList[testNum]);
                 stderr.println(e.getMessage());
                 return false;
            }
            catch (IOException e) {
                stderr.println("I/O error: \"" + e.getMessage() +
                               "\" while reading trace file for " + traceFile);
                return false;
            }
            
            for (int i = 0; i < procList.length; i++) {
                if (!trHandler.containsTrace(procList[i])) {
                    // This method wasn't hit by the trace
                    continue;
                }
                
                try {
                    trace = trHandler.getTrace(procList[i]);
                }
                catch (MethodNotFoundException e) {
                    // Strange, this shouldn't happen because of the
                    // existence check above.
                    continue;
                }
                
                MethodSignature mSig =
                    (MethodSignature) nameSigMap.get(procList[i]);
                procCFG = (CFG) procCFGs.get(mSig).getGraph();
                
                if (procCFG.getHighestNodeId() != trace.getHighestBlockID()) {
                    stderr.println("Mismatch in block count in trace " +
                        traceFile.substring(0, traceFile.lastIndexOf('.')) +
                        ".");
                    stderr.println("  (" + procCFG.getSignature() + ")");
                    return false;
                }
                try {
                    th = thHandler.getTestHistory(procList[i]);
                }
                catch (MethodNotFoundException e) {
                    e.printStackTrace(stderr);
                    return false;
                }
                for (int blockID = 1; blockID <= trace.getHighestBlockID(); blockID++) {
                    BlockType nodeType = procCFG.getBlock(blockID).getType();
                    int mask = nodeType.toMask();
                    
                    if ((typeFlags & mask) == mask) {
                        if (trace.query(blockID)) {
                            th.set(blockID, testNum);
                        }
                    }
                }
            }
        }

        // Write test history file
        try {
            thHandler.writeTestHistoryFile(thFile);
        }
        catch (IOException e) {
            stderr.println("I/O error: \"" + e.getMessage() +
                "\" while writing test history file '" + thFile + "'");
            return false;
        }
        return true;
    }
    
    /*************************************************************************
     * A string comparator which pads the beginning of the shorter string
     * with zeros before performing the lexographical comparison. Strings
     * of equal length are ordered using the usual lexographic definition.
     *
     * <p>For strings whose leading characters are numeric, this effectivly
     * imposes correct numeric ordering on the strings. This is primarily
     * intended for use in ordering a list (array) of numbered trace files,
     * where normal lexographic sorting will yield a list of the form
     * [ 0.tr 1.tr 10.tr ... 19.tr 2.tr ... ] rather than the desired
     * [ 0.tr 1.tr 2.tr ... 10.tr ... 19.tr 20.tr ... n.tr ].</p>
     */
    private class NumericStringComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            String str1 = (String) o1;
            String str2 = (String) o2;
            int compareLength = (str1.length() > str2.length()) ? str1.length() : str2.length();
            for (int i = compareLength - str1.length(); i > 0; i--) {
                str1 = "0" + str1;
            }
            for (int i = compareLength - str2.length(); i > 0; i--) {
                str2 = "0" + str2;
            }
            return str1.compareTo(str2);
        }
    }

    /*************************************************************************
     * Entry point for the test history builder.
     */
    public static void main(String[] argv) {
        String traceDir = null, thFile = null, tag = null;
        int typeFlags = 0x00000000;
        int argIndex = 1;
        List classList = new ArrayList();
        
        try {
            if (argv.length < 1) {
                System.err.println("USAGE: java sofya.tools.TestHistoryBuilder -<B|E|X|C> [-tag <tag>] " +
                                   "<tracedir> <test_history_file> <classname|classlist_file>");  
                System.exit(1);
            }

            // Keep things simple - first argument _must_ be block type parameter
            for (int i = 1; i < argv[0].length(); i++) {
                switch(argv[0].charAt(i)) {
                    case 'B':
                        typeFlags |= BlockType.MASK_BASIC;
                        break;
                    case 'E':
                        typeFlags |= BlockType.MASK_ENTRY;
                        break;
                    case 'X':
                        typeFlags |= BlockType.MASK_EXIT;
                        break;
                    case 'C':
                        typeFlags |= BlockType.MASK_CALL;
                        break;
                    case 'R':
                        typeFlags |= BlockType.MASK_RETURN;
                        break;
                    default:
                        System.err.println("Invalid block type");
                        System.exit(1);
                }
            }
            if ((typeFlags & BlockType.MASK_VALID) == 0) {
                System.err.println("No valid block type specified");
                System.exit(1);
            }

            // If tag is used, it _must_ be second argument
            if ((argv.length > 1) && argv[1].equals("-tag")) {
                if (argv.length > 2) {
                    tag = argv[2];
                    argIndex = 3;
                }
                else {
                    System.err.println("Tag value not specified");
                    System.exit(1);
                }
            }

            // if no arguments given, prompt for test dir name
            if (argv.length < (argIndex + 1)) {
                System.out.print("Enter test directory name: ");
                traceDir = stdin.readLine();
            }
            else { // test directory is first argument
                traceDir = argv[argIndex];
            }
            argIndex += 1;

            // if necessary, prompt for test history file name
            if (argv.length < (argIndex + 1)) {
                System.out.print("Enter test history file name: ");   
                thFile = stdin.readLine();   
            }
            else { // test history file name is second argument
                thFile = argv[argIndex]; 
            }
            argIndex += 1;
            
            if (argv.length < (argIndex + 1)) {
                System.out.print("Enter tested class name: ");
                classList.add(stdin.readLine());
            }
            else {
                // List of classes/jars/'prog'-files follows
                List unitList = new ArrayList();
                while (argIndex < argv.length) {
                    if (argv[argIndex].endsWith(".prog")) {
                        try {
                            Handler.readProgFile(argv[argIndex], tag, unitList);
                            
                            int size = unitList.size();
                            Iterator units = unitList.iterator();
                            for (int i = size; i-- > 0; ) {
                                ProgramUnit pUnit = (ProgramUnit) units.next();
                                classList.addAll(pUnit.classes);
                            }
                        }
                        catch (IOException e) {
                            System.err.println(e.getMessage());
                            System.exit(1);
                        }
                    }
                    else if (argv[argIndex].endsWith(".jar")) {
                        try {
                            Handler.readJarClasses(argv[argIndex], classList);
                        }
                        catch (IOException e) {
                            System.err.println(e.getMessage());
                            System.exit(1);
                        }
                    }
                    else {
                        classList.add(argv[argIndex]);
                    }
                    argIndex += 1;
                }
            }
            
            //System.out.println("traceDir: " + traceDir + "\nthFile: " + thFile + "\nprogName: " + progName);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        TestHistoryBuilder thBuilder = new TestHistoryBuilder(typeFlags, tag);
        
        long startTime = System.currentTimeMillis();
        
        if (!thBuilder.buildTestHistory(traceDir, thFile, classList)) {
            System.err.println("Test history construction failed");
            System.exit(1);
        }
        
        long endTime = System.currentTimeMillis();
        //System.out.println("Time elapsed (ms): " + (endTime - startTime));
    }
}
