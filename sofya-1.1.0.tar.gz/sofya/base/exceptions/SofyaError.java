/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base.exceptions;

/**
 * Error which indicates that a serious internal error has occurred in
 * the Sofya system.
 *
 * @author Alex Kinneer
 * @version 09/23/2004
 */
public class SofyaError extends Error {
    private Throwable cause = null;
    
    /**
     * Creates a new Sofya error.
     */
    public SofyaError() {
        super();
    }
    
    /**
     * Creates a new Sofya error with a given message.
     *
     * @param msg Message describing the error.
     */
    public SofyaError(String msg) {
        super(msg);
    }
    
    /**
     * Creates a new Sofya error with a message and encapsulating an
     * original cause for failure.
     *
     * @param msg Message describing the error.
     * @param cause Exception which indicated the error.
     */
    public SofyaError(String msg, Throwable cause) {
        super(msg);
        this.cause = cause;
    }
    
    /**
     * Gets the exception that is the original source of the error
     * (may be <code>null</code>).
     */
    public Throwable getCause() {
        return cause;
    }
}
