/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base.exceptions;

/**
 * Error which indicates that an internal assertion has been violated.
 *
 * @author Alex Kinneer
 * @version 09/23/2004
 */
public class AssertError extends SofyaError {
    /**
     * Creates a new assertion error.
     */
    public AssertError() {
        super();
    }
    
    /**
     * Creates a new assertion error with a given message.
     *
     * @param msg Message to be associated with the assertion.
     */
    public AssertError(String msg) {
        super(msg);
    }
    
    /**
     * Convenience method to automatically raise an instance of this error
     * if a given condition is not true.
     *
     * @param condition Condition which must be true.
     *
     * @throws An instance of this class if <code>condition</code> is false.
     */
    public static void assertTrue(boolean condition) {
        if (!condition) {
            throw new AssertError();
        }
    }
}
