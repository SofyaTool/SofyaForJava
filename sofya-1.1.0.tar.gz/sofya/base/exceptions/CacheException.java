/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base.exceptions;

/**
 * Defines an exception which indicates that something prevented a
 * cache or cache-related operation from being serviced.
 *
 * @author Alex Kinneer
 * @version 09/08/2004
 */
public class CacheException extends RuntimeException  {
    /** Wrapped exception that is the original cause, if applicable. */
    private Throwable cause = null;
    
    /** Create an instance with no message. */
    public CacheException() { super(); }
    
    /** Create an instance with the given message. */
    public CacheException(String s) { super(s); }
    
    /** Creates an instance with the given message wrapping another
        exception. */
    public CacheException(String s, Throwable e) {
        super(s);
        cause = e;
    }
    
    /** Gets the exception that is the original source of the problem
        (may be <code>null</code>). */
    public Throwable getCause() {
        return cause;
    }
}
