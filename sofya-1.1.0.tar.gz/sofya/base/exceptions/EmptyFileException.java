/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base.exceptions;

/**
 * Defines an exception which indicates that a given file contains no data.
 *
 * @author Hitesh Sharma
 * @version 07/04/2002
 */
public class EmptyFileException extends java.io.IOException {
    /*************************************************************************
     * Creates new instance of this exception using the default message.
     */
    public EmptyFileException() {
        super("File is Empty");
    } 

    /*************************************************************************
     * Creates new instance of this exception with a given message.
     *
     * @param msg Message to be associated with this exception in place
     * of the default message.
     */
    public EmptyFileException(String msg) { 
        super(msg) ;
    }
}



/*****************************************************************************/

/*
  $Log: EmptyFileException.java,v $
  Revision 1.2  2005/06/06 18:47:11  kinneer
  Added copyright notices.

  Revision 1.1.1.1  2005/01/06 17:34:16  kinneer
  Sofya Java Bytecode Instrumentation and Analysis System

  Revision 1.6  2003/08/18 18:42:44  kinneer
  See v2.1.0 release notes for details.

  Revision 1.5  2003/08/13 18:28:36  kinneer
  Release 2.0, please refer to release notes for details.

  Revision 1.4  2003/08/01 17:10:46  kinneer
  All file handler implementations changed from HashMaps to TreeMaps.
  See release notes for additional details.  Version string for
  Galileo has been set.

  All classes cleaned for readability and JavaDoc'ed.

  Revision 1.3  2002/07/04 06:56:48  sharmahi
  galileo/src/handlers/AbstractFile.java

  Revision 1.2  2002/06/25 09:09:56  sharmahi
  Added Package name "handlers"

*/