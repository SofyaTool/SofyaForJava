/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base;

import java.util.List;
import java.util.ArrayList;

/**
 * Encapsulates information about a set of classes constituting a portion
 * of a program. Typically used to identify classes contained in jar files
 * and/or specified in &apos;prog&apos; files.
 *
 * @author Alex Kinneer
 * @version 06/01/2005
 */
public class ProgramUnit {
    /** The location where class files associated with this program unit
        can be found. */
    public final String location;
    /** The classes associated with this program unit. */
    public final List classes;
    
    /** Flag specifying whether the location field should be considered
        valid. If <code>false</code>, tools should assume that entries
        in the class list may already include path information. */
    public final boolean useLocation;
    /** Flag specifying whether the location field points to a jar file. */
    public final boolean isJar;
    
    /**
     * Creates a default program unit.
     *
     * <p>The <code>location</code> field will be <code>null</code>,
     * the <code>useLocation</code> field set to <code>false</code>,
     * and the <code>isJar</code> field set to <code>false</code>.</p>
     *
     * <p>This constructor is typically used to create a &quot;default&quot;
     * program unit which contains the class names specified as arguments to
     * a tool. Some tools prefer to process such entries directly and should
     * be able to accommodate entries which already have associated path
     * information.</p> 
     */
    public ProgramUnit() {
        this.location = null;
        this.useLocation = false;
        this.isJar = false;
        this.classes = new ArrayList();
    }
    
    /**
     * Creates a program unit to specify classes at a specific location.
     *
     * <p>The <code>isJar</code> field is automatically set by parsing
     * the provided location field. The <code>location</code> field is
     * always set to <code>true</code> by this constructor.</p>
     *
     * @param location Name of the directory or jar file which constitutes
     * this program unit.
     *
     */
    public ProgramUnit(String location) {
        this.isJar = location.endsWith(".jar");
        this.useLocation = true;
        
        if (!isJar && !location.endsWith("/")) {
            location += "/";
        }
        
        this.location = location;
        this.classes = new ArrayList();
    }
    
    /**
     * Creates a program unit to specify classes at a specific location
     * with particular characteristics.
     *
     * <p>This constructor is primarily intended to be used for
     * deserialization.</p>
     *
     * @param location Name of the directory or jar file which constitutes
     * this program unit.
     * @param useLocation Flag specifying whether the location should be
     * considered valid.
     * @param isJar Flag specifying whether the location points to a
     * jar file.
     * @param classes List of classes constituting the program unit.
     */
    public ProgramUnit(String location, boolean useLocation, boolean isJar,
            List classes) {
        this.location = location;
        this.useLocation = useLocation;
        this.isJar = isJar;
        this.classes = classes;
    }
    
    /**
     * Adds a class to this program unit.
     *
     * @param className Name of the class to be added to this program unit.
     */
    public void addClass(String className) {
        classes.add(className);
    }
}
