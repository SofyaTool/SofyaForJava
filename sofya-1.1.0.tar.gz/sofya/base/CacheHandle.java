/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base;

import java.io.File;

/**
 * Handle to a cache directory in the Sofya database.
 *
 * <p>A cache handle is issued by {@link sofya.base.Handler#newCache}
 * and is used by other cache-related methods to uniquely identify the
 * cache on which an operation should be performed. The primary purpose
 * of this design is to reduce the probability that different clients will
 * inadvertently operate on the same cache.</p>
 *
 * @author Alex Kinneer
 * @version 11/29/2004
 */
public final class CacheHandle {
    /** File handle to the directory with which this cache handle
        is associated. */
    private File cacheDir = null;

    /** No argument constructor is invalid. */
    private CacheHandle() { }
    
    /**
     * Creates a new cache handle linked to a specified cache directory.
     *
     * @param cacheDir File handle to the cache directory with which
     * this cache handle is associated.
     */
    CacheHandle(File cacheDir) {
        if (cacheDir == null) {
            throw new NullPointerException();
        }
        this.cacheDir = cacheDir.getAbsoluteFile();
    }
    
    /**
     * Gets the file handle for the underlying cache directory.
     *
     * @return File handle to the cache directory with which this cache
     * handle is associated.
     */
    File getDirectory() {
        return cacheDir;
    }
    
    /**
     * Converts this cache handle to a string.
     *
     * @return A string containing the path to the underlying cache directory.
     */
    public String toString() {
        return cacheDir.toString() + File.separatorChar;
    }
}
