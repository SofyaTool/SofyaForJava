/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.Type;
import org.apache.bcel.generic.ObjectType;

/**
 * Defines general utility methods that belong to no class in particular.
 *
 * @author Alex Kinneer
 * @version 12/07/2004
 */
public class Utility {
    /** The utility class need not be instantiated. */
    private Utility() { }
    
    /**
     * Converts a BCEL <code>Type</code> object to its corresponding
     * <code>java.lang.Class</code>.
     *
     * @param t BCEL type object to be converted.
     *
     * @return The class object corresponding to the given BCEL type.
     *
     * @throws ClassNotFoundException If the corresponding class cannot be
     * found by the classloader (most often because it is not on the
     * classpath), or if the BCEL type is <code>Type.UNKNOWN</code>.
     */
    public static Class typeToClass(Type t)
                        throws ClassNotFoundException {
        switch (t.getType()) {
        case Constants.T_BOOLEAN:
            return Boolean.TYPE;
        case Constants.T_CHAR:
            return Character.TYPE;
        case Constants.T_FLOAT:
            return Float.TYPE;
        case Constants.T_DOUBLE:
            return Double.TYPE;
        case Constants.T_BYTE:
            return Byte.TYPE;
        case Constants.T_SHORT:
            return Short.TYPE;
        case Constants.T_INT:
            return Integer.TYPE;
        case Constants.T_LONG:
            return Long.TYPE;
        case Constants.T_VOID:
            return Void.TYPE;
        case Constants.T_ARRAY:
            return Class.forName(t.getSignature().replace('/', '.'));
        case Constants.T_OBJECT:
            return Class.forName(((ObjectType) t).getClassName());
        default:
            throw new ClassNotFoundException();
        }
    }
    
    /**
     * Converts an array of BCEL <code>Type</code> objects to their
     * corresponding <code>java.lang.Class</code> objects.
     *
     * @param ts BCEL type objects to be converted.
     *
     * @return The class objects corresponding to the given BCEL types.
     *
     * @throws ClassNotFoundException If a corresponding class cannot be
     * found by the classloader (most often because it is not on the
     * classpath), or if a BCEL type is <code>Type.UNKNOWN</code>.
     */
    public static Class[] typesToClasses(Type[] ts)
                          throws ClassNotFoundException {
        int size = ts.length;
        Class[] classes = new Class[size];
        for (int i = 0; i < size; i++) {
            classes[i] = typeToClass(ts[i]);
        }
        return classes;
    }
    
}
