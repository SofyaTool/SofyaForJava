/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.base;

import java.io.OutputStream;
import java.io.IOException;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

/**
 * Specialized <code>JarOutputStream</code> which disables the
 * <code>close()</code> method.
 *
 * <p>Using this class protects a JarOutputStream from being
 * arbitrarily closed when an external method is called to write
 * data to the stream. The <code>closeStream</code> method
 * may be used instead to close the stream. Specifically, this
 * class is used to protect a JarOutputStream from closure
 * by the <code>dump</code> method of the BCEL
 * <code>JavaClass</code> class.
 *
 * @author Alex Kinneer
 * @version 09/16/2004
 */
public class ProtectedJarOutputStream extends JarOutputStream {
    /**
     * Creates a ProtectedJarOutputStream which writes to the given
     * underlying stream.
     *
     * @param out Any output stream to which Jar file data is to be
     * written.
     */
    public ProtectedJarOutputStream(OutputStream out) throws IOException {
        super(out);
    }
        
    /**
     * Creates a ProtectedJarOutputStream which writes to the given
     * underlying stream and inserts the provided manifest file into
     * the Jar file.
     *
     * @param out Any output stream to which Jar file data is to be
     * written.
     * @param man Manifest to be inserted into the Jar file.
     */
    public ProtectedJarOutputStream(OutputStream out, Manifest man) throws IOException {
        super(out, man);
    }
        
    /**
     * Null override to prevent the stream from being closed with this
     * method.
     *
     * @throws IOException Never for this method.
     */
    public void close() throws IOException { }
        
    /**
     * Actually closes the stream.
     */
    public void closeStream() throws IOException {
        super.close();
    }
}
