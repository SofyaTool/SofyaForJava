/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.viewers;

/**
 * An exception that indicates that a given file name is already in use.
 *
 * @author Hitesh Sharma
 * @version 07/08/2002
 */
public class SameFileNameException extends java.io.IOException {
    /*************************************************************************
     * Creates new instance of this exception using the default message.
     */
    public SameFileNameException() {
        super("Output file has same name") ;
    } 

    /*************************************************************************
     * Creates new instance of this exception with a given message.
     *
     * @param msg Message to be associated with this exception in place
     * of the default message.
     */
    public SameFileNameException(String msg) { 
        super(msg) ;
    }
}



/*****************************************************************************/

/*
  $Log: SameFileNameException.java,v $
  Revision 1.3  2005/10/12 19:08:59  kinneer
  Minor JavaDoc revision.

  Revision 1.2  2005/06/06 18:48:08  kinneer
  Added copyright notices.

  Revision 1.1.1.1  2005/01/06 17:34:16  kinneer
  Sofya Java Bytecode Instrumentation and Analysis System

  Revision 1.4  2003/08/18 18:43:33  kinneer
  See v2.1.0 release notes for details.

  Revision 1.3  2003/08/13 18:28:53  kinneer
  Release 2.0, please refer to release notes for details.

  Revision 1.2  2003/08/01 17:13:54  kinneer
  Viewers interface deprecated. Viewer abstract class introduced. See
  release notes for additional details.

  All classes cleaned for readability and JavaDoc'ed.

  Revision 1.1  2003/03/03 20:41:00  aristot
  Moved SameFileNameException to viewers dir

  Revision 1.2  2002/07/08 05:45:36  sharmahi
  Added package name

  Revision 1.1  2002/07/03 06:16:16  sharmahi
  galileo/src/handlers/AbstractFile.java

  Revision 1.2  2002/06/25 09:09:56  sharmahi
  Added Package name "handlers"

*/