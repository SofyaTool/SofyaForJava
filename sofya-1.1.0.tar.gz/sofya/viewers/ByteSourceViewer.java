/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.viewers;

import java.io.*;
import java.util.*;

import sofya.base.ByteSourceHandler;
import sofya.base.exceptions.*;

import org.apache.bcel.*;
import org.apache.bcel.generic.*;
import org.apache.bcel.classfile.*;

/**
 * The ByteSourceViewer is used to display a human-readable listing of the
 * compiled Java bytecode for a class. Instructions are listed using the
 * assembly mnemonics defined by the Java Virtual Machine specification.
 *
 * <p>Usage:<br><code>java sofya.viewers.ByteSourceViewer
 * &lt;SourceFile&gt; [OutputFile]<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[OutputFile] :
 * Redirect output of viewer to <i>OutputFile</i><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Do not include <i>.class</i> extension
 * with <i>SourceFile</i>)</code></p>
 *
 * @author Alex Kinneer
 * @version 04/05/2004
 */
public class ByteSourceViewer extends Viewer {
    /** File handler for the class file being viewed. */
    private ByteSourceHandler inputHandler = new ByteSourceHandler();
    /** Specifies the name of a particular method to be viewed in the class. */
    private String methodName = null;

    /*************************************************************************
     * Standard constructor, creates a ByteSourceViewer to display the
     * contents of the specified Java class to the system console
     * (<code>System.out</code>).
     *
     * @param inputFile Name of the Java class whose bytecode is to be
     * displayed.
     */ 
    public ByteSourceViewer(String inputFile) {
        super(inputFile);
    }
    
    /*************************************************************************
     * Standard constructor, creates a ByteSourceViewer to display the
     * contents of the specified Java class to the specified output file.
     *
     * @param inputFile Name of the Java class whose bytecode is to be
     * displayed.
     * @param outputFile Name of the file to which the viewer output should
     * be written.
     *
     * @throws SameFileNameException If the specified output file and input
     * file are the same file.
     * @throws IOException If there is an error creating the output file.
     */ 
    public ByteSourceViewer(String inputFile, String outputFile)
           throws SameFileNameException, IOException {
        super(inputFile, outputFile);
    }
    
    /*************************************************************************
     * Standard constructor, creates a ByteSourceViewer to display the
     * contents of the specified Java class to the specified output stream.
     *
     * <p><b>Note:</b> When using {@link Viewer#print()}, an output file
     * specified using {@link Viewer#setOutputFile} takes precedence over
     * the specified stream.</p>
     *
     * @param inputFile Name of the Java class whose bytecode is to be
     * displayed.
     * @param stream Stream to which the viewer output should be written.
     */ 
    public ByteSourceViewer(String inputFile, OutputStream stream) {
        super(inputFile, stream);
    }
    
    /*************************************************************************
     * Prints the bytecode for the Java class to the specified stream.
     *
     * @param stream Stream to which the bytecode should be written.
     *
     * @throws IOException If there is an error writing to the stream, or
     * creating the output file, if applicable.
     */ 
    public void print(PrintWriter stream) throws IOException {
        inputHandler.readSourceFile(inputFile);
        String[] methods = inputHandler.getMethodList();
        String methodCode = null;
        
        for (int i = 0; i < methods.length; i++) {
            if ((methodName == null) || (methods[i].indexOf(methodName) != -1)) {
                stream.println(methods[i]);
                try {
                    methodCode = inputHandler.getSource(methods[i]);
                    stream.println(methodCode);
                }
                catch (MethodNotFoundException dontCare) { }
            }
        }
    }
    
    /*************************************************************************
     * Prints the ByteSourceViewer usage message and exits.
     */ 
    private static void printUsage() {
        System.err.println("Usage: java sofya.viewers.ByteSourceViewer " +
            "<source_class> [output_file]");
        System.exit(1);
    }
    
    /*************************************************************************
     * Entry point for ByteSourceViewer.
     */ 
    public static void main(String argv[]) {
        if (argv.length < 1 || argv.length > 4) {
            printUsage();
        }

        try {
            ByteSourceViewer bsView = new ByteSourceViewer(argv[0]);
            int i = 1; for ( ; i < argv.length; i++) {
                if (argv[i].equals("-method")) {
                    if (i + 1 < argv.length) {
                        bsView.methodName = argv[++i];
                    }
                    else {
                        System.err.println("Method name missing");
                        System.exit(1);
                    }
                }
                else {
                    bsView.setOutputFile(argv[i]);
                }
            }
            bsView.print();
        }
        catch (IOException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (ClassFormatException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (RuntimeException e) {
            throw e;
        }
        catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}



/*****************************************************************************/

/*
  $Log: ByteSourceViewer.java,v $
  Revision 1.2  2005/06/06 18:48:08  kinneer
  Added copyright notices.

  Revision 1.1.1.1  2005/01/06 17:34:16  kinneer
  Sofya Java Bytecode Instrumentation and Analysis System

  Revision 1.9  2004/04/29 20:04:59  kinneer
  Changed to produce more useful output on unexpected errors.

  Revision 1.8  2004/04/07 22:13:36  kinneer
  Minor change to argument processing for easier extensibility.

  Revision 1.7  2004/04/03 00:10:33  kinneer
  Added parameter to allow viewing of individual methods' bytecodes.

  Revision 1.6  2003/09/25 16:39:38  kinneer
  Modified to handle new possibility of MethodNotFoundExceptions thrown
  from handlers.

  Revision 1.5  2003/08/27 18:45:12  kinneer
  Release 2.2.0.  Additional details in release notes.

  Revision 1.4  2003/08/18 18:43:32  kinneer
  See v2.1.0 release notes for details.

  Revision 1.3  2003/08/13 18:28:52  kinneer
  Release 2.0, please refer to release notes for details.

  Revision 1.2  2003/08/01 17:13:54  kinneer
  Viewers interface deprecated. Viewer abstract class introduced. See
  release notes for additional details.

  All classes cleaned for readability and JavaDoc'ed.

  Revision 1.1  2003/03/03 20:35:43  aristot
  Moved ByteSourceViewers to viewers dir

  Revision 1.2  2002/08/21 06:27:53  sharmahi
  removed line numbers being output.

  Revision 1.1  2002/08/07 07:57:03  sharmahi
  After adding comments

*/      
   
      
