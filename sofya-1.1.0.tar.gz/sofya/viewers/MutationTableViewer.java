/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.viewers;

import java.io.PrintWriter;
import java.io.OutputStream;
import java.io.IOException;

import sofya.base.exceptions.SofyaError;
import sofya.mutator.*;

/**
 * The MutationTableViewer is used to display the a mutation table in a
 * human readable format, or as a list for processing.
 *
 * <p>Usage:<br>
 * <code>java sofya.viewers.MutationTableViewer &lt;mutation_table_file&gt;
 * [-t <i>l|d</i>] [OutputFile]<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-t <i>l|d</i> : Format of the output.<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OutputFile : Redirect output of viewer
 * to <i>OutputFile</i>
 * </code></p>
 *
 * @author Alex Kinneer
 * @version 10/10/2005
 */
public class MutationTableViewer extends Viewer {
    /** Output format specifier. */
    private int format = LIST;
    
    /** Constant flag for list format. */
    public static final int LIST = 0;
    /** Constant flag for descriptive format. */
    public static final int DESCRIPTIVE = 1;
    
    /**
     * Mutation visitor that instructs visited mutations to print themselves.
     */
    private static class PrintVisitor implements MutationVisitor {
        private PrintWriter pw;
        private int format = LIST;
        
        /** Offset used for indentation of mutations in mutation groups. */
        private int tabOffset = 0;
        
        private PrintVisitor() {
        }
        
        public PrintVisitor(int format, PrintWriter pw) {
            this.pw = pw;
            this.format = format;
        }
        
        public void visit(Mutation m) {
            print(m);
        }
        
        public void visit(MutationGroup m, boolean start) {
            if (start) {
                print(m);
                tabOffset += 1;
                m.visitMembers(true);
            }
            else {
                tabOffset -= 1;
            }
        }
        
        public void visit(GroupableMutation m) {
            print(m);
        }
        
        public void visit(ClassMutation m) {
            print(m);
        }
        
        public void visit(MethodMutation m) {
            print(m);
        }
        
        private void print(Mutation m) {
            for (int i = 0; i < tabOffset; i++) {
                pw.print("    ");
            }
            
            switch (format) {
            case LIST:
                pw.println(m.print());
                break;
            case DESCRIPTIVE:
                pw.println(m);
                break;
            default:
                throw new SofyaError("Illegal format");
            }
        }
    }
    
    /**********************************************************************
     * Creates a MutationTableViewer to display a mutation table.
     * 
     * @param inputFile Name of the mutation table file to be displayed.
     * @param format Output format to be used. Should be one of the
     * following:
     * <ul>
     * <li>MutationTableViewer.LIST</li>
     * <li>MutationTableViewer.DESCRIPTIVE</li>
     * </ul>
     */
    public MutationTableViewer(String inputFile, int format) {
        super(inputFile);
        setOutputFormat(format);
    }
    
    /**********************************************************************
     * Creates a MutationTableViewer to display a mutation table in the
     * specified format to the specified output file.
     * 
     * @param inputFile Name of the mutation table file to be displayed.
     * @param outputFile Name of the file to which the viewer output should
     * be written.
     * @param format Output format to be used. Should be one of the
     * following:
     * <ul>
     * <li>MutationTableViewer.LIST</li>
     * <li>MutationTableViewer.DESCRIPTIVE</li>
     * </ul>
     */
    public MutationTableViewer(String inputFile, String outputFile, int format)
                               throws SameFileNameException, IOException {
        super(inputFile, outputFile);
        setOutputFormat(format);
    }
    
    /**********************************************************************
     * Creates a MutationTableViewer to display a mutation table in the
     * specified format to the specified output stream.
     * 
     * @param inputFile Name of the mutation table file to be displayed.
     * @param stream Stream to which the viewer output should be written.
     * @param format Output format to be used. Should be one of the
     * following:
     * <ul>
     * <li>MutationTableViewer.LIST</li>
     * <li>MutationTableViewer.DESCRIPTIVE</li>
     * </ul>
     */
    public MutationTableViewer(String inputFile, OutputStream stream,
                               int format) {
        super(inputFile, stream);
        setOutputFormat(format);
    }

    /*************************************************************************
     * Sets the output format to be used.
     *
     * @param format Output format to be used. Should be one of the
     * following:
     * <ul>
     * <li>MutationTableViewer.LIST</li>
     * <li>MutationTableViewer.DESCRIPTIVE</li>
     * </ul>
     *
     * @throws IllegalArgumentException If the specified output format is
     * not recognized.
     */ 
    public void setOutputFormat(int format) {
        if ((format < 0) || (format > 1)) {
            throw new IllegalArgumentException("Invalid output format");
        }
        this.format = format;
    }
    
    /*************************************************************************
     * Gets the output format currently set to be used.
     *
     * @return An integer representing the currently specified output
     * format (see {@link MutationTableViewer#setOutputFormat}).
     */ 
    public int getOutputFormat() {
        return format;
    }
    
    public void print(PrintWriter pw) throws IOException {
        PrintVisitor printer = new PrintVisitor(format, pw);
        
        MutationIterator mutants = MutationHandler.readMutationFile(inputFile);
        int count = mutants.count();
        for (int i = count; i-- > 0; ) {
            Mutation m = mutants.nextMutation();
            
            try {
                m.accept(printer);
            }
            catch (MutationException e) {
                IOException ioe = new IOException("Error printing mutation");
                ioe.initCause(e);
                throw ioe;
            }
        }
    }
    
    /*************************************************************************
     * Prints the usage message and exits.
     */ 
    private static void printUsage() {
        System.err.println("Usage: java sofya.viewers.MutationTableViewer " +
                           "<mutation_table_file> [-t <l|d>] [output_file]");
        System.exit(1);
    }
    
    public static void main(String[] argv) {
        int format = LIST;
        String outputFile = null;

        if (argv.length < 1) {
            printUsage();
        }
        
        int argIndex = 1;
        
        for ( ; argIndex < argv.length; argIndex++) {
            if (argv[argIndex].equals("-t")) {
                argIndex += 1;
                if (argIndex == argv.length) {
                    printUsage();
                }
                if (argv[argIndex].equals("l")) {
                    format = LIST;
                }
                else if (argv[argIndex].equals("d")) {
                    format = DESCRIPTIVE;
                }
                else {
                    System.out.println("Invalid output format");
                    printUsage();
                }
            }
            else if (!argv[argIndex].startsWith("-")) {
                break;
            }
        }

        if (argIndex < argv.length) {
            outputFile = argv[argIndex];
        }
        
        try {
            MutationTableViewer mtv = new MutationTableViewer(argv[0], format);
            if (outputFile != null) {
                mtv.setOutputFile(outputFile);
            }
            mtv.print();
        }
        catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (RuntimeException e) {
            throw e;
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }

    }
}
