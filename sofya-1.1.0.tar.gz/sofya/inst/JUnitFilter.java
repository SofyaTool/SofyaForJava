/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.net.*;
import java.util.*;

import sofya.base.Handler;
import sofya.base.ProjectDescription;
import sofya.base.exceptions.*;

import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.collections.MapIterator;

import gnu.trove.TIntObjectHashMap;
import gnu.trove.TObjectIntHashMap;

/**
 * A JUnitFilter is intended for use by a JUnit test runner to generate
 * traces from JUnit test cases run on an instrumented subject.
 *
 * <p>JUnitFilter does not provide any mechanism for invoking a subject class
 * in a separate virtual machine, has a restricted set of configuration
 * options, and exposes special methods for controlling the writing of
 * trace files.  It is expected that an instance of a JUnitFilter class will be
 * created inside a JUnit test runner (the single instance restriction still
 * applies). Instrumented JUnit test suites and test cases can then be run,
 * using a TestListener (part of the JUnit framework) to initiate writing of
 * trace files at the appropriate times. It is strongly recommended that the
 * listener regularly issue calls to the <code>checkError</code> method to
 * ensure timely termination in the event of a failure. This class requires
 * that the subject classes be instrumented using the '<code>junit</code>'
 * mode of instrumentation (see {@link sofya.inst.cfInstrumentor}).</p>
 *
 * <p>This class cannot be run directly from the command line.</p>
 *
 * @author Alex Kinneer
 * @version 10/01/2004
 */
public abstract class JUnitFilter extends AbstractFilter {
    /** Control flag specifying that a coverage trace should be generated. */
    public static final int COVERAGE_TRACE = 1;
    /** Control flag specifying that a sequence trace should be generated. */
    public static final int SEQUENCE_TRACE = 2;

    /** Maximum number of methods for which byte arrays can be cached
        when handling optimized normal instrumentation. */
    protected static final int OBJECT_ARRAY_CACHE_SIZE = 1000;
    
    /** Size of the array which records object sequence information
        when handling optimized sequence instrumentation. */
    protected static final int SEQUENCE_ARRAY_SIZE = 8192;
    /** Reference to this filter instance. Used to bind calls to virtual
        methods that are implemented by concrete subclasses to provide
        processing appropriate to the type of instrumentation on which
        they operate. */
    protected static JUnitFilter theFilter = null;

    /** Specifies what type of trace JUnitFilter will produce. */
    protected static int filterMode = COVERAGE_TRACE;
    /** Indicates the type of instrumentation present in the subject. Note that
        this is automatically detected, and JUnitFilter will reject subjects
        with mixed instrumentation.*/
    protected static int instMode = -1;

    /** Storage location for exceptions raised during trace processing; rethrown
        by the <code>checkError</code> method if non-null. */
    protected static Exception storedException = null;
    // Only one instance is allowed, so static is okay

    /** LRU cache which holds the byte arrays recording which objects have been
        hit in each method. If the cache fills, data is written to the trace
        before the oldest array is removed from the cache. */
    protected static LRUTraceMap traceObjArrays;
      /* Using an LRU map creates a rough upper bound on memory consumption.
         Assuming an average of 100 blocks in a typical method (probably even
         a little high), allocating a cache for 1000 methods limits the
         memory usage to (1 * 100 * 1000) = 100,000 bytes, or about 100K. Do
         NOT set this value too low, or performance will suffer severely as the
         system spends too much time shifting entries in and out of the cache
         and writing redundant data to the trace. */
    /** Current trace being recorded. */
    protected static Trace methodTrace;

    /** Array which stores the hit object IDs sequentially, using
        special marker/index pairs to indicate entry into new methods.
        It is public so that the instrumentation is not required
        to make a method call to retrieve a reference to it. */
    public static int[] sequenceArray;
    /** Index pointing to the next open entry in the sequence array.
        Instrumentation is responsible for updating this pointer when
        recording an object ID, and calling
        <code>writeSequenceData</code> when the array is filled. */
    public static int sequenceIndex = 0;
    /** Stores the signature string of the method for which objects
        are currently being recorded. This is required when object
        IDs for a method bridge an array transmit-and-reset event. */ 
    protected static String currentMethodSig = null;
    /** Maps indices following new method markers to the signature
        string for that method. */
    protected static TIntObjectHashMap indexToNameMap;
    /** Maps signature strings for a method to an already assigned
        index, if any. */
    protected static TObjectIntHashMap nameToIndexMap;
    /** Holds the next value available for use as an index to a
        method signature string. */
    protected static int nextMethodIndex = 0;
    /** Stack which holds the signatures of methods on the call stack.
        Used in basic block sequence tracing to ensure that blocks are
        associated with the correct method after returning from a called
        method. */
    protected static LinkedList methodSigStack;
    /** Writer for sequence output file. */
    protected static PrintWriter pw;

    /** Socket to which processed trace information should be relayed. */
    private static Socket relaySocket = null;

    /** String containing data to be recorded prior to trace data. */
    private static String preData = null;
    /** String containing data to be recorded after processing of trace data. */
    private static String postData = null;
    /** Flag which controls whether processed trace data is relayed to another
        socket or written to a file. */
    protected static boolean relayToSocket = false;

    /** Flag which indicates if an instrumentation error (wrong mode of
        instrumentation) has been detected. It is used to suppress repeat
        messages. */
    protected static boolean instError = false;

    /*************************************************************************
     * Creates a JUnitFilter with a default configuration.
     *
     * <p>The filter will be configured to perform a coverage trace
     * using the default trace file name.</p>
     */
    protected JUnitFilter() throws IllegalArgumentException, CreateException {
        appendToTrace = false;
        trName = "instout";
        theFilter = this;
        instanceReady = true;
    }

    /*************************************************************************
     * Creates a JUnitFilter with the specified configuration.
     *
     * @param typeFlags Bit mask representing the types of objects
     * to be traced.
     * @param appendToTrace If <code>true</code>, filter will append the
     * current trace information to any existing trace file. Otherwise any
     * previous trace file will be overwritten. (See note above)
     * @param trName Name of the trace file to be written. (See note above)
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws CreateException If there is already an instance of a filter
     * created which has not been destroyed (see
     * {@link sofya.inst.AbstractFilter#destroy}).
     */
    protected JUnitFilter(int typeFlags, boolean appendToTrace, String trName)
              throws IllegalArgumentException, CreateException {
        try {
            configureFilter(typeFlags, appendToTrace, trName);
        }
        catch (ExecException cannotHappen) { }
        theFilter = this;
        instanceReady = true;
    }

    /*************************************************************************
     * Destroys this filter instance, making it possible to create a new
     * instance.
     *
     * <p>This override will additionally insure that the relay socket
     * is closed, if applicable.</p>
     */
    public void destroy() {
        if (filterMode == SEQUENCE_TRACE) {
            if (relayToSocket) {
                if (postData != null) {
                    pw.print(postData + "\n");
                    pw.print("\n");
                    pw.flush();
                }
                if (pw.checkError()) {
                    System.err.println("WARNING: Error writing finishing data to trace");
                }
                pw.close();

                try {
                    relaySocket.close();
                }
                catch (IOException e) {
                    System.err.println("WARNING: Attempt to close relay socket failed.");
                }
                relaySocket = null;
            }
        }
        
        cleanup();
        // Internal implementation clears the relayToSocket flag, so we
        // have to call it after we checked the flag
        destroy(true);
    }

    protected void destroy(boolean makeUnrunnable) {
        super.destroy(makeUnrunnable);
        filterMode = COVERAGE_TRACE;
        instMode = -1;
        relayToSocket = false;
        preData = null;
        postData = null;
    }

    /*************************************************************************
     * Gets the program entity that is traced by this filter.
     * This allows the abstract superclass to implement some general
     * functions, simply using dynamic binding to the actual current object
     * to determine proper actions and values when necessary.
     *
     * @return The program entity (e.g. block, edge) that this filter
     * knows how to trace.
     */
    protected abstract TraceObjectType getObjectType();

    /*************************************************************************
     * Initializes the JUnitFilter such that it is ready to process
     * instrumentation and generate trace files.
     *
     * @throws SetupException If there is an error attempting to set up this
     * filter to receive instrumentation.
     * @throws TraceFileException If the append to trace option is enabled
     * and the existing trace is not compatible with the current
     * configuration; if the relay to socket option is enabled and the
     * connection cannot be made.
     */
    public void initialize() throws SetupException, TraceFileException {
        if (!instanceReady) {
            throw new SetupException("JUnitFilter is no longer runnable, a " +
                "new instance must be created");
        }
        
        switch (filterMode) {
        case COVERAGE_TRACE:
            traceHandler = new TraceHandler(typeFlags, getObjectType());
            if (appendToTrace) {
                try {
                    traceHandler.readTraceFile(ProjectDescription.dbDir +
                        File.separatorChar + trName + ".tr");
                }
                catch (EmptyFileException e) {
                    // To avoid the exception below. Since it's empty anyway,
                    // we can just override the block types.
                    traceHandler.setTypeFlags(typeFlags);
                }
                catch (FileNotFoundException e) {
                    // To avoid the exception below. We'll just create it.
                    traceHandler.setTypeFlags(typeFlags);
                }
                catch (BadFileFormatException e) {
                    throw new TraceFileException("Cannot append to trace - " +
                        "the existing trace is invalid: " + e.getMessage());
                }
                catch (IOException e) {
                    throw new TraceFileException("I/O error: \"" +
                        e.getMessage() + "\" attempting to read existing " +
                        "trace");
                }
                
                if (traceHandler.getTypeFlags() != typeFlags) {
                    throw new TraceFileException("Selected trace object " +
                        "types do not match types in existing trace");
                }
            }
            else {
                traceHandler.setTypeFlags(typeFlags);
            }
            break;
        case SEQUENCE_TRACE:
            if (relayToSocket) {
                if (relaySocket == null) {
                    try {
                        relaySocket =
                            new Socket(SequentialFilter.relaySocketAddr,
                                       SequentialFilter.relaySocketPort);
                        pw = new PrintWriter(
                             new BufferedWriter(
                             new OutputStreamWriter(
                                 relaySocket.getOutputStream())));
                    }
                    catch (Exception e) {
                        e.printStackTrace(System.err);
                        throw new TraceFileException("Could not create " +
                            "relay socket");
                    }
                }
                if (preData != null) {
                    pw.print(preData);
                    if (pw.checkError()) {
                        System.err.println("WARNING: Error writing starting " +
                            "data to trace");
                    }
                }
            }
            break;
        default:
            throw new IllegalStateException("Unrecognized filter mode");
        }
    }

    /*************************************************************************
     * Initializes the data structures necessary to process the instrumentation
     * detected in the subject. All invocations subsequent to the first must
     * specify the same form of instrumentation, or the method will fail. In
     * practice it should only be called once.
     *
     * @param _instMode Type of instrumentation detected in the subject.
     *
     * @throws IllegalStateException If this method has previously been called
     * with a different mode of instrumentation.
     */
    protected static void setup(int _instMode) {
        if ((instMode != -1) && (instMode != _instMode)) {
            throw new IllegalStateException("Subject contains inconsistent " +
                "instrumentation");
        }
        instMode = _instMode;
        
        // Initialize data structures
        switch (instMode) {
        case INST_COMPATIBLE:
            break;
        case INST_OPT_NORMAL:
            traceObjArrays = new LRUTraceMap(OBJECT_ARRAY_CACHE_SIZE);
            break;
        case INST_OPT_SEQUENCE:
            sequenceArray = new int[SEQUENCE_ARRAY_SIZE];
            Arrays.fill(sequenceArray, 0);
            indexToNameMap = new TIntObjectHashMap();
            nameToIndexMap = new TObjectIntHashMap();
            methodSigStack = new LinkedList();
            break;
        default:
            throw new IllegalArgumentException("Subject contains " +
                "unrecognized type of instrumentation");
        }
    }

    /*************************************************************************
     * Clears instrumentation data structures (for the next test case).
     */
    protected void reset() {
        if (instMode == -1) return;
        
        switch (instMode) {
            case INST_COMPATIBLE:
                break;
            case INST_OPT_NORMAL:
                traceObjArrays.clear();
                break;
            case INST_OPT_SEQUENCE:
                sequenceIndex = 0;
                currentMethodSig = null;
                methodSigStack.clear();
                break;
            default:
                throw new IllegalStateException("Unrecognized type of " +
                    "instrumentation");
        }
    }
    
    /*************************************************************************
     * Signals that a new trace file is to be generated.
     *
     * <p>During sequence traces, this causes the next trace file to be
     * opened for output.  The previous trace file must be moved after
     * calling {@link JUnitFilter#writeTraceFile} but prior to calling this
     * method or it will be overwritten (unless JUnitFilter is set to
     * append traces). This is handled automatically when using the
     * <code>'-o'</code> option to the <code>SelectiveTestRunner</code>.</p>
     *
     * <p>This method also resets the flag indicating whether a test case
     * was instrumented.</p>
     *
     * @param testNumber Number associated with the current test (used for
     * sequence traces).
     *
     * @throws TraceFileException If there is an error writing the trace
     * file.
     */ 
    public void newTraceFile(int testNumber) throws TraceFileException {
        isInstrumented = false;

        if (filterMode == SEQUENCE_TRACE) {
            if (!relayToSocket) {
                try {
                    pw = new PrintWriter(
                         new BufferedWriter(
                         new OutputStreamWriter(
                         Handler.openOutputFile(
                             trName + ".seq", null, appendToTrace))));
                }
                catch (Exception e) {
                    e.printStackTrace(System.err);
                    throw new TraceFileException("Could not create trace file");
                }
            }
            pw.print(testNumber);
        }
    }

    /*************************************************************************
     * Writes a trace file for the current test case.
     *
     * <p>The type of trace file written will depend on the current filter
     * mode. Additionally, depending on input parameters, when generating a
     * sequence trace the output may be redirected to a socket and thus no
     * output file will be produced. Data structures for handling
     * instrumentation will be reset for the next test case.</p>
     *
     * @throws TraceFileException If there is an error writing the trace
     * file.
     */ 
    public void writeTraceFile() throws TraceFileException {
        try {
            if (instMode != -1) {
                finish();
            }
            // else we haven't inferred what type of instrumentation is present,
            // which is only possible if none has been encountered yet. Thus
            // we don't need to worry about any unprocessed cached data.
        
            switch (filterMode) {
            case COVERAGE_TRACE:
                try {
                    traceHandler.writeTraceFile(trName, false);
                }
                catch (IOException e) {
                    e.printStackTrace();
                    throw new TraceFileException("Cannot write out the trace " +
                        "file");
                }
                finally {
                    if (!appendToTrace) {
                        traceHandler.clear();
                    }
                }
                break;
            case SEQUENCE_TRACE:
                pw.print(")x");
                if (relayToSocket) {
                    pw.print("\n");
                }
                else {
                    pw.print(" ");
                }
                pw.flush();
                if (!relayToSocket) {
                    pw.close();
                }
                if (pw.checkError()) {
                    System.err.println("WARNING: Error writing to trace");
                }
                break;
            default:
                throw new IllegalStateException("Unrecognized filter mode");
            }
        }
        finally {
            reset();
        }
    }
    
    /*************************************************************************
     * Checks whether the last test case was instrumented.
     *
     * <p>If the test case executed instrumented code, this method will
     * return <code>true</code> until the next call to
     * {@link JUnitFilter#newTraceFile}, otherwise it returns
     * <code>false</code>.</p>
     *
     * @return <code>true</code> if the last test case executed instrumented
     * code and <code>newTraceFile</code> has not yet been called,
     * <code>false</code> otherwise.
     */
    public boolean checkInstrumented() {
        return isInstrumented;
    }
    
    /*************************************************************************
     * Checks whether any exceptions have been raised during processing, and
     * rethrows the exception for handling if so. This method returns without
     * action if there are no errors.
     *
     * @throws ExecException If the exception raised is specific in some way
     * to the execution of the filter.
     * @throws Exception For all other exceptions that have been raised and
     * stored.
     */
    public void checkError() throws ExecException, Exception {
        if (storedException != null) {
            throw storedException;
        }
    }
    
    /*************************************************************************
     * Cleans up after filter is done executing.
     */
    protected void cleanup() {
        if (pw != null) {
            pw.flush();
            pw.close();
            pw = null;
        }
    }
    
    /*************************************************************************
     * Checks that the type of instrumentation is compatible with JUnitFilter.
     * This also makes the instrumentor implementation easier by allowing it to
     * simply change the name of the class the instrumentation-related methods
     * are invoked on depending on what type of instrumentation it has been
     * directed to insert.
     *
     * <p><strong>Note: It is not necessary for a subject to call this method
     * to be properly traced</strong> (assuming the instrumentation is
     * appropriate). This method is merely provided to assist the
     * instrumentor.</p>
     *
     * @param port <i>Ignored.</i>
     * @param _instMode Flag indicating the type of instrumentation present in
     * the subject. All types are supported as long as the instrumentation is
     * targeted for JUnitFilter.
     * @param _doTimestamps <i>Ignored.</i>
     * @param _useSignalSocket <i>Ignored.</i>
     * @param _entityType <i>Ignored</i>
     */
    public static void start(int port, int _instMode, boolean _doTimestamps,
                             boolean _useSignalSocket, int _entityType) {
        if ((_instMode < 1) || (_instMode > 4)) {
            if (!instError) {
                System.err.println("Cannot process type of instrumentation " +
                    "present in subject!");
                instError = true;
            }
            return;
        }
    }

    /*************************************************************************
     * Ensures that all data currently in the cache is written to the
     * trace, guaranteeing that it will be complete.
     */ 
    public static void finish() {
        switch (instMode) {
        case INST_COMPATIBLE:
            break;
        case INST_OPT_NORMAL:
            MapIterator it = traceObjArrays.orderedMapIterator();
            while (it.hasNext()) {
                String mSig = (String) it.next();
                theFilter.writeTraceData(it.getValue(), mSig, -1, -1);
            }
            break;
        case INST_OPT_SEQUENCE:
            writeSequenceData();
            break;
        default:
            throw new IllegalStateException("Unrecognized type of " +
                "instrumentation");
        }
    }

    /*************************************************************************
     * Writes all currently witnessed objects to the trace.
     *
     * <p>This method is virtual so that subclasses can provide processing
     * specific to the type of instrumentation they operate on. Where
     * appropriate, static instrumentation methods invoke this method on the
     * internal reference to this filter object, which should be initialized by
     * the constructor.</p>
     *
     * @param objects Reference to a (Java) Object or object array containing
     * trace object information to be recorded in the trace. The type of this
     * argument depends on the type of instrumentation, so a generic Object
     * reference is used.
     * @param mSignature Signature of the method for which the object
     * data is to be written.
     * @param fromIndex Pointer to the element in the array from which
     * the method should start reading object information. This parameter is
     * ignored unless handling sequence instrumentation.
     * @param toIndex Pointer to the element in the array at which the method
     * should stop reading object information. This parameter is ignored
     * unless handling sequence instrumentation.
     */ 
    protected abstract void writeTraceData(Object objects, String mSignature,
                                           int fromIndex, int toIndex);

    /*************************************************************************
     * Notifies JUnitFilter of the number of blocks in the current method
     * so that a trace of the correct size can be allocated (if necessary).
     * This method is retained for compatibility with previous instrumentation.
     *
     * @param mSignature Signature of the method for which the block count
     * is being sent.
     * @param blockCount Number of blocks in the method.
     */ 
    public static void writeBlockCount(String mSignature, int blockCount) {
        writeObjectCount(mSignature, blockCount);
    }

    /*************************************************************************
     * Notifies JUnitFilter of the number of objects in the current method
     * so that a trace of the correct size can be allocated (if necessary).
     *
     * @param mSignature Signature of the method for which the object count
     * is being sent.
     * @param objCount Number of objects in the method.
     */ 
    public static void writeObjectCount(String mSignature, int objCount) {
        mSignature = mSignature.replace('@', '.');
        if (filterMode == COVERAGE_TRACE) {
            if (!traceHandler.containsTrace(mSignature)) {
                traceHandler.setTrace(mSignature, new Trace(objCount));
            }
        }
    }

    /*************************************************************************
     * Marks a single object in the trace; used by compatible mode
     * instrumentation.
     *
     * @param bId The ID of the object marked by this instrumentation
     * statement.
     * @param mSignature Signature of the method owning the object.
     */
    public static void writeTraceMessage(int bId, String mSignature) {
        if (instMode != INST_COMPATIBLE) {
            if (instMode == -1) {
                setup(INST_COMPATIBLE);
            }
            else {
                throw new IllegalStateException("Subject contains " +
                    "inconsistent instrumentation");
            }
        }

        isInstrumented = true;
        theFilter.writeTraceData(new int[]{bId}, mSignature.replace('@', '.'),
                                 0, 1);
    }
    
    /*************************************************************************
     * Maps to an equivalent call to {@link JUnitFilter#getObjectArray};
     * this method is retained for backwards compatibility with previous
     * instrumentation.
     *
     * @param mSignature Signature of the method for which the byte array
     * is to be retrieved. The signature guarantees uniqueness.
     * @param blockCount Number of basic blocks in the method, used only
     * when the array must be allocated. This value should be determined
     * by the CFG builder and set by the instrumentor.
     *
     * @return The byte array recording blocks hit in the method.
     */ 
    public static byte[] getBlockArray(String mSignature, int blockCount) {
        return getObjectArray(mSignature, blockCount);
    }

    /*************************************************************************
     * Gets the byte array recording which objects have been hit in a given
     * method.
     *
     * <p>If this is the first time the method has been traced (or the
     * method has been removed from the cache), an array of the necessary
     * size is allocated and initialized. Calls to this method are
     * inserted at the beginning of methods in the subject by the
     * instrumentor.</p>
     *
     * @param mSignature Signature of the method for which the byte array
     * is to be retrieved. The signature guarantees uniqueness.
     * @param objCount Number of objects in the method, used only
     * when the array must be allocated. This value should be determined
     * by the CFG builder and set by the instrumentor.
     *
     * @return The byte array recording objects hit in the method.
     */ 
    public static byte[] getObjectArray(String mSignature, int objCount) {
        if (filterMode == SEQUENCE_TRACE) {
            throw new ConfigurationError("Cannot generate sequence " +
                "trace from coverage instrumentation");
        }

        if (instMode != INST_OPT_NORMAL) {
            if (instMode == -1) {
                setup(INST_OPT_NORMAL);
            }
            else {
                throw new IllegalStateException("Subject contains " +
                    "inconsistent instrumentation");
            }
        }

        isInstrumented = true;
        writeObjectCount(mSignature, objCount);

        mSignature = mSignature.replace('@', '.');
        if (!traceObjArrays.containsKey(mSignature)) {
            // Need to allocate and initialize new one
            byte[] traceObjArray = new byte[objCount];
            Arrays.fill(traceObjArray, (byte) 0);
            traceObjArrays.put(mSignature, traceObjArray);
            return traceObjArray;
        }
        else {
            return (byte[]) traceObjArrays.get(mSignature);
        }
    }
    
    /*************************************************************************
     * Inserts a new method marker and index into the sequence array.
     * (See {@link sofya.inst.SocketProbe#markMethodInSequence}).
     *
     * @param mSignature Signature of the method which has been entered
     * and needs to be marked in the array.
     * @param objCount Number of objects in the method (this will be used
     * in the filter to allocate a trace of the correct size, if necessary).
     */ 
    public static void markMethodInSequence(String mSignature, int objCount) {
        if (instMode != INST_OPT_SEQUENCE) {
            if (instMode == -1) {
                setup(INST_OPT_SEQUENCE);
            }
            else {
                throw new IllegalStateException("Subject contains " +
                    "inconsistent instrumentation");
            }
        }

        isInstrumented = true;
        writeObjectCount(mSignature, objCount);
        
        mSignature = mSignature.replace('@', '.');
        if (sequenceIndex > sequenceArray.length - 2) {
            // The array is full, so transmit the data. This also resets the
            // index
            writeSequenceData();
        }
        sequenceArray[sequenceIndex++] = SocketProbe.NEW_METHOD_MARKER;
        if (nameToIndexMap.containsKey(mSignature)) {
            // We've already linked this method to an index, so use that value
            sequenceArray[sequenceIndex++] = nameToIndexMap.get(mSignature);
        }
        else {
            // Need to create a new index to correspond to this method
            sequenceArray[sequenceIndex++] = nextMethodIndex;
            nameToIndexMap.put(mSignature, nextMethodIndex);
            indexToNameMap.put(nextMethodIndex, mSignature);
            // Overflow detection not necessary - see writeSequenceData()
            nextMethodIndex++;
        }
    }

    /*************************************************************************
     * Writes the current contents of the object sequence array to the trace.
     * (See {@link sofya.inst.SocketProbe#writeSequenceData}).
     */
    public static void writeSequenceData() {
        int fromIndex = 0;
        int toIndex = 0;
        while (toIndex < sequenceIndex) {
            if (sequenceArray[toIndex] == SocketProbe.NEW_METHOD_MARKER) {
                if (toIndex > fromIndex) {
                    if (currentMethodSig != null) {
                        theFilter.writeTraceData(sequenceArray,
                            currentMethodSig, fromIndex, toIndex);
                    }
                    else {
                        System.err.println("ERROR: Orphaned block sequence " +
                            "information detected. Trace is likely invalid!");
                    }
                }
                if (theFilter.getObjectType() == TraceObjectType.BASIC_BLOCK) {
                    methodSigStack.addLast(currentMethodSig);
                }
                currentMethodSig =
                    (String) indexToNameMap.get(sequenceArray[++toIndex]);
                fromIndex = ++toIndex;
            }
            else if (sequenceArray[toIndex] >>> 26 == BlockType.EXIT.toInt()) {
                if (toIndex >= fromIndex) {
                    if (currentMethodSig != null) {
                        theFilter.writeTraceData(sequenceArray,
                            currentMethodSig, fromIndex, toIndex + 1);
                    }
                    else {
                        System.err.println("ERROR: Orphaned block sequence " +
                            "information detected. Trace is likely invalid!");
                    }
                }
                try {
                    currentMethodSig = (String) methodSigStack.removeLast();
                }
                catch (NoSuchElementException e) {
                    System.err.println("ERROR: Number of method entries and " +
                        "exits is unbalanced.");
                }
                fromIndex = ++toIndex;
            }
            else {
                toIndex++;
            }
        }
        if (toIndex > fromIndex) {
            if (currentMethodSig != null) {
                theFilter.writeTraceData(sequenceArray, currentMethodSig,
                                         fromIndex, toIndex);
            }
            else {
                System.err.println("ERROR: Orphaned block sequence " +
                    "information detected. Trace is likely invalid!");
            }
        }

        sequenceIndex = 0;
        // Now that the array is cleared, we can also clear any current
        // mappings of indices to method signatures and vice-versa. This is
        // easier than trying to attach overflow protection to the index
        // counter, and safer since overflow detection would only be able to
        // report that the trace is invalid, not recover from it.
        indexToNameMap.clear();
        nameToIndexMap.clear();
        nextMethodIndex = 0;
    }
    
    /*************************************************************************
     * Configures filter with a new set of parameters to run a subject class.
     *
     * @param typeFlags Bit mask representing the types of objects to be
     * traced.
     * @param appendToTrace If <code>true</code>, filter will append the
     * current trace information to any existing trace file. Otherwise any
     * previous trace file will be overwritten.
     * @param trName Name of the trace file to be written.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws ExecException If called while filter is running.
     */
    public void configureFilter(int typeFlags, boolean appendToTrace,
                                String trName)
                                throws IllegalArgumentException, ExecException {
        setTypeFlags(typeFlags);
        setAppendTrace(appendToTrace);
        setTraceFileName(trName);
        reset();
    }

    /*************************************************************************
     * Reports whether JUnitFilter is currently set to generate coverage
     * traces or sequence traces.
     *
     * @return Integer value indicating the trace mode to which JUnitFilter
     * is currently set, either {@link JUnitFilter#COVERAGE_TRACE} or
     * {@link JUnitFilter#SEQUENCE_TRACE}.
     */
    public int getFilterMode() {
        return filterMode;
    }
    
    /*************************************************************************
     * Sets whether JUnitFilter is currently set to generate coverage
     * traces or sequence traces.
     *
     * @param filterMode Integer value specifying the trace mode to which
     * JUnitFilter is to be set, must be either
     * {@link JUnitFilter#COVERAGE_TRACE} or
     * {@link JUnitFilter#SEQUENCE_TRACE}.
     */
    public void setFilterMode(int filterMode) throws SetupException {
        if (!((filterMode == COVERAGE_TRACE) || (filterMode == SEQUENCE_TRACE))) {
            throw new IllegalArgumentException("Unrecognized filter mode");
        }
        this.filterMode = filterMode;
    }

    /*************************************************************************
     * Reports whether JUnitFilter is set to relay trace information to
     * a socket. This is relevant only when in sequence trace mode.
     *
     * @return <code>true</code> if trace information will be relayed to
     * a socket, <code>false</code> otherwise.
     */
    public boolean usingRelaySocket() {
        return relayToSocket;
    }

    /*************************************************************************
     * Sets whether JUnitFilter is set to relay trace information to
     * a socket. This is relevant only when in sequence trace mode - if
     * called in coverage trace mode this method will have no effect.
     *
     * @param enable <code>true</code> to specify that trace data should
     * be sent to a socket, <code>false</code> to specify that trace data
     * should be written to file.
     */
    public void useRelaySocket(boolean enable) {
        if (filterMode == COVERAGE_TRACE) return;
        relayToSocket = enable;
    }
    
    /*************************************************************************
     * Gets the data set to be inserted at the beginning of the trace(s).
     *
     * @return Data which will be inserted at the beginning of the trace(s).
     */
    public String getPreData() {
        return preData;
    }
    
    /*************************************************************************
     * Sets the data to be inserted at the beginning of the trace(s).
     * 
     * @param data Data which will be inserted at the beginning of the
     * trace(s).
     */
    public void setPreData(String data) {
        preData = data;
    }
    
    /*************************************************************************
     * Gets the data set to be inserted at the end of the trace(s).
     *
     * @return Data which will be inserted at the end of the trace(s).
     */
    public String getPostData() {
        return postData;
    }
    
    /*************************************************************************
     * Sets the data to be inserted at the end of the trace(s).
     * 
     * @param data Data which will be inserted at the end of the trace(s).
     */
    public void setPostData(String data) {
        postData = data;
    }

    /*************************************************************************
     * Customized implementation of the LRU map to ensure that the hit
     * object data in the byte array for a least-recently-used method is
     * written to the trace before its entry is removed from the map.
     */ 
    private static class LRUTraceMap extends LRUMap {
        public LRUTraceMap(int maxSize) {
            super(maxSize);
        }
        
        protected boolean removeLRU(LinkEntry entry) {
            // Actually record the trace data for the block array about to be
            // kicked
            Object value = entry.getValue();
            if (value != null) {
                theFilter.writeTraceData(value,
                                         (String) entry.getKey(),
                                         -1 ,-1);
            }
            return true;
        }
    }
}
