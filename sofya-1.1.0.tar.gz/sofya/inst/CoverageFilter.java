/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.util.List;
import java.io.OutputStream;

/**
 * Abstract base class of all classes which generate coverage traces
 * from an instrumented subject.
 *
 * <p>Coverage trace specific options, configuration, and data structures
 * are found in this class.</p>
 *
 * @author Alex Kinneer
 * @version 05/19/2004
 */
public abstract class CoverageFilter extends ProgramFilter {
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter()}.
     */
    protected CoverageFilter() {
        super();
    }
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter(
     * java.lang.String[],java.io.OutputStream,java.io.OutputStream,
     * java.io.OutputStream)}.
     */
    public CoverageFilter(String[] argv, OutputStream subjectSink,
                          OutputStream stdoutSink, OutputStream stderrSink)
                          throws IllegalArgumentException, CreateException {
        super(argv, subjectSink, stdoutSink, stderrSink);
    }
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter(
     * java.lang.String,java.lang.String[],java.lang.String,int,int,boolean,
     * int,boolean,java.lang.String,java.io.OutputStream,java.io.OutputStream,
     * java.io.OutputStream)}.
     */
    public CoverageFilter(String className, String[] subjectArgs, 
                          String subjectCP, int typeFlags, int port,
                          boolean pipeInput, int timeLimit,
                          boolean appendToTrace, String trName,
                          OutputStream subjectSink, OutputStream stdoutSink,
                          OutputStream stderrSink)
                          throws IllegalArgumentException, CreateException {
        super(className, subjectArgs, subjectCP, typeFlags, port,
              pipeInput, timeLimit, appendToTrace, trName,
              subjectSink, stdoutSink, stderrSink);
    }
}
