/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import sofya.base.Handler;
import sofya.base.ProjectDescription;

import java.io.*;
import java.lang.reflect.*;
import java.util.List;
import java.util.ListIterator;
import java.util.StringTokenizer;

/**
 * This class provides the ability to execute a
 * {@link sofya.inst.ProgramFilter} multiple times with different subjects
 * and/or configurations within the same JVM.
 *
 * <p>A batch file must be provided which specifies on each line a
 * distinct set of configuration parameters to be passed to the
 * <code>ProgramFilter</code>, including the name of the subject class.</p>
 *
 * <p>Usage:<br><code>java sofya.inst.BatchFilter &lt;batch_file&gt;
 * </code></p>
 *
 * @author Alex Kinneer
 * @version 07/01/2005
 */
public final class BatchFilter {
    /** Filter which will be used as a library object. */
    private static ProgramFilter filter;
    
    /** No reason to instantiate this class. */
    private BatchFilter() { }
    
    /**
     * Prints the BatchFilter usage message and exits.
     */
    private static void printUsage() {
        System.err.println("Usage:");
        System.err.println("java sofya.inst.BatchFilter <batch_file>");
        System.exit(1);
    }
    
    /**
     * Entry point for BatchFilter. Reads the batch file and
     * executes the subjects with their associated configuration
     * parameters.
     *
     * @param argv Command line parameters to BatchFilter. One
     * argument is expected, the path to the batch file.
     */
    public static void main(String[] argv) {
        if (argv.length < 1) {
            printUsage();
        }
        
        boolean mtsEcho = false;
        
        int argi = 0;
        if (argv[0].equals("-mts")) {
            mtsEcho = true;
            argi += 1;
        }
        
        if (argi == argv.length) {
            System.err.println("ERROR: Must specify file or '-stdin'");
            System.exit(1);
        }
        
        LineNumberReader batchData = null;  // (LineNumberReader is buffered)
        if (argv[argi].equals("-stdin")) {
            batchData = new LineNumberReader(new InputStreamReader(System.in));
        }
        else {
            try {
                batchData = new LineNumberReader(new InputStreamReader(
                    new FileInputStream(argv[argi])));
            }
            catch (FileNotFoundException e) {
                System.err.println("ERROR: file '" + argv[argi] + "' could " +
                    "not be found");
                System.exit(1);
            }
            catch (IOException e) {
                e.printStackTrace();
                System.err.println("ERROR: I/O problem opening batch file");
                System.exit(1);
            }
        }
        
        // Use reflection to instantiate a filter of the requested type. This
        // is ultimately cleaner and makes supporting new types of filters
        // trivial (on the off chance that need should arise).
        String filterType = null;
        try {
            filterType = batchData.readLine();
            if (filterType == null) {
                System.err.println("ERROR: batch file is empty");
                System.exit(1);
            }
            Constructor ct = (Class.forName(filterType)).getConstructor(
                new Class[]{Class.forName("[Ljava.lang.String;"),
                            Class.forName("java.io.OutputStream"),
                            Class.forName("java.io.OutputStream"),
                            Class.forName("java.io.OutputStream")});
            // Create a dummy instance (the arguments are valid but the
            // class name is not). We'll just reconfigure it first thing
            // in the loop - and this makes the loop simpler.
            filter = (ProgramFilter) ct.newInstance(
                new Object[]{new String[]{"-B", "foo"},
                             System.out,
                             System.out,
                             System.err});
        }
        catch (NoSuchMethodException e) {
            // Couldn't find the constructor
            System.err.println("ERROR: " + filterType + " is not a filter " +
                "class (or does not implement the necessary constructor)");
            System.exit(1);
        }
        catch (ClassCastException e) {
            // It has a matching constructor, but it's no filter
            System.err.println("ERROR: " + filterType + " is not a filter " +
                "class");
            System.exit(1);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.err.println("ERROR: I/O problem reading filter type from " +
                "batch file");
            System.exit(1);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR: Failed to instantiate filter");
            System.exit(1);
        }

        try {
            String configLine;
            
            int testNum = 1;
            while ((configLine = batchData.readLine()) != null) {
                try {
                    if (mtsEcho) {
                        System.out.println(">>>>>>>>running test " + testNum);
                        configLine = "-o ../outputs/t" + testNum + " "
                            + configLine;
                    }
                
                    List badParams = filter.configureFilter(
                        splitParams(configLine));
                    if (badParams.size() > 0) {
                        StringBuffer sb = new StringBuffer();
                        for (ListIterator li = badParams.listIterator();
                                li.hasNext(); ) {
                            sb.append("'");
                            sb.append((String) li.next());
                            sb.append("' ");
                        }
                        System.err.println("ERROR: Line " +
                            batchData.getLineNumber() + ", " +
                            "Unrecognized parameter(s): " + sb.toString());
                        System.exit(1);
                    }
                }
                catch (IllegalArgumentException e) {
                    System.err.println("ERROR: Line " +
                        batchData.getLineNumber() + ", " + e.getMessage());
                    System.exit(1);
                }
                catch (IllegalStateException e) { // Shouldn't happen
                    System.err.println("ERROR: Line " +
                        batchData.getLineNumber() + ", Attempted to " +
                        "reconfigure running filter");
                    System.exit(1);
                }
                
                try {
                    filter.runFilter();
                }
                catch (Exception e) {
                    e.printStackTrace();
                    System.err.println("ERROR: Line " +
                        batchData.getLineNumber() + ", Execution of filter " +
                        "failed");
                    System.exit(1);
                }
                
                if (mtsEcho) {
                    boolean copied = Handler.copyFile(
                        new File(ProjectDescription.dbDir + File.separatorChar +
                            filter.getTraceFileName() + ".tr"),
                        new File(".." + File.separatorChar + "traces" +
                            File.separatorChar + String.valueOf(testNum - 1) +
                            ".tr"));
                    if (!copied) {
                        System.err.println("ERROR: Line " +
                            batchData.getLineNumber() + ", Failed to copy " +
                            "trace file");
                        System.exit(1);
                    }
                    testNum += 1;
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
            System.err.println("ERROR: Line " + batchData.getLineNumber() +
                ", I/O problem reading batch file");
            System.exit(1);
        }
        finally {
            // For sequence filter, this ensures the relay socket is closed if
            // necessary
            filter.destroy();
        }
    }
    
    /**
     * Utility method to split an input line from the batch file
     * into an array of strings.
     *
     * @param params String containing a configuration line read
     * from the batch file.
     *
     * @return The list of parameters as separate strings.
     */
    private static String[] splitParams(String params) {
        StringTokenizer stok = new StringTokenizer(params);
        String[] configParams = new String[stok.countTokens()];
        for (int i = 0; stok.hasMoreTokens(); i++) {
            configParams[i] = stok.nextToken();
        }
        return configParams;
    }
}
