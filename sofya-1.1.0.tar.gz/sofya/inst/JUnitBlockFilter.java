/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.net.*;
import java.util.*;

import sofya.base.exceptions.*;

/**
 * The JUnitBlockFilter class provides the ability to collect basic block
 * coverage and sequence traces from JUnit test cases run on instrumented
 * classes.
 *
 * @author Alex Kinneer
 * @version 09/24/2004
 */
public class JUnitBlockFilter extends JUnitFilter implements BlockTracer {
    /** Conditional compilation debug flag. */
    private static final boolean DEBUG = false;

    /*************************************************************************
     * Creates a JUnitBlockFilter with a default configuration.
     *
     * <p>The filter will be configured to perform a coverage trace on
     * block types &apos;BEXC&apos; using the default trace file name.</p>
     */
    public JUnitBlockFilter() throws IllegalArgumentException, CreateException {
        super();
        typeFlags = 0x0000000F;
    }
    
    /*************************************************************************
     * Creates a JUnitBlockFilter with the specified configuration.
     *
     * @param typeFlags Bit mask representing the types of blocks to be
     * traced. Can be any bitwise combination of the following
     * (See {@link sofya.base.SConstants}):
     * <ul>
     * <li><code>SConstants.BlockType.MASK_BASIC</code></li>
     * <li><code>SConstants.BlockType.MASK_ENTRY</code></li>
     * <li><code>SConstants.BlockType.MASK_EXIT</code></li>
     * <li><code>SConstants.BlockType.MASK_CALL</code></li>
     * </ul>
     * @param appendToTrace If <code>true</code>, filter will append the current
     * trace information to any existing trace file. Otherwise any previous
     * trace file will be overwritten.
     * @param trName Name of the trace file to be written.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws CreateException If there is already an instance of a filter
     * created which has not been destroyed
     * (see {@link sofya.inst.JUnitFilter#destroy}).
     */
    public JUnitBlockFilter(int typeFlags, boolean appendToTrace,
                            String trName)
                            throws IllegalArgumentException, CreateException {
        super(typeFlags, appendToTrace, trName);
    }
    
    public TraceObjectType getObjectType() {
        return TraceObjectType.BASIC_BLOCK;
    }
    
    /*************************************************************************
     * Writes currently witnessed blocks to the trace.
     *
     * @param blocks Reference to a (Java) Object or object array containing
     * witnessed block information to be recorded in the trace. The type of
     * this argument depends on the type of instrumentation, so a generic
     * Object reference is used.
     * @param mSignature Signature of the method for which the block
     * data is to be written.
     * @param fromIndex Pointer to the element in the array from which
     * the method should start reading block information. This parameter is
     * ignored unless handling sequence instrumentation.
     * @param toIndex Pointer to the element in the array at which the method
     * should stop reading block information. This parameter is ignored
     * unless handling sequence instrumentation.
     */ 
    protected void writeTraceData(Object blocks, String mSignature,
                                  int fromIndex, int toIndex) {
        try {  // Trap runtime exceptions,
        
        switch (filterMode) {
        case COVERAGE_TRACE:
            try {
                methodTrace = traceHandler.getTrace(mSignature);
            }
            catch (MethodNotFoundException e) {
                switch (instMode) {
                case INST_COMPATIBLE:
                case INST_OPT_SEQUENCE:
                    throw new ExecException("ERROR: Trace was not properly " +
                        "allocated");
                case INST_OPT_NORMAL:
                    System.err.println("WARNING: Trace was not allocated at " +
                        "the expected time");
                    methodTrace = new Trace(((byte[]) blocks).length);
                    traceHandler.setTrace(mSignature, methodTrace);
                    break;
                default:
                    throw new ExecException("ERROR: Unknown or incompatible " +
                        "instrumentation");
                }
            }
            
            switch (instMode) {
            case INST_OPT_NORMAL:
                byte[] byteArray = (byte[]) blocks;
                for (int bId = 0; bId < byteArray.length; bId++) {
                    switch (byteArray[bId]) {
                    case 0:
                        // Block wasn't hit
                        continue;
                    case BlockType.IBLOCK:
                        if ((typeFlags & BlockType.MASK_BASIC)
                                == BlockType.MASK_BASIC) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.out.println("tr.setBit <basic> success");
                            }
                        }
                        break;
                    case BlockType.IENTRY:
                        if ((typeFlags & BlockType.MASK_ENTRY)
                                == BlockType.MASK_ENTRY) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.out.println("tr.setBit <entry> success");
                            }
                        }
                        break;
                    case BlockType.IEXIT:
                        if ((typeFlags & BlockType.MASK_EXIT)
                                == BlockType.MASK_EXIT) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.out.println("tr.setBit <exit> success");
                            }
                        }
                        break;
                    case BlockType.ICALL:
                        if ((typeFlags & BlockType.MASK_CALL)
                                == BlockType.MASK_CALL) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.out.println("tr.setBit <call> success");
                            }
                        }
                        break;
                    case BlockType.IRETURN:
                        if ((typeFlags & BlockType.MASK_RETURN)
                                == BlockType.MASK_RETURN) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.out.println("tr.setBit <return> " +
                                    "success");
                            }
                        }
                        break;
                    default:
                        throw new ExecException("Invalid block type code " +
                            "received from instrumented class");
                    }
                }
                break;
            case INST_COMPATIBLE:
                // In compatible mode instrumentation, the block data is packed
                // in the same way as for sequence instrumentation, so it's
                // easier to simply let it masquerade as such
            case INST_OPT_SEQUENCE:
                int[] intArray = (int[]) blocks;
                for (int i = fromIndex; i < toIndex; i++) {
                    int nodeType = intArray[i] >>> 26;
                    int blockID = intArray[i] & 0x03FFFFFF;
                    switch (nodeType) {
                    case BlockType.IBLOCK:
                        if ((typeFlags & BlockType.MASK_BASIC)
                                == BlockType.MASK_BASIC) {
                            methodTrace.set(blockID);
                            if (DEBUG) {
                                System.out.println("tr.setBit <basic> success");
                            }
                        }
                        break;
                    case BlockType.IENTRY:
                        if ((typeFlags & BlockType.MASK_ENTRY)
                                == BlockType.MASK_ENTRY) {
                            methodTrace.set(blockID);
                            if (DEBUG) {
                                System.out.println("tr.setBit <entry> success");
                            }
                        }
                        break;
                    case BlockType.IEXIT:
                        if ((typeFlags & BlockType.MASK_EXIT)
                                == BlockType.MASK_EXIT) {
                            methodTrace.set(blockID);
                            if (DEBUG) {
                                System.out.println("tr.setBit <exit> success");
                            }
                        }
                        break;
                    case BlockType.ICALL:
                        if ((typeFlags & BlockType.MASK_CALL)
                                == BlockType.MASK_CALL) {
                            methodTrace.set(blockID);
                            if (DEBUG) {
                                System.out.println("tr.setBit <call> success");
                            }
                        }
                        break;
                    case BlockType.IRETURN:
                        if ((typeFlags & BlockType.MASK_RETURN)
                                == BlockType.MASK_RETURN) {
                            methodTrace.set(blockID);
                            if (DEBUG) {
                                System.out.println("tr.setBit <return> " +
                                    "success");
                            }
                        }
                        break;
                    default:
                        throw new ExecException("Invalid block type code " +
                            "received from instrumented class");
                    }
                }
                break;
            default:
                throw new ConfigurationError("Unknown or incompatible " +
                    "instrumentation");
            }
            break;
        case SEQUENCE_TRACE:
            switch (instMode) {
            case INST_OPT_NORMAL:
                throw new ConfigurationError("Cannot generate sequence " +
                    "trace from coverage instrumentation");
            case INST_COMPATIBLE:
            case INST_OPT_SEQUENCE:
                int[] intArray = (int[]) blocks;
                for (int i = fromIndex; i < toIndex; i++) {
                    int nodeType = intArray[i] >>> 26;
                    int blockID = intArray[i] & 0x03FFFFFF;
                    switch (nodeType) {
                    case BlockType.IBLOCK:
                        if ((typeFlags & BlockType.MASK_BASIC)
                                == BlockType.MASK_BASIC) {
                            pw.println(mSignature + "\tbasic block: " +
                                blockID);
                        }
                        break;
                    case BlockType.IENTRY:
                        if ((typeFlags & BlockType.MASK_ENTRY)
                                == BlockType.MASK_ENTRY) {
                            pw.print(mSignature.replace(' ','^'));
                            if (relayToSocket) {
                                pw.print("\n");
                            }
                            else {
                                pw.print(" ");
                            }
                            // pw.println(mSignature + "\tentry block: " +
                            //     blockID);
                        }
                        break;
                    case BlockType.IEXIT:
                        if ((typeFlags & BlockType.MASK_EXIT)
                                == BlockType.MASK_EXIT) {
                            pw.print(")r");
                            if (relayToSocket) {
                                pw.print("\n");
                            }
                            else {
                                pw.print(" ");
                            }
                            // pw.println(mSignature + "\texit block: " +
                            //     blockID);
                        }
                        break;
                    case BlockType.ICALL:
                        if ((typeFlags & BlockType.MASK_CALL)
                                == BlockType.MASK_CALL) {
                            pw.println(mSignature + "\tcall block: " + blockID);
                        }
                        break;
                    case BlockType.IRETURN:
                        if ((typeFlags & BlockType.MASK_RETURN)
                                == BlockType.MASK_RETURN) {
                            pw.println(mSignature + "\treturn block: " +
                                blockID);
                        }
                        break;
                    default:
                        throw new ExecException("Invalid block type code " +
                            "received from instrumented class");
                    }
                    
                    if (pw.checkError()) {
                        throw new TraceFileException("Error writing to trace " +
                            "file");
                    }
                }
                break;
            default:
                throw new ExecException("ERROR: Unknown or incompatible " +
                    "instrumentation");
            }
            break;
        }


        // Catch all unexpected exceptions and store them
        } catch (Exception e) {
            e.printStackTrace();
            storedException = e;
            System.err.println("Error writing trace message");
        }
    }
    
    public void setTypeFlags(int typeFlags) throws IllegalArgumentException {
        super.setTypeFlags(typeFlags, TraceObjectType.BASIC_BLOCK);
    }
    
    public boolean isTypeBasic() {
        return super.isTypeBasic();
    }
    
    public void setTypeBasic(boolean enable) {
        super.setTypeBasic(enable);
    }

    public boolean isTypeEntry() {
        return super.isTypeEntry();
    }
    
    public void setTypeEntry(boolean enable) {
        super.setTypeEntry(enable);
    }
    
    public boolean isTypeExit() {
        return super.isTypeExit();
    }
    
    public void setTypeExit(boolean enable) {
        super.setTypeExit(enable);
    }

    public boolean isTypeCall() {
        return super.isTypeCall();
    }
    
    public void setTypeCall(boolean enable) {
        super.setTypeCall(enable);
    }
}
