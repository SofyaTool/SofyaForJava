/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

/**
 * This interface defines the contract of configuration methods which are
 * relevant to filter classes which operate on a basic block representation
 * of Java class files.
 *
 * @author Alex Kinneer
 * @version 05/20/2004
 *
 * @see sofya.inst.AbstractFilter
 */
public interface BlockTracer {
    /*************************************************************************
     * Gets bit vector representing block types that are currently set to be
     * traced by this filter.
     *
     * @return Bit vector controlling what types of blocks are traced.
     */
    public int getTypeFlags();
    
    /*************************************************************************
     * Sets bit vector controlling what block types are to be traced by this
     * filter.
     *
     * @param typeFlags Bit mask representing the types of blocks to be
     * traced. Can be any bitwise combination of the following
     * (See {@link sofya.base.SConstants}):
     * <ul>
     * <li><code>SConstants.BlockType.MASK_BASIC</code></li>
     * <li><code>SConstants.BlockType.MASK_ENTRY</code></li>
     * <li><code>SConstants.BlockType.MASK_EXIT</code></li>
     * <li><code>SConstants.BlockType.MASK_CALL</code></li>
     * </ul>
     *
     * @throws IllegalArgumentException If the bit vector doesn't have a bit set
     * which corresponds to a valid block type.
     * @throws ExecException If called while filter is running.
     */
    public void setTypeFlags(int typeFlags) throws IllegalArgumentException;
    
    /*************************************************************************
     * Reports  whether filter is currently set to trace basic blocks.
     *
     * @return <code>true</code> if basic blocks are to be traced,
     * <code>false</code> otherwise.
     */
    public boolean isTypeBasic();
    
    /*************************************************************************
     * Sets whether filter is to trace basic blocks.
     *
     * @param enable <code>true</code> to enable basic block tracing,
     * <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeBasic(boolean enable);

    /*************************************************************************
     * Reports  whether filter is to trace entry blocks.
     *
     * @return <code>true</code> if entry blocks are to be traced,
     * <code>false</code> otherwise.
     */
    public boolean isTypeEntry();
    
    /*************************************************************************
     * Sets whether filter is to trace entry blocks.
     *
     * @param enable <code>true</code> to enable entry block tracing,
     * <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeEntry(boolean enable);
    
    /*************************************************************************
     * Reports  whether filter is to trace exit blocks.
     *
     * @return <code>true</code> if exit blocks are to be traced,
     * <code>false</code> otherwise.
     */
    public boolean isTypeExit();
    
    /*************************************************************************
     * Sets whether filter is to trace exit blocks.
     *
     * @param enable <code>true</code> to enable exit block tracing,
     * <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeExit(boolean enable);

    /*************************************************************************
     * Reports  whether filter is to trace call blocks.
     *
     * @return <code>true</code> if call blocks are to be traced,
     * <code>false</code> otherwise.
     */
    public boolean isTypeCall();
    
    /*************************************************************************
     * Sets whether filter is to trace call blocks.
     *
     * @param enable <code>true</code> to enable call block tracing,
     * <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeCall(boolean enable);
}
