/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.net.*;
import java.util.*;

import sofya.base.Handler;

/**
 * Class to construct a list of the methods traversed by a subject in
 * chronological order.
 *
 * <p>The usage and considerations for this class are
 * the same as for {@link sofya.inst.Filter}.  The only difference is
 * the type of trace file that is generated.</p>
 *
 * @author Alex Kinneer
 * @version 09/24/2004
 */
public class SequenceFilter extends SequentialFilter implements BlockTracer {
    /** Conditional compilation debug flag. */
    private static final boolean DEBUG = false;
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter()}.
     */
    protected SequenceFilter() {
        super();
    }

    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter(
     * java.lang.String[],java.io.OutputStream,java.io.OutputStream,
     * java.io.OutputStream)}.
     */
    public SequenceFilter(String[] argv, OutputStream subjectSink,
                          OutputStream stdoutSink, OutputStream stderrSink)
                          throws IllegalArgumentException, CreateException {
        super(argv, subjectSink, stdoutSink, stderrSink);
    }

    /*************************************************************************
     * Standard constructor, constructs SequenceFilter with the specified
     * initial configuration.
     *
     * @param className Name of the subject class which is to be executed.
     * @param subjectArgs Set of arguments to be passed to the subject class.
     * @param subjectCP Java classpath that will be set for the subject when
     * it is executed.
     * @param typeFlags Bit mask representing the types of blocks to be
     * traced.
     * @param port The port number on which filter should listen for incoming
     * instrumentation messages from the subject. The valid range is
     * 1024 to 65535. An exception is the value -1, which instructs Filter
     * to select the default port.
     * @param pipeInput If <code>true</code>, filter will redirect input on
     * standard in to the subject's standard input stream.
     * @param timeLimit The length of time in seconds that the subject is
     * allowed to run before being killed.
     * @param appendToTrace If <code>true</code>, filter will append the
     * current trace information to any existing trace file. Otherwise any
     * previous trace file will be overwritten.
     * @param trName Name of the trace file to be written.
     * @param subjectSink Output stream to which subject's outputs are to be
     * written. If <code>null</code>, <code>System.out</code> is used by
     * default.
     * @param stdoutSink Output stream to which filter's normal outputs are to
     * be written. If <code>null</code>, <code>System.out</code> is used by
     * default. When filter is compiled in <code>DEBUG</code> mode, debug
     * information is also printed to this stream.
     * @param stderrSink Output stream to which filter's error outputs are to
     * be written. If <code>null</code>, <code>System.err</code> is used by
     * default.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws CreateException If there is already an instance of SequenceFilter
     * created which has not been destroyed (see
     * {@link sofya.inst.Filter#destroy}).
     */
    public SequenceFilter(String className, String[] subjectArgs,
            String subjectCP, int typeFlags, int port, boolean pipeInput,
            int timeLimit, boolean appendToTrace, String trName,
            OutputStream subjectSink, OutputStream stdoutSink,
            OutputStream stderrSink)
            throws IllegalArgumentException, CreateException {
        super(className, subjectArgs, subjectCP, typeFlags, port, pipeInput,
              timeLimit, appendToTrace, trName, subjectSink, stdoutSink,
              stderrSink);
    }
    
    public void run() {
        try {
            if (!subjectIsFilter) {
                if (DEBUG) stdoutStream.println("runNormal");
                runNormal();
            }
            else {
                if (DEBUG) stdoutStream.println("runSynchronized");
                runSynchronized();
            }
        }
        catch (Exception e) {  // Will catch any runtime exceptions
            storedException = e;
            if (subjectIsFilter) {
                synchronized(timeLock) {
                    threadConnected[threadID] = false;
                    timeLock.notify();
                }
            }
        }
    }
    
    protected void runNormal() {
        Socket connection = null;
        DataInputStream connectionIn = null;
        StreamTokenizer stok = null;
        int maxBlockId, blockID;
        
        try {
            connection = serverSocket.accept();
            // The fact that a socket is being opened means we know the
            // subject is instrumented
            isInstrumented = true;
            // The handshake currently consists of validating the
            // instrumentation type.
            if (DEBUG) stdoutStream.println("Performing handshake");
            try {
                doHandshake(connection);
            }
            catch (ExecException e) {
                if (DEBUG) {
                    stdoutStream.println("Handshake failed: subject refused");
                }
                storedException = e;
                stopServer();
                return;
            }
            connectionIn = new DataInputStream(
                new BufferedInputStream(connection.getInputStream()));
            threadConnected[threadID] = true;
        }
        catch (IOException e) {
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            storedException = e;
            stderrStream.println("Error accepting instrumentation connection!");
            stopServer();
            return;
        }

        byte[] buffer = new byte[1024];
        while (!forceStop) {
            try {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message. Sequence filter
                    // just consumes it since it doesn't need to know
                    // the block count for the method
                    parseMethodSignature(connectionIn, buffer);
                    maxBlockId = connectionIn.readInt();
                    if (DEBUG) {
                        stdoutStream.println("Received create trace " +
                            "message for: " + classMethodName);
                    }
                    continue;
                }

                // Check timestamp flag
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }
                
                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);
                if (DEBUG) {
                    stdoutStream.println("Received signature: " +
                        classMethodName);
                }

                // Now read and mark each block
                int dataLength = connectionIn.readInt();  // Number of blocks
                for (int i = 0; i < dataLength; i++) {
                    blockID = connectionIn.readInt();
                    int nodeType = blockID >>> 26;
                    blockID &= 0x03FFFFFF;
                    if (DEBUG) {
                        stdoutStream.println("Recording block ID=" + blockID +
                            ", type=" + nodeType);
                    }
                    // Output format for entry/exit blocks defined by Jim Law -
                    // 1/21/2004
                    switch (nodeType) {
                    case BlockType.IBLOCK:
                        if ((typeFlags & BlockType.MASK_BASIC)
                                == BlockType.MASK_BASIC) {
                            pw.println(classMethodName + "\tbasic block: " +
                                blockID);
                        }
                        break;
                    case BlockType.IENTRY:
                        if ((typeFlags & BlockType.MASK_ENTRY)
                                == BlockType.MASK_ENTRY) {
                            if (DEBUG) {
                                stdoutStream.println("Entry block data " +
                                    "written to trace");
                            }
                            pw.print(classMethodName.replace(' ','^'));
                            if (relayToSocket) {
                                pw.print("\n");
                            }
                            else {
                                pw.print(" ");
                            }
                            // pw.println(classMethodName + "\tentry block: " +
                            //     blockID);
                        }
                        break;
                    case BlockType.IEXIT:
                        if ((typeFlags & BlockType.MASK_EXIT)
                                == BlockType.MASK_EXIT) {
                            if (DEBUG) {
                                stdoutStream.println("Exit block data " +
                                    "written to trace");
                            }
                            pw.print(")r");
                            if (relayToSocket) {
                                pw.print("\n");
                            }
                            else {
                                pw.print(" ");
                            }
                            // pw.println(classMethodName + "\texit block: " +
                            //     blockID);
                        }
                        break;
                    case BlockType.ICALL:
                        if ((typeFlags & BlockType.MASK_CALL)
                                == BlockType.MASK_CALL) {
                            pw.println(classMethodName + "\tcall block: " +
                                blockID);
                        }
                        break;
                    case BlockType.IRETURN:
                        if ((typeFlags & BlockType.MASK_RETURN)
                                == BlockType.MASK_RETURN) {
                            pw.println(classMethodName + "\treturn block: " +
                                blockID);
                        }
                        break;
                    default:
                        storedException = new ExecException("Invalid block " +
                            "type code received from instrumented\nclass");
                        break;
                    }
                    
                    if (pw.checkError()) {
                        storedException = new TraceFileException("Error " +
                            "writing to trace file");
                        break;
                    }
                }
            }
            catch (EOFException e) {
                break;
            }
            catch (Exception e) {
                storedException = e;
                break;
            }
            
            // For non-preemptive JVMs
            if (NO_PREEMPT) {
                Thread.currentThread().yield();
            }
        }
       
        if (DEBUG) stdoutStream.println("Filter loop exited");
        
        threadConnected[threadID] = false;
        try {
            connectionIn.close();
            connection.close();
        }
        catch (IOException e) { }

        stopServer();
    }
    
    protected void runSynchronized() {
        Socket connection = null;
        Socket signalSocket = null;
        DataInputStream connectionIn = null;
        DataInputStream signalIn = null;
        DataOutputStream signalOut = null;
        long timeStamp = 0;
        int maxBlockId, blockID;
    
        try {
            // Make sure server socket does not try to accept two connections
            // simultaneously. This is probably unnecessary, but erring on the
            // side of caution.
            synchronized(connectLock) {
                connection = serverSocket.accept();
                isInstrumented = true;
            }
            // The handshake currently consists of validating the
            // instrumentation type.
            int instMode = -1;
            try {
                instMode = doHandshake(connection);
            }
            catch (ExecException e) {
                storedException = e;
                stopServer();
                return;
            }
            connectionIn = new DataInputStream(
                new BufferedInputStream(connection.getInputStream()));
            // Connect the signal socket
            if (instMode == INST_COMPATIBLE) {
                signalSocket = openSignalSocket(connection);
                signalIn = new DataInputStream(signalSocket.getInputStream());
                signalOut =
                    new DataOutputStream(signalSocket.getOutputStream());
            }
            // Indicate that this thread is now connected and processing.
            synchronized(flagLock) {
                threadConnected[threadID] = true;
            }
        }
        catch (IOException e) {
            // This may happen if either a filter or SocketProbe was
            // instrumented but not the other. Thus it is considered part of
            // orderly shutdown.
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            storedException = e;
            stderrStream.println("Error accepting instrumentation connection!");
            stopServer();
            return;
        }
        
        byte[] buffer = new byte[1024];
        runLoop:
        while (!forceStop
                && (filter[(threadID + 1) % 2].storedException == null)) {
            try {
                // If we're about to block reading, notify the other thread so
                // it can continue processing (its trace message must be oldest
                // at this point).
                synchronized(timeLock) {
                    if (!(connectionIn.available() > 0)
                            && threadConnected[(threadID + 1) % 2]) {
                        try {
                            // Force a synchronization with the subject. By
                            // requiring a response, we ensure that  any old
                            // messages still waiting from being blocked when
                            // the socket buffer became full will be written
                            // before we decide whether to grant the the other
                            // thread permission to begin processing.
                            signalOut.writeInt(SIG_ECHO);
                            signalOut.flush();
                            signalIn.readInt();
                        }
                        catch (IOException e) {
                            // If this fails, socket has been closed on other
                            // end
                            break runLoop;
                        }
                    }
                    // Continue to check for new messages until we are signaled
                    // to stop, the subject terminates (closes the socket), or
                    // the other thread finishes processing (at which point this
                    // thread continues to run as if it were a regular
                    // unsynchronized processing thread).
                    while (!(connectionIn.available() > 0)
                            && threadConnected[(threadID + 1) % 2]) {
                        if (forceStop) break runLoop;
                        // Since ready() returns false both when there is no
                        // data to be read and when the socket is closed, the
                        // only way to determine whether the subject has
                        // terminated is to actually attempt to write something
                        // to its control socket. If the subject is still
                        // alive, its SocketProbe simply consumes this signal.
                        try {
                            signalOut.writeInt(SIG_CHKALIVE);
                            signalOut.flush();
                        }
                        catch (IOException e) {
                            break runLoop;
                        }
                        // Everything in the other thread's queue must be older
                        // than whatever will come here next, so let it process
                        // them as a block before checking again.
                        pendingTimeStamp = System.currentTimeMillis();
                        timeLock.notify();
                        timeLock.wait();
                    }
                }
                
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message. Sequence filter
                    // just consumes it since it doesn't need to know
                    // the block count for the method
                    parseMethodSignature(connectionIn, buffer);
                    maxBlockId = connectionIn.readInt();
                }

                // Read timestamp, we may block here
                if (connectionIn.readByte() == 1) {
                    timeStamp = connectionIn.readLong();
                }
                else {
                    storedException = new ExecException("Malformed trace " +
                        "message: timestamp was not provided");
                    break;
                }
            
                // Now check the timestamp against the last one the other thread
                // blocked on. If ours is larger (the trace message is more
                // recent), sleep and allow the other thread to process and
                // register its message. Otherwise, continue processing trace
                // messages until we get one that is younger than the one
                // currently held by the other thread. This check is not
                // performed at all if the other thread is determined to be
                // unconnected.
                synchronized(timeLock) {
                    if ((timeStamp >= pendingTimeStamp)
                            && threadConnected[(threadID + 1) % 2]) {
                        pendingTimeStamp = timeStamp;
                        try {
                            timeLock.notify();
                            timeLock.wait();
                        }
                        catch (InterruptedException e) {
                            storedException = new ExecException(
                                "SequenceFilter thread " + threadID +
                                "was interrupted!");
                            break;
                        }
                    }
                    if (DEBUG) {
                        stdoutStream.println("Thread " + threadID +
                            " processing message, timestamp: " + timeStamp);
                    }
                }
            
                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);
                
                // Now mark the block
                int dataLength = connectionIn.readInt();  // Number of blocks
                if (dataLength > 0) {
                    synchronized(traceLock) {
                        blockID = connectionIn.readInt();
                        int nodeType = blockID >>> 26;
                        blockID &= 0x03FFFFFF;
                        // Output format for entry/exit blocks defined by Jim
                        // Law - 1/21/2004
                        switch (nodeType) {
                        case BlockType.IBLOCK:
                        //case BlockType.BLOCK.toInt():
                            if ((typeFlags & BlockType.MASK_BASIC)
                                == BlockType.MASK_BASIC) {
                                pw.println(classMethodName + "\tbasic block: " +
                                    blockID);
                            }
                            break;
                        case BlockType.IENTRY:
                            if ((typeFlags & BlockType.MASK_ENTRY)
                                == BlockType.MASK_ENTRY) {
                                pw.print(classMethodName.replace(' ','^'));
                                if (relayToSocket) {
                                    pw.print("\n");
                                }
                                else {
                                    pw.print(" ");
                                }
                            }
                            break;
                        case BlockType.IEXIT:
                            if ((typeFlags & BlockType.MASK_EXIT)
                                == BlockType.MASK_EXIT) {
                                pw.print(")r");
                                if (relayToSocket) {
                                    pw.print("\n");
                                }
                                else {
                                    pw.print(" ");
                                }
                            }
                            break;
                        case BlockType.ICALL:
                            if ((typeFlags & BlockType.MASK_CALL)
                                == BlockType.MASK_CALL) {
                                pw.println(classMethodName + "\tcall block: " +
                                    blockID);
                            }
                            break;
                        case BlockType.IRETURN:
                            if ((typeFlags & BlockType.MASK_RETURN)
                                == BlockType.MASK_RETURN) {
                                pw.println(classMethodName + "\treturn " +
                                    "block: " + blockID);
                            }
                            break;
                        default:
                            storedException = new ExecException("Invalid " +
                                "block type code received from " +
                                "instrumented\nclass");
                            break;
                        }
                        
                        if (pw.checkError()) {
                            storedException = new TraceFileException("Error " +
                                "writing to trace file");
                            break;
                        }
                        
                        if (dataLength > 1) {
                            stderrStream.println("WARNING: Multiple block " +
                                "IDs encoded in trace message, only the " +
                                "first will be recorded");
                            // Now eat the rest (so the input stream is still
                            // in synch)
                            for (int i = 0; i < dataLength - 1; i++) {
                                connectionIn.readInt();
                            }
                        }
                    }
                }
                else {
                    stderrStream.println("WARNING: No block ID encoded in " +
                        "trace message");
                }
            }
            catch (EOFException e) {
                break;
            }
            catch (SocketException e) {
                if (!e.getMessage().toLowerCase()
                        .startsWith("connection reset")) {
                    storedException = e;
                }
                break;
            }
            catch (InterruptedException e) {
                storedException = new ExecException("Unrecoverable " +
                    "interrupt received by thread " + threadID);
                break;
            }
            catch (Exception e) {
                storedException = e;
                break;
            }

            // For non-preemptive JVMs
            if (NO_PREEMPT) {
                Thread.currentThread().yield();
            }
        }
       
        if (DEBUG) stdoutStream.println("Filter loop exited");
        
        try {
            signalOut.close();
            signalIn.close();
            signalSocket.close();
            connectionIn.close();
            connection.close();
        }
        catch (IOException e) { }

        // Set this thread's flag to indicate that it has finished processing
        // and retrieve the flag containing the other thread's state.
        boolean otherConnected;
        synchronized(flagLock) {
            threadConnected[threadID] = false;
            otherConnected = threadConnected[(threadID + 1) % 2];
        }
        
        // If the other thread is still connected, notify it to continue
        // processing. With this thread's connected flag set to false, the
        // other thread will continue to process until completion without
        // blocking. If the other thread is not still connected, we are
        // completely finished, so stop the server socket.
        if (otherConnected) {
            if (DEBUG) stdoutStream.println(threadID + " notifying");
            synchronized(timeLock) {
                timeLock.notify();
            }
        }
        else {
            if (DEBUG) stdoutStream.println(threadID + " shutting down");
            stopServer();
        }
    }

    protected int doHandshake(Socket msgSocket)
                  throws IOException, ExecException {
        DataInputStream in = new DataInputStream(msgSocket.getInputStream());
        DataOutputStream out =
            new DataOutputStream(msgSocket.getOutputStream());
        
        // Check if the trace objects are basic blocks
        TraceObjectType objType = TraceObjectType.fromInt(in.readInt());
        if (objType != TraceObjectType.BASIC_BLOCK) {
            out.writeInt(1);  // Error code
            out.flush();
            throw new ExecException("Subject is not instrumented for basic " +
                "block tracing");
        }
        // Success code
        out.writeInt(0);
        out.flush();

        // Check if the declared type of instrumentation is one we can handle
        int instMode = in.readInt();
        switch (instMode) {
            case INST_COMPATIBLE:
                // Compatible-mode instrumentation is always okay
                out.writeInt(0);
                out.flush();
                break;
            case INST_OPT_NORMAL:
                // Regular-mode-optimized is never okay
                out.writeInt(1);  // Error code
                out.flush();
                throw new ExecException("Subject is not instrumented for " +
                    "sequence traces!");
            case INST_OPT_SEQUENCE:
                if (subjectIsFilter) {
                    // Optimized-sequence-mode instrumentation will not work
                    // on filter-as-subject
                    out.writeInt(1);
                    out.flush();
                    throw new ExecException("Cannot use optimized sequence " +
                        "filter instrumentation when the subject is another " +
                        "filter!");
                }
                else {
                    // Other subjects are fine
                    out.writeInt(0);
                    out.flush();
                }
                break;
            case INST_OLD_UNSUPPORTED:
                out.writeInt(1);  // Error code
                out.flush();
                throw new ExecException("Subject instrumentation is of old " +
                    "form that is no longer supported");
            default:
                // Don't know what kind of instrumentation it is
                out.writeInt(1);
                out.flush();
                throw new ExecException("Subject is not instrumented for " +
                    "sequence traces!");
        }
        return instMode;
    }

    public void runFilter()
                throws SetupException, ExecException, TraceFileException {
        if (!instanceReady) {
            throw new ExecException("SequenceFilter is no longer runnable, " +
                "a new instance must be created");
        }

        try {
            setup();
            if (relayToSocket) {
                if (relaySocket == null) {
                    try {
                        relaySocket = new Socket(relaySocketAddr,
                                                 relaySocketPort);
                        pw = new PrintWriter(
                             new BufferedWriter(
                             new OutputStreamWriter(
                                 relaySocket.getOutputStream())));
                    }
                    catch (Exception e) {
                        e.printStackTrace(stderrStream);
                        throw new TraceFileException("Could not create " +
                            "relay socket");
                    }
                    if (DEBUG) stdoutStream.println("Relay socket connected");
                }
            }
            else {
                try {
                    pw = new PrintWriter(
                         new BufferedWriter(
                         new OutputStreamWriter(Handler.openOutputFile(
                             trName + ".seq", null, appendToTrace))));
                }
                catch (Exception e) {
                    e.printStackTrace(stderrStream);
                    throw new TraceFileException("Could not create trace file");
                }
                if (DEBUG) stdoutStream.println("Sequence trace file opened");
            }
            
            if (preData != null) {
                pw.print(preData);
                if (pw.checkError()) {
                    throw new TraceFileException("Error writing pre-trace " +
                        "data");
                }
            }
            
            runSubject();
            
            Exception e = filter[0].storedException;
            if ((e == null) && (filter[1] != null)) {
                e = filter[1].storedException;
            }
            if (e != null) {
                if (e instanceof ExecException) {
                    throw (ExecException) e;
                }
                else {
                    e.printStackTrace(stderrStream);
                    throw new ExecException("Error during trace processing");
                }
            }
            
            if (!isInstrumented) {
                throw new ExecException("Class is not instrumented");
            }
        }
        finally {
            if (pw != null) {
                if (postData != null) {
                    pw.print(postData + "\n");
                }
                pw.print("\n");
                pw.flush();  // JLaw, 1/21/2004: Why? Paranoia. Raging paranoia.
                pw.close();
                if (DEBUG) {
                    stdoutStream.println("Post data written and trace file " +
                        "closed");
                }
            }
            if (DEBUG) stdoutStream.println("Cleaning up");
            cleanup();
            if ((pw != null) && pw.checkError()) {
                throw new TraceFileException("Error writing finishing data " +
                    "to trace");
            }
        }
    }

    protected ProgramFilter newInstance() {
        return new SequenceFilter();
    }
    
    /**
     * <b>SequenceFilter ignores calls to this method</b>.
     *
     * <p>SequenceFilter writes trace files progressively as trace information
     * is received.</p>
     */
    protected void writeTraceFile() { }
    
    protected boolean parseTypeCodes(String typeCodes) {
        boolean typesSet = false;
        for (int j = 1; j < typeCodes.length(); j++) {
            switch(typeCodes.charAt(j)) {
            case 'B':
                typeFlags |= BlockType.MASK_BASIC;
                break;
            case 'E':
                typeFlags |= BlockType.MASK_ENTRY;
                break;
            case 'X':
                typeFlags |= BlockType.MASK_EXIT;
                break;
            case 'C':
                typeFlags |= BlockType.MASK_CALL;
                break;
            case 'R':
                typeFlags |= BlockType.MASK_RETURN;
                break;
            default:
                throw new IllegalArgumentException("Invalid trace type");
            }
            typesSet = true;
        }
        return typesSet;
    }

    public void setTypeFlags(int typeFlags) throws IllegalArgumentException,
                                                   IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeFlags(typeFlags, TraceObjectType.BASIC_BLOCK);
    }
    
    public boolean isTypeBasic() {
        return super.isTypeBasic();
    }
    
    public void setTypeBasic(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeBasic(enable);
    }

    public boolean isTypeEntry() {
        return super.isTypeEntry();
    }
    
    public void setTypeEntry(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeEntry(enable);
    }
    
    public boolean isTypeExit() {
        return super.isTypeExit();
    }
    
    public void setTypeExit(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeExit(enable);
    }

    public boolean isTypeCall() {
        return super.isTypeCall();
    }
    
    public void setTypeCall(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeCall(enable);
    }

    /*************************************************************************
     * Prints the SequenceFilter usage message and exits.
     */
    private static void printUsage() {
        stderrStream.println("Usage:\njava sofya.inst.SequenceFilter " +
            "[-port N] [-cp PATH] [-i] [-tl N] [-at]\n [-trname <TraceName>] " +
            "[-o OutputFile] [-relay] [-pre <data>] [-post <data>]\n" +
            " -<B|E|X|C> <classfileName> <arguments>");
        stderrStream.println("   -port <N> : Listen for subject trace " +
            "statements on port number N");
        stderrStream.println("   -cp <PATH> : Set CLASSPATH for subject to " +
            "PATH");
        stderrStream.println("   -i : Enable piping of stdin to the subject");
        stderrStream.println("   -tl <N> : Kill subject after N seconds");
        stderrStream.println("   -at : Append current trace to any existing " +
            "trace file");
        stderrStream.println("   -trname <TraceName> : Set trace file name " +
            "to <TraceName> (no extension)");
        stderrStream.println("   -o <OutputFile> : Redirect subject's output " +
            "to <OutputFile>");
        stderrStream.println("   -relay : Relay processed trace data to " +
            "socket (DAG builder)");
        stderrStream.println("   -pre <data> : Prepend <data> to trace");
        stderrStream.println("   -post <data> : Append <data> to trace");
        stderrStream.println("   -<B|E|X|C> : Any permutation of the " +
            "following : B-Basic,E-Entry,X-Exit,C-Call");
        System.exit(1);
    }

    /*************************************************************************
     * The entry point for SequenceFilter, creates the SequenceFilter object
     * and runs it.
     */
    public static void main(String[] argv) {
        try {
            SequenceFilter sf =
                new SequenceFilter(argv, System.out, System.out, System.err);
            sf.runFilter();
            // Necessary only to ensure the relay socket gets closed
            // if it was created
            sf.destroy();
        }
        catch (IllegalArgumentException e) {
            stderrStream.println(e.getMessage());
            printUsage();
        }
        catch (Filter.CreateException e) {
            stderrStream.println("Error creating filter: " + e.getMessage());
            System.exit(1);
        }
        catch (Filter.SetupException e) {
            stderrStream.println("Error during initialization: " +
                e.getMessage());
            System.exit(1);
        }
        catch (Filter.ExecException e) {
            stderrStream.println("Error executing subject: " + e.getMessage());
            System.exit(1);
        }
        catch (Filter.TraceFileException e) {
            stderrStream.println("Error writing trace file: " + e.getMessage());
            System.exit(1);
        }
        catch (Exception e) {
            e.printStackTrace();
            stderrStream.println("Unrecoverable exception was thrown!");
            System.exit(1);
        }
    }
}
/*****************************************************************************/
 
/* $Log: SequenceFilter.java,v $
/* Revision 1.2  2005/06/06 18:47:47  kinneer
/* Minor revisions and added copyright notices.
/*
/* Revision 1.1.1.1  2005/01/06 17:34:16  kinneer
/* Sofya Java Bytecode Instrumentation and Analysis System
/*
/* Revision 1.24  2004/05/26 23:45:03  kinneer
/* Refactoring of the sequence filter for basic blocks. Common functions
/* and configuration for all sequence filters is now found in the new abstract
/* class SequentialFilter.
/*
/* Revision 1.23  2004/04/29 20:19:26  kinneer
/* Implemented change to 'BEXCR' parameter behavior: '-B' no longer selects
/* all block types, combination must be used instead.
/*
/* Added wrapped exceptions in Filter.
/*
/* Modified JUnitFilter to send tokens as required for the DAG builder.
/*
/* Revision 1.22  2004/04/02 23:56:06  kinneer
/* Added accessors/mutators for SequenceFilter-specific parameters.
/* Made relay socket variables protected visible for use by JUnitFilter.
/*
/* Revision 1.21  2004/02/18 20:28:32  kinneer
/* Stripped out 'legacy probe' code - removal of CFG loading makes support
/* of this impossible.
/*
/* Revision 1.20  2004/02/18 19:23:05  kinneer
/* Modifications to support new instrumentation methods (packed block
/* types/IDs, encoding of block counts). CFGs are no longer loaded during
/* Filter execution.
/*
/* Changed parameter processing methods to allow for hierarchical
/* handling of parameters - subclasses can define new parameters specific
/* to those classes.
/*
/* SequenceFilter modified to support relay of data to another socket.
/* Also supports prepended and appended user-defined data in traces.
/*
/* Revision 1.19  2004/02/09 22:55:37  kinneer
/* Critical bugfix - repeat configuration and invocation while using the
/* relay socket will no longer cause all invocations after the first to write
/* to a file instead of the socket. Added some minor javadocs.
/*
/* Revision 1.18  2004/02/03 21:23:34  kinneer
/* Updated documentation.
/*
/* Revision 1.16  2004/02/02 21:48:03  kinneer
/* Merged in Jim's output format changes.
/*
/* Revision 1.15  2004/02/02 19:11:58  kinneer
/* Restructured configureFilter() and destroy() to more easily support
/* subclass-specific command-line parameters.
/*
/* Revision 1.14  2004/01/16 01:02:25  kinneer
/* Updated to support new trace message protocol and negotiate whether
/* to accept subject based on mode of instrumentation which is present.
/*
/* Revision 1.13  2003/11/25 23:19:29  kinneer
/* Added tag support.
/*
/* Revision 1.12  2003/10/10 18:51:38  kinneer
/* Fix to exception handler instrumentation.  Improved exception handling
/* and reporting in filter(s).
/*
/* Revision 1.11  2003/10/02 21:34:37  kinneer
/* Modifications related to converstion to stream tokenizer. See also
/* Filter.java commit comments.
/*
/* Revision 1.10  2003/09/16 21:59:03  kinneer
/* Bugfixes and feature additions as described in release notes.
/*
/* Revision 1.9  2003/08/27 18:45:00  kinneer
/* Release 2.2.0.  Additional details in release notes.
/*
/* Revision 1.8  2003/08/13 18:28:46  kinneer
/* Release 2.0, please refer to release notes for details.
/*
/* Revision 1.7  2003/08/01 17:13:14  kinneer
/* Entry/exit blocks instrumented correctly. Additional bug fixes,
/* see release notes.
/*
/* Revision 1.6  2003/07/24 23:28:52  kinneer
/* Javadocs/comments updated.
/*
/* Revision 1.5  2003/07/08 00:12:09  kinneer
/* All classes JavaDoc commented.  Readability cleanup.
/*
/* Revision 1.4  2003/07/07 20:21:31  kinneer
/* Completely new thread-safe implementation of Filter and related
/* changes to Instrumentor.  This is an initial commit simply for the
/* sake of ensuring the new codebase is in the repository.  More
/* extensive comments to follow with subsequent revisions.
/*
/* Known issues:
/* 1.  Port numbers above 32767 generate a ldc_w instruction rather than
/*     an sipush instruction.  Under some (rare) circumstances this appears to
/*     cause instrumentation problems.  Currently believed to be a bug
/*     in BCEL (incorrect generation of indices into the constant pool).
/*
/* Issues inherited from previous versions:
/* 1.  Instrumentation of constructors may be incorrect
/* 2.  Instrumentation of exception handling blocks is definitely incorrect
/*
/* Resolved issues:
/* 1.  Multi-threaded subjects are now handled correctly
/* 2.  Subjects should never be incorrectly tagged as not instrumented
/* 3.  Subject system.exit calls no longer require special handling
/* 4.  Ability to run Filter on itself, both new and legacy versions
/*
/* Other notes:
/* ExeClass, Probe, and InstrumentedClassLoader are now deprecated.
/* Implications for SequenceFilter are unclear pending discussion.
/* FilterProbe removed.  New class SocketProbe added.
/*
/* Revision 1.3  2002/08/22 02:12:27  thorat
/* changed the output .seq filename to instout.seq
/*
/* Revision 1.2  2002/08/20 23:29:40  thorat
/*  Changed in main()
/*
*/
