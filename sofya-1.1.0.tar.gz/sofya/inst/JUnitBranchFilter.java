/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.net.*;
import java.util.*;

import sofya.base.exceptions.*;

/**
 * The JUnitBranchFilter class provides the ability to collect branch edge
 * coverage and sequence traces from JUnit test cases run on instrumented
 * classes.
 *
 * @author Alex Kinneer
 * @version 09/24/2004
 */
public class JUnitBranchFilter extends JUnitFilter implements BranchTracer {
    /** Conditional compilation debug flag. */
    private static final boolean DEBUG = false;

    /*************************************************************************
     * Creates a JUnitBranchFilter with a default configuration.
     *
     * <p>The filter will be configured to perform a coverage trace on
     * branch types &apos;ISTCEO&apos; using the default trace file name.</p>
     */
    public JUnitBranchFilter() throws IllegalArgumentException,
                                      CreateException {
        super();
        typeFlags = BranchType.MASK_VALID;
    }
    
    /*************************************************************************
     * Creates a JUnitBranchFilter with the specified configuration.
     *
     * @param typeFlags Bit mask representing the types of branches to be
     * traced. Can be any bitwise combination of the following
     * (See {@link sofya.base.SConstants}):
     * <ul>
     * <li><code>SConstants.BranchType.MASK_IF</code></li>
     * <li><code>SConstants.BranchType.MASK_SWITCH</code></li>
     * <li><code>SConstants.BranchType.MASK_THROW</code></li>
     * <li><code>SConstants.BranchType.MASK_CALL</code></li>
     * <li><code>SConstants.BranchType.MASK_ENTRY</code></li>
     * <li><code>SConstants.BranchType.MASK_OTHER</code></li>
     * </ul>
     * @param appendToTrace If <code>true</code>, filter will append the current
     * trace information to any existing trace file. Otherwise any previous
     * trace file will be overwritten.
     * @param trName Name of the trace file to be written.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws CreateException If there is already an instance of a filter
     * created which has not been destroyed
     * (see {@link sofya.inst.JUnitFilter#destroy}).
     */
    public JUnitBranchFilter(int typeFlags, boolean appendToTrace,
                             String trName)
                             throws IllegalArgumentException, CreateException {
        super(typeFlags, appendToTrace, trName);
    }
    
    public TraceObjectType getObjectType() {
        return TraceObjectType.BRANCH_EDGE;
    }
    
    /*************************************************************************
     * Writes currently witnessed branches to the trace.
     *
     * @param branches Reference to a (Java) Object or object array containing
     * witnessed branch information to be recorded in the trace. The type of
     * this argument depends on the type of instrumentation, so a generic
     * Object reference is used.
     * @param mSignature Signature of the method for which the branch
     * data is to be written.
     * @param fromIndex Pointer to the element in the array from which
     * the method should start reading branch information. This parameter is
     * ignored unless handling sequence instrumentation.
     * @param toIndex Pointer to the element in the array at which the method
     * should stop reading branch information. This parameter is ignored
     * unless handling sequence instrumentation.
     */ 
    protected void writeTraceData(Object branches, String mSignature,
                                  int fromIndex, int toIndex) {
        try {  // Trap runtime exceptions,
        
        switch (filterMode) {
        case COVERAGE_TRACE:
            try {
                methodTrace = traceHandler.getTrace(mSignature);
            }
            catch (MethodNotFoundException e) {
                switch (instMode) {
                case INST_COMPATIBLE:
                case INST_OPT_SEQUENCE:
                    throw new ExecException("ERROR: Trace was not properly " +
                        "allocated");
                case INST_OPT_NORMAL:
                    System.err.println("WARNING: Trace was not allocated at " +
                        "the expected time");
                    methodTrace = new Trace(((byte[]) branches).length);
                    traceHandler.setTrace(mSignature, methodTrace);
                    break;
                default:
                    throw new ExecException("ERROR: Unknown or incompatible " +
                        "instrumentation");
                }
            }
            
            switch (instMode) {
            case INST_OPT_NORMAL:
                byte[] byteArray = (byte[]) branches;
                for (int bId = 0; bId < byteArray.length; bId++) {
                    switch (byteArray[bId]) {
                    case 0:
                        // Block wasn't hit
                        continue;
                    case BranchType.IIF:
                        if ((typeFlags & BranchType.MASK_IF)
                                == BranchType.MASK_IF) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.err.println("tr.setBit <if> success");
                            }
                        }
                        break;
                    case BranchType.ISWITCH:
                        if ((typeFlags & BranchType.MASK_SWITCH)
                                == BranchType.MASK_SWITCH) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.err.println("tr.setBit <switch> success");
                            }
                        }
                        break;
                    case BranchType.ITHROW:
                        if ((typeFlags & BranchType.MASK_THROW)
                                == BranchType.MASK_THROW) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.err.println("tr.setBit <throw> success");
                            }
                        }
                        break;
                    case BranchType.ICALL:
                        if ((typeFlags & BranchType.MASK_CALL)
                                == BranchType.MASK_CALL) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.err.println("tr.setBit <call> success");
                            }
                        }
                        break;
                    case BranchType.IENTRY:
                        if ((typeFlags & BranchType.MASK_ENTRY)
                                == BranchType.MASK_ENTRY) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.err.println("tr.setBit <entry> success");
                            }
                        }
                        break;
                    case BranchType.IOTHER:
                        if ((typeFlags & BranchType.MASK_OTHER)
                                == BranchType.MASK_OTHER) {
                            methodTrace.set(bId + 1);
                            if (DEBUG) {
                                System.err.println("tr.setBit <other> success");
                            }
                        }
                        break;
                    default:
                        throw new ExecException("Invalid branch type code " +
                            "received from instrumented class");
                    }
                }
                break;
            case INST_COMPATIBLE:
                // In compatible mode instrumentation, the block data is packed
                // in the same way as for sequence instrumentation, so it's
                // easier to simply let it masquerade as such
            case INST_OPT_SEQUENCE:
                int[] intArray = (int[]) branches;
                for (int i = fromIndex; i < toIndex; i++) {
                    int branchType = intArray[i] >>> 26;
                    int branchID = intArray[i] & 0x03FFFFFF;
                    switch (branchType) {
                    case BranchType.IIF:
                        if ((typeFlags & BranchType.MASK_IF)
                                == BranchType.MASK_IF) {
                            methodTrace.set(branchID);
                        }
                        break;
                    case BranchType.ISWITCH:
                        if ((typeFlags & BranchType.MASK_SWITCH)
                                == BranchType.MASK_SWITCH) {
                            methodTrace.set(branchID);
                        }
                        break;
                    case BranchType.ITHROW:
                        if ((typeFlags & BranchType.MASK_THROW)
                                == BranchType.MASK_THROW) {
                            methodTrace.set(branchID);
                        }
                        break;
                    case BranchType.ICALL:
                        if ((typeFlags & BranchType.MASK_CALL)
                                == BranchType.MASK_CALL) {
                            methodTrace.set(branchID);
                        }
                        break;
                    case BranchType.IENTRY:
                        if ((typeFlags & BranchType.MASK_ENTRY)
                                == BranchType.MASK_ENTRY) {
                            methodTrace.set(branchID);
                        }
                        break;
                    case BranchType.IOTHER:
                        if ((typeFlags & BranchType.MASK_OTHER)
                                == BranchType.MASK_OTHER) {
                            methodTrace.set(branchID);
                        }
                        break;
                    default:
                        throw new ExecException("Invalid branch type code " +
                            "received from instrumented class");
                    }
                }
                break;
            default:
                throw new ConfigurationError("Unknown or incompatible " +
                    "instrumentation");
            }
            break;
        case SEQUENCE_TRACE:
            switch (instMode) {
            case INST_OPT_NORMAL:
                throw new ConfigurationError("Cannot generate sequence " +
                    "trace from coverage instrumentation");
            case INST_COMPATIBLE:
            case INST_OPT_SEQUENCE:
                int[] intArray = (int[]) branches;
                for (int i = fromIndex; i < toIndex; i++) {
                    int branchType = intArray[i] >>> 26;
                    int branchID = intArray[i] & 0x03FFFFFF;
                    switch (branchType) {
                    case BranchType.IIF:
                        if ((typeFlags & BranchType.MASK_IF)
                                == BranchType.MASK_IF) {
                            pw.println(mSignature + " " +  branchID);
                        }
                        break;
                    case BranchType.ISWITCH:
                        if ((typeFlags & BranchType.MASK_SWITCH)
                                == BranchType.MASK_SWITCH) {
                            pw.println(mSignature + " " +  branchID);
                        }
                        break;
                    case BranchType.ITHROW:
                        if ((typeFlags & BranchType.MASK_THROW)
                                == BranchType.MASK_THROW) {
                            pw.println(mSignature + " " +  branchID);
                        }
                        break;
                    case BranchType.ICALL:
                        if ((typeFlags & BranchType.MASK_CALL)
                                == BranchType.MASK_CALL) {
                            pw.println(mSignature + " " +  branchID);
                        }
                        break;
                    case BranchType.IENTRY:
                        if ((typeFlags & BranchType.MASK_ENTRY)
                                == BranchType.MASK_ENTRY) {
                            pw.println(mSignature + " " +  branchID);
                        }
                        break;
                    case BranchType.IOTHER:
                        if ((typeFlags & BranchType.MASK_OTHER)
                                == BranchType.MASK_OTHER) {
                            pw.println(mSignature + " " +  branchID);
                        }
                        break;
                    default:
                        throw new ExecException("Invalid branch type code " +
                            "received from instrumented class");
                    }
                    
                    if (pw.checkError()) {
                        throw new TraceFileException("Error writing to trace " +
                            "file");
                    }
                }
                break;
            default:
                throw new ExecException("ERROR: Unknown or incompatible " +
                    "instrumentation");
            }
            break;
        }


        // Catch all unexpected exceptions and store them
        } catch (Exception e) {
            e.printStackTrace();
            storedException = e;
            System.err.println("Error writing trace message");
        }
    }
    
    public void setTypeFlags(int typeFlags) throws IllegalArgumentException {
        super.setTypeFlags(typeFlags, TraceObjectType.BRANCH_EDGE);
    }

    public boolean isTypeIfs() {
        return super.isTypeIfs();
    }
    
    public void setTypeIfs(boolean enable) {
        super.setTypeIfs(enable);
    }

    public boolean isTypeSwitches() {
        return super.isTypeSwitches();
    }
    
    public void setTypeSwitches(boolean enable) {
        super.setTypeSwitches(enable);
    }
    
    public boolean isTypeThrows() {
        return super.isTypeThrows();
    }
    
    public void setTypeThrows(boolean enable) {
        super.setTypeThrows(enable);
    }

    public boolean isTypeCalls() {
        return super.isTypeCalls();
    }
    
    public void setTypeCalls(boolean enable) {
        super.setTypeCalls(enable);
    }
    
    public boolean isTypeEntries() {
        return super.isTypeEntries();
    }
    
    public void setTypeEntries(boolean enable) {
        super.setTypeEntries(enable);
    }

    public boolean isTypeOthers() {
        return super.isTypeOthers();
    }
    
    public void setTypeOthers(boolean enable) {
        super.setTypeOthers(enable);
    }
}
