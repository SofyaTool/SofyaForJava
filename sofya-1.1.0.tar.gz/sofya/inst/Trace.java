/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.util.*;

import sofya.base.Handler;

/**
 * A trace encapsulates information collected from execution of an instrumented
 * method by a filter.
 *
 * @author Alex Kinneer
 * @version 09/23/2004
 *
 * @see sofya.inst.TraceHandler
 * @see sofya.inst.Instrumentor
 * @see sofya.inst.ProgramFilter
 * @see sofya.viewers.TraceViewer
 */
public class Trace {
    /** Bit vector which records blocks hit during execution. */
    private BitSet traceVector;
    /** Highest block number found in the method. */
    private int highestBlockID;
    
    /**************************************************************************
     * Default constructor is useless, since trace will have
     * no blocks allocated, so prevent its use.
     */
    private Trace() { }
    
    /**************************************************************************
     * Default constructor, creates a trace with the specified number of
     * method blocks.
     *
     * @param highestBlockID Highest possible block number in the method,
     * cannot be changed after instantiation.
     */
    public Trace(int highestBlockID) {
        this.highestBlockID = highestBlockID;
        this.traceVector = new BitSet(highestBlockID);
    }
    
    /**************************************************************************
     * Gets the highest block ID present in the method.
     *
     * @return The highest ID of any block found in the method.
     */
    public int getHighestBlockID() {
        return highestBlockID;
    }
    
    /**************************************************************************
     * Marks that a block was hit during execution.
     *
     * @param blockID ID of the block which was executed.
     */
    public void set(int blockID) {
        if ((blockID - 1 > highestBlockID) || (blockID < 1)) {
            throw new IndexOutOfBoundsException("Method does not contain block " + blockID);
        }
        traceVector.set(blockID - 1);
    }
    
    /**************************************************************************
     * Queries whether a block was hit during execution.
     *
     * @param blockID ID of the method block to be queried.
     *
     * @return <code>true</code> if the block was hit during execution,
     * <code>false</code> otherwise.
     */
    public boolean query(int blockID) {
        if ((blockID - 1 > highestBlockID) || (blockID < 1)) {
            throw new IndexOutOfBoundsException("Method does not contain block " + blockID);
        }
        return traceVector.get(blockID - 1);
    }
    
    /**************************************************************************
     * Marks that a block was not hit during execution.
     *
     * @param blockID ID of the block for which executed status is being
     * cleared.
     */
    public void unset(int blockID) {
        if ((blockID - 1 > highestBlockID) || (blockID < 1)) {
            throw new IndexOutOfBoundsException("Method does not contain block " + blockID);
        }
        traceVector.clear(blockID - 1);    
    }
    
    /**************************************************************************
     * Clears the executed status for every method block.
     */
    public void clear() {
        BitSet zeroMask = new BitSet(traceVector.size());
        traceVector.and(zeroMask);
    }
    
    /**************************************************************************
     * Sets the trace vector for for this trace to the specified bit vector,
     * represented by a hexadecimal string.
     *
     * <p>The hexadecimal string should be a contiguous string of hexadecimal
     * digits with no special formatting. Any existing trace information
     * associated with the block will be replaced.</p>
     *
     * <p>This method will <i>not</i> reset the highest block ID for the
     * trace object. If the specified bit vector is larger than the number
     * of blocks set for this trace object, excess blocks will be
     * inaccessible (block ID keyed methods will return an
     * IndexOutOfBoundsException for those indices) and will be ignored when
     * the trace file is written. This is in part to mask the padding
     * required internally for block counts which are not multiples of four.</p>
     *
     * @param hexString New trace vector, in hexadecimal form.
     */
    void setTraceVector(String hexString) {
        traceVector = TraceHandler.toBinary(hexString);
    }

    /**************************************************************************
     * Gets the trace vector from this trace, represented as a hexadecimal
     * string.
     *
     * <p>The bit vector will be end-padded to the nearest multiple of four
     * and converted to a contiguous string of hexadecimal digits.</p>
     *
     * @return The trace vector stored by this trace object.
     */
    String getTraceVector() {
        return TraceHandler.toHex(traceVector, highestBlockID);
    }

    /**************************************************************************
     * Creates a deep clone of this trace object.
     *
     * @return A new trace object with the same number of method blocks
     * and the same blocks marked as hit during execution.
     */
    public Object clone() {
        Trace traceClone = new Trace(this.highestBlockID);
        traceClone.traceVector = (BitSet) this.traceVector.clone();
        return traceClone;
    }

    /**************************************************************************
     * Tests whether this trace object is equal to another trace.
     *
     * <p>Two trace objects are considered equal if their block counts and
     * trace bit vectors are equivalent.</p>
     *
     * @param obj Trace to which this trace should be compared for equality.
     *
     * @return <code>true</code> if the specified trace is equal to
     * this trace, <code>false</code> otherwise.
     */
    public boolean equals(Object obj) {
        if (this == obj) return true;
        Trace trace = (Trace) obj;
        if ((this.highestBlockID != trace.highestBlockID) ||
            !this.traceVector.equals(trace.traceVector)) {
            return false;
        }
        return true;
    }
    
    /**************************************************************************
     * Creates a trace that is the union of this trace and another trace.
     *
     * <p>The specified trace must have the same number of method blocks as
     * this trace. The method will then take the logical union of the
     * bit vectors in the two traces. The resulting trace will be an entirely
     * new object, neither the current trace or the specified trace will be
     * modified by this method.</p>
     *
     * @param tr Trace for which the union should be taken with
     * this trace.
     *
     * @return An entirely new trace object, representing the union
     * of this trace and the specified trace.
     */
    public Trace union(Trace tr) {
        if (this.highestBlockID != tr.highestBlockID) {
            throw new IllegalArgumentException("Methods do not have matching " +
                "number of blocks");
        }
        
        Trace unionTrace = new Trace(this.highestBlockID);
        (unionTrace.traceVector = (BitSet) this.traceVector.clone()).or(
                                  tr.traceVector);
        
        return unionTrace;
    }
    
    /**************************************************************************
     * Returns a string representation of this trace.
     *
     * <p>This method simply calls the <code>toString()</code> method of the
     * underlying BitSet and returns the result. Typically this is a list of
     * the bits in the BitSet using vector notation
     * (e.g. <code>[ 0 1 1 0 ... 1 ]</code>).</p>
     *
     * @return String representation of this trace object.
     */
    public String toString() {
        return traceVector.toString();
    }
}

/****************************************************************************/

/*
  $Log: Trace.java,v $
  Revision 1.2  2005/06/06 18:47:47  kinneer
  Minor revisions and added copyright notices.

  Revision 1.1.1.1  2005/01/06 17:34:16  kinneer
  Sofya Java Bytecode Instrumentation and Analysis System

  Revision 1.12  2004/04/16 17:59:52  kinneer
  Added union method to support trace file merging.

  Revision 1.11  2004/04/14 18:48:55  kinneer
  Moved binary/hex conversion routines to Handler class to simplify
  maintenance.

  Revision 1.10  2003/08/27 18:44:06  kinneer
  New handlers architecture. Addition of test history related classes.
  Part of release 2.2.0.

  Revision 1.9  2003/08/13 18:28:37  kinneer
  Release 2.0, please refer to release notes for details.

  Revision 1.8  2003/08/01 17:10:46  kinneer
  All file handler implementations changed from HashMaps to TreeMaps.
  See release notes for additional details.  Version string for
  Galileo has been set.

  All classes cleaned for readability and JavaDoc'ed.

  Revision 1.7  2002/07/17 05:51:27  sharmahi
  Modified package name

  Revision 1.6  2002/07/08 05:46:53  sharmahi
  Modified package name

  Revision 1.5  2002/06/25 09:09:57  sharmahi
  Added Package name "handlers"

  Revision 1.3  2002/06/09 08:45:27  sharmahi
  After first glance and review of fomrat, code style and file layout

  Revision 1.2  2002/04/16 08:42:06  sharmahi
  galileo/src/handlers/

  Revision 1.1  2002/04/06 01:26:19  sharmahi
  After first Code reviews and implementing the changes suggested.


*/    
  
   
   
