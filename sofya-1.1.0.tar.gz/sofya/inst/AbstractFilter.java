/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import sofya.base.SConstants;

/**
 * Abstract base class of all classes which perform the task of running an
 * instrumented subject and generating a trace or trace files from that
 * instrumentation.
 *
 * @author Alex Kinneer
 * @version 09/24/2004
 */
public abstract class AbstractFilter implements SConstants {
    /** Flag which controls whether instantiation is permitted. */
    protected static boolean instanceReady = false;

    /** Flag indicating whether subject is instrumented. Set to true once a
        connection has been made from the subject. */
    protected static volatile boolean isInstrumented = false;

    /** Trace type bit vector. */
    protected static int typeFlags = 0x00000000;
    /** Flag specifying whether Filter should overwrite or append to any
        existing trace file. */
    protected static boolean appendToTrace = false;
    /** Name of the trace file to be written. */
    protected static String trName = "instout";
    
     /** Stores cumulative trace information */
    protected static TraceHandler traceHandler;

    /*************************************************************************
     * Destroys this filter instance, making it possible to create a new
     * instance.
     *
     * <p>The filter object is not actually destroyed, but actions that
     * cannot reasonably depend on indeterminate finalization by the garbage
     * collector are performed. After calling this method, you will no
     * longer be able to execute/use this instance of filter - subclasses
     * are encouraged to throw an <code>IllegalStateException</code> in
     * that circumstance.
     *
     * <p><b>Note:</b> It may be more efficient to reconfigure an existing
     * filter than to destroy and create a new instance.</p>
     */
    public void destroy() {
        destroy(true);
    }

    /*************************************************************************
     * Internal implementation of the destroy method.
     *
     * @param makeUnrunnable If <code>true</code>, the filter object is
     * rendered permanently unrunnable (a new filter object must be
     * instantiated) - this is the behavior of the public method. If
     * <code>false</code>, class variables are cleared but the object
     * remains runnable. This enables subclasses to provide configuration
     * of new fields in addition to existing fields through the use
     * of chaining.
     */
    protected void destroy(boolean makeUnrunnable) {
        typeFlags = 0x00000000;
        appendToTrace = false;
        trName = "instout";
        if (makeUnrunnable) {
            instanceReady = false;
        }
    }    

    /*************************************************************************
     * Performs any cleanup required after the filter has completed
     * execution.
     */
    protected void cleanup() { }

    /*************************************************************************
     * Reports whether filter is set to append the current trace to any
     * existing trace file or whether it will overwrite it.
     *
     * @return <code>true</code> if filter will append the trace to any
     * existing trace file, <code>false</code> otherwise.
     */
    public boolean getAppendTrace() {
        return appendToTrace;
    }
    
    /*************************************************************************
     * Sets whether filter will append the current trace to any existing trace
     * file or whether it will overwrite it.
     *
     * @param enable <code>true</code> to have filter append to the existing
     * trace file, <code>false</code> otherwise.
     */
    public void setAppendTrace(boolean enable) {
        appendToTrace = enable;
    }

    /*************************************************************************
     * Gets the name of the trace file that will be written.
     *
     * @return The name of the trace file.
     */
    public String getTraceFileName() {
        return trName;
    } 

    /*************************************************************************
     * Sets the name of the trace file to be written.
     *
     * @param value The name of the trace file to be written.
     */
    public void setTraceFileName(String value) {
        if ((value == null) || (value.length() == 0)) {
            throw new IllegalArgumentException("Trace file name must be " +
                "specified");
        }
        trName = value;
    }

    /*************************************************************************
     * Gets the bit vector controlling what object types are currently
     * set to be traced by this filter. The meanings of the bits are
     * defined in terms of the program entity that is traced by this filter.
     *
     * @return Bit vector controlling what types of objects are traced.
     */
    public int getTypeFlags() {
        return typeFlags;
    }
    
    /*************************************************************************
     * Sets the bit vector controlling what object types are to be traced by
     * this filter.
     *
     * @throws IllegalArgumentException If the bit vector doesn't have a set
     * bit which corresponds to a valid object type for the program entity
     * that is traced by this filter.
     */
    public abstract void setTypeFlags(int typeFlags)
                         throws IllegalArgumentException;
    
    
    ////////////////////////////////////////////////////////////////////////////
    // The following protected methods provide correct implementations of the
    // BlockTracer and BranchTracer interfaces. A subclass should override
    // the appropriate subset of these methods with a public access level to
    // satisfy the interface it implements.
    //
    // Formally, any filter should be considered a member from the set which is
    // the cross product of the abstraction sets: {coverage, sequence},
    // {block, branch}. Both abstraction sets contain concepts that should
    // be implemented in abstract base classes and shared through inheritance -
    // basically this is one of the rare cases where true (concrete) multiple
    // inheritance is desired.
    //
    // Since concrete multiple inheritance is not possible in Java, this is the
    // best available workaround. The notion of coverage versus sequence
    // tracing is considered to be the dominant abstraction, and thus is
    // encoded in the actual inheritance hierarchy.  Therefore the type of
    // trace object operated on by a given filter is encoded through
    // interfaces, but this class implicitly and privately provides the concrete
    // implementations of those interfaces for subclasses to expose as
    // appropriate. Effectively then, these methods from this class can be
    // thought of as an extra-lingual encoding of a second base class
    // encoding concrete implementations of the other abstraction so as to
    // make them available through inheritance.
    
    /*************************************************************************
     * Sets the bit vector controlling what types of objects are to be traced
     * by this filter.
     *
     * @param typeFlags Bit vector representing the types of objects to be
     * traced.
     * @param objType The type of program entity traced by this filter.
     *
     * @throws IllegalArgumentException If the bit vector doesn't have a set
     * bit which corresponds to a valid object type.
     */
    protected void setTypeFlags(int typeFlags, TraceObjectType objType)
                   throws IllegalArgumentException {
        if ((typeFlags & objType.validMask()) == 0) {
            throw new IllegalArgumentException("No valid type specified");
        }
        this.typeFlags = typeFlags;
    }

    /*************************************************************************
     * Reports whether filter is currently set to trace basic blocks.
     *
     * @return <code>true</code> if basic blocks are to be traced,
     * <code>false</code> otherwise.
     */
    protected boolean isTypeBasic() {
        return (typeFlags & BlockType.MASK_BASIC) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace basic blocks.
     *
     * @param enable <code>true</code> to enable basic block tracing,
     * <code>false</code> to disable.
     */
    protected void setTypeBasic(boolean enable) {
        typeFlags = (enable) ? typeFlags | BlockType.MASK_BASIC
                             : typeFlags & 0xFFFFFFFE;
    }

    /*************************************************************************
     * Reports whether filter is to trace entry blocks.
     *
     * @return <code>true</code> if entry blocks are to be traced,
     * <code>false</code> otherwise.
     */
    protected boolean isTypeEntry() {
        return (typeFlags & BlockType.MASK_ENTRY) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace entry blocks.
     *
     * @param enable <code>true</code> to enable entry block tracing,
     * <code>false</code> to disable.
     */
    protected void setTypeEntry(boolean enable) {
        typeFlags = (enable) ? typeFlags | BlockType.MASK_ENTRY
                             : typeFlags & 0xFFFFFFFD;
    }
    
    /*************************************************************************
     * Reports whether filter is to trace exit blocks.
     *
     * @return <code>true</code> if exit blocks are to be traced,
     * <code>false</code> otherwise.
     */
    protected boolean isTypeExit() {
        return (typeFlags & BlockType.MASK_EXIT) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace exit blocks.
     *
     * @param enable <code>true</code> to enable exit block tracing,
     * <code>false</code> to disable.
     */
    protected void setTypeExit(boolean enable) {
        typeFlags = (enable) ? typeFlags | BlockType.MASK_EXIT
                             : typeFlags & 0xFFFFFFFB;
    }

    /*************************************************************************
     * Reports whether filter is to trace call blocks.
     *
     * @return <code>true</code> if call blocks are to be traced,
     * <code>false</code> otherwise.
     */
    protected boolean isTypeCall() {
        return (typeFlags & BlockType.MASK_CALL) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace call blocks.
     *
     * @param enable <code>true</code> to enable call block tracing,
     * <code>false</code> to disable.
     */
    protected void setTypeCall(boolean enable) {
        typeFlags = (enable) ? typeFlags | BlockType.MASK_CALL
                             : typeFlags & 0xFFFFFFF7;
    }
    
    /*************************************************************************
     * Reports whether filter is to trace return blocks.
     *
     * @return <code>true</code> if return blocks are to be traced,
     * <code>false</code> otherwise.
     */
    private boolean isTypeReturn() {
        return (typeFlags & BlockType.MASK_RETURN) != 0;
    }
    
    /*************************************************************************  
     * Sets whether filter is to trace return blocks.
     *
     * @param enable <code>true</code> to enable return block tracing,
     * <code>false</code> to disable.
     */
    private void setTypeReturn(boolean enable) {
        typeFlags = (enable) ? typeFlags | BlockType.MASK_RETURN
                             : typeFlags & 0xFFFFFFEF;
    }

    /*************************************************************************
     * Reports whether filter is currently set to trace <code>if</code>
     * branches.
     *
     * @return <code>true</code> if <code>if</code> branches are to be traced,
     * <code>false</code> otherwise.
     */
    protected boolean isTypeIfs() {
        return (typeFlags & BranchType.MASK_IF) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace <code>if</code> branches.
     *
     * @param enable <code>true</code> to enable <code>if</code> branch
     * tracing, <code>false</code> to disable.
     */
    protected void setTypeIfs(boolean enable) {
        typeFlags = (enable) ? typeFlags | BranchType.MASK_IF
                             : typeFlags & 0xFFFFFFFE;
    }

    /*************************************************************************
     * Reports whether filter is to trace <code>switch</code> branches.
     *
     * @return <code>true</code> if <code>switch</code> branches are to be
     * traced, <code>false</code> otherwise.
     */
    protected boolean isTypeSwitches() {
        return (typeFlags & BranchType.MASK_SWITCH) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace <code>switch</code> branches.
     *
     * @param enable <code>true</code> to enable <code>switch</code> branch
     * tracing, <code>false</code> to disable.
     */
    protected void setTypeSwitches(boolean enable) {
        typeFlags = (enable) ? typeFlags | BranchType.MASK_SWITCH
                             : typeFlags & 0xFFFFFFFD;
    }
    
    /*************************************************************************
     * Reports whether filter is to trace throw branches.
     *
     * @return <code>true</code> if throw branches are to be traced,
     * <code>false</code> otherwise.
     */
    protected boolean isTypeThrows() {
        return (typeFlags & BranchType.MASK_THROW) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace throw branches.
     *
     * @param enable <code>true</code> to enable throw branch tracing,
     * <code>false</code> to disable.
     */
    protected void setTypeThrows(boolean enable) {
        typeFlags = (enable) ? typeFlags | BranchType.MASK_THROW
                             : typeFlags & 0xFFFFFFFB;
    }

    /*************************************************************************
     * Reports whether filter is to trace call branches.
     *
     * @return <code>true</code> if call branches are to be traced,
     * <code>false</code> otherwise.
     */
    protected boolean isTypeCalls() {
        return (typeFlags & BranchType.MASK_CALL) != 0;
    }
    
    /*************************************************************************
     * Sets whether filter is to trace call branches.
     *
     * @param enable <code>true</code> to enable call branch tracing,
     * <code>false</code> to disable.
     */
    protected void setTypeCalls(boolean enable) {
        typeFlags = (enable) ? typeFlags | BranchType.MASK_CALL
                             : typeFlags & 0xFFFFFFF7;
    }
    
    /*************************************************************************
     * Reports whether filter is to trace &quot;entry&quot; branches.
     *
     * @return <code>true</code> if &quot;entry&quot; branches are to be
     * traced, <code>false</code> otherwise.
     */
    protected boolean isTypeEntries() {
        return (typeFlags & BranchType.MASK_ENTRY) != 0;
    }
    
    /*************************************************************************  
     * Sets whether filter is to trace &quot;entry&quot; branches.
     *
     * @param enable <code>true</code> to enable &quot;entry&quot; branch
     * tracing, <code>false</code> to disable.
     */
    protected void setTypeEntries(boolean enable) {
        typeFlags = (enable) ? typeFlags | BranchType.MASK_ENTRY
                             : typeFlags & 0xFFFFFFEF;
    }

    /*************************************************************************
     * Reports whether filter is to trace &quot;other&quot; branches.
     *
     * <p>Currently this corresponds only the summary branch that is marked
     * for imprecisely identified exceptional exits (such as those caused
     * by an untrapped divide-by-zero or array index out of bounds
     * exception and similar).
     *
     * @return <code>true</code> if &quot;other&quot; branches are to be
     * traced, <code>false</code> otherwise.
     */
    protected boolean isTypeOthers() {
        return (typeFlags & BranchType.MASK_OTHER) != 0;
    }
    
    /*************************************************************************  
     * Sets whether filter is to trace &quot;other&quot; branches.
     *
     * @param enable <code>true</code> to enable &quot;other&quot; branch
     * tracing, <code>false</code> to disable.
     */
    protected void setTypeOthers(boolean enable) {
        typeFlags = (enable) ? typeFlags | BranchType.MASK_OTHER
                             : typeFlags & 0xFFFFFFDF;
    }

    /** Exception that indicates an error occurred during instantiation of a
        filter object or that instantation is not permitted. */
    public static class CreateException extends Exception {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;
        
        /** Creates an instance with the given message. */
        public CreateException(String s) { super(s); }
        
        /** Creates an instance with the given message wrapping another
            exception. */
        public CreateException(String s, Throwable e) {
            super(s);
            cause = e;
        }
        
        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }
    
    /** Exception that indicates an error occurred while preparing to execute
        a subject class. */
    public static class SetupException extends Exception {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;
        
        /** Create an instance with the given message. */
        public SetupException(String s) { super(s); }
        
        /** Creates an instance with the given message wrapping another
            exception. */
        public SetupException(String s, Throwable e) {
            super(s);
            cause = e;
        }
        
        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }
    
    /** Exception that indicates an error occurred in filter while executing
        a subject class. */
    public static class ExecException extends Exception  {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;
        
        /** Create an instance with the given message. */
        public ExecException(String s) { super(s); }
        
        /** Creates an instance with the given message wrapping another
            exception. */
        public ExecException(String s, Throwable e) {
            super(s);
            cause = e;
        }
        
        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }
    
    /** Exception that indicates an error occurred while creating or writing
        the trace file. */
    public static class TraceFileException extends Exception  {
        /** Wrapped exception that is the original cause, if applicable. */
        private Throwable cause = null;
        
        /** Create an instance with the given message. */
        public TraceFileException(String s) { super(s); }
        
        /** Creates an instance with the given message wrapping another
            exception. */
        public TraceFileException(String s, Throwable e) {
            super(s);
            cause = e;
        }
        
        /** Gets the exception that is the original source of the problem
            (may be <code>null</code>). */
        public Throwable getCause() {
            return cause;
        }
    }
}
