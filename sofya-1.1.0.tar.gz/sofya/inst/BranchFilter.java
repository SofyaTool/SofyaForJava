/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.net.*;
import java.util.*;

import sofya.base.ProjectDescription;
import sofya.base.exceptions.*;

/**
 * This class is responsible for executing a subject containing
 * branch instrumentation and generating a trace file from the instrumentation.
 *
 * <p>Usage:<br><code>java sofya.inst.BranchFilter [-port <i>n</i>]
 * [-cp <i>path</i>] [-i] [-tl <i>num_secs</i>] [-at] [-o <i>OutputFile</i>]
 * [-trname <i>TraceName</i>] -&lt;I|S|T|C|E|O&gt; &lt;classfileName&gt;
 * &lt;arguments&gt;</code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-port <i>n</i> : Listen for subject trace
 * statements on port number <i>n</i></code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-cp <i>path</i> : Set CLASSPATH for subject
 * to <i>path</i></code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-i : Enable piping of stdin to the
 * subject</code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-tl <i>num_secs</i> : Kill the subject after
 * <i>num_secs</i> if it has not yet terminated</code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-at : Append current trace to any existing
 * trace file</code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-trname <i>TraceName</i> : Set trace file
 * name to be <i>TraceName</i> (do not include .tr extension)</code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-o <i>OutputFile</i> : Redirect the subject's
 * output to <i>OutputFile</i></code><br>
 * &nbsp&nbsp&nbsp&nbsp&nbsp<code>-&lt;I|S|T|C|E|O&gt; : Any permutation of the
 * following : I-Ifs,S-Switches,T-Throws,C-Calls,E-Entries,O-Others</code></p>
 *
 * <p>Using the <code>-cp</code> parameter overrides the system classpath for
 * the subject. Naturally the classpath provided should include the location
 * of the subject's classes.</p>
 *
 * <p>Piping of the standard input is disabled by default to avoid the overhead
 * of an additional thread and because subjects blocking for input is
 * inconsistent with the objective of automated regression testing. This does
 * however mean that if a subject class requires external input, the entire
 * system will deadlock. The <code>-i</code> parameter is intended to prevent
 * this deadlock in the event that it is desired to perform a supervised
 * execution of subject class that in its natural form requires input.</p>
 *
 * <p>Use of the <code>-tl</code> parameter is preferred over killing the
 * Filter process itself, as the former allows Filter to perform various
 * cleanup actions (and generate a partial trace).</p>
 *
 * @see sofya.inst.SocketProbe
 * @see sofya.inst.BranchInstrumentor
 * @see sofya.inst.cfInstrumentor
 *
 * @author Alex Kinneer
 * @version 09/24/2004
 */
public class BranchFilter extends CoverageFilter implements BranchTracer {
    /** Conditional compilation debug flag. */
    private static final boolean DEBUG = false;
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter()}.
     */
    protected BranchFilter() {
        super();
    }
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter(
     * java.lang.String[],java.io.OutputStream,java.io.OutputStream,
     * java.io.OutputStream)}.
     */
    public BranchFilter(String[] argv, OutputStream subjectSink,
                        OutputStream stdoutSink, OutputStream stderrSink)
                        throws IllegalArgumentException, CreateException {
        super(argv, subjectSink, stdoutSink, stderrSink);
    }
    
    /*************************************************************************
     * Standard constructor, constructs a branch filter with the specified
     * initial configuration.
     *
     * @param className Name of the subject class which is to be executed.
     * @param subjectArgs Set of arguments to be passed to the subject class.
     * @param subjectCP Java classpath that will be set for the subject when it
     * is executed.
     * @param typeFlags Bit mask representing the types of branches to be
     * traced. Can be any bitwise combination of the following
     * (See {@link sofya.base.SConstants}):
     * <ul>
     * <li><code>SConstants.BranchType.MASK_IF</code></li>
     * <li><code>SConstants.BranchType.MASK_SWITCH</code></li>
     * <li><code>SConstants.BranchType.MASK_THROW</code></li>
     * <li><code>SConstants.BranchType.MASK_CALL</code></li>
     * <li><code>SConstants.BranchType.MASK_ENTRY</code></li>
     * <li><code>SConstants.BranchType.MASK_OTHER</code></li>
     * </ul>
     * @param port The port number on which filter should listen for incoming
     * instrumentation messages from the subject. The valid range is
     * 1024 to 65535. An exception is the value -1, which instructs Filter
     * to select the default port.
     * @param pipeInput If <code>true</code>, filter will redirect input on
     * standard in to the subject's standard input stream.
     * @param timeLimit The length of time in seconds that the subject is
     * allowed to run before being killed.
     * @param appendToTrace If <code>true</code>, filter will append the current
     * trace information to any existing trace file. Otherwise any previous
     * trace file will be overwritten.
     * @param trName Name of the trace file to be written.
     * @param subjectSink Output stream to which subject's outputs are to be
     * written. If <code>null</code>, <code>System.out</code> is used by
     * default.
     * @param stdoutSink Output stream to which filter's normal outputs are to
     * be written. If <code>null</code>, <code>System.out</code> is used by
     * default. When filter is compiled in <code>DEBUG</code> mode, debug
     * information is also printed to this stream.
     * @param stderrSink Output stream to which filter's error outputs are to
     * be written. If <code>null</code>, <code>System.err</code> is used by
     * default.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws CreateException If there is already an instance of Filter
     * created which has not been destroyed (see
     * {@link sofya.inst.Filter#destroy}).
     */
    public BranchFilter(String className, String[] subjectArgs, String subjectCP,
                        int typeFlags, int port, boolean pipeInput,
                        int timeLimit, boolean appendToTrace, String trName,
                        OutputStream subjectSink, OutputStream stdoutSink,
                        OutputStream stderrSink)
                        throws IllegalArgumentException, CreateException {
        super(className, subjectArgs, subjectCP, typeFlags, port,
              pipeInput, timeLimit, appendToTrace, trName,
              subjectSink, stdoutSink, stderrSink);
    }
    
    protected void runNormal() {
        Socket connection = null;
        DataInputStream connectionIn = null;
        Trace trace = null;
        int maxBranchId, branchID;

        try {
            connection = serverSocket.accept();
            // The fact that a socket is being opened means we know the subject is instrumented
            isInstrumented = true;
            // The handshake currently consists of validating the instrumentation type.
            try {
                doHandshake(connection);
            }
            catch (ExecException e) {
                storedException = e;
                stopServer();
                return;
            }
            connectionIn = new DataInputStream(new BufferedInputStream(connection.getInputStream()));
            threadConnected[threadID] = true;
        }
        catch (IOException e) {
            if (e.getMessage().toLowerCase().startsWith("socket closed")) { return; }
            storedException = e;
            stderrStream.println("Error accepting instrumentation connection!");
            stopServer();
            return;
        }

        byte[] buffer = new byte[1024];
        while (!forceStop) {
            try {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message
                    parseMethodSignature(connectionIn, buffer);
                    maxBranchId = connectionIn.readInt();
                    if (!traceHandler.containsTrace(classMethodName)) {
                        traceHandler.setTrace(classMethodName, new Trace(maxBranchId));
                    }
                    else {
                        trace = traceHandler.getTrace(classMethodName);
                        if (trace.getHighestBlockID() != maxBranchId) {
                            storedException = new ExecException("Method " + classMethodName +
                                " reports inconsistent number of branch edges");
                            break;
                        }
                    }
                    continue;
                }
                
                // Check timestamp flag
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }
                
                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);
                
                // Now read and mark each block
                int dataLength = connectionIn.readInt();  // Number of edges to be processed
                for (int i = 0; i < dataLength; i++) {
                    branchID = connectionIn.readInt();
                    int edgeType = branchID >>> 26;
                    branchID &= 0x03FFFFFF;
                    trace = traceHandler.getTrace(classMethodName);
                    switch (edgeType) {
                    case BranchType.IIF:
                        if ((typeFlags & BranchType.MASK_IF)
                                == BranchType.MASK_IF) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println("tr.setBit <if> success");
                        }
                        break;
                    case BranchType.ISWITCH:
                        if ((typeFlags & BranchType.MASK_SWITCH)
                                == BranchType.MASK_SWITCH) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println("tr.setBit <switch> success");
                        }
                        break;
                    case BranchType.ITHROW:
                        if ((typeFlags & BranchType.MASK_THROW)
                                == BranchType.MASK_THROW) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println("tr.setBit <throw> success");
                        }
                        break;
                    case BranchType.ICALL:
                        if ((typeFlags & BranchType.MASK_CALL)
                                == BranchType.MASK_CALL) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println("tr.setBit <call> success");
                        }
                        break;
                    case BranchType.IENTRY:
                        if ((typeFlags & BranchType.MASK_ENTRY)
                                == BranchType.MASK_ENTRY) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println("tr.setBit <entry> success");
                        }
                        break;
                    case BranchType.IOTHER:
                        if ((typeFlags & BranchType.MASK_OTHER)
                                == BranchType.MASK_OTHER) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println("tr.setBit <other> success");
                        }
                        break;
                    default:
                        storedException = new ExecException("Invalid branch type code " +
                            "received from instrumented\nclass");
                        break;
                    }
                }
            }
            catch (EOFException e) {
                break;
            }
            catch (Exception e) {
                storedException = e;
                break;
            }

            // For non-preemptive JVMs
            if (NO_PREEMPT) {
                Thread.currentThread().yield();
            }
        }
       
        if (DEBUG) stdoutStream.println("Filter loop exited");

        threadConnected[threadID] = false;
        try {
            connectionIn.close();
            connection.close();
        }
        catch (IOException e) { }
        
        stopServer();
    }
    
    protected void runSynchronized() {
        Socket connection = null;
        Socket signalSocket = null;
        DataInputStream connectionIn = null;
        Trace trace = null;
        int maxBranchId, branchID;

        try {
            // Make sure server socket does not try to accept two connections simultaneously.
            // This is probably unnecessary, but erring on the side of caution.
            synchronized(connectLock) {
                connection = serverSocket.accept();
                isInstrumented = true;
                if (DEBUG) stdoutStream.println(threadID + ": accepted connection");
            }
            // The handshake currently consists of validating the instrumentation type.
            int instMode = -1;
            try {
                instMode = doHandshake(connection);
            }
            catch (ExecException e) {
                storedException = e;
                stopServer();
                return;
            }
            if (DEBUG) stdoutStream.println(threadID + ": completed handshake");
            connectionIn = new DataInputStream(new BufferedInputStream(connection.getInputStream()));
            // Connect the signal socket. We won't do anything with it, but the alternative
            // is to require the user to instrument Filter as a subject differently when
            // they intend to run it with SequenceFilter as opposed to the regular Filter
            if (instMode == INST_COMPATIBLE) signalSocket = openSignalSocket(connection);
            if (DEBUG) stdoutStream.println(threadID + ": connected signal socket");
            // Indicate that this thread is now connected and processing.
            synchronized(flagLock) {
                threadConnected[threadID] = true;
            }
            if (DEBUG) stdoutStream.println(threadID + ": is connected");
        }
        catch (IOException e) {
            // This may happen if either Filter or SocketProbe was instrumented but not the
            // other. Thus it is considered part of orderly shutdown.
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            storedException = e;
            stderrStream.println("Error accepting instrumentation connection!");
            stopServer();
            return;
        }

        byte[] buffer = new byte[1024];
        while (!forceStop && (filter[(threadID + 1) % 2].storedException == null)) {
            try {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message
                    parseMethodSignature(connectionIn, buffer);
                    maxBranchId = connectionIn.readInt();
                    synchronized(traceLock) {
                        if (!traceHandler.containsTrace(classMethodName)) {
                            traceHandler.setTrace(classMethodName, new Trace(maxBranchId));
                        }
                        else {
                            trace = traceHandler.getTrace(classMethodName);
                            if (trace.getHighestBlockID() != maxBranchId) {
                                storedException = new ExecException("Method " + classMethodName +
                                    " reports inconsistent number of branch edges");
                                break;
                            }
                        }
                    }
                    continue;
                }

                // Strip timestamp
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }
                
                // Read the method signature information and use it to load the CFG
                parseMethodSignature(connectionIn, buffer);
                if (DEBUG) stdoutStream.println(threadID + ": " + classMethodName);
            
                // Now read and mark each block
                int dataLength = connectionIn.readInt();  // Number of blocks to be processed
                for (int i = 0; i < dataLength; i++) {
                    branchID = connectionIn.readInt();
                    int edgeType = branchID >>> 26;
                    branchID &= 0x03FFFFFF;
                    trace = traceHandler.getTrace(classMethodName);
                    switch (edgeType) {
                    case BranchType.IIF:
                        if ((typeFlags & BranchType.MASK_IF)
                                == BranchType.MASK_IF) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println(threadID + ": tr.setBit <if> success");
                        }
                        break;
                    case BranchType.ISWITCH:
                        if ((typeFlags & BranchType.MASK_SWITCH)
                                == BranchType.MASK_SWITCH) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println(threadID + ": tr.setBit <switch> success");
                        }
                        break;
                    case BranchType.ITHROW:
                        if ((typeFlags & BranchType.MASK_THROW)
                                == BranchType.MASK_THROW) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println(threadID + ": tr.setBit <throw> success");
                        }
                        break;
                    case BranchType.ICALL:
                        if ((typeFlags & BranchType.MASK_CALL)
                                == BranchType.MASK_CALL) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println(threadID + ": tr.setBit <call> success");
                        }
                        break;
                    case BranchType.IENTRY:
                        if ((typeFlags & BranchType.MASK_ENTRY)
                                == BranchType.MASK_ENTRY) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println(threadID + ": tr.setBit <entry> success");
                        }
                        break;
                    case BranchType.IOTHER:
                        if ((typeFlags & BranchType.MASK_OTHER)
                                == BranchType.MASK_OTHER) {
                            trace.set(branchID);
                            if (DEBUG) stdoutStream.println(threadID + ": tr.setBit <other> success");
                        }
                        break;
                    default:
                        storedException = new ExecException("Invalid branch type code " +
                            "received from instrumented\nclass");
                        break;
                    }
                }
            }
            catch (EOFException e) {
                if (DEBUG) System.out.println(threadID + ": end of stream");
                break;
            }
            catch (Exception e) {
                storedException = e;
                break;
            }
            
            // For non-preemptive JVMs
            if (NO_PREEMPT) {
                Thread.currentThread().yield();
            }
        }
       
        if (DEBUG) stdoutStream.println(threadID + ": Filter loop exited");
        
        try {
            connectionIn.close();
            connection.close();
            if (signalSocket != null) signalSocket.close();
        }
        catch (IOException e) { }
        
        // Set this thread's flag to indicate that it has finished processing
        // and retrieve the flag containing the other thread's state.
        boolean otherConnected;
        synchronized(flagLock) {
            threadConnected[threadID] = false;
            if (!threadConnected[(threadID + 1) % 2]) {
                if (DEBUG) stdoutStream.println(threadID + ": shutting down");
                stopServer();
            }
        }
    }
    
    protected int doHandshake(Socket msgSocket)
                  throws IOException, ExecException {
        DataInputStream in = new DataInputStream(msgSocket.getInputStream());
        DataOutputStream out = new DataOutputStream(msgSocket.getOutputStream());
        
        // Check if the trace objects are branch edges
        TraceObjectType objType = TraceObjectType.fromInt(in.readInt());
        if (objType != TraceObjectType.BRANCH_EDGE) {
            out.writeInt(1);  // Error code
            out.flush();
            throw new ExecException("Subject is not instrumented for branch " +
                "tracing");
        }
        // Success code
        out.writeInt(0);
        out.flush();
        
        // Check if the declared type of instrumentation is one we can handle.
        // Coverage filters can handle all types except JUnit - some will just
        // be slower than others.
        int instMode = in.readInt();
        if ((instMode < 1) || (instMode == 3) || (instMode > 4)) {
            out.writeInt(1);  // Error code
            out.flush();
            if (instMode == INST_OLD_UNSUPPORTED) {
                throw new ExecException("Subject instrumentation is of old form " +
                    "that is no longer supported");
            }
            else {
                throw new ExecException("Cannot process type of instrumentation " +
                    "present in subject!");
            }
        }
        // Success code
        out.writeInt(0);
        out.flush();
        
        // Nonetheless, print a warning for optimized sequence filter instrumentation
        if (instMode == INST_OPT_SEQUENCE) {
            stdoutStream.println("INFO: Subject is instrumented for sequence tracing. " +
                 "Running it through");
            stdoutStream.println("this filter will be inefficient (and will not " +
                 "provide sequence");
            stdoutStream.println("information)");
        }
        return instMode;
    }

    public void runFilter() throws SetupException, ExecException, TraceFileException {
        if (!instanceReady) {
            throw new ExecException("Filter is no longer runnable, a new instance must be created");
        }
        try {
            setup();
            traceHandler = new TraceHandler(typeFlags, TraceObjectType.BRANCH_EDGE);
            if (appendToTrace) {
                try {
                    traceHandler.readTraceFile(ProjectDescription.dbDir +
                        File.separatorChar + trName + ".tr");
                }
                catch (EmptyFileException e) {
                    // To avoid the exception below. Since it's empty anyway,
                    // we can just override the block types.
                    traceHandler.setTypeFlags(typeFlags);
                }
                catch (FileNotFoundException e) {
                    // To avoid the exception below. We'll just
                    // create the trace.
                    traceHandler.setTypeFlags(typeFlags);
                }
                catch (BadFileFormatException e) {
                    throw new TraceFileException("Cannot append to trace - the existing trace is " +
                        "invalid: " + e.getMessage());
                }
                catch (IOException e) {
                    throw new TraceFileException("I/O error: \"" + e.getMessage() +
                               "\" attempting to read existing trace");
                }
                
                if (traceHandler.getTypeFlags() != typeFlags) {
                    throw new TraceFileException("Selected block types do not match types in " +
                        "existing trace");
                }
            }
            else {
                traceHandler.setTypeFlags(typeFlags);
            }
            runSubject();
            
            Exception e = filter[0].storedException;
            if ((e == null) && (filter[1] != null)) e = filter[1].storedException;
            if (e != null) {
                if (e instanceof ExecException) {
                    throw (ExecException) e;
                }
                else {
                    throw new ExecException("Error during trace processing", e);
                }
            }

            if (!isInstrumented) {
                throw new ExecException("Class is not instrumented");
            }
            else {
                writeTraceFile();
            }
        }
        finally {
            cleanup();
        }
    }
    
    protected ProgramFilter newInstance() {
        return new BranchFilter();
    }

    protected void writeTraceFile() throws TraceFileException {
        try {
            traceHandler.writeTraceFile(trName, false);
        }
        catch (IOException e) {
            throw new TraceFileException("Cannot write out the trace file", e);
        }
    }

    protected boolean parseTypeCodes(String typeCodes) {
        boolean typesSet = false;
        for (int j = 1; j < typeCodes.length(); j++) {
            switch(typeCodes.charAt(j)) {
            case 'I':
                typeFlags |= BranchType.IIF;
                break;
            case 'S':
                typeFlags |= BranchType.ISWITCH;
                break;
            case 'T':
                typeFlags |= BranchType.ITHROW;
                break;
            case 'C':
                typeFlags |= BranchType.ICALL;
                break;
            case 'E':
                typeFlags |= BranchType.IENTRY;
                break;
            case 'O':
                typeFlags |= BranchType.IOTHER;
                break;
            default:
                throw new IllegalArgumentException("Invalid trace type");
            }
            typesSet = true;
        }
        return typesSet;
    }
    
    public void setTypeFlags(int typeFlags) throws IllegalArgumentException,
                                                   IllegalStateException {
        if (this.typeFlags != typeFlags) {
            checkRunning("Cannot change trace type while filter is running");
        }
        super.setTypeFlags(typeFlags, TraceObjectType.BRANCH_EDGE);
    }

    public boolean isTypeIfs() {
        return super.isTypeIfs();
    }
    
    public void setTypeIfs(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeIfs(enable);
    }

    public boolean isTypeSwitches() {
        return super.isTypeSwitches();
    }
    
    public void setTypeSwitches(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeSwitches(enable);
    }
    
    public boolean isTypeThrows() {
        return super.isTypeThrows();
    }
    
    public void setTypeThrows(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeThrows(enable);
    }

    public boolean isTypeCalls() {
        return super.isTypeCalls();
    }
    
    public void setTypeCalls(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeCalls(enable);
    }
    
    public boolean isTypeEntries() {
        return super.isTypeEntries();
    }
    
    public void setTypeEntries(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeEntries(enable);
    }

    public boolean isTypeOthers() {
        return super.isTypeOthers();
    }
    
    public void setTypeOthers(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeOthers(enable);
    }

    /*************************************************************************
     * Prints the Filter usage message and exits.
     */
    private static void printUsage() {
        stderrStream.println("Usage:\njava sofya.inst.BranchFilter " +
            "[-port N] [-cp PATH] [-i] [-tl N] [-at]\n [-trname <TraceName>] " +
            "[-o OutputFile] -<I|S|T|C|E|O> <classfileName>\n <arguments>");
        stderrStream.println("   -port <N> : Listen for subject trace " +
            "statements on port number N");
        stderrStream.println("   -cp <PATH> : Set CLASSPATH for subject to " +
            "PATH");
        stderrStream.println("   -i : Enable piping of stdin to the subject");
        stderrStream.println("   -tl <N> : Kill subject after N seconds");
        stderrStream.println("   -at : Append current trace to any existing " +
            "trace file");
        stderrStream.println("   -trname <TraceName> : Set trace file name " +
            "to <TraceName> (no extension)");
        stderrStream.println("   -o <OutputFile> : Redirect subject's output " +
            "to <OutputFile>");
        stderrStream.println("   -<I|S|T|C|E|O> : Any permutation of the " +
            "following : I-Ifs,S-Switches,T-Throws\n                        " +
            "C-Calls,E-Entries,O-Others");
        System.exit(1);
    }
   
    /*************************************************************************
     * Entry point for BranchFilter.
     */
    public static void main(String[] argv) {
        try {
            BranchFilter f = new BranchFilter(argv, System.out,
                System.out, System.err);
            f.runFilter();
        }
        catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            if (!e.getMessage().startsWith("Port")) {
                printUsage();
            }
            System.exit(1);
        }
        catch (Filter.CreateException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error creating filter: " + e.getMessage());
            System.exit(1);
        }
        catch (Filter.SetupException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error during initialization: " +
                e.getMessage());
            System.exit(1);
        }
        catch (Filter.ExecException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error executing subject: " + e.getMessage());
            System.exit(1);
        }
        catch (Filter.TraceFileException e) {
            Throwable source = e.getCause();
            if (source != null) source.printStackTrace();
            System.err.println("Error writing trace file: " + e.getMessage());
            System.exit(1);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.err.println("Unrecoverable exception was thrown!");
            System.exit(1);
        }
    }
}
