/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

/**
 * This interface defines the contract of configuration methods which are
 * relevant to filter classes which operate on a branch edge representation
 * of Java class files.
 *
 * @author Alex Kinneer
 * @version 05/20/2004
 *
 * @see sofya.inst.AbstractFilter
 */
public interface BranchTracer {
    /*************************************************************************
     * Gets bit vector representing branch types that are currently set to be
     * traced by this filter.
     *
     * @return Bit vector controlling what types of branches are traced.
     */
    public int getTypeFlags();
    
    /*************************************************************************
     * Sets bit vector controlling what branch types are to be traced by this
     * filter.
     *
     * @param typeFlags Bit mask representing the types of branches to be
     * traced. Can be any bitwise combination of the following
     * (See {@link sofya.base.SConstants}):
     * <ul>
     * <li><code>SConstants.BranchType.MASK_IF</code></li>
     * <li><code>SConstants.BranchType.MASK_SWITCH</code></li>
     * <li><code>SConstants.BranchType.MASK_THROW</code></li>
     * <li><code>SConstants.BranchType.MASK_CALL</code></li>
     * <li><code>SConstants.BranchType.MASK_ENTRY</code></li>
     * <li><code>SConstants.BranchType.MASK_OTHER</code></li>
     * </ul>
     *
     * @throws IllegalArgumentException If the bit vector doesn't have a bit
     * set which corresponds to a valid branch type.
     * @throws ExecException If called while filter is running.
     */
    public void setTypeFlags(int typeFlags) throws IllegalArgumentException;

    /*************************************************************************
     * Reports whether filter is currently set to trace <code>if</code> branches.
     *
     * @return <code>true</code> if <code>if</code> branches are to be traced,
     * <code>false</code> otherwise.
     */
    public boolean isTypeIfs();
    
    /*************************************************************************
     * Sets whether filter is to trace <code>if</code> branches.
     *
     * @param enable <code>true</code> to enable <code>if</code> branch
     * tracing, <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeIfs(boolean enable);

    /*************************************************************************
     * Reports whether filter is to trace <code>switch</code> branches.
     *
     * @return <code>true</code> if <code>switch</code> branches are to be
     * traced, <code>false</code> otherwise.
     */
    public boolean isTypeSwitches();
    
    /*************************************************************************
     * Sets whether filter is to trace <code>switch</code> branches.
     *
     * @param enable <code>true</code> to enable <code>switch</code> branch
     * tracing, <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeSwitches(boolean enable);
    
    /*************************************************************************
     * Reports whether filter is to trace throw branches.
     *
     * @return <code>true</code> if throw branches are to be traced,
     * <code>false</code> otherwise.
     */
    public boolean isTypeThrows();
    
    /*************************************************************************
     * Sets whether filter is to trace throw branches.
     *
     * @param enable <code>true</code> to enable throw branch tracing,
     * <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeThrows(boolean enable);

    /*************************************************************************
     * Reports whether filter is to trace call branches.
     *
     * @return <code>true</code> if call branches are to be traced,
     * <code>false</code> otherwise.
     */
    public boolean isTypeCalls();
    
    /*************************************************************************
     * Sets whether filter is to trace call branches.
     *
     * @param enable <code>true</code> to enable call branch tracing,
     * <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeCalls(boolean enable);
    
    /*************************************************************************
     * Reports whether filter is to trace &quot;entry&quot; branches.
     *
     * @return <code>true</code> if &quot;entry&quot; branches are to be
     * traced, <code>false</code> otherwise.
     */
    public boolean isTypeEntries();
    
    /*************************************************************************  
     * Sets whether filter is to trace &quot;entry&quot; branches.
     *
     * @param enable <code>true</code> to enable &quot;entry&quot; branch
     * tracing, <code>false</code> to disable.
     */
    public void setTypeEntries(boolean enable);

    /*************************************************************************
     * Reports whether filter is to trace &quot;other&quot; branches.
     *
     * <p>Currently this corresponds only the summary branch that is marked
     * for imprecisely identified exceptional exits (such as those caused
     * by an untrapped divide-by-zero or array index out of bounds
     * exception and similar).
     *
     * @return <code>true</code> if &quot;other&quot; branches are to be
     * traced, <code>false</code> otherwise.
     */
    public boolean isTypeOthers();
    
    /*************************************************************************  
     * Sets whether filter is to trace &quot;other&quot; branches.
     *
     * @param enable <code>true</code> to enable &quot;other&quot; branch
     * tracing, <code>false</code> to disable.
     *
     * @throws ExecException If called while filter is running.
     */
    public void setTypeOthers(boolean enable);
}
