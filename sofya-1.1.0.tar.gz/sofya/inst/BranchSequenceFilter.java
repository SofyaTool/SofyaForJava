/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.net.*;
import java.util.*;

import sofya.base.Handler;

/**
 * Class to construct a list of the branches traversed by a subject in
 * chronological order.
 *
 * <p>The usage and considerations for this class are similar to
 * those for {@link sofya.inst.BranchFilter}.  The only difference is
 * the type of trace file that is generated.</p>
 *
 * @author Alex Kinneer
 * @version 09/24/2004
 */
public class BranchSequenceFilter
             extends SequentialFilter implements BranchTracer {
    /** Conditional compilation debug flag. */
    private static final boolean DEBUG = false;
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter()}.
     */
    protected BranchSequenceFilter() {
        super();
    }

    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter(
     * java.lang.String[],java.io.OutputStream,java.io.OutputStream,
     * java.io.OutputStream)}.
     */
    public BranchSequenceFilter(String[] argv, OutputStream subjectSink,
            OutputStream stdoutSink, OutputStream stderrSink)
            throws IllegalArgumentException, CreateException {
        super(argv, subjectSink, stdoutSink, stderrSink);
    }

    /*************************************************************************
     * Standard constructor, constructs BranchSequenceFilter with the
     * specified initial configuration.
     *
     * @param className Name of the subject class which is to be executed.
     * @param subjectArgs Set of arguments to be passed to the subject class.
     * @param subjectCP Java classpath that will be set for the subject when
     * it is executed.
     * @param typeFlags Bit mask representing the types of branches to be
     * traced. Can be any bitwise combination of the following
     * (See {@link sofya.base.SConstants}):
     * <ul>
     * <li><code>SConstants.BranchType.MASK_IF</code></li>
     * <li><code>SConstants.BranchType.MASK_SWITCH</code></li>
     * <li><code>SConstants.BranchType.MASK_THROW</code></li>
     * <li><code>SConstants.BranchType.MASK_CALL</code></li>
     * <li><code>SConstants.BranchType.MASK_ENTRY</code></li>
     * <li><code>SConstants.BranchType.MASK_OTHER</code></li>
     * </ul>
     * @param port The port number on which filter should listen for incoming
     * instrumentation messages from the subject. The valid range is
     * 1024 to 65535. An exception is the value -1, which instructs Filter
     * to select the default port.
     * @param pipeInput If <code>true</code>, filter will redirect input on
     * standard in to the subject's standard input stream.
     * @param timeLimit The length of time in seconds that the subject is
     * allowed to run before being killed.
     * @param appendToTrace If <code>true</code>, filter will append the
     * current trace information to any existing trace file. Otherwise any
     * previous trace file will be overwritten.
     * @param trName Name of the trace file to be written.
     * @param subjectSink Output stream to which subject's outputs are to be
     * written. If <code>null</code>, <code>System.out</code> is used by
     * default.
     * @param stdoutSink Output stream to which filter's normal outputs are to
     * be written. If <code>null</code>, <code>System.out</code> is used by
     * default. When filter is compiled in <code>DEBUG</code> mode, debug
     * information is also printed to this stream.
     * @param stderrSink Output stream to which filter's error outputs are to
     * be written. If <code>null</code>, <code>System.err</code> is used by
     * default.
     *
     * @throws IllegalArgumentException If required parameters are missing,
     * invalid parameters are encountered, or data required for optional
     * parameters is missing.
     * @throws CreateException If there is already an instance of 
     * BranchSequenceFilter created which has not been destroyed (see
     * {@link sofya.inst.Filter#destroy}).
     */
    public BranchSequenceFilter(String className, String[] subjectArgs,
            String subjectCP, int typeFlags, int port, boolean pipeInput,
            int timeLimit, boolean appendToTrace, String trName,
            OutputStream subjectSink, OutputStream stdoutSink,
            OutputStream stderrSink)
            throws IllegalArgumentException, CreateException {
        super(className, subjectArgs, subjectCP, typeFlags, port, pipeInput,
              timeLimit, appendToTrace, trName, subjectSink, stdoutSink,
              stderrSink);
    }
    
    public void run() {
        try {
            if (!subjectIsFilter) {
                if (DEBUG) stdoutStream.println("runNormal");
                runNormal();
            }
            else {
                if (DEBUG) stdoutStream.println("runSynchronized");
                runSynchronized();
            }
        }
        catch (Exception e) {  // Will catch any runtime exceptions
            storedException = e;
            if (subjectIsFilter) {
                synchronized(timeLock) {
                    threadConnected[threadID] = false;
                    timeLock.notify();
                }
            }
        }
    }
    
    protected void runNormal() {
        Socket connection = null;
        DataInputStream connectionIn = null;
        StreamTokenizer stok = null;
        int maxBranchId, branchID;
        
        try {
            connection = serverSocket.accept();
            // The fact that a socket is being opened means we know the
            // subject is instrumented
            isInstrumented = true;
            // The handshake currently consists of validating the
            // instrumentation type.
            if (DEBUG) stdoutStream.println("Performing handshake");
            try {
                doHandshake(connection);
            }
            catch (ExecException e) {
                if (DEBUG) {
                    stdoutStream.println("Handshake failed: subject refused");
                }
                storedException = e;
                stopServer();
                return;
            }
            connectionIn = new DataInputStream(
                new BufferedInputStream(connection.getInputStream()));
            threadConnected[threadID] = true;
        }
        catch (IOException e) {
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            storedException = e;
            stderrStream.println("Error accepting instrumentation connection!");
            stopServer();
            return;
        }

        byte[] buffer = new byte[1024];
        while (!forceStop) {
            try {
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message. Sequence filter
                    // just consumes it since it doesn't need to know
                    // the block count for the method
                    parseMethodSignature(connectionIn, buffer);
                    maxBranchId = connectionIn.readInt();
                    if (DEBUG) {
                        stdoutStream.println("Received create trace " +
                            "message for: " + classMethodName);
                    }
                    continue;
                }

                // Check timestamp flag
                if (connectionIn.readByte() == 1) {
                    connectionIn.readLong();  // Eat it
                }
                
                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);
                if (DEBUG) {
                    stdoutStream.println("Received signature: " +
                        classMethodName);
                }

                // Now read and mark each block
                int dataLength = connectionIn.readInt();  // Number of branches
                for (int i = 0; i < dataLength; i++) {
                    branchID = connectionIn.readInt();
                    int edgeType = branchID >>> 26;
                    branchID &= 0x03FFFFFF;
                    if (DEBUG) {
                        stdoutStream.println("Recording branch ID=" + branchID +
                            ", type=" + edgeType);
                    }
                    switch (edgeType) {
                    case BranchType.IIF:
                        if ((typeFlags & BranchType.MASK_IF)
                                == BranchType.MASK_IF) {
                            pw.println(classMethodName + " " +  branchID);
                        }
                        break;
                    case BranchType.ISWITCH:
                        if ((typeFlags & BranchType.MASK_SWITCH) 
                                == BranchType.MASK_SWITCH) {
                            pw.println(classMethodName + " " +  branchID);
                        }
                        break;
                    case BranchType.ITHROW:
                        if ((typeFlags & BranchType.MASK_THROW)
                                == BranchType.MASK_THROW) {
                            pw.println(classMethodName + " " +  branchID);
                        }
                        break;
                    case BranchType.ICALL:
                        if ((typeFlags & BranchType.MASK_CALL)
                                == BranchType.MASK_CALL) {
                            pw.println(classMethodName + " " +  branchID);
                        }
                        break;
                    case BranchType.IENTRY:
                        if ((typeFlags & BranchType.MASK_ENTRY)
                                == BranchType.MASK_ENTRY) {
                            pw.println(classMethodName + " " +  branchID);
                        }
                        break;
                    case BranchType.IOTHER:
                        if ((typeFlags & BranchType.MASK_OTHER)
                                == BranchType.MASK_OTHER) {
                            pw.println(classMethodName + " " +  branchID);
                        }
                        break;
                    default:
                        storedException = new ExecException("Invalid branch type code " +
                            "received from instrumented\nclass");
                        break;
                    }
                    
                    if (pw.checkError()) {
                        storedException = new TraceFileException("Error " +
                            "writing to trace file");
                        break;
                    }
                }
            }
            catch (EOFException e) {
                break;
            }
            catch (Exception e) {
                storedException = e;
                break;
            }
            
            // For non-preemptive JVMs
            if (NO_PREEMPT) {
                Thread.currentThread().yield();
            }
        }
       
        if (DEBUG) stdoutStream.println("Filter loop exited");
        
        threadConnected[threadID] = false;
        try {
            connectionIn.close();
            connection.close();
        }
        catch (IOException e) { }

        stopServer();
    }
    
    protected void runSynchronized() {
        Socket connection = null;
        Socket signalSocket = null;
        DataInputStream connectionIn = null;
        DataInputStream signalIn = null;
        DataOutputStream signalOut = null;
        long timeStamp = 0;
        int maxBranchId, branchID;
    
        try {
            // Make sure server socket does not try to accept two connections
            // simultaneously. This is probably unnecessary, but erring on the
            // side of caution.
            synchronized(connectLock) {
                connection = serverSocket.accept();
                isInstrumented = true;
            }
            // The handshake currently consists of validating the
            // instrumentation type.
            int instMode = -1;
            try {
                instMode = doHandshake(connection);
            }
            catch (ExecException e) {
                storedException = e;
                stopServer();
                return;
            }
            connectionIn = new DataInputStream(
                new BufferedInputStream(connection.getInputStream()));
            // Connect the signal socket
            if (instMode == INST_COMPATIBLE) {
                signalSocket = openSignalSocket(connection);
                signalIn = new DataInputStream(signalSocket.getInputStream());
                signalOut =
                    new DataOutputStream(signalSocket.getOutputStream());
            }
            // Indicate that this thread is now connected and processing.
            synchronized(flagLock) {
                threadConnected[threadID] = true;
            }
        }
        catch (IOException e) {
            // This may happen if either a filter or SocketProbe was
            // instrumented but not the other. Thus it is considered part of
            // orderly shutdown.
            if (e.getMessage().toLowerCase().startsWith("socket closed")) {
                return;
            }
            storedException = e;
            stderrStream.println("Error accepting instrumentation connection!");
            stopServer();
            return;
        }
        
        byte[] buffer = new byte[1024];
        runLoop:
        while (!forceStop
                && (filter[(threadID + 1) % 2].storedException == null)) {
            try {
                // If we're about to block reading, notify the other thread so
                // it can continue processing (its trace message must be oldest
                // at this point).
                synchronized(timeLock) {
                    if (!(connectionIn.available() > 0)
                            && threadConnected[(threadID + 1) % 2]) {
                        try {
                            // Force a synchronization with the subject. By
                            // requiring a response, we ensure that  any old
                            // messages still waiting from being blocked when
                            // the socket buffer became full will be written
                            // before we decide whether to grant the the other
                            // thread permission to begin processing.
                            signalOut.writeInt(SIG_ECHO);
                            signalOut.flush();
                            signalIn.readInt();
                        }
                        catch (IOException e) {
                            // If this fails, socket has been closed on other
                            // end
                            break runLoop;
                        }
                    }
                    // Continue to check for new messages until we are signaled
                    // to stop, the subject terminates (closes the socket), or
                    // the other thread finishes processing (at which point this
                    // thread continues to run as if it were a regular
                    // unsynchronized processing thread).
                    while (!(connectionIn.available() > 0)
                            && threadConnected[(threadID + 1) % 2]) {
                        if (forceStop) break runLoop;
                        // Since ready() returns false both when there is no
                        // data to be read and when the socket is closed, the
                        // only way to determine whether the subject has
                        // terminated is to actually attempt to write something
                        // to its control socket. If the subject is still
                        // alive, its SocketProbe simply consumes this signal.
                        try {
                            signalOut.writeInt(SIG_CHKALIVE);
                            signalOut.flush();
                        }
                        catch (IOException e) {
                            break runLoop;
                        }
                        // Everything in the other thread's queue must be older
                        // than whatever will come here next, so let it process
                        // them as a block before checking again.
                        pendingTimeStamp = System.currentTimeMillis();
                        timeLock.notify();
                        timeLock.wait();
                    }
                }
                
                // Check message code
                if (connectionIn.readByte() == 2) {
                    // This is the trace creation message. Sequence filter
                    // just consumes it since it doesn't need to know
                    // the block count for the method
                    parseMethodSignature(connectionIn, buffer);
                    maxBranchId = connectionIn.readInt();
                }

                // Read timestamp, we may block here
                if (connectionIn.readByte() == 1) {
                    timeStamp = connectionIn.readLong();
                }
                else {
                    storedException = new ExecException("Malformed trace " +
                        "message: timestamp was not provided");
                    break;
                }
            
                // Now check the timestamp against the last one the other thread
                // blocked on. If ours is larger (the trace message is more
                // recent), sleep and allow the other thread to process and
                // register its message. Otherwise, continue processing trace
                // messages until we get one that is younger than the one
                // currently held by the other thread. This check is not
                // performed at all if the other thread is determined to be
                // unconnected.
                synchronized(timeLock) {
                    if ((timeStamp >= pendingTimeStamp)
                            && threadConnected[(threadID + 1) % 2]) {
                        pendingTimeStamp = timeStamp;
                        try {
                            timeLock.notify();
                            timeLock.wait();
                        }
                        catch (InterruptedException e) {
                            storedException = new ExecException(
                                "SequenceFilter thread " + threadID +
                                "was interrupted!");
                            break;
                        }
                    }
                    if (DEBUG) {
                        stdoutStream.println("Thread " + threadID +
                            " processing message, timestamp: " + timeStamp);
                    }
                }
            
                // Read the method signature information
                parseMethodSignature(connectionIn, buffer);
                
                // Now mark the block
                int dataLength = connectionIn.readInt();  // Number of branches
                if (dataLength > 0) {
                    synchronized(traceLock) {
                        branchID = connectionIn.readInt();
                        int edgeType = branchID >>> 26;
                        branchID &= 0x03FFFFFF;
                        switch (edgeType) {
                        case BranchType.IIF:
                            if ((typeFlags & BranchType.MASK_IF)
                                    == BranchType.MASK_IF) {
                                pw.println(classMethodName + " " +  branchID);
                            }
                            break;
                        case BranchType.ISWITCH:
                            if ((typeFlags & BranchType.MASK_SWITCH) 
                                    == BranchType.MASK_SWITCH) {
                                pw.println(classMethodName + " " +  branchID);
                            }
                            break;
                        case BranchType.ITHROW:
                            if ((typeFlags & BranchType.MASK_THROW)
                                    == BranchType.MASK_THROW) {
                                pw.println(classMethodName + " " +  branchID);
                            }
                            break;
                        case BranchType.ICALL:
                            if ((typeFlags & BranchType.MASK_CALL)
                                    == BranchType.MASK_CALL) {
                                pw.println(classMethodName + " " +  branchID);
                            }
                            break;
                        case BranchType.IENTRY:
                            if ((typeFlags & BranchType.MASK_ENTRY)
                                    == BranchType.MASK_ENTRY) {
                                pw.println(classMethodName + " " +  branchID);
                            }
                            break;
                        case BranchType.IOTHER:
                            if ((typeFlags & BranchType.MASK_OTHER)
                                    == BranchType.MASK_OTHER) {
                                pw.println(classMethodName + " " +  branchID);
                        }
                        break;
                        default:
                            storedException = new ExecException("Invalid " +
                                "branch type code received from " +
                                "instrumented\nclass");
                            break;
                        }
                        
                        if (pw.checkError()) {
                            storedException = new TraceFileException("Error " +
                                "writing to trace file");
                            break;
                        }
                        
                        if (dataLength > 1) {
                            stderrStream.println("WARNING: Multiple branch " +
                                "IDs encoded in trace message, only the " +
                                "first will be recorded");
                            // Now eat the rest (so the input stream is still
                            // in synch)
                            for (int i = 0; i < dataLength - 1; i++) {
                                connectionIn.readInt();
                            }
                        }
                    }
                }
                else {
                    stderrStream.println("WARNING: No branch ID encoded in " +
                        "trace message");
                }
            }
            catch (EOFException e) {
                break;
            }
            catch (SocketException e) {
                if (!e.getMessage().toLowerCase()
                        .startsWith("connection reset")) {
                    storedException = e;
                }
                break;
            }
            catch (InterruptedException e) {
                storedException = new ExecException("Unrecoverable " +
                    "interrupt received by thread " + threadID);
                break;
            }
            catch (Exception e) {
                storedException = e;
                break;
            }

            // For non-preemptive JVMs
            if (NO_PREEMPT) {
                Thread.currentThread().yield();
            }
        }
       
        if (DEBUG) stdoutStream.println("Filter loop exited");
        
        try {
            signalOut.close();
            signalIn.close();
            signalSocket.close();
            connectionIn.close();
            connection.close();
        }
        catch (IOException e) { }

        // Set this thread's flag to indicate that it has finished processing
        // and retrieve the flag containing the other thread's state.
        boolean otherConnected;
        synchronized(flagLock) {
            threadConnected[threadID] = false;
            otherConnected = threadConnected[(threadID + 1) % 2];
        }
        
        // If the other thread is still connected, notify it to continue
        // processing. With this thread's connected flag set to false, the
        // other thread will continue to process until completion without
        // blocking. If the other thread is not still connected, we are
        // completely finished, so stop the server socket.
        if (otherConnected) {
            if (DEBUG) stdoutStream.println(threadID + " notifying");
            synchronized(timeLock) {
                timeLock.notify();
            }
        }
        else {
            if (DEBUG) stdoutStream.println(threadID + " shutting down");
            stopServer();
        }
    }

    protected int doHandshake(Socket msgSocket)
                  throws IOException, ExecException {
        DataInputStream in = new DataInputStream(msgSocket.getInputStream());
        DataOutputStream out =
            new DataOutputStream(msgSocket.getOutputStream());
        
        // Check if the trace objects are basic blocks
        TraceObjectType objectType = TraceObjectType.fromInt(in.readInt());
        if (objectType != TraceObjectType.BRANCH_EDGE) {
            out.writeInt(1);  // Error code
            out.flush();
            throw new ExecException("Subject is not instrumented for branch " +
                "tracing");
        }
        // Success code
        out.writeInt(0);
        out.flush();

        // Check if the declared type of instrumentation is one we can handle
        int instMode = in.readInt();
        switch (instMode) {
            case INST_COMPATIBLE:
                // Compatible-mode instrumentation is always okay
                out.writeInt(0);
                out.flush();
                break;
            case INST_OPT_NORMAL:
                // Regular-mode-optimized is never okay
                out.writeInt(1);  // Error code
                out.flush();
                throw new ExecException("Subject is not instrumented for " +
                    "sequence traces!");
            case INST_OPT_SEQUENCE:
                if (subjectIsFilter) {
                    // Optimized-sequence-mode instrumentation will not work
                    // on filter-as-subject
                    out.writeInt(1);
                    out.flush();
                    throw new ExecException("Cannot use optimized sequence " +
                        "filter instrumentation when the subject is another " +
                        "filter!");
                }
                else {
                    // Other subjects are fine
                    out.writeInt(0);
                    out.flush();
                }
                break;
            case INST_OLD_UNSUPPORTED:
                out.writeInt(1);  // Error code
                out.flush();
                throw new ExecException("Subject instrumentation is of old " +
                    "form that is no longer supported");
            default:
                // Don't know what kind of instrumentation it is
                out.writeInt(1);
                out.flush();
                throw new ExecException("Subject is not instrumented for " +
                    "sequence traces!");
        }
        return instMode;
    }

    public void runFilter()
                throws SetupException, ExecException, TraceFileException {
        if (!instanceReady) {
            throw new ExecException("BranchSequenceFilter is no longer " +
                "runnable, a new instance must be created");
        }

        try {
            setup();
            if (relayToSocket) {
                if (relaySocket == null) {
                    try {
                        relaySocket = new Socket(relaySocketAddr,
                                                 relaySocketPort);
                        pw = new PrintWriter(
                             new BufferedWriter(
                             new OutputStreamWriter(
                                 relaySocket.getOutputStream())));
                    }
                    catch (Exception e) {
                        e.printStackTrace(stderrStream);
                        throw new TraceFileException("Could not create " +
                            "relay socket");
                    }
                    if (DEBUG) stdoutStream.println("Relay socket connected");
                }
            }
            else {
                try {
                    pw = new PrintWriter(
                         new BufferedWriter(
                         new OutputStreamWriter(Handler.openOutputFile(
                             trName + ".seq", null, appendToTrace))));
                }
                catch (Exception e) {
                    e.printStackTrace(stderrStream);
                    throw new TraceFileException("Could not create trace file");
                }
                if (DEBUG) stdoutStream.println("Sequence trace file opened");
            }
            
            if (preData != null) {
                pw.print(preData);
                if (pw.checkError()) {
                    throw new TraceFileException("Error writing pre-trace " +
                        "data");
                }
            }
            
            runSubject();
            
            Exception e = filter[0].storedException;
            if ((e == null) && (filter[1] != null)) {
                e = filter[1].storedException;
            }
            if (e != null) {
                if (e instanceof ExecException) {
                    throw (ExecException) e;
                }
                else {
                    e.printStackTrace(stderrStream);
                    throw new ExecException("Error during trace processing");
                }
            }
            
            if (!isInstrumented) {
                throw new ExecException("Class is not instrumented");
            }
        }
        finally {
            if (pw != null) {
                if (postData != null) {
                    pw.print(postData + "\n");
                }
                pw.print("\n");
                pw.flush();  // JLaw, 1/21/2004: Why? Paranoia. Raging paranoia.
                pw.close();
                if (DEBUG) {
                    stdoutStream.println("Post data written and trace file " +
                        "closed");
                }
            }
            if (DEBUG) stdoutStream.println("Cleaning up");
            cleanup();
            if ((pw != null) && pw.checkError()) {
                throw new TraceFileException("Error writing finishing data " +
                    "to trace");
            }
        }
    }

    protected ProgramFilter newInstance() {
        return new BranchSequenceFilter();
    }
    
    /**
     * <b>BranchSequenceFilter ignores calls to this method</b>.
     *
     * <p>BranchSequenceFilter writes trace files progressively as trace
     * information is received.</p>
     */
    protected void writeTraceFile() { }
    
    protected boolean parseTypeCodes(String typeCodes) {
        boolean typesSet = false;
        for (int j = 1; j < typeCodes.length(); j++) {
            switch(typeCodes.charAt(j)) {
            case 'I':
                typeFlags |= BranchType.MASK_IF;
                break;
            case 'S':
                typeFlags |= BranchType.MASK_SWITCH;
                break;
            case 'T':
                typeFlags |= BranchType.MASK_THROW;
                break;
            case 'C':
                typeFlags |= BranchType.MASK_CALL;
                break;
            case 'E':
                typeFlags |= BranchType.MASK_ENTRY;
                break;
            case 'O':
                typeFlags |= BranchType.MASK_OTHER;
                break;
            default:
                throw new IllegalArgumentException("Invalid trace type");
            }
            typesSet = true;
        }
        return typesSet;
    }
    
    public void setTypeFlags(int typeFlags) throws IllegalArgumentException,
                                                   IllegalStateException {
        if (this.typeFlags != typeFlags) {
            checkRunning("Cannot change trace type while filter is running");
        }
        super.setTypeFlags(typeFlags, TraceObjectType.BRANCH_EDGE);
    }

    public boolean isTypeIfs() {
        return super.isTypeIfs();
    }
    
    public void setTypeIfs(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeIfs(enable);
    }

    public boolean isTypeSwitches() {
        return super.isTypeSwitches();
    }
    
    public void setTypeSwitches(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeSwitches(enable);
    }
    
    public boolean isTypeThrows() {
        return super.isTypeThrows();
    }
    
    public void setTypeThrows(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeThrows(enable);
    }

    public boolean isTypeCalls() {
        return super.isTypeCalls();
    }
    
    public void setTypeCalls(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeCalls(enable);
    }
    
    public boolean isTypeEntries() {
        return super.isTypeEntries();
    }
    
    public void setTypeEntries(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeEntries(enable);
    }

    public boolean isTypeOthers() {
        return super.isTypeOthers();
    }
    
    public void setTypeOthers(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change trace type while filter is running");
        super.setTypeOthers(enable);
    }

    /*************************************************************************
     * Prints the BranchSequenceFilter usage message and exits.
     */
    private static void printUsage() {
        stderrStream.println("Usage:\njava sofya.inst.BranchSequenceFilter " +
            "[-port N] [-cp PATH] [-i] [-tl N] [-at]\n [-trname <TraceName>] " +
            "[-o OutputFile] [-relay] [-pre <data>] [-post <data>]\n" +
            " -<I|S|T|C|E|O> <classfileName> <arguments>");
        stderrStream.println("   -port <N> : Listen for subject trace " +
            "statements on port number N");
        stderrStream.println("   -cp <PATH> : Set CLASSPATH for subject to " +
            "PATH");
        stderrStream.println("   -i : Enable piping of stdin to the subject");
        stderrStream.println("   -tl <N> : Kill subject after N seconds");
        stderrStream.println("   -at : Append current trace to any existing " +
            "trace file");
        stderrStream.println("   -trname <TraceName> : Set trace file name " +
            "to <TraceName> (no extension)");
        stderrStream.println("   -o <OutputFile> : Redirect subject's output " +
            "to <OutputFile>");
        stderrStream.println("   -relay : Relay processed trace data to " +
            "socket (DAG builder)");
        stderrStream.println("   -pre <data> : Prepend <data> to trace");
        stderrStream.println("   -post <data> : Append <data> to trace");
        stderrStream.println("   -<I|S|T|C|E|O> : Any permutation of the " +
            "following : I-Ifs,S-Switches,T-Throws\n                        " +
            "C-Calls,E-Entries,O-Others");
        System.exit(1);
    }

    /*************************************************************************
     * The entry point for BranchSequenceFilter, creates the
     * BranchSequenceFilter object and runs it.
     */
    public static void main(String[] argv) {
        try {
            BranchSequenceFilter bsf =
                new BranchSequenceFilter(argv, System.out, System.out,
                                         System.err);
            bsf.runFilter();
            // Necessary only to ensure the relay socket gets closed
            // if it was created
            bsf.destroy();
        }
        catch (IllegalArgumentException e) {
            stderrStream.println(e.getMessage());
            printUsage();
        }
        catch (Filter.CreateException e) {
            stderrStream.println("Error creating filter: " + e.getMessage());
            System.exit(1);
        }
        catch (Filter.SetupException e) {
            stderrStream.println("Error during initialization: " +
                e.getMessage());
            System.exit(1);
        }
        catch (Filter.ExecException e) {
            stderrStream.println("Error executing subject: " + e.getMessage());
            System.exit(1);
        }
        catch (Filter.TraceFileException e) {
            stderrStream.println("Error writing trace file: " + e.getMessage());
            System.exit(1);
        }
        catch (Exception e) {
            e.printStackTrace();
            stderrStream.println("Unrecoverable exception was thrown!");
            System.exit(1);
        }
    }
}
/*****************************************************************************/
 
/* $Log: BranchSequenceFilter.java,v $
/* Revision 1.2  2005/06/06 18:47:47  kinneer
/* Minor revisions and added copyright notices.
/*
/* Revision 1.1.1.1  2005/01/06 17:34:16  kinneer
/* Sofya Java Bytecode Instrumentation and Analysis System
/*
/* Revision 1.2  2004/06/04 21:05:32  kinneer
/* Removed invalid CVS log info.
/*
/* Revision 1.1  2004/06/02 19:24:13  kinneer
/* New class to collect sequence traces from branch instrumentation.
*/
