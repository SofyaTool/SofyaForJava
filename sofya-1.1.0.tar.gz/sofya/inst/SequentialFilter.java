/*
 * Copyright (c) 2003-2005 Alex Kinneer. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package sofya.inst;

import java.io.*;
import java.net.*;
import java.util.List;
import java.util.ListIterator;

/**
 * Abstract base class of all classes which generate sequence traces
 * from an instrumented subject.
 *
 * <p>Sequence trace specific options, configuration, and data structures
 * are found in this class.</p>
 *
 * @author Alex Kinneer
 * @version 05/19/2004
 */
public abstract class SequentialFilter extends ProgramFilter {
    /** Socket to which processed trace information should be relayed. */
    protected static Socket relaySocket = null;
    /** Machine address to which the relay socket will attempt to connect. */
    protected static final String relaySocketAddr = "127.0.0.1";
    /** Port to which the relay socket will attempt to connect. */
    protected static final int relaySocketPort = 9288;

    /** String containing data to be recorded prior to trace data. */
    protected static String preData = null;
    /** String containing data to be recorded after processing of trace data. */
    protected static String postData = null;
    /** Flag which controls whether processed trace data is relayed to another
        socket or written to a file. */
    protected static boolean relayToSocket = false;

    /** Writer for sequence output file. */
    protected static PrintWriter pw;
    /** Last timestamp that forced a synchronization, used when subject is
        Filter. */
    protected static volatile long pendingTimeStamp = 0;
    /** Synchronizes access to <code>pendingTimeStamp</code> and controls
        notifications between threads. */
    protected static Object timeLock = new Object();

    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter()}.
     */
    protected SequentialFilter() {
        super();
    }
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter(
     * java.lang.String[],java.io.OutputStream,java.io.OutputStream,
     * java.io.OutputStream)}.
     */
    public SequentialFilter(String[] argv, OutputStream subjectSink,
                            OutputStream stdoutSink, OutputStream stderrSink)
                            throws IllegalArgumentException, CreateException {
        super(argv, subjectSink, stdoutSink, stderrSink);
    }
    
    /*************************************************************************
     * <b>See</b> {@link sofya.inst.ProgramFilter#ProgramFilter(
     * java.lang.String,java.lang.String[],java.lang.String,int,int,boolean,
     * int,boolean,java.lang.String,java.io.OutputStream,java.io.OutputStream,
     * java.io.OutputStream)}.
     */
    public SequentialFilter(String className, String[] subjectArgs, 
                            String subjectCP, int typeFlags, int port,
                            boolean pipeInput, int timeLimit,
                            boolean appendToTrace, String trName,
                            OutputStream subjectSink, OutputStream stdoutSink,
                            OutputStream stderrSink)
                            throws IllegalArgumentException, CreateException {
        super(className, subjectArgs, subjectCP, typeFlags, port,
              pipeInput, timeLimit, appendToTrace, trName,
              subjectSink, stdoutSink, stderrSink);
    }

    /*************************************************************************
     * Destroys this filter instance, making it possible to create a new
     * instance.
     *
     * <p>In addition to the actions performed by
     * {@link sofya.inst.ProgramFilter#destroy()}, this implementation
     * ensures the relay socket is closed if necessary.</p>
     *
     * <p><b>Note:</b> It may be more efficient to reconfigure an existing
     * filter using {@link SequentialFilter#configureFilter} than to destroy
     * and create a new instance.</p>
     *
     * @throws IllegalStateException If called while filter is running.
     */
    public void destroy() throws IllegalStateException {
        checkRunning("Cannot destroy running filter");
        if (relayToSocket) {
            try {
                relaySocket.close();
            }
            catch (IOException e) {
                stderrStream.println("WARNING: Attempt to close relay socket " +
                    " failed.");
            }
            relaySocket = null;
        }
        // Internal implementation clears the relayToSocket flag, so we
        // have to call it after we checked the flag
        destroy(true);
    }

    protected void destroy(boolean makeUnrunnable) {
        super.destroy(makeUnrunnable);
        pendingTimeStamp = 0;
        relayToSocket = false;
        preData = null;
        postData = null;
    }

    protected List configureFilter(List params)
                   throws IllegalArgumentException, IllegalStateException {
        for (ListIterator li = params.listIterator(); li.hasNext(); ) {
            String param = (String) li.next();
            if (param.startsWith("-")) {
                if (param.equals("-relay")) {
                    li.remove();
                    relayToSocket = true;
                }
                else if (param.equals("-pre")) {
                    li.remove();
                    if (li.hasNext()) {
                        preData = (String) li.next();
                        li.remove();
                    }
                    else {
                        throw new IllegalArgumentException("Pre-trace data not specified");
                    }
                }
                else if (param.equals("-post")) {
                    li.remove();
                    if (li.hasNext()) {
                        postData = (String) li.next();
                        li.remove();
                    }
                    else {
                        throw new IllegalArgumentException("Post-trace data not specified");
                    }
                }
            }
            else {
                break;
            }
        }
        
        return super.configureFilter(params);
    }
    
    /*************************************************************************
     * Reports whether SequenceFilter is set to relay trace information to
     * a socket.
     *
     * @return <code>true</code> if trace information will be relayed to
     * a socket, <code>false</code> otherwise.
     */
    public boolean usingRelaySocket() {
        return relayToSocket;
    }

    /*************************************************************************
     * Sets whether SequenceFilter is set to relay trace information to
     * a socket.
     *
     * @param enable <code>true</code> to specify that trace data should
     * be sent to a socket, <code>false</code> to specify that trace data
     * should be written to file.
     */
    public void useRelaySocket(boolean enable) throws IllegalStateException {
        checkRunning("Cannot change use of relay socket while filter " +
            "is running");
        relayToSocket = enable;
    }
    
    /*************************************************************************
     * Gets the data set to be inserted at the beginning of the trace.
     *
     * @return Data which will be inserted at the beginning of the trace.
     */
    public String getPreData() {
        return preData;
    }
    
    /*************************************************************************
     * Sets the data to be inserted at the beginning of the trace.
     * 
     * @param data Data which will be inserted at the beginning of the
     * trace.
     */
    public void setPreData(String data) throws IllegalStateException {
        checkRunning("Cannot change trace post-data while filter " +
            "is running");
        preData = data;
    }
    
    /*************************************************************************
     * Gets the data set to be inserted at the end of the trace.
     *
     * @return Data which will be inserted at the end of the trace.
     */
    public String getPostData() {
        return postData;
    }
    
    /*************************************************************************
     * Sets the data to be inserted at the end of the trace.
     * 
     * @param data Data which will be inserted at the end of the trace.
     */
    public void setPostData(String data) throws IllegalStateException {
        checkRunning("Cannot change trace pre-data while filter " +
            "is running");
        postData = data;
    }
}
