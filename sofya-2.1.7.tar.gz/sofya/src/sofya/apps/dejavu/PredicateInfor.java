package sofya.apps.dejavu;

import java.util.ArrayList;



public class PredicateInfor {
	int NodeID;
	ArrayList<String> HitPredInfor;
	PredicateInfor(int id, ArrayList<String> pre){
		this.NodeID=id;
		this.HitPredInfor=pre;
	}
	PredicateInfor(){
		
	}

}
